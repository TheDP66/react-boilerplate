import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/AuthenticatedRouter.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f9dec5ba"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/dharma/Work/react-boilerplate/src/routes/AuthenticatedRouter.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import Cookies from "/node_modules/.vite/deps/js-cookie.js?v=ea88deea";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=f9dec5ba"; const React = __vite__cjsImport4_react.__esModule ? __vite__cjsImport4_react.default : __vite__cjsImport4_react;
import { Navigate, Outlet, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=f16f2ff9";
import { removeAllCookies } from "/src/utils/cookies.jsx";
const AuthenticatedRouter = () => {
  _s();
  const location = useLocation();
  if (!Cookies.get("refresh_token")) {
    Cookies.set("redirect_uri", location.pathname);
    removeAllCookies();
  }
  return Cookies.get("refresh_token") ? /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/routes/AuthenticatedRouter.jsx",
    lineNumber: 13,
    columnNumber: 41
  }, this) : /* @__PURE__ */ jsxDEV(Navigate, { to: "/login" }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/routes/AuthenticatedRouter.jsx",
    lineNumber: 13,
    columnNumber: 54
  }, this);
};
_s(AuthenticatedRouter, "pkHmaVRPskBaU4tMJuJJpV42k1I=", false, function() {
  return [useLocation];
});
_c = AuthenticatedRouter;
export default AuthenticatedRouter;
var _c;
$RefreshReg$(_c, "AuthenticatedRouter");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/dharma/Work/react-boilerplate/src/routes/AuthenticatedRouter.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBYXdDOzs7Ozs7Ozs7Ozs7Ozs7OztBQWJ4QyxPQUFPQSxhQUFhO0FBQ3BCLE9BQU9DLFdBQVc7QUFDbEIsU0FBU0MsVUFBVUMsUUFBUUMsbUJBQW1CO0FBQzlDLFNBQVNDLHdCQUF3QjtBQUVqQyxNQUFNQyxzQkFBc0JBLE1BQU07QUFBQUMsS0FBQTtBQUNoQyxRQUFNQyxXQUFXSixZQUFZO0FBRTdCLE1BQUksQ0FBQ0osUUFBUVMsSUFBSSxlQUFlLEdBQUc7QUFDakNULFlBQVFVLElBQUksZ0JBQWdCRixTQUFTRyxRQUFRO0FBQzdDTixxQkFBaUI7QUFBQSxFQUNuQjtBQUVBLFNBQU9MLFFBQVFTLElBQUksZUFBZSxJQUFJLHVCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFPLElBQU0sdUJBQUMsWUFBUyxJQUFHLFlBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFxQjtBQUMxRTtBQUFFRixHQVRJRCxxQkFBbUI7QUFBQSxVQUNORixXQUFXO0FBQUE7QUFBQVEsS0FEeEJOO0FBV04sZUFBZUE7QUFBb0IsSUFBQU07QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkNvb2tpZXMiLCJSZWFjdCIsIk5hdmlnYXRlIiwiT3V0bGV0IiwidXNlTG9jYXRpb24iLCJyZW1vdmVBbGxDb29raWVzIiwiQXV0aGVudGljYXRlZFJvdXRlciIsIl9zIiwibG9jYXRpb24iLCJnZXQiLCJzZXQiLCJwYXRobmFtZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQXV0aGVudGljYXRlZFJvdXRlci5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IENvb2tpZXMgZnJvbSBcImpzLWNvb2tpZVwiO1xuaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgTmF2aWdhdGUsIE91dGxldCwgdXNlTG9jYXRpb24gfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xuaW1wb3J0IHsgcmVtb3ZlQWxsQ29va2llcyB9IGZyb20gXCIuLi91dGlscy9jb29raWVzXCI7XG5cbmNvbnN0IEF1dGhlbnRpY2F0ZWRSb3V0ZXIgPSAoKSA9PiB7XG4gIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKTtcblxuICBpZiAoIUNvb2tpZXMuZ2V0KFwicmVmcmVzaF90b2tlblwiKSkge1xuICAgIENvb2tpZXMuc2V0KFwicmVkaXJlY3RfdXJpXCIsIGxvY2F0aW9uLnBhdGhuYW1lKTtcbiAgICByZW1vdmVBbGxDb29raWVzKClcbiAgfSBcblxuICByZXR1cm4gQ29va2llcy5nZXQoXCJyZWZyZXNoX3Rva2VuXCIpID8gPE91dGxldCAvPiA6IDxOYXZpZ2F0ZSB0bz1cIi9sb2dpblwiIC8+O1xufTtcblxuZXhwb3J0IGRlZmF1bHQgQXV0aGVudGljYXRlZFJvdXRlcjtcbiJdLCJmaWxlIjoiL2hvbWUvZGhhcm1hL1dvcmsvcmVhY3QtYm9pbGVycGxhdGUvc3JjL3JvdXRlcy9BdXRoZW50aWNhdGVkUm91dGVyLmpzeCJ9