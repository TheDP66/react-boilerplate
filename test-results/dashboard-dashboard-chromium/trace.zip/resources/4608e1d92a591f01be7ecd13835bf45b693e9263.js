import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/users/Users.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f9dec5ba"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/dharma/Work/react-boilerplate/src/pages/users/Users.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=f9dec5ba"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import StickyHeader from "/src/layouts/StickyHeader.jsx";
const Users = () => {
  return /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV(StickyHeader, { title: "Users" }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/pages/users/Users.jsx",
    lineNumber: 5,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/pages/users/Users.jsx",
    lineNumber: 4,
    columnNumber: 10
  }, this);
};
_c = Users;
export default Users;
var _c;
$RefreshReg$(_c, "Users");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/dharma/Work/react-boilerplate/src/pages/users/Users.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBTU07QUFOTixPQUFPQSxvQkFBa0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDekIsT0FBT0Msa0JBQWtCO0FBRXpCLE1BQU1DLFFBQVFBLE1BQU07QUFDbEIsU0FDRSx1QkFBQyxTQUNDLGlDQUFDLGdCQUFhLE9BQU8sV0FBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUE2QixLQUQvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRUE7QUFFSjtBQUFFQyxLQU5JRDtBQVFOLGVBQWVBO0FBQU0sSUFBQUM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwiU3RpY2t5SGVhZGVyIiwiVXNlcnMiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlVzZXJzLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgU3RpY2t5SGVhZGVyIGZyb20gXCIuLi8uLi9sYXlvdXRzL1N0aWNreUhlYWRlclwiO1xuXG5jb25zdCBVc2VycyA9ICgpID0+IHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgPFN0aWNreUhlYWRlciB0aXRsZT17XCJVc2Vyc1wifSAvPlxuICAgIDwvZGl2PlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgVXNlcnM7XG4iXSwiZmlsZSI6Ii9ob21lL2RoYXJtYS9Xb3JrL3JlYWN0LWJvaWxlcnBsYXRlL3NyYy9wYWdlcy91c2Vycy9Vc2Vycy5qc3gifQ==