import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/lib/useQueryGql.jsx");import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/dharma/Work/react-boilerplate/src/lib/useQueryGql.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useQuery } from "/node_modules/.vite/deps/@apollo_client.js?v=6e4ae227";
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=f9dec5ba"; const useContext = __vite__cjsImport3_react["useContext"];
import DataContext from "/src/context/DataContext.jsx";
export const useQueryGql = (query, variables) => {
  _s();
  const {
    error,
    data,
    loading
  } = useQuery(query, {
    variables
  });
  const {
    showNotification
  } = useContext(DataContext);
  if (!loading) {
    if (error) {
      showNotification({
        type: "error",
        message: "Something went wrong!",
        description: error.message
      });
    }
  }
  return {
    error,
    data,
    loading
  };
};
_s(useQueryGql, "hWKcNxeMx9FIiBZt9PYIkqYne5Q=", false, function() {
  return [useQuery];
});
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/dharma/Work/react-boilerplate/src/lib/useQueryGql.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLFNBQVNBLGdCQUFnQjtBQUN6QixTQUFTQyxrQkFBa0I7QUFDM0IsT0FBT0MsaUJBQWlCO0FBRWpCLGFBQU1DLGNBQWNBLENBQUNDLE9BQU9DLGNBQWM7QUFBQUMsS0FBQTtBQUMvQyxRQUFNO0FBQUEsSUFBRUM7QUFBQUEsSUFBT0M7QUFBQUEsSUFBTUM7QUFBQUEsRUFBUSxJQUFJVCxTQUFTSSxPQUFPO0FBQUEsSUFBRUM7QUFBQUEsRUFBVSxDQUFDO0FBQzlELFFBQU07QUFBQSxJQUFFSztBQUFBQSxFQUFpQixJQUFJVCxXQUFXQyxXQUFXO0FBRW5ELE1BQUksQ0FBQ08sU0FBUztBQUNaLFFBQUlGLE9BQU87QUFDVEcsdUJBQWlCO0FBQUEsUUFDZkMsTUFBTTtBQUFBLFFBQ05DLFNBQVM7QUFBQSxRQUNUQyxhQUFhTixNQUFNSztBQUFBQSxNQUNyQixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFFQSxTQUFPO0FBQUEsSUFBRUw7QUFBQUEsSUFBT0M7QUFBQUEsSUFBTUM7QUFBQUEsRUFBUTtBQUNoQztBQUFFSCxHQWZXSCxhQUFXO0FBQUEsVUFDV0gsUUFBUTtBQUFBIiwibmFtZXMiOlsidXNlUXVlcnkiLCJ1c2VDb250ZXh0IiwiRGF0YUNvbnRleHQiLCJ1c2VRdWVyeUdxbCIsInF1ZXJ5IiwidmFyaWFibGVzIiwiX3MiLCJlcnJvciIsImRhdGEiLCJsb2FkaW5nIiwic2hvd05vdGlmaWNhdGlvbiIsInR5cGUiLCJtZXNzYWdlIiwiZGVzY3JpcHRpb24iXSwic291cmNlcyI6WyJ1c2VRdWVyeUdxbC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUXVlcnkgfSBmcm9tIFwiQGFwb2xsby9jbGllbnRcIjtcbmltcG9ydCB7IHVzZUNvbnRleHQgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCBEYXRhQ29udGV4dCBmcm9tIFwiLi4vY29udGV4dC9EYXRhQ29udGV4dFwiO1xuXG5leHBvcnQgY29uc3QgdXNlUXVlcnlHcWwgPSAocXVlcnksIHZhcmlhYmxlcykgPT4ge1xuICBjb25zdCB7IGVycm9yLCBkYXRhLCBsb2FkaW5nIH0gPSB1c2VRdWVyeShxdWVyeSwgeyB2YXJpYWJsZXMgfSk7XG4gIGNvbnN0IHsgc2hvd05vdGlmaWNhdGlvbiB9ID0gdXNlQ29udGV4dChEYXRhQ29udGV4dCk7XG5cbiAgaWYgKCFsb2FkaW5nKSB7XG4gICAgaWYgKGVycm9yKSB7XG4gICAgICBzaG93Tm90aWZpY2F0aW9uKHtcbiAgICAgICAgdHlwZTogXCJlcnJvclwiLFxuICAgICAgICBtZXNzYWdlOiBcIlNvbWV0aGluZyB3ZW50IHdyb25nIVwiLFxuICAgICAgICBkZXNjcmlwdGlvbjogZXJyb3IubWVzc2FnZSxcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuXG4gIHJldHVybiB7IGVycm9yLCBkYXRhLCBsb2FkaW5nIH07XG59O1xuIl0sImZpbGUiOiIvaG9tZS9kaGFybWEvV29yay9yZWFjdC1ib2lsZXJwbGF0ZS9zcmMvbGliL3VzZVF1ZXJ5R3FsLmpzeCJ9