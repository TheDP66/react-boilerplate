import {
  require_dayjs_min
} from "/node_modules/.vite/deps/chunk-GPPGD6VO.js?v=97c9eb9a";
import "/node_modules/.vite/deps/chunk-ROME4SDB.js?v=97c9eb9a";
export default require_dayjs_min();
//# sourceMappingURL=dayjs.js.map
