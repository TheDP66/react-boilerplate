import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/layouts/components/DarkModeSwitch.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f9dec5ba"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/dharma/Work/react-boilerplate/src/layouts/components/DarkModeSwitch.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Button, theme } from "/node_modules/.vite/deps/antd.js?v=26d7e361";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=f9dec5ba"; const React = __vite__cjsImport4_react.__esModule ? __vite__cjsImport4_react.default : __vite__cjsImport4_react;
import { MoonIcon } from "/src/assets/svg/moonSvg.jsx";
import { SunIcon } from "/src/assets/svg/sunSvg.jsx";
import { useDispatch, useSelector } from "/node_modules/.vite/deps/react-redux.js?v=3db4bc54";
import { toggleDarkMode } from "/src/redux/actions/appAction.jsx";
const {
  useToken
} = theme;
const DarkModeSwitch = () => {
  _s();
  const dispatch = useDispatch();
  const {
    app
  } = useSelector((state) => state);
  const {
    token
  } = useToken();
  return /* @__PURE__ */ jsxDEV("div", { style: {
    backgroundColor: token.colorBgLayout,
    display: "flex",
    borderRadius: "6px",
    padding: "3px",
    gap: "2px"
  }, children: [
    /* @__PURE__ */ jsxDEV(Button, { icon: /* @__PURE__ */ jsxDEV(SunIcon, { stroke: app.darkMode ? "rgba(255,255,255,1)" : "rgba(0,0,0,.8)", style: {
      opacity: app.darkMode ? 0.5 : 1
    } }, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/DarkModeSwitch.jsx",
      lineNumber: 27,
      columnNumber: 21
    }, this), type: "primary", size: "middle", style: {
      backgroundColor: app.darkMode ? token.colorBgLayout : token.colorBgElevated,
      boxShadow: app.darkMode ? "none" : "0 2px 0 rgba(60, 80, 250, 0.1)",
      zIndex: app.darkMode ? 1 : 2
    }, onClick: () => dispatch(toggleDarkMode(false)) }, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/DarkModeSwitch.jsx",
      lineNumber: 27,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Button, { icon: /* @__PURE__ */ jsxDEV(MoonIcon, { stroke: app.darkMode ? "rgba(255, 255, 255, 0.8)" : token.colorTextSecondary, style: {
      opacity: app.darkMode ? 1 : 0.5
    } }, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/DarkModeSwitch.jsx",
      lineNumber: 34,
      columnNumber: 21
    }, this), type: "primary", size: "middle", style: {
      backgroundColor: app.darkMode ? token.colorBgContainer : token.colorBgLayout,
      boxShadow: app.darkMode ? "0 2px 0 rgba(60, 80, 250, 0.1)" : "none",
      zIndex: app.darkMode ? 2 : 1
    }, onClick: () => dispatch(toggleDarkMode(true)) }, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/DarkModeSwitch.jsx",
      lineNumber: 34,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/DarkModeSwitch.jsx",
    lineNumber: 20,
    columnNumber: 10
  }, this);
};
_s(DarkModeSwitch, "bMfaq9vhUSa3V1SuPqqx/ltWHu0=", false, function() {
  return [useDispatch, useSelector, useToken];
});
_c = DarkModeSwitch;
export default DarkModeSwitch;
var _c;
$RefreshReg$(_c, "DarkModeSwitch");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/dharma/Work/react-boilerplate/src/layouts/components/DarkModeSwitch.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMEJVOzs7Ozs7Ozs7Ozs7Ozs7OztBQTFCVixTQUFTQSxRQUFRQyxhQUFhO0FBQzlCLE9BQU9DLFdBQVc7QUFDbEIsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLGVBQWU7QUFDeEIsU0FBU0MsYUFBYUMsbUJBQW1CO0FBQ3pDLFNBQVNDLHNCQUFzQjtBQUUvQixNQUFNO0FBQUEsRUFBRUM7QUFBUyxJQUFJUDtBQUVyQixNQUFNUSxpQkFBaUJBLE1BQU07QUFBQUMsS0FBQTtBQUMzQixRQUFNQyxXQUFXTixZQUFZO0FBQzdCLFFBQU07QUFBQSxJQUFFTztBQUFBQSxFQUFJLElBQUlOLFlBQWFPLFdBQVVBLEtBQUs7QUFDNUMsUUFBTTtBQUFBLElBQUVDO0FBQUFBLEVBQU0sSUFBSU4sU0FBUztBQUUzQixTQUNFLHVCQUFDLFNBQ0MsT0FBTztBQUFBLElBQ0xPLGlCQUFpQkQsTUFBTUU7QUFBQUEsSUFDdkJDLFNBQVM7QUFBQSxJQUNUQyxjQUFjO0FBQUEsSUFDZEMsU0FBUztBQUFBLElBQ1RDLEtBQUs7QUFBQSxFQUNQLEdBRUE7QUFBQSwyQkFBQyxVQUNDLE1BQ0UsdUJBQUMsV0FDQyxRQUFRUixJQUFJUyxXQUFXLHdCQUF3QixrQkFDL0MsT0FBTztBQUFBLE1BQ0xDLFNBQVNWLElBQUlTLFdBQVcsTUFBTTtBQUFBLElBQ2hDLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlJLEdBR04sTUFBSyxXQUNMLE1BQUssVUFDTCxPQUFPO0FBQUEsTUFDTE4saUJBQWlCSCxJQUFJUyxXQUNqQlAsTUFBTUUsZ0JBQ05GLE1BQU1TO0FBQUFBLE1BQ1ZDLFdBQVdaLElBQUlTLFdBQVcsU0FBUztBQUFBLE1BQ25DSSxRQUFRYixJQUFJUyxXQUFXLElBQUk7QUFBQSxJQUM3QixHQUNBLFNBQVMsTUFBTVYsU0FBU0osZUFBZSxLQUFLLENBQUMsS0FsQi9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FrQmlEO0FBQUEsSUFFakQsdUJBQUMsVUFDQyxNQUNFLHVCQUFDLFlBQ0MsUUFDRUssSUFBSVMsV0FDQSw2QkFDQVAsTUFBTVksb0JBRVosT0FBTztBQUFBLE1BQ0xKLFNBQVNWLElBQUlTLFdBQVcsSUFBSTtBQUFBLElBQzlCLEtBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFJLEdBR04sTUFBSyxXQUNMLE1BQUssVUFDTCxPQUFPO0FBQUEsTUFDTE4saUJBQWlCSCxJQUFJUyxXQUNqQlAsTUFBTWEsbUJBQ05iLE1BQU1FO0FBQUFBLE1BQ1ZRLFdBQVdaLElBQUlTLFdBQVcsbUNBQW1DO0FBQUEsTUFDN0RJLFFBQVFiLElBQUlTLFdBQVcsSUFBSTtBQUFBLElBQzdCLEdBQ0EsU0FBUyxNQUFNVixTQUFTSixlQUFlLElBQUksQ0FBQyxLQXRCOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXNCZ0Q7QUFBQSxPQW5EbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXFEQTtBQUVKO0FBQUVHLEdBN0RJRCxnQkFBYztBQUFBLFVBQ0RKLGFBQ0RDLGFBQ0VFLFFBQVE7QUFBQTtBQUFBb0IsS0FIdEJuQjtBQStETixlQUFlQTtBQUFlLElBQUFtQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiQnV0dG9uIiwidGhlbWUiLCJSZWFjdCIsIk1vb25JY29uIiwiU3VuSWNvbiIsInVzZURpc3BhdGNoIiwidXNlU2VsZWN0b3IiLCJ0b2dnbGVEYXJrTW9kZSIsInVzZVRva2VuIiwiRGFya01vZGVTd2l0Y2giLCJfcyIsImRpc3BhdGNoIiwiYXBwIiwic3RhdGUiLCJ0b2tlbiIsImJhY2tncm91bmRDb2xvciIsImNvbG9yQmdMYXlvdXQiLCJkaXNwbGF5IiwiYm9yZGVyUmFkaXVzIiwicGFkZGluZyIsImdhcCIsImRhcmtNb2RlIiwib3BhY2l0eSIsImNvbG9yQmdFbGV2YXRlZCIsImJveFNoYWRvdyIsInpJbmRleCIsImNvbG9yVGV4dFNlY29uZGFyeSIsImNvbG9yQmdDb250YWluZXIiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkRhcmtNb2RlU3dpdGNoLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBCdXR0b24sIHRoZW1lIH0gZnJvbSBcImFudGRcIjtcbmltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IE1vb25JY29uIH0gZnJvbSBcIi4uLy4uL2Fzc2V0cy9zdmcvbW9vblN2Z1wiO1xuaW1wb3J0IHsgU3VuSWNvbiB9IGZyb20gXCIuLi8uLi9hc3NldHMvc3ZnL3N1blN2Z1wiO1xuaW1wb3J0IHsgdXNlRGlzcGF0Y2gsIHVzZVNlbGVjdG9yIH0gZnJvbSBcInJlYWN0LXJlZHV4XCI7XG5pbXBvcnQgeyB0b2dnbGVEYXJrTW9kZSB9IGZyb20gXCIuLi8uLi9yZWR1eC9hY3Rpb25zL2FwcEFjdGlvblwiO1xuXG5jb25zdCB7IHVzZVRva2VuIH0gPSB0aGVtZTtcblxuY29uc3QgRGFya01vZGVTd2l0Y2ggPSAoKSA9PiB7XG4gIGNvbnN0IGRpc3BhdGNoID0gdXNlRGlzcGF0Y2goKTtcbiAgY29uc3QgeyBhcHAgfSA9IHVzZVNlbGVjdG9yKChzdGF0ZSkgPT4gc3RhdGUpO1xuICBjb25zdCB7IHRva2VuIH0gPSB1c2VUb2tlbigpO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgc3R5bGU9e3tcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiB0b2tlbi5jb2xvckJnTGF5b3V0LFxuICAgICAgICBkaXNwbGF5OiBcImZsZXhcIixcbiAgICAgICAgYm9yZGVyUmFkaXVzOiBcIjZweFwiLFxuICAgICAgICBwYWRkaW5nOiBcIjNweFwiLFxuICAgICAgICBnYXA6IFwiMnB4XCIsXG4gICAgICB9fVxuICAgID5cbiAgICAgIDxCdXR0b25cbiAgICAgICAgaWNvbj17XG4gICAgICAgICAgPFN1bkljb25cbiAgICAgICAgICAgIHN0cm9rZT17YXBwLmRhcmtNb2RlID8gXCJyZ2JhKDI1NSwyNTUsMjU1LDEpXCIgOiBcInJnYmEoMCwwLDAsLjgpXCJ9XG4gICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICBvcGFjaXR5OiBhcHAuZGFya01vZGUgPyAwLjUgOiAxLFxuICAgICAgICAgICAgfX1cbiAgICAgICAgICAvPlxuICAgICAgICB9XG4gICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcbiAgICAgICAgc2l6ZT1cIm1pZGRsZVwiXG4gICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgYmFja2dyb3VuZENvbG9yOiBhcHAuZGFya01vZGVcbiAgICAgICAgICAgID8gdG9rZW4uY29sb3JCZ0xheW91dFxuICAgICAgICAgICAgOiB0b2tlbi5jb2xvckJnRWxldmF0ZWQsXG4gICAgICAgICAgYm94U2hhZG93OiBhcHAuZGFya01vZGUgPyBcIm5vbmVcIiA6IFwiMCAycHggMCByZ2JhKDYwLCA4MCwgMjUwLCAwLjEpXCIsXG4gICAgICAgICAgekluZGV4OiBhcHAuZGFya01vZGUgPyAxIDogMixcbiAgICAgICAgfX1cbiAgICAgICAgb25DbGljaz17KCkgPT4gZGlzcGF0Y2godG9nZ2xlRGFya01vZGUoZmFsc2UpKX1cbiAgICAgIC8+XG4gICAgICA8QnV0dG9uXG4gICAgICAgIGljb249e1xuICAgICAgICAgIDxNb29uSWNvblxuICAgICAgICAgICAgc3Ryb2tlPXtcbiAgICAgICAgICAgICAgYXBwLmRhcmtNb2RlXG4gICAgICAgICAgICAgICAgPyBcInJnYmEoMjU1LCAyNTUsIDI1NSwgMC44KVwiXG4gICAgICAgICAgICAgICAgOiB0b2tlbi5jb2xvclRleHRTZWNvbmRhcnlcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgIG9wYWNpdHk6IGFwcC5kYXJrTW9kZSA/IDEgOiAwLjUsXG4gICAgICAgICAgICB9fVxuICAgICAgICAgIC8+XG4gICAgICAgIH1cbiAgICAgICAgdHlwZT1cInByaW1hcnlcIlxuICAgICAgICBzaXplPVwibWlkZGxlXCJcbiAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IGFwcC5kYXJrTW9kZVxuICAgICAgICAgICAgPyB0b2tlbi5jb2xvckJnQ29udGFpbmVyXG4gICAgICAgICAgICA6IHRva2VuLmNvbG9yQmdMYXlvdXQsXG4gICAgICAgICAgYm94U2hhZG93OiBhcHAuZGFya01vZGUgPyBcIjAgMnB4IDAgcmdiYSg2MCwgODAsIDI1MCwgMC4xKVwiIDogXCJub25lXCIsXG4gICAgICAgICAgekluZGV4OiBhcHAuZGFya01vZGUgPyAyIDogMSxcbiAgICAgICAgfX1cbiAgICAgICAgb25DbGljaz17KCkgPT4gZGlzcGF0Y2godG9nZ2xlRGFya01vZGUodHJ1ZSkpfVxuICAgICAgLz5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IERhcmtNb2RlU3dpdGNoO1xuIl0sImZpbGUiOiIvaG9tZS9kaGFybWEvV29yay9yZWFjdC1ib2lsZXJwbGF0ZS9zcmMvbGF5b3V0cy9jb21wb25lbnRzL0RhcmtNb2RlU3dpdGNoLmpzeCJ9