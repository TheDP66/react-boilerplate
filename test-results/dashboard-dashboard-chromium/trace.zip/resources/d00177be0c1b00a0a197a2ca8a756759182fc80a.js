import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/layouts/components/SearchField.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f9dec5ba"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/dharma/Work/react-boilerplate/src/layouts/components/SearchField.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { SearchOutlined } from "/node_modules/.vite/deps/@ant-design_icons.js?v=7a8c6384";
import { Button, Input, List, Modal, Result } from "/node_modules/.vite/deps/antd.js?v=26d7e361";
import Fuse from "/node_modules/.vite/deps/fuse__js.js?v=52055671";
import Lottie from "/node_modules/.vite/deps/lottie-react.js?v=f06392c1";
import __vite__cjsImport7_react from "/node_modules/.vite/deps/react.js?v=f9dec5ba"; const React = __vite__cjsImport7_react.__esModule ? __vite__cjsImport7_react.default : __vite__cjsImport7_react; const useEffect = __vite__cjsImport7_react["useEffect"]; const useRef = __vite__cjsImport7_react["useRef"]; const useState = __vite__cjsImport7_react["useState"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=f16f2ff9";
import noResultAnimation from "/src/assets/lottie/no-result.json?import";
import typingAnimation from "/src/assets/lottie/typing.json?import";
import { generateAuthRoute } from "/src/utils/pages.jsx";
const SearchField = () => {
  _s();
  const navigate = useNavigate();
  const fusePage = new Fuse(generateAuthRoute(), {
    keys: ["path", "label.props.children"]
  });
  const inputRef = useRef(null);
  const [searchModal, setSearchModal] = useState(false);
  const [keyword, setKeyword] = useState("");
  const [pageResult, setPageResult] = useState([]);
  const handleOpenModal = () => {
    setSearchModal(true);
  };
  const handleSearch = (e) => {
    setKeyword(e.target.value);
    const resPage = fusePage.search(e.target.value);
    setPageResult(resPage);
  };
  const handleClickPage = (path) => {
    navigate(path);
    handleClose();
  };
  const handleClose = () => {
    setSearchModal(false);
    setKeyword("");
    setPageResult([]);
  };
  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.focus();
    }
  }, []);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(Button, { size: "middle", type: "default", icon: /* @__PURE__ */ jsxDEV(SearchOutlined, { style: {
      marginRight: "4px"
    }, onClick: handleOpenModal }, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/SearchField.jsx",
      lineNumber: 45,
      columnNumber: 50
    }, this), onClick: handleOpenModal, style: {
      marginRight: "16px",
      paddingRight: "52px",
      cursor: "pointer"
    }, children: "Search..." }, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/SearchField.jsx",
      lineNumber: 45,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Modal, { open: searchModal, onCancel: handleClose, closable: false, destroyOnClose: true, title: /* @__PURE__ */ jsxDEV(Input, { ref: inputRef, autoFocus: true, size: "large", placeholder: "Search...", prefix: /* @__PURE__ */ jsxDEV(SearchOutlined, { style: {
      marginRight: "8px"
    } }, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/SearchField.jsx",
      lineNumber: 56,
      columnNumber: 172
    }, this), style: {
      marginRight: "16px",
      cursor: "pointer"
    }, onChange: handleSearch, value: keyword }, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/SearchField.jsx",
      lineNumber: 56,
      columnNumber: 95
    }, this), footer: null, bodyStyle: {
      padding: "10px 0",
      height: "60vh",
      overflowY: "scroll"
    }, centered: true, id: "search-modal", children: keyword === "" ? /* @__PURE__ */ jsxDEV(Result, { icon: /* @__PURE__ */ jsxDEV(Lottie, { animationData: typingAnimation, loop: true, style: {
      height: "160px"
    } }, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/SearchField.jsx",
      lineNumber: 66,
      columnNumber: 41
    }, this), subTitle: "Type something to search" }, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/SearchField.jsx",
      lineNumber: 66,
      columnNumber: 27
    }, this) : pageResult.length === 0 ? /* @__PURE__ */ jsxDEV(Result, { icon: /* @__PURE__ */ jsxDEV(Lottie, { animationData: noResultAnimation, loop: true, style: {
      height: "160px"
    } }, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/SearchField.jsx",
      lineNumber: 68,
      columnNumber: 95
    }, this), subTitle: "No result found" }, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/SearchField.jsx",
      lineNumber: 68,
      columnNumber: 81
    }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("h4", { style: {
        lineHeight: "0",
        fontWeight: "600",
        opacity: 0.75
      }, children: "Pages" }, void 0, false, {
        fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/SearchField.jsx",
        lineNumber: 71,
        columnNumber: 13
      }, this),
      pageResult.map((item) => /* @__PURE__ */ jsxDEV(Fragment, { children: console.log("item", item) }, void 0, false, {
        fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/SearchField.jsx",
        lineNumber: 78,
        columnNumber: 37
      }, this)),
      /* @__PURE__ */ jsxDEV(List, { dataSource: pageResult, renderItem: (page) => /* @__PURE__ */ jsxDEV(List.Item, { onClick: () => handleClickPage(page.item.label.props.to), style: {
        cursor: "pointer"
      }, children: /* @__PURE__ */ jsxDEV(List.Item.Meta, { avatar: page.item.icon, title: page.item.label.props.children, description: page.item.description }, void 0, false, {
        fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/SearchField.jsx",
        lineNumber: 84,
        columnNumber: 19
      }, this) }, page.refIndex, false, {
        fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/SearchField.jsx",
        lineNumber: 81,
        columnNumber: 63
      }, this) }, void 0, false, {
        fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/SearchField.jsx",
        lineNumber: 81,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/SearchField.jsx",
      lineNumber: 70,
      columnNumber: 46
    }, this) }, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/SearchField.jsx",
      lineNumber: 56,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/SearchField.jsx",
    lineNumber: 43,
    columnNumber: 10
  }, this);
};
_s(SearchField, "x6btr30sSzeIsNkZVhFsG56Dybw=", false, function() {
  return [useNavigate];
});
_c = SearchField;
export default SearchField;
var _c;
$RefreshReg$(_c, "SearchField");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/dharma/Work/react-boilerplate/src/layouts/components/SearchField.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0RVLFNBc0VJLFVBdEVKOzs7Ozs7Ozs7Ozs7Ozs7OztBQXhEVixTQUFTQSxzQkFBc0I7QUFDL0IsU0FBU0MsUUFBUUMsT0FBT0MsTUFBTUMsT0FBT0MsY0FBYztBQUNuRCxPQUFPQyxVQUFVO0FBQ2pCLE9BQU9DLFlBQVk7QUFDbkIsT0FBT0MsU0FBU0MsV0FBV0MsUUFBUUMsZ0JBQWdCO0FBQ25ELFNBQVNDLG1CQUFtQjtBQUM1QixPQUFPQyx1QkFBdUI7QUFDOUIsT0FBT0MscUJBQXFCO0FBQzVCLFNBQVNDLHlCQUF5QjtBQUVsQyxNQUFNQyxjQUFjQSxNQUFNO0FBQUFDLEtBQUE7QUFDeEIsUUFBTUMsV0FBV04sWUFBWTtBQUM3QixRQUFNTyxXQUFXLElBQUliLEtBQUtTLGtCQUFrQixHQUFHO0FBQUEsSUFDN0NLLE1BQU0sQ0FBQyxRQUFRLHNCQUFzQjtBQUFBLEVBQ3ZDLENBQUM7QUFFRCxRQUFNQyxXQUFXWCxPQUFPLElBQUk7QUFDNUIsUUFBTSxDQUFDWSxhQUFhQyxjQUFjLElBQUlaLFNBQVMsS0FBSztBQUNwRCxRQUFNLENBQUNhLFNBQVNDLFVBQVUsSUFBSWQsU0FBUyxFQUFFO0FBQ3pDLFFBQU0sQ0FBQ2UsWUFBWUMsYUFBYSxJQUFJaEIsU0FBUyxFQUFFO0FBRS9DLFFBQU1pQixrQkFBa0JBLE1BQU07QUFDNUJMLG1CQUFlLElBQUk7QUFBQSxFQUNyQjtBQUVBLFFBQU1NLGVBQWdCQyxPQUFNO0FBQzFCTCxlQUFXSyxFQUFFQyxPQUFPQyxLQUFLO0FBRXpCLFVBQU1DLFVBQVVkLFNBQVNlLE9BQU9KLEVBQUVDLE9BQU9DLEtBQUs7QUFDOUNMLGtCQUFjTSxPQUFPO0FBQUEsRUFDdkI7QUFFQSxRQUFNRSxrQkFBbUJDLFVBQVM7QUFDaENsQixhQUFTa0IsSUFBSTtBQUNiQyxnQkFBWTtBQUFBLEVBQ2Q7QUFFQSxRQUFNQSxjQUFjQSxNQUFNO0FBQ3hCZCxtQkFBZSxLQUFLO0FBQ3BCRSxlQUFXLEVBQUU7QUFDYkUsa0JBQWMsRUFBRTtBQUFBLEVBQ2xCO0FBRUFsQixZQUFVLE1BQU07QUFDZCxRQUFJWSxTQUFTaUIsU0FBUztBQUNwQmpCLGVBQVNpQixRQUFRQyxNQUFNO0FBQUEsSUFDekI7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUVMLFNBQ0UsbUNBRUU7QUFBQSwyQkFBQyxVQUNDLE1BQUssVUFDTCxNQUFLLFdBQ0wsTUFDRSx1QkFBQyxrQkFDQyxPQUFPO0FBQUEsTUFBRUMsYUFBYTtBQUFBLElBQU0sR0FDNUIsU0FBU1osbUJBRlg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUUyQixHQUc3QixTQUFTQSxpQkFDVCxPQUFPO0FBQUEsTUFDTFksYUFBYTtBQUFBLE1BQ2JDLGNBQWM7QUFBQSxNQUNkQyxRQUFRO0FBQUEsSUFDVixHQUFFLHlCQWRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpQkE7QUFBQSxJQUdBLHVCQUFDLFNBQ0MsTUFBTXBCLGFBQ04sVUFBVWUsYUFDVixVQUFVLE9BQ1YsZ0JBQWMsTUFDZCxPQUNFLHVCQUFDLFNBQ0MsS0FBS2hCLFVBQ0wsV0FBUyxNQUNULE1BQUssU0FDTCxhQUFZLGFBQ1osUUFBUSx1QkFBQyxrQkFBZSxPQUFPO0FBQUEsTUFBRW1CLGFBQWE7QUFBQSxJQUFNLEtBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOEMsR0FDdEQsT0FBTztBQUFBLE1BQUVBLGFBQWE7QUFBQSxNQUFRRSxRQUFRO0FBQUEsSUFBVSxHQUNoRCxVQUFVYixjQUNWLE9BQU9MLFdBUlQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFpQixHQUduQixRQUFRLE1BQ1IsV0FBVztBQUFBLE1BQ1RtQixTQUFTO0FBQUEsTUFDVEMsUUFBUTtBQUFBLE1BQ1JDLFdBQVc7QUFBQSxJQUNiLEdBQ0EsVUFBUSxNQUNSLElBQUcsZ0JBRUZyQixzQkFBWSxLQUNYLHVCQUFDLFVBQ0MsTUFDRSx1QkFBQyxVQUNDLGVBQWVWLGlCQUNmLE1BQU0sTUFDTixPQUFPO0FBQUEsTUFBRThCLFFBQVE7QUFBQSxJQUFRLEtBSDNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHNkIsR0FHL0IsVUFBUyw4QkFSWDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUXFDLElBRW5DbEIsV0FBV29CLFdBQVcsSUFDeEIsdUJBQUMsVUFDQyxNQUNFLHVCQUFDLFVBQ0MsZUFBZWpDLG1CQUNmLE1BQU0sTUFDTixPQUFPO0FBQUEsTUFBRStCLFFBQVE7QUFBQSxJQUFRLEtBSDNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHNkIsR0FHL0IsVUFBUyxxQkFSWDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUTRCLElBRzVCLG1DQUNFO0FBQUEsNkJBQUMsUUFBRyxPQUFPO0FBQUEsUUFBRUcsWUFBWTtBQUFBLFFBQUtDLFlBQVk7QUFBQSxRQUFPQyxTQUFTO0FBQUEsTUFBSyxHQUFFLHFCQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNDdkIsV0FBV3dCLElBQUtDLFVBQ2YsbUNBQ0NDLGtCQUFRQyxJQUFJLFFBQVFGLElBQUksS0FEekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBLENBQ0Q7QUFBQSxNQUNELHVCQUFDLFFBQ0MsWUFBWXpCLFlBQ1osWUFBYTRCLFVBQ1gsdUJBQUMsS0FBSyxNQUFMLEVBRUMsU0FBUyxNQUFNbkIsZ0JBQWdCbUIsS0FBS0gsS0FBS0ksTUFBTUMsTUFBTUMsRUFBRSxHQUN2RCxPQUFPO0FBQUEsUUFBRWYsUUFBUTtBQUFBLE1BQVUsR0FFM0IsaUNBQUMsS0FBSyxLQUFLLE1BQVYsRUFDQyxRQUFRWSxLQUFLSCxLQUFLTyxNQUNsQixPQUFPSixLQUFLSCxLQUFLSSxNQUFNQyxNQUFNRyxVQUM3QixhQUFhTCxLQUFLSCxLQUFLUyxlQUh6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR3FDLEtBUGhDTixLQUFLTyxVQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVQSxLQWJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFjSTtBQUFBLFNBdkJOO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5QkEsS0ExRUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTRFQTtBQUFBLE9BbEdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtR0E7QUFFSjtBQUFFNUMsR0E3SUlELGFBQVc7QUFBQSxVQUNFSixXQUFXO0FBQUE7QUFBQWtELEtBRHhCOUM7QUErSU4sZUFBZUE7QUFBWSxJQUFBOEM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlNlYXJjaE91dGxpbmVkIiwiQnV0dG9uIiwiSW5wdXQiLCJMaXN0IiwiTW9kYWwiLCJSZXN1bHQiLCJGdXNlIiwiTG90dGllIiwiUmVhY3QiLCJ1c2VFZmZlY3QiLCJ1c2VSZWYiLCJ1c2VTdGF0ZSIsInVzZU5hdmlnYXRlIiwibm9SZXN1bHRBbmltYXRpb24iLCJ0eXBpbmdBbmltYXRpb24iLCJnZW5lcmF0ZUF1dGhSb3V0ZSIsIlNlYXJjaEZpZWxkIiwiX3MiLCJuYXZpZ2F0ZSIsImZ1c2VQYWdlIiwia2V5cyIsImlucHV0UmVmIiwic2VhcmNoTW9kYWwiLCJzZXRTZWFyY2hNb2RhbCIsImtleXdvcmQiLCJzZXRLZXl3b3JkIiwicGFnZVJlc3VsdCIsInNldFBhZ2VSZXN1bHQiLCJoYW5kbGVPcGVuTW9kYWwiLCJoYW5kbGVTZWFyY2giLCJlIiwidGFyZ2V0IiwidmFsdWUiLCJyZXNQYWdlIiwic2VhcmNoIiwiaGFuZGxlQ2xpY2tQYWdlIiwicGF0aCIsImhhbmRsZUNsb3NlIiwiY3VycmVudCIsImZvY3VzIiwibWFyZ2luUmlnaHQiLCJwYWRkaW5nUmlnaHQiLCJjdXJzb3IiLCJwYWRkaW5nIiwiaGVpZ2h0Iiwib3ZlcmZsb3dZIiwibGVuZ3RoIiwibGluZUhlaWdodCIsImZvbnRXZWlnaHQiLCJvcGFjaXR5IiwibWFwIiwiaXRlbSIsImNvbnNvbGUiLCJsb2ciLCJwYWdlIiwibGFiZWwiLCJwcm9wcyIsInRvIiwiaWNvbiIsImNoaWxkcmVuIiwiZGVzY3JpcHRpb24iLCJyZWZJbmRleCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiU2VhcmNoRmllbGQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFNlYXJjaE91dGxpbmVkIH0gZnJvbSBcIkBhbnQtZGVzaWduL2ljb25zXCI7XG5pbXBvcnQgeyBCdXR0b24sIElucHV0LCBMaXN0LCBNb2RhbCwgUmVzdWx0IH0gZnJvbSBcImFudGRcIjtcbmltcG9ydCBGdXNlIGZyb20gXCJmdXNlLmpzXCI7XG5pbXBvcnQgTG90dGllIGZyb20gXCJsb3R0aWUtcmVhY3RcIjtcbmltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcbmltcG9ydCBub1Jlc3VsdEFuaW1hdGlvbiBmcm9tIFwiLi4vLi4vYXNzZXRzL2xvdHRpZS9uby1yZXN1bHQuanNvblwiO1xuaW1wb3J0IHR5cGluZ0FuaW1hdGlvbiBmcm9tIFwiLi4vLi4vYXNzZXRzL2xvdHRpZS90eXBpbmcuanNvblwiO1xuaW1wb3J0IHsgZ2VuZXJhdGVBdXRoUm91dGUgfSBmcm9tIFwiLi4vLi4vdXRpbHMvcGFnZXNcIjtcblxuY29uc3QgU2VhcmNoRmllbGQgPSAoKSA9PiB7XG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgY29uc3QgZnVzZVBhZ2UgPSBuZXcgRnVzZShnZW5lcmF0ZUF1dGhSb3V0ZSgpLCB7XG4gICAga2V5czogW1wicGF0aFwiLCBcImxhYmVsLnByb3BzLmNoaWxkcmVuXCJdLFxuICB9KTtcblxuICBjb25zdCBpbnB1dFJlZiA9IHVzZVJlZihudWxsKTtcbiAgY29uc3QgW3NlYXJjaE1vZGFsLCBzZXRTZWFyY2hNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtrZXl3b3JkLCBzZXRLZXl3b3JkXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbcGFnZVJlc3VsdCwgc2V0UGFnZVJlc3VsdF0gPSB1c2VTdGF0ZShbXSk7XG5cbiAgY29uc3QgaGFuZGxlT3Blbk1vZGFsID0gKCkgPT4ge1xuICAgIHNldFNlYXJjaE1vZGFsKHRydWUpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVNlYXJjaCA9IChlKSA9PiB7XG4gICAgc2V0S2V5d29yZChlLnRhcmdldC52YWx1ZSk7XG5cbiAgICBjb25zdCByZXNQYWdlID0gZnVzZVBhZ2Uuc2VhcmNoKGUudGFyZ2V0LnZhbHVlKTtcbiAgICBzZXRQYWdlUmVzdWx0KHJlc1BhZ2UpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUNsaWNrUGFnZSA9IChwYXRoKSA9PiB7XG4gICAgbmF2aWdhdGUocGF0aCk7XG4gICAgaGFuZGxlQ2xvc2UoKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVDbG9zZSA9ICgpID0+IHtcbiAgICBzZXRTZWFyY2hNb2RhbChmYWxzZSk7XG4gICAgc2V0S2V5d29yZChcIlwiKTtcbiAgICBzZXRQYWdlUmVzdWx0KFtdKTtcbiAgfTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChpbnB1dFJlZi5jdXJyZW50KSB7XG4gICAgICBpbnB1dFJlZi5jdXJyZW50LmZvY3VzKCk7XG4gICAgfVxuICB9LCBbXSk7XG5cbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgey8qIFNlYWNoIEZpZWxkIG9uIFRvcCBCYXIgKi99XG4gICAgICA8QnV0dG9uXG4gICAgICAgIHNpemU9XCJtaWRkbGVcIlxuICAgICAgICB0eXBlPVwiZGVmYXVsdFwiXG4gICAgICAgIGljb249e1xuICAgICAgICAgIDxTZWFyY2hPdXRsaW5lZFxuICAgICAgICAgICAgc3R5bGU9e3sgbWFyZ2luUmlnaHQ6IFwiNHB4XCIgfX1cbiAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZU9wZW5Nb2RhbH1cbiAgICAgICAgICAvPlxuICAgICAgICB9XG4gICAgICAgIG9uQ2xpY2s9e2hhbmRsZU9wZW5Nb2RhbH1cbiAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICBtYXJnaW5SaWdodDogXCIxNnB4XCIsXG4gICAgICAgICAgcGFkZGluZ1JpZ2h0OiBcIjUycHhcIixcbiAgICAgICAgICBjdXJzb3I6IFwicG9pbnRlclwiLFxuICAgICAgICB9fVxuICAgICAgPlxuICAgICAgICBTZWFyY2guLi5cbiAgICAgIDwvQnV0dG9uPlxuXG4gICAgICB7LyogU2VhcmNoIE1vZGFsICovfVxuICAgICAgPE1vZGFsXG4gICAgICAgIG9wZW49e3NlYXJjaE1vZGFsfVxuICAgICAgICBvbkNhbmNlbD17aGFuZGxlQ2xvc2V9XG4gICAgICAgIGNsb3NhYmxlPXtmYWxzZX1cbiAgICAgICAgZGVzdHJveU9uQ2xvc2VcbiAgICAgICAgdGl0bGU9e1xuICAgICAgICAgIDxJbnB1dFxuICAgICAgICAgICAgcmVmPXtpbnB1dFJlZn1cbiAgICAgICAgICAgIGF1dG9Gb2N1c1xuICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoLi4uXCJcbiAgICAgICAgICAgIHByZWZpeD17PFNlYXJjaE91dGxpbmVkIHN0eWxlPXt7IG1hcmdpblJpZ2h0OiBcIjhweFwiIH19IC8+fVxuICAgICAgICAgICAgc3R5bGU9e3sgbWFyZ2luUmlnaHQ6IFwiMTZweFwiLCBjdXJzb3I6IFwicG9pbnRlclwiIH19XG4gICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlU2VhcmNofVxuICAgICAgICAgICAgdmFsdWU9e2tleXdvcmR9XG4gICAgICAgICAgLz5cbiAgICAgICAgfVxuICAgICAgICBmb290ZXI9e251bGx9XG4gICAgICAgIGJvZHlTdHlsZT17e1xuICAgICAgICAgIHBhZGRpbmc6IFwiMTBweCAwXCIsXG4gICAgICAgICAgaGVpZ2h0OiBcIjYwdmhcIixcbiAgICAgICAgICBvdmVyZmxvd1k6IFwic2Nyb2xsXCIsXG4gICAgICAgIH19XG4gICAgICAgIGNlbnRlcmVkXG4gICAgICAgIGlkPVwic2VhcmNoLW1vZGFsXCJcbiAgICAgID5cbiAgICAgICAge2tleXdvcmQgPT09IFwiXCIgPyAoXG4gICAgICAgICAgPFJlc3VsdFxuICAgICAgICAgICAgaWNvbj17XG4gICAgICAgICAgICAgIDxMb3R0aWVcbiAgICAgICAgICAgICAgICBhbmltYXRpb25EYXRhPXt0eXBpbmdBbmltYXRpb259XG4gICAgICAgICAgICAgICAgbG9vcD17dHJ1ZX1cbiAgICAgICAgICAgICAgICBzdHlsZT17eyBoZWlnaHQ6IFwiMTYwcHhcIiB9fVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgc3ViVGl0bGU9XCJUeXBlIHNvbWV0aGluZyB0byBzZWFyY2hcIlxuICAgICAgICAgIC8+XG4gICAgICAgICkgOiBwYWdlUmVzdWx0Lmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgICA8UmVzdWx0XG4gICAgICAgICAgICBpY29uPXtcbiAgICAgICAgICAgICAgPExvdHRpZVxuICAgICAgICAgICAgICAgIGFuaW1hdGlvbkRhdGE9e25vUmVzdWx0QW5pbWF0aW9ufVxuICAgICAgICAgICAgICAgIGxvb3A9e3RydWV9XG4gICAgICAgICAgICAgICAgc3R5bGU9e3sgaGVpZ2h0OiBcIjE2MHB4XCIgfX1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHN1YlRpdGxlPVwiTm8gcmVzdWx0IGZvdW5kXCJcbiAgICAgICAgICAvPlxuICAgICAgICApIDogKFxuICAgICAgICAgIDw+XG4gICAgICAgICAgICA8aDQgc3R5bGU9e3sgbGluZUhlaWdodDogXCIwXCIsIGZvbnRXZWlnaHQ6IFwiNjAwXCIsIG9wYWNpdHk6IDAuNzUgfX0+XG4gICAgICAgICAgICAgIFBhZ2VzXG4gICAgICAgICAgICA8L2g0PlxuICAgICAgICAgICAge3BhZ2VSZXN1bHQubWFwKChpdGVtKSA9PiAoXG4gICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgIHtjb25zb2xlLmxvZygnaXRlbScsIGl0ZW0pfVxuICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPExpc3RcbiAgICAgICAgICAgICAgZGF0YVNvdXJjZT17cGFnZVJlc3VsdH1cbiAgICAgICAgICAgICAgcmVuZGVySXRlbT17KHBhZ2UpID0+IChcbiAgICAgICAgICAgICAgICA8TGlzdC5JdGVtXG4gICAgICAgICAgICAgICAgICBrZXk9e3BhZ2UucmVmSW5kZXh9XG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVDbGlja1BhZ2UocGFnZS5pdGVtLmxhYmVsLnByb3BzLnRvKX1cbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGN1cnNvcjogXCJwb2ludGVyXCIgfX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8TGlzdC5JdGVtLk1ldGFcbiAgICAgICAgICAgICAgICAgICAgYXZhdGFyPXtwYWdlLml0ZW0uaWNvbn1cbiAgICAgICAgICAgICAgICAgICAgdGl0bGU9e3BhZ2UuaXRlbS5sYWJlbC5wcm9wcy5jaGlsZHJlbn1cbiAgICAgICAgICAgICAgICAgICAgZGVzY3JpcHRpb249e3BhZ2UuaXRlbS5kZXNjcmlwdGlvbn1cbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9MaXN0Lkl0ZW0+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvPlxuICAgICAgICApfVxuICAgICAgPC9Nb2RhbD5cbiAgICA8Lz5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IFNlYXJjaEZpZWxkO1xuIl0sImZpbGUiOiIvaG9tZS9kaGFybWEvV29yay9yZWFjdC1ib2lsZXJwbGF0ZS9zcmMvbGF5b3V0cy9jb21wb25lbnRzL1NlYXJjaEZpZWxkLmpzeCJ9