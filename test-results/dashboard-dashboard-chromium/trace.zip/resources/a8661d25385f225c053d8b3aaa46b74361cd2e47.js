import {
  require_react
} from "/node_modules/.vite/deps/chunk-ZGRSIX2Q.js?v=97c9eb9a";
import "/node_modules/.vite/deps/chunk-ROME4SDB.js?v=97c9eb9a";
export default require_react();
//# sourceMappingURL=react.js.map
