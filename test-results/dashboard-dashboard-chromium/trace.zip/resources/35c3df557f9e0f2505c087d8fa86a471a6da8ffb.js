import {
  ActionTypes,
  applyMiddleware,
  bindActionCreators,
  combineReducers,
  compose,
  createStore,
  init_redux,
  legacy_createStore
} from "/node_modules/.vite/deps/chunk-D6UQ5NFJ.js?v=97c9eb9a";
import "/node_modules/.vite/deps/chunk-3QQTPB3K.js?v=97c9eb9a";
import "/node_modules/.vite/deps/chunk-ROME4SDB.js?v=97c9eb9a";
init_redux();
export {
  ActionTypes as __DO_NOT_USE__ActionTypes,
  applyMiddleware,
  bindActionCreators,
  combineReducers,
  compose,
  createStore,
  legacy_createStore
};
//# sourceMappingURL=redux.js.map
