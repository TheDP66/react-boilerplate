import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/layouts/components/PopoverNotification.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f9dec5ba"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/dharma/Work/react-boilerplate/src/layouts/components/PopoverNotification.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { BellOutlined, SettingOutlined } from "/node_modules/.vite/deps/@ant-design_icons.js?v=7a8c6384";
import { Badge, Button, Popover, Space, Tabs } from "/node_modules/.vite/deps/antd.js?v=26d7e361";
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=f9dec5ba"; const React = __vite__cjsImport5_react.__esModule ? __vite__cjsImport5_react.default : __vite__cjsImport5_react;
import NotificationList from "/src/layouts/components/NotificationList.jsx";
const PopoverNotification = () => {
  const items = [{
    label: /* @__PURE__ */ jsxDEV(Space, { children: [
      " ",
      "All ",
      /* @__PURE__ */ jsxDEV(Badge, { count: 100 }, void 0, false, {
        fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/PopoverNotification.jsx",
        lineNumber: 9,
        columnNumber: 15
      }, this),
      " "
    ] }, void 0, true, {
      fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/PopoverNotification.jsx",
      lineNumber: 7,
      columnNumber: 12
    }, this),
    key: 1,
    children: /* @__PURE__ */ jsxDEV(NotificationList, { type: "all" }, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/PopoverNotification.jsx",
      lineNumber: 12,
      columnNumber: 15
    }, this)
  }, {
    label: /* @__PURE__ */ jsxDEV(Space, { children: " General " }, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/PopoverNotification.jsx",
      lineNumber: 14,
      columnNumber: 12
    }, this),
    key: 2,
    children: /* @__PURE__ */ jsxDEV(NotificationList, { type: "general" }, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/PopoverNotification.jsx",
      lineNumber: 16,
      columnNumber: 15
    }, this)
  }];
  return /* @__PURE__ */ jsxDEV("div", { style: {
    display: "flex",
    alignItems: "center",
    backgroundColor: "transparent",
    borderRadius: "6px"
  }, children: /* @__PURE__ */ jsxDEV(Popover, { placement: "bottomRight", arrow: false, title: "Notifications", trigger: "click", content: /* @__PURE__ */ jsxDEV(Tabs, { size: "small", tabBarExtraContent: /* @__PURE__ */ jsxDEV(Popover, { placement: "bottomRight", arrow: false, title: /* @__PURE__ */ jsxDEV("span", { style: {
    fontWeight: 400
  }, children: "Settings" }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/PopoverNotification.jsx",
    lineNumber: 24,
    columnNumber: 196
  }, this), trigger: "click", children: /* @__PURE__ */ jsxDEV(Button, { type: "default", icon: /* @__PURE__ */ jsxDEV(SettingOutlined, {}, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/PopoverNotification.jsx",
    lineNumber: 27,
    columnNumber: 46
  }, this), size: "small" }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/PopoverNotification.jsx",
    lineNumber: 27,
    columnNumber: 17
  }, this) }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/PopoverNotification.jsx",
    lineNumber: 24,
    columnNumber: 142
  }, this), style: {
    maxWidth: "75vw",
    width: "400px"
  }, items }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/PopoverNotification.jsx",
    lineNumber: 24,
    columnNumber: 103
  }, this), children: /* @__PURE__ */ jsxDEV(Badge, { count: "100", offset: [-6, 6], dot: true, children: /* @__PURE__ */ jsxDEV(Button, { type: "text", icon: /* @__PURE__ */ jsxDEV(BellOutlined, {}, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/PopoverNotification.jsx",
    lineNumber: 33,
    columnNumber: 37
  }, this), size: "middle" }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/PopoverNotification.jsx",
    lineNumber: 33,
    columnNumber: 11
  }, this) }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/PopoverNotification.jsx",
    lineNumber: 32,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/PopoverNotification.jsx",
    lineNumber: 24,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/PopoverNotification.jsx",
    lineNumber: 18,
    columnNumber: 10
  }, this);
};
_c = PopoverNotification;
export default PopoverNotification;
var _c;
$RefreshReg$(_c, "PopoverNotification");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/dharma/Work/react-boilerplate/src/layouts/components/PopoverNotification.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWWM7QUFaZCwyQkFBdUJBO0FBQWUsTUFBUSxjQUFtQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDakUsU0FBU0MsT0FBT0MsUUFBUUMsU0FBU0MsT0FBT0MsWUFBWTtBQUNwRCxPQUFPQyxXQUFXO0FBQ2xCLE9BQU9DLHNCQUFzQjtBQUU3QixNQUFNQyxzQkFBc0JBLE1BQU07QUFFaEMsUUFBTUMsUUFBUSxDQUNaO0FBQUEsSUFDRUMsT0FDRSx1QkFBQyxTQUNFO0FBQUE7QUFBQSxNQUFHO0FBQUEsTUFDQSx1QkFBQyxTQUFNLE9BQU8sT0FBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtCO0FBQUEsTUFBSTtBQUFBLFNBRjVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBRUZDLEtBQUs7QUFBQSxJQUNMQyxVQUFVLHVCQUFDLG9CQUFpQixNQUFLLFNBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNEI7QUFBQSxFQUN4QyxHQUNBO0FBQUEsSUFDRUYsT0FBTyx1QkFBQyxTQUFNLHlCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZ0I7QUFBQSxJQUN2QkMsS0FBSztBQUFBLElBQ0xDLFVBQVUsdUJBQUMsb0JBQWlCLE1BQUssYUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnQztBQUFBLEVBQzVDLENBQUM7QUFHSCxTQUNFLHVCQUFDLFNBQ0MsT0FBTztBQUFBLElBQ0xDLFNBQVM7QUFBQSxJQUNUQyxZQUFZO0FBQUEsSUFDWkMsaUJBQWlCO0FBQUEsSUFDakJDLGNBQWM7QUFBQSxFQUNoQixHQUVBLGlDQUFDLFdBQ0MsV0FBVSxlQUNWLE9BQU8sT0FDUCxPQUFPLGlCQUNQLFNBQVEsU0FDUixTQUNFLHVCQUFDLFFBQ0MsTUFBSyxTQUNMLG9CQUNFLHVCQUFDLFdBQ0MsV0FBVSxlQUNWLE9BQU8sT0FDUCxPQUFPLHVCQUFDLFVBQUssT0FBTztBQUFBLElBQUVDLFlBQVk7QUFBQSxFQUFJLEdBQUcsd0JBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBMEMsR0FDakQsU0FBUyxTQUVULGlDQUFDLFVBQ0MsTUFBSyxXQUNMLE1BQU0sdUJBQUMscUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFnQixHQUN0QixNQUFLLFdBSFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUdjLEtBVGhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FXQSxHQUVGLE9BQU87QUFBQSxJQUFFQyxVQUFVO0FBQUEsSUFBUUMsT0FBTztBQUFBLEVBQVEsR0FDMUMsU0FqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWlCZSxHQUlqQixpQ0FBQyxTQUFNLE9BQU8sT0FBTyxRQUFRLENBQUMsSUFBSSxDQUFDLEdBQUcsS0FBRyxNQUN2QyxpQ0FBQyxVQUFPLE1BQUssUUFBTyxNQUFNLHVCQUFDLGtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBYSxHQUFLLE1BQU0sWUFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUEyRCxLQUQ3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRUEsS0E3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQThCQSxLQXRDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBdUNBO0FBRUo7QUFBRUMsS0E5RElaO0FBZ0VOLGVBQWVBO0FBQW9CLElBQUFZO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJTZXR0aW5nT3V0bGluZWQiLCJCYWRnZSIsIkJ1dHRvbiIsIlBvcG92ZXIiLCJTcGFjZSIsIlRhYnMiLCJSZWFjdCIsIk5vdGlmaWNhdGlvbkxpc3QiLCJQb3BvdmVyTm90aWZpY2F0aW9uIiwiaXRlbXMiLCJsYWJlbCIsImtleSIsImNoaWxkcmVuIiwiZGlzcGxheSIsImFsaWduSXRlbXMiLCJiYWNrZ3JvdW5kQ29sb3IiLCJib3JkZXJSYWRpdXMiLCJmb250V2VpZ2h0IiwibWF4V2lkdGgiLCJ3aWR0aCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUG9wb3Zlck5vdGlmaWNhdGlvbi5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQmVsbE91dGxpbmVkLCBTZXR0aW5nT3V0bGluZWQgfSBmcm9tIFwiQGFudC1kZXNpZ24vaWNvbnNcIjtcbmltcG9ydCB7IEJhZGdlLCBCdXR0b24sIFBvcG92ZXIsIFNwYWNlLCBUYWJzIH0gZnJvbSBcImFudGRcIjtcbmltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCBOb3RpZmljYXRpb25MaXN0IGZyb20gXCIuL05vdGlmaWNhdGlvbkxpc3RcIjtcblxuY29uc3QgUG9wb3Zlck5vdGlmaWNhdGlvbiA9ICgpID0+IHtcblxuICBjb25zdCBpdGVtcyA9IFtcbiAgICB7XG4gICAgICBsYWJlbDogKFxuICAgICAgICA8U3BhY2U+XG4gICAgICAgICAge1wiIFwifVxuICAgICAgICAgIEFsbCA8QmFkZ2UgY291bnQ9ezEwMH0gLz57XCIgXCJ9XG4gICAgICAgIDwvU3BhY2U+XG4gICAgICApLFxuICAgICAga2V5OiAxLFxuICAgICAgY2hpbGRyZW46IDxOb3RpZmljYXRpb25MaXN0IHR5cGU9XCJhbGxcIiAvPixcbiAgICB9LFxuICAgIHtcbiAgICAgIGxhYmVsOiA8U3BhY2U+IEdlbmVyYWwgPC9TcGFjZT4sXG4gICAgICBrZXk6IDIsXG4gICAgICBjaGlsZHJlbjogPE5vdGlmaWNhdGlvbkxpc3QgdHlwZT1cImdlbmVyYWxcIiAvPixcbiAgICB9LFxuICBdO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgc3R5bGU9e3tcbiAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXG4gICAgICAgIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsXG4gICAgICAgIGJhY2tncm91bmRDb2xvcjogXCJ0cmFuc3BhcmVudFwiLFxuICAgICAgICBib3JkZXJSYWRpdXM6IFwiNnB4XCIsXG4gICAgICB9fVxuICAgID5cbiAgICAgIDxQb3BvdmVyXG4gICAgICAgIHBsYWNlbWVudD1cImJvdHRvbVJpZ2h0XCJcbiAgICAgICAgYXJyb3c9e2ZhbHNlfVxuICAgICAgICB0aXRsZT17XCJOb3RpZmljYXRpb25zXCJ9XG4gICAgICAgIHRyaWdnZXI9XCJjbGlja1wiXG4gICAgICAgIGNvbnRlbnQ9e1xuICAgICAgICAgIDxUYWJzXG4gICAgICAgICAgICBzaXplPVwic21hbGxcIlxuICAgICAgICAgICAgdGFiQmFyRXh0cmFDb250ZW50PXtcbiAgICAgICAgICAgICAgPFBvcG92ZXJcbiAgICAgICAgICAgICAgICBwbGFjZW1lbnQ9XCJib3R0b21SaWdodFwiXG4gICAgICAgICAgICAgICAgYXJyb3c9e2ZhbHNlfVxuICAgICAgICAgICAgICAgIHRpdGxlPXs8c3BhbiBzdHlsZT17eyBmb250V2VpZ2h0OiA0MDAgfX0+U2V0dGluZ3M8L3NwYW4+fVxuICAgICAgICAgICAgICAgIHRyaWdnZXI9e1wiY2xpY2tcIn1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJkZWZhdWx0XCJcbiAgICAgICAgICAgICAgICAgIGljb249ezxTZXR0aW5nT3V0bGluZWQgLz59XG4gICAgICAgICAgICAgICAgICBzaXplPVwic21hbGxcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvUG9wb3Zlcj5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHN0eWxlPXt7IG1heFdpZHRoOiBcIjc1dndcIiwgd2lkdGg6IFwiNDAwcHhcIiB9fVxuICAgICAgICAgICAgaXRlbXM9e2l0ZW1zfVxuICAgICAgICAgIC8+XG4gICAgICAgIH1cbiAgICAgID5cbiAgICAgICAgPEJhZGdlIGNvdW50PXtcIjEwMFwifSBvZmZzZXQ9e1stNiwgNl19IGRvdD5cbiAgICAgICAgICA8QnV0dG9uIHR5cGU9XCJ0ZXh0XCIgaWNvbj17PEJlbGxPdXRsaW5lZCAvPn0gc2l6ZT17XCJtaWRkbGVcIn0gLz5cbiAgICAgICAgPC9CYWRnZT5cbiAgICAgIDwvUG9wb3Zlcj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IFBvcG92ZXJOb3RpZmljYXRpb247XG4iXSwiZmlsZSI6Ii9ob21lL2RoYXJtYS9Xb3JrL3JlYWN0LWJvaWxlcnBsYXRlL3NyYy9sYXlvdXRzL2NvbXBvbmVudHMvUG9wb3Zlck5vdGlmaWNhdGlvbi5qc3gifQ==