import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/UnauthenticatedRouter.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f9dec5ba"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/dharma/Work/react-boilerplate/src/routes/UnauthenticatedRouter.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import Cookies from "/node_modules/.vite/deps/js-cookie.js?v=ea88deea";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=f9dec5ba"; const React = __vite__cjsImport4_react.__esModule ? __vite__cjsImport4_react.default : __vite__cjsImport4_react;
import { Navigate, Outlet, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=f16f2ff9";
import { unauthenticatedPageList } from "/src/constant/pageList.jsx";
const UnauthenticatedRouter = () => {
  _s();
  const location = useLocation();
  return Cookies.get("refresh_token") ? /* @__PURE__ */ jsxDEV(Navigate, { to: "/dashboard" }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/routes/UnauthenticatedRouter.jsx",
    lineNumber: 9,
    columnNumber: 41
  }, this) : unauthenticatedPageList.findIndex((page) => location.pathname.replace("/", "") === page.path) > -1 ? /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/routes/UnauthenticatedRouter.jsx",
    lineNumber: 9,
    columnNumber: 171
  }, this) : /* @__PURE__ */ jsxDEV(Navigate, { to: "/login" }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/routes/UnauthenticatedRouter.jsx",
    lineNumber: 9,
    columnNumber: 184
  }, this);
};
_s(UnauthenticatedRouter, "pkHmaVRPskBaU4tMJuJJpV42k1I=", false, function() {
  return [useLocation];
});
_c = UnauthenticatedRouter;
export default UnauthenticatedRouter;
var _c;
$RefreshReg$(_c, "UnauthenticatedRouter");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/dharma/Work/react-boilerplate/src/routes/UnauthenticatedRouter.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU0k7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBVEosT0FBT0EsYUFBYTtBQUNwQixPQUFPQyxXQUFXO0FBQ2xCLFNBQVNDLFVBQVVDLFFBQVFDLG1CQUFtQjtBQUM5QyxTQUFTQywrQkFBK0I7QUFFeEMsTUFBTUMsd0JBQXdCQSxNQUFNO0FBQUFDLEtBQUE7QUFDbEMsUUFBTUMsV0FBV0osWUFBWTtBQUU3QixTQUFPSixRQUFRUyxJQUFJLGVBQWUsSUFDaEMsdUJBQUMsWUFBUyxJQUFHLGdCQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBeUIsSUFDdkJKLHdCQUF3QkssVUFDdkJDLFVBQVNILFNBQVNJLFNBQVNDLFFBQVEsS0FBSyxFQUFFLE1BQU1GLEtBQUtHLElBQ3hELElBQUksS0FDSix1QkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBTyxJQUVQLHVCQUFDLFlBQVMsSUFBRyxZQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBcUI7QUFFekI7QUFBRVAsR0FaSUQsdUJBQXFCO0FBQUEsVUFDUkYsV0FBVztBQUFBO0FBQUFXLEtBRHhCVDtBQWNOLGVBQWVBO0FBQXNCLElBQUFTO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJDb29raWVzIiwiUmVhY3QiLCJOYXZpZ2F0ZSIsIk91dGxldCIsInVzZUxvY2F0aW9uIiwidW5hdXRoZW50aWNhdGVkUGFnZUxpc3QiLCJVbmF1dGhlbnRpY2F0ZWRSb3V0ZXIiLCJfcyIsImxvY2F0aW9uIiwiZ2V0IiwiZmluZEluZGV4IiwicGFnZSIsInBhdGhuYW1lIiwicmVwbGFjZSIsInBhdGgiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlVuYXV0aGVudGljYXRlZFJvdXRlci5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IENvb2tpZXMgZnJvbSBcImpzLWNvb2tpZVwiO1xuaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgTmF2aWdhdGUsIE91dGxldCwgdXNlTG9jYXRpb24gfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xuaW1wb3J0IHsgdW5hdXRoZW50aWNhdGVkUGFnZUxpc3QgfSBmcm9tIFwiLi4vY29uc3RhbnQvcGFnZUxpc3RcIjtcblxuY29uc3QgVW5hdXRoZW50aWNhdGVkUm91dGVyID0gKCkgPT4ge1xuICBjb25zdCBsb2NhdGlvbiA9IHVzZUxvY2F0aW9uKCk7XG5cbiAgcmV0dXJuIENvb2tpZXMuZ2V0KFwicmVmcmVzaF90b2tlblwiKSA/IChcbiAgICA8TmF2aWdhdGUgdG89XCIvZGFzaGJvYXJkXCIgLz5cbiAgKSA6IHVuYXV0aGVudGljYXRlZFBhZ2VMaXN0LmZpbmRJbmRleChcbiAgICAgIChwYWdlKSA9PiBsb2NhdGlvbi5wYXRobmFtZS5yZXBsYWNlKFwiL1wiLCBcIlwiKSA9PT0gcGFnZS5wYXRoXG4gICAgKSA+IC0xID8gKFxuICAgIDxPdXRsZXQgLz5cbiAgKSA6IChcbiAgICA8TmF2aWdhdGUgdG89XCIvbG9naW5cIiAvPlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgVW5hdXRoZW50aWNhdGVkUm91dGVyO1xuIl0sImZpbGUiOiIvaG9tZS9kaGFybWEvV29yay9yZWFjdC1ib2lsZXJwbGF0ZS9zcmMvcm91dGVzL1VuYXV0aGVudGljYXRlZFJvdXRlci5qc3gifQ==