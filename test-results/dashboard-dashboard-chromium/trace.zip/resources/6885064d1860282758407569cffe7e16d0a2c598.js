export const dashboard = {
	title: "Dashboard"
};
export const title = "My App";
export default {
	dashboard: dashboard,
	title: title
};
