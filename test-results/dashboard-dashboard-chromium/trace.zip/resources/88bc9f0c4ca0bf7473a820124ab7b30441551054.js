import {
  require_react
} from "/node_modules/.vite/deps/chunk-ZGRSIX2Q.js?v=97c9eb9a";
import {
  __toESM
} from "/node_modules/.vite/deps/chunk-ROME4SDB.js?v=97c9eb9a";

// node_modules/@ant-design/icons/es/components/Context.js
var import_react = __toESM(require_react());
var IconContext = (0, import_react.createContext)({});
var Context_default = IconContext;

export {
  Context_default
};
//# sourceMappingURL=chunk-NSNQ4QUV.js.map
