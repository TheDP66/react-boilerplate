import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/layouts/Bottombar.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f9dec5ba"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/dharma/Work/react-boilerplate/src/layouts/Bottombar.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Footer } from "/node_modules/.vite/deps/antd_es_layout_layout.js?v=bb8c6b63";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=f9dec5ba"; const React = __vite__cjsImport4_react.__esModule ? __vite__cjsImport4_react.default : __vite__cjsImport4_react;
const Bottombar = () => {
  return /* @__PURE__ */ jsxDEV(Footer, { style: {
    opacity: 0.5,
    textAlign: "center",
    fontSize: "12px"
  }, children: "React Boilerplate ANTD ©2023 Created by IT Apps" }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/layouts/Bottombar.jsx",
    lineNumber: 4,
    columnNumber: 10
  }, this);
};
_c = Bottombar;
export default Bottombar;
var _c;
$RefreshReg$(_c, "Bottombar");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/dharma/Work/react-boilerplate/src/layouts/Bottombar.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBS0k7QUFMSiwyQkFBdUI7QUFBQSxNQUF1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDOUMsT0FBT0EsV0FBVztBQUVsQixNQUFNQyxZQUFZQSxNQUFNO0FBQ3RCLFNBQ0UsdUJBQUMsVUFDQyxPQUFPO0FBQUEsSUFDTEMsU0FBUztBQUFBLElBQ1RDLFdBQVc7QUFBQSxJQUNYQyxVQUFVO0FBQUEsRUFDWixHQUFFLCtEQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FRQTtBQUVKO0FBQUVDLEtBWklKO0FBY04sZUFBZUE7QUFBVSxJQUFBSTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJCb3R0b21iYXIiLCJvcGFjaXR5IiwidGV4dEFsaWduIiwiZm9udFNpemUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkJvdHRvbWJhci5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRm9vdGVyIH0gZnJvbSBcImFudGQvZXMvbGF5b3V0L2xheW91dFwiO1xuaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuXG5jb25zdCBCb3R0b21iYXIgPSAoKSA9PiB7XG4gIHJldHVybiAoXG4gICAgPEZvb3RlclxuICAgICAgc3R5bGU9e3tcbiAgICAgICAgb3BhY2l0eTogMC41LFxuICAgICAgICB0ZXh0QWxpZ246IFwiY2VudGVyXCIsXG4gICAgICAgIGZvbnRTaXplOiBcIjEycHhcIixcbiAgICAgIH19XG4gICAgPlxuICAgICAgUmVhY3QgQm9pbGVycGxhdGUgQU5URCDCqTIwMjMgQ3JlYXRlZCBieSBJVCBBcHBzXG4gICAgPC9Gb290ZXI+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBCb3R0b21iYXI7XG4iXSwiZmlsZSI6Ii9ob21lL2RoYXJtYS9Xb3JrL3JlYWN0LWJvaWxlcnBsYXRlL3NyYy9sYXlvdXRzL0JvdHRvbWJhci5qc3gifQ==