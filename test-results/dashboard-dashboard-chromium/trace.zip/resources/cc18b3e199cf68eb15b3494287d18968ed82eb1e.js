import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f9dec5ba"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=f16f2ff9";
import { accountAbility } from "/src/utils/ability.jsx";
import { store } from "/src/redux/store.jsx";
export const generateAuthPage = ({
  key,
  label,
  icon,
  element,
  description,
  style
}) => {
  try {
    const user = accountAbility();
    if (user.can("read", key)) {
      return {
        path: key,
        element,
        key,
        label: /* @__PURE__ */ jsxDEV(Link, { to: `/${key}`, children: label }, key, false, {
          fileName: "/home/dharma/Work/react-boilerplate/src/utils/pages.jsx",
          lineNumber: 21,
          columnNumber: 16
        }, this),
        icon,
        style,
        description
      };
    } else {
      return {
        unauthorized: true
      };
    }
  } catch (error) {
    return {
      unauthorized: true
    };
  }
};
export const generateAuthParentPage = ({
  key,
  label,
  icon,
  children
}) => {
  children = children.filter((page) => !page.unauthorized);
  if (children.length === 0) {
    return {
      unauthorized: true
    };
  } else {
    return {
      key,
      label,
      icon,
      children
    };
  }
};
export const generateDetailAuthPage = ({
  key,
  element
}) => {
  return {
    path: key,
    element,
    key
  };
};
export const generateAuthRoute = () => {
  let pages = [];
  const page = store.getState().app.page;
  page.list.forEach((item) => {
    if (item.children) {
      item.children.forEach((subitem) => {
        pages.push(subitem);
      });
    } else if (item.type !== "divider") {
      pages.push(item);
    }
  });
  page.detail.forEach((item) => {
    pages.push(item);
  });
  return pages;
};

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0JVO0FBdEJWLFNBQVNBLFlBQVk7QUFDckIsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLGFBQWE7QUFHZixhQUFNQyxtQkFBbUJBLENBQUM7QUFBQSxFQUMvQkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFDRixNQUFNO0FBQ0osTUFBSTtBQUNGLFVBQU1DLE9BQU9ULGVBQWU7QUFFNUIsUUFBSVMsS0FBS0MsSUFBSSxRQUFRUCxHQUFHLEdBQUc7QUFDekIsYUFBTztBQUFBLFFBQ0xRLE1BQU1SO0FBQUFBLFFBQ05HO0FBQUFBLFFBQ0FIO0FBQUFBLFFBQ0FDLE9BQ0UsdUJBQUMsUUFBZSxJQUFLLElBQUdELEdBQUksSUFDekJDLG1CQURRRCxLQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBRUZFO0FBQUFBLFFBQ0FHO0FBQUFBLFFBQ0FEO0FBQUFBLE1BQ0Y7QUFBQSxJQUNGLE9BQU87QUFDTCxhQUFPO0FBQUEsUUFBRUssY0FBYztBQUFBLE1BQUs7QUFBQSxJQUM5QjtBQUFBLEVBQ0YsU0FBU0MsT0FBTztBQUNkLFdBQU87QUFBQSxNQUFFRCxjQUFjO0FBQUEsSUFBSztBQUFBLEVBQzlCO0FBQ0Y7QUFHTyxhQUFNRSx5QkFBeUJBLENBQUM7QUFBQSxFQUFFWDtBQUFBQSxFQUFLQztBQUFBQSxFQUFPQztBQUFBQSxFQUFNVTtBQUFTLE1BQU07QUFDeEVBLGFBQVdBLFNBQVNDLE9BQVFDLFVBQVMsQ0FBQ0EsS0FBS0wsWUFBWTtBQUV2RCxNQUFJRyxTQUFTRyxXQUFXLEdBQUc7QUFDekIsV0FBTztBQUFBLE1BQUVOLGNBQWM7QUFBQSxJQUFLO0FBQUEsRUFDOUIsT0FBTztBQUNMLFdBQU87QUFBQSxNQUFFVDtBQUFBQSxNQUFLQztBQUFBQSxNQUFPQztBQUFBQSxNQUFNVTtBQUFBQSxJQUFTO0FBQUEsRUFDdEM7QUFDRjtBQUdPLGFBQU1JLHlCQUF5QkEsQ0FBQztBQUFBLEVBQUVoQjtBQUFBQSxFQUFLRztBQUFRLE1BQU07QUFDMUQsU0FBTztBQUFBLElBQ0xLLE1BQU1SO0FBQUFBLElBQ05HO0FBQUFBLElBQ0FIO0FBQUFBLEVBQ0Y7QUFDRjtBQUdPLGFBQU1pQixvQkFBb0JBLE1BQU07QUFDckMsTUFBSUMsUUFBUTtBQUNaLFFBQU1KLE9BQU9oQixNQUFNcUIsU0FBUyxFQUFFQyxJQUFJTjtBQUVsQ0EsT0FBS08sS0FBS0MsUUFBU0MsVUFBUztBQUMxQixRQUFJQSxLQUFLWCxVQUFVO0FBQ2pCVyxXQUFLWCxTQUFTVSxRQUFTRSxhQUFZO0FBQ2pDTixjQUFNTyxLQUFLRCxPQUFPO0FBQUEsTUFDcEIsQ0FBQztBQUFBLElBQ0gsV0FBV0QsS0FBS0csU0FBUyxXQUFXO0FBQ2xDUixZQUFNTyxLQUFLRixJQUFJO0FBQUEsSUFDakI7QUFBQSxFQUNGLENBQUM7QUFFRFQsT0FBS2EsT0FBT0wsUUFBU0MsVUFBUztBQUM1QkwsVUFBTU8sS0FBS0YsSUFBSTtBQUFBLEVBQ2pCLENBQUM7QUFFRCxTQUFPTDtBQUNUIiwibmFtZXMiOlsiTGluayIsImFjY291bnRBYmlsaXR5Iiwic3RvcmUiLCJnZW5lcmF0ZUF1dGhQYWdlIiwia2V5IiwibGFiZWwiLCJpY29uIiwiZWxlbWVudCIsImRlc2NyaXB0aW9uIiwic3R5bGUiLCJ1c2VyIiwiY2FuIiwicGF0aCIsInVuYXV0aG9yaXplZCIsImVycm9yIiwiZ2VuZXJhdGVBdXRoUGFyZW50UGFnZSIsImNoaWxkcmVuIiwiZmlsdGVyIiwicGFnZSIsImxlbmd0aCIsImdlbmVyYXRlRGV0YWlsQXV0aFBhZ2UiLCJnZW5lcmF0ZUF1dGhSb3V0ZSIsInBhZ2VzIiwiZ2V0U3RhdGUiLCJhcHAiLCJsaXN0IiwiZm9yRWFjaCIsIml0ZW0iLCJzdWJpdGVtIiwicHVzaCIsInR5cGUiLCJkZXRhaWwiXSwic291cmNlcyI6WyJwYWdlcy5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTGluayB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XG5pbXBvcnQgeyBhY2NvdW50QWJpbGl0eSB9IGZyb20gXCIuL2FiaWxpdHlcIjtcbmltcG9ydCB7IHN0b3JlIH0gZnJvbSBcIi4uL3JlZHV4L3N0b3JlXCI7XG5cbi8vID8gZ2VuZXJhdGVBdXRoUGFnZSgpIHVzZWQgZm9yIGZvcm1hdGluZyBhbmQgZ2VuZXJhdGluZyBwYWdlIG9iamVjdFxuZXhwb3J0IGNvbnN0IGdlbmVyYXRlQXV0aFBhZ2UgPSAoe1xuICBrZXksXG4gIGxhYmVsLFxuICBpY29uLFxuICBlbGVtZW50LFxuICBkZXNjcmlwdGlvbixcbiAgc3R5bGUsXG59KSA9PiB7XG4gIHRyeSB7XG4gICAgY29uc3QgdXNlciA9IGFjY291bnRBYmlsaXR5KCk7XG5cbiAgICBpZiAodXNlci5jYW4oXCJyZWFkXCIsIGtleSkpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHBhdGg6IGtleSxcbiAgICAgICAgZWxlbWVudCxcbiAgICAgICAga2V5LFxuICAgICAgICBsYWJlbDogKFxuICAgICAgICAgIDxMaW5rIGtleT17a2V5fSB0bz17YC8ke2tleX1gfT5cbiAgICAgICAgICAgIHtsYWJlbH1cbiAgICAgICAgICA8L0xpbms+XG4gICAgICAgICksXG4gICAgICAgIGljb24sXG4gICAgICAgIHN0eWxlLFxuICAgICAgICBkZXNjcmlwdGlvbixcbiAgICAgIH07XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiB7IHVuYXV0aG9yaXplZDogdHJ1ZSB9O1xuICAgIH1cbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICByZXR1cm4geyB1bmF1dGhvcml6ZWQ6IHRydWUgfTtcbiAgfVxufTtcblxuLy8gPyBnZW5lcmF0ZUF1dGhQYXJlbnRQYWdlKCkgdXNlZCB0byBjaGVjayBpZiBtZW51IGhhdmUgY2hpbGQgb3Igbm90XG5leHBvcnQgY29uc3QgZ2VuZXJhdGVBdXRoUGFyZW50UGFnZSA9ICh7IGtleSwgbGFiZWwsIGljb24sIGNoaWxkcmVuIH0pID0+IHtcbiAgY2hpbGRyZW4gPSBjaGlsZHJlbi5maWx0ZXIoKHBhZ2UpID0+ICFwYWdlLnVuYXV0aG9yaXplZCk7XG5cbiAgaWYgKGNoaWxkcmVuLmxlbmd0aCA9PT0gMCkge1xuICAgIHJldHVybiB7IHVuYXV0aG9yaXplZDogdHJ1ZSB9O1xuICB9IGVsc2Uge1xuICAgIHJldHVybiB7IGtleSwgbGFiZWwsIGljb24sIGNoaWxkcmVuIH07XG4gIH1cbn07XG5cbi8vID8gZ2VuZXJhdGVEZXRhaWxBdXRoUGFnZSgpIHVzZWQgZm9yIGZvcm1hdGluZyBhbmQgZ2VuZXJhdGluZyBkZXRhaWwgcGFnZSBvYmplY3RcbmV4cG9ydCBjb25zdCBnZW5lcmF0ZURldGFpbEF1dGhQYWdlID0gKHsga2V5LCBlbGVtZW50IH0pID0+IHtcbiAgcmV0dXJuIHtcbiAgICBwYXRoOiBrZXksXG4gICAgZWxlbWVudCxcbiAgICBrZXksXG4gIH07XG59O1xuXG4vLyA/IGdlbmVyYXRlQXV0aFJvdXRlKCkgdXNlZCBmb3IgZ2VuZXJhdGluZyByb3V0ZXMgZm9yIGFsbCBhdXRoZW50aWNhdGVkIHBhZ2VcbmV4cG9ydCBjb25zdCBnZW5lcmF0ZUF1dGhSb3V0ZSA9ICgpID0+IHtcbiAgbGV0IHBhZ2VzID0gW107XG4gIGNvbnN0IHBhZ2UgPSBzdG9yZS5nZXRTdGF0ZSgpLmFwcC5wYWdlO1xuXG4gIHBhZ2UubGlzdC5mb3JFYWNoKChpdGVtKSA9PiB7XG4gICAgaWYgKGl0ZW0uY2hpbGRyZW4pIHtcbiAgICAgIGl0ZW0uY2hpbGRyZW4uZm9yRWFjaCgoc3ViaXRlbSkgPT4ge1xuICAgICAgICBwYWdlcy5wdXNoKHN1Yml0ZW0pO1xuICAgICAgfSk7XG4gICAgfSBlbHNlIGlmIChpdGVtLnR5cGUgIT09IFwiZGl2aWRlclwiKSB7XG4gICAgICBwYWdlcy5wdXNoKGl0ZW0pO1xuICAgIH1cbiAgfSk7XG5cbiAgcGFnZS5kZXRhaWwuZm9yRWFjaCgoaXRlbSkgPT4ge1xuICAgIHBhZ2VzLnB1c2goaXRlbSk7XG4gIH0pO1xuXG4gIHJldHVybiBwYWdlcztcbn07XG4iXSwiZmlsZSI6Ii9ob21lL2RoYXJtYS9Xb3JrL3JlYWN0LWJvaWxlcnBsYXRlL3NyYy91dGlscy9wYWdlcy5qc3gifQ==