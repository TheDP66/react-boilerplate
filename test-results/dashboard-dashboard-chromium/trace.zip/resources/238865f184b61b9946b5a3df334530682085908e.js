import {
  SiderContext,
  Sider_default
} from "/node_modules/.vite/deps/chunk-QVR55UVE.js?v=97c9eb9a";
import "/node_modules/.vite/deps/chunk-2F7KT3CG.js?v=97c9eb9a";
import "/node_modules/.vite/deps/chunk-KXJUBSWK.js?v=97c9eb9a";
import "/node_modules/.vite/deps/chunk-GSZ7ISAW.js?v=97c9eb9a";
import "/node_modules/.vite/deps/chunk-S336X63N.js?v=97c9eb9a";
import "/node_modules/.vite/deps/chunk-NSNQ4QUV.js?v=97c9eb9a";
import "/node_modules/.vite/deps/chunk-7WPSNT37.js?v=97c9eb9a";
import "/node_modules/.vite/deps/chunk-VLJ7Q36Z.js?v=97c9eb9a";
import "/node_modules/.vite/deps/chunk-3QQTPB3K.js?v=97c9eb9a";
import "/node_modules/.vite/deps/chunk-ZGRSIX2Q.js?v=97c9eb9a";
import "/node_modules/.vite/deps/chunk-ROME4SDB.js?v=97c9eb9a";
export {
  SiderContext,
  Sider_default as default
};
//# sourceMappingURL=antd_es_layout_Sider.js.map
