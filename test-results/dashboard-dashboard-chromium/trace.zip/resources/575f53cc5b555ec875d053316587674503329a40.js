import {
  es_default
} from "/node_modules/.vite/deps/chunk-YMU2OWCY.js?v=97c9eb9a";
import "/node_modules/.vite/deps/chunk-ROME4SDB.js?v=97c9eb9a";
export {
  es_default as default
};
//# sourceMappingURL=redux-thunk.js.map
