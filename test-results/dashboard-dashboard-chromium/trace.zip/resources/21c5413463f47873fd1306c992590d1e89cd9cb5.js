import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/LaravelEchoClient.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f9dec5ba"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/dharma/Work/react-boilerplate/src/components/LaravelEchoClient.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=f9dec5ba"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"];
import { useDispatch } from "/node_modules/.vite/deps/react-redux.js?v=3db4bc54";
import audiobell from "/src/assets/audios/Notif_RT.mp3?import";
import logoDNet from "/src/assets/images/logo d~net.png?import";
import "/src/lib/laravelEcho.jsx";
import { GLOBALTYPES } from "/src/redux/actions/globalTypes.jsx";
const LaravelEchoClient = () => {
  _s();
  const dispatch = useDispatch();
  const spawnNotification = ({
    title,
    icon,
    body,
    url
  }) => {
    let options = {
      body,
      icon
    };
    let n = new Notification(title, options);
    try {
      const audio = new Audio(audiobell);
      audio.play();
    } catch (error) {
      dispatch({
        type: GLOBALTYPES.MESSAGE,
        payload: {
          error: error.message
        }
      });
    }
    n.onclick = (e) => {
      e.preventDefault();
      window.open(url, "_blank");
    };
  };
  useEffect(() => {
    window.Echo.channel("public").listen("PublicEvent", (e) => {
      console.log("e", e);
      spawnNotification({
        title: "New Color",
        icon: logoDNet,
        body: e.color,
        url: "https://youtube.com"
      });
    });
  }, []);
  return /* @__PURE__ */ jsxDEV(Fragment, {}, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/components/LaravelEchoClient.jsx",
    lineNumber: 54,
    columnNumber: 10
  }, this);
};
_s(LaravelEchoClient, "rAh3tY+Iv6hWC9AI4Dm+rCbkwNE=", false, function() {
  return [useDispatch];
});
_c = LaravelEchoClient;
export default LaravelEchoClient;
var _c;
$RefreshReg$(_c, "LaravelEchoClient");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/dharma/Work/react-boilerplate/src/components/LaravelEchoClient.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdURTOzs7Ozs7Ozs7Ozs7Ozs7OztBQXZEVCxPQUFPQSxTQUFTQyxpQkFBaUI7QUFDakMsU0FBU0MsbUJBQW1CO0FBQzVCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsY0FBYztBQUNyQixPQUFPO0FBQ1AsU0FBU0MsbUJBQW1CO0FBRTVCLE1BQU1DLG9CQUFvQkEsTUFBTTtBQUFBQyxLQUFBO0FBQzlCLFFBQU1DLFdBQVdOLFlBQVk7QUFFN0IsUUFBTU8sb0JBQW9CQSxDQUFDO0FBQUEsSUFBRUM7QUFBQUEsSUFBT0M7QUFBQUEsSUFBTUM7QUFBQUEsSUFBTUM7QUFBQUEsRUFBSSxNQUFNO0FBQ3hELFFBQUlDLFVBQVU7QUFBQSxNQUNaRjtBQUFBQSxNQUNBRDtBQUFBQSxJQUNGO0FBRUEsUUFBSUksSUFBSSxJQUFJQyxhQUFhTixPQUFPSSxPQUFPO0FBRXZDLFFBQUk7QUFJRixZQUFNRyxRQUFRLElBQUlDLE1BQU1mLFNBQVM7QUFDakNjLFlBQU1FLEtBQUs7QUFBQSxJQUNiLFNBQVNDLE9BQU87QUFDZFosZUFBUztBQUFBLFFBQ1BhLE1BQU1oQixZQUFZaUI7QUFBQUEsUUFDbEJDLFNBQVM7QUFBQSxVQUNQSCxPQUFPQSxNQUFNSTtBQUFBQSxRQUNmO0FBQUEsTUFDRixDQUFDO0FBQUEsSUFDSDtBQUVBVCxNQUFFVSxVQUFXQyxPQUFNO0FBQ2pCQSxRQUFFQyxlQUFlO0FBRWpCQyxhQUFPQyxLQUFLaEIsS0FBSyxRQUFRO0FBQUEsSUFDM0I7QUFBQSxFQUNGO0FBRUFaLFlBQVUsTUFBTTtBQUNkMkIsV0FBT0UsS0FBS0MsUUFBUSxRQUFRLEVBQUVDLE9BQU8sZUFBZ0JOLE9BQU07QUFDekRPLGNBQVFDLElBQUksS0FBS1IsQ0FBQztBQUVsQmpCLHdCQUFrQjtBQUFBLFFBQ2hCQyxPQUFPO0FBQUEsUUFDUEMsTUFBTVA7QUFBQUEsUUFDTlEsTUFBTWMsRUFBRVM7QUFBQUEsUUFDUnRCLEtBQUs7QUFBQSxNQUNQLENBQUM7QUFBQSxJQUNILENBQUM7QUFBQSxFQUdILEdBQUcsRUFBRTtBQUVMLFNBQU87QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFFO0FBQ1g7QUFBRU4sR0FqRElELG1CQUFpQjtBQUFBLFVBQ0pKLFdBQVc7QUFBQTtBQUFBa0MsS0FEeEI5QjtBQW1ETixlQUFlQTtBQUFrQixJQUFBOEI7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwidXNlRWZmZWN0IiwidXNlRGlzcGF0Y2giLCJhdWRpb2JlbGwiLCJsb2dvRE5ldCIsIkdMT0JBTFRZUEVTIiwiTGFyYXZlbEVjaG9DbGllbnQiLCJfcyIsImRpc3BhdGNoIiwic3Bhd25Ob3RpZmljYXRpb24iLCJ0aXRsZSIsImljb24iLCJib2R5IiwidXJsIiwib3B0aW9ucyIsIm4iLCJOb3RpZmljYXRpb24iLCJhdWRpbyIsIkF1ZGlvIiwicGxheSIsImVycm9yIiwidHlwZSIsIk1FU1NBR0UiLCJwYXlsb2FkIiwibWVzc2FnZSIsIm9uY2xpY2siLCJlIiwicHJldmVudERlZmF1bHQiLCJ3aW5kb3ciLCJvcGVuIiwiRWNobyIsImNoYW5uZWwiLCJsaXN0ZW4iLCJjb25zb2xlIiwibG9nIiwiY29sb3IiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkxhcmF2ZWxFY2hvQ2xpZW50LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyB1c2VEaXNwYXRjaCB9IGZyb20gXCJyZWFjdC1yZWR1eFwiO1xuaW1wb3J0IGF1ZGlvYmVsbCBmcm9tIFwiLi4vYXNzZXRzL2F1ZGlvcy9Ob3RpZl9SVC5tcDNcIjtcbmltcG9ydCBsb2dvRE5ldCBmcm9tIFwiLi4vYXNzZXRzL2ltYWdlcy9sb2dvIGR+bmV0LnBuZ1wiO1xuaW1wb3J0IFwiLi4vbGliL2xhcmF2ZWxFY2hvXCI7XG5pbXBvcnQgeyBHTE9CQUxUWVBFUyB9IGZyb20gXCIuLi9yZWR1eC9hY3Rpb25zL2dsb2JhbFR5cGVzXCI7XG5cbmNvbnN0IExhcmF2ZWxFY2hvQ2xpZW50ID0gKCkgPT4ge1xuICBjb25zdCBkaXNwYXRjaCA9IHVzZURpc3BhdGNoKCk7XG5cbiAgY29uc3Qgc3Bhd25Ob3RpZmljYXRpb24gPSAoeyB0aXRsZSwgaWNvbiwgYm9keSwgdXJsIH0pID0+IHtcbiAgICBsZXQgb3B0aW9ucyA9IHtcbiAgICAgIGJvZHksXG4gICAgICBpY29uLFxuICAgIH07XG5cbiAgICBsZXQgbiA9IG5ldyBOb3RpZmljYXRpb24odGl0bGUsIG9wdGlvbnMpO1xuXG4gICAgdHJ5IHtcbiAgICAgIC8vIGlmIChub3RpZnkuc291bmQpIGF1ZGlvUmVmLmN1cnJlbnQucGxheSgpO1xuXG4gICAgICAvLyA/IEZvcmNlIHBsYXkgbm90aWZpY2F0aW9uIHNvdW5kXG4gICAgICBjb25zdCBhdWRpbyA9IG5ldyBBdWRpbyhhdWRpb2JlbGwpO1xuICAgICAgYXVkaW8ucGxheSgpO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBkaXNwYXRjaCh7XG4gICAgICAgIHR5cGU6IEdMT0JBTFRZUEVTLk1FU1NBR0UsXG4gICAgICAgIHBheWxvYWQ6IHtcbiAgICAgICAgICBlcnJvcjogZXJyb3IubWVzc2FnZSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIG4ub25jbGljayA9IChlKSA9PiB7XG4gICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG5cbiAgICAgIHdpbmRvdy5vcGVuKHVybCwgXCJfYmxhbmtcIik7XG4gICAgfTtcbiAgfTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHdpbmRvdy5FY2hvLmNoYW5uZWwoXCJwdWJsaWNcIikubGlzdGVuKFwiUHVibGljRXZlbnRcIiwgKGUpID0+IHtcbiAgICAgIGNvbnNvbGUubG9nKFwiZVwiLCBlKTtcblxuICAgICAgc3Bhd25Ob3RpZmljYXRpb24oe1xuICAgICAgICB0aXRsZTogXCJOZXcgQ29sb3JcIixcbiAgICAgICAgaWNvbjogbG9nb0ROZXQsXG4gICAgICAgIGJvZHk6IGUuY29sb3IsXG4gICAgICAgIHVybDogXCJodHRwczovL3lvdXR1YmUuY29tXCIsXG4gICAgICB9KTtcbiAgICB9KTtcblxuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmVcbiAgfSwgW10pO1xuXG4gIHJldHVybiA8PjwvPjtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IExhcmF2ZWxFY2hvQ2xpZW50O1xuIl0sImZpbGUiOiIvaG9tZS9kaGFybWEvV29yay9yZWFjdC1ib2lsZXJwbGF0ZS9zcmMvY29tcG9uZW50cy9MYXJhdmVsRWNob0NsaWVudC5qc3gifQ==