import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/layouts/Topbar.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f9dec5ba"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/dharma/Work/react-boilerplate/src/layouts/Topbar.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Divider, theme } from "/node_modules/.vite/deps/antd.js?v=26d7e361";
import { Header } from "/node_modules/.vite/deps/antd_es_layout_layout.js?v=bb8c6b63";
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=f9dec5ba"; const React = __vite__cjsImport5_react.__esModule ? __vite__cjsImport5_react.default : __vite__cjsImport5_react;
import DarkModeSwitch from "/src/layouts/components/DarkModeSwitch.jsx";
import LogoButton from "/src/layouts/components/LogoButton.jsx";
import PopoverNotification from "/src/layouts/components/PopoverNotification.jsx";
import SearchField from "/src/layouts/components/SearchField.jsx";
import UserProfileAvatar from "/src/layouts/components/UserProfileAvatar.jsx";
const {
  useToken
} = theme;
const Topbar = () => {
  _s();
  const {
    token
  } = useToken();
  return /* @__PURE__ */ jsxDEV(Header, { style: {
    padding: "0 10px",
    backgroundColor: token.colorBgContainer,
    display: "flex",
    flexDirection: "row",
    justifyContent: "space-between",
    width: "100%"
  }, children: [
    /* @__PURE__ */ jsxDEV("div", { style: {
      display: "flex",
      alignItems: "center",
      gap: "16px"
    }, children: [
      /* @__PURE__ */ jsxDEV(LogoButton, {}, void 0, false, {
        fileName: "/home/dharma/Work/react-boilerplate/src/layouts/Topbar.jsx",
        lineNumber: 31,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(SearchField, {}, void 0, false, {
        fileName: "/home/dharma/Work/react-boilerplate/src/layouts/Topbar.jsx",
        lineNumber: 33,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/home/dharma/Work/react-boilerplate/src/layouts/Topbar.jsx",
      lineNumber: 26,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: {
      display: "flex",
      alignItems: "center",
      gap: "8px"
    }, children: [
      /* @__PURE__ */ jsxDEV(DarkModeSwitch, {}, void 0, false, {
        fileName: "/home/dharma/Work/react-boilerplate/src/layouts/Topbar.jsx",
        lineNumber: 41,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(PopoverNotification, {}, void 0, false, {
        fileName: "/home/dharma/Work/react-boilerplate/src/layouts/Topbar.jsx",
        lineNumber: 43,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Divider, { type: "vertical", style: {
        margin: 0
      } }, void 0, false, {
        fileName: "/home/dharma/Work/react-boilerplate/src/layouts/Topbar.jsx",
        lineNumber: 45,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(UserProfileAvatar, {}, void 0, false, {
        fileName: "/home/dharma/Work/react-boilerplate/src/layouts/Topbar.jsx",
        lineNumber: 49,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/home/dharma/Work/react-boilerplate/src/layouts/Topbar.jsx",
      lineNumber: 36,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/dharma/Work/react-boilerplate/src/layouts/Topbar.jsx",
    lineNumber: 18,
    columnNumber: 10
  }, this);
};
_s(Topbar, "CXYXngGSy/ueZ8bUn1vgrdGvaEo=", false, function() {
  return [useToken];
});
_c = Topbar;
export default Topbar;
var _c;
$RefreshReg$(_c, "Topbar");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/dharma/Work/react-boilerplate/src/layouts/Topbar.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0NROzs7Ozs7Ozs7Ozs7Ozs7OztBQWhDUixTQUFTQSxTQUFTQyxhQUFhO0FBQy9CLFNBQVNDLGNBQWM7QUFDdkIsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxvQkFBb0I7QUFDM0IsT0FBT0MsZ0JBQWdCO0FBQ3ZCLE9BQU9DLHlCQUF5QjtBQUNoQyxPQUFPQyxpQkFBaUI7QUFDeEIsT0FBT0MsdUJBQXVCO0FBRTlCLE1BQU07QUFBQSxFQUFFQztBQUFTLElBQUlSO0FBRXJCLE1BQU1TLFNBQVNBLE1BQU07QUFBQUMsS0FBQTtBQUNuQixRQUFNO0FBQUEsSUFBRUM7QUFBQUEsRUFBTSxJQUFJSCxTQUFTO0FBRTNCLFNBQ0UsdUJBQUMsVUFDQyxPQUFPO0FBQUEsSUFDTEksU0FBUztBQUFBLElBQ1RDLGlCQUFpQkYsTUFBTUc7QUFBQUEsSUFDdkJDLFNBQVM7QUFBQSxJQUNUQyxlQUFlO0FBQUEsSUFDZkMsZ0JBQWdCO0FBQUEsSUFDaEJDLE9BQU87QUFBQSxFQUNULEdBRUE7QUFBQSwyQkFBQyxTQUNDLE9BQU87QUFBQSxNQUNMSCxTQUFTO0FBQUEsTUFDVEksWUFBWTtBQUFBLE1BQ1pDLEtBQUs7QUFBQSxJQUNQLEdBRUE7QUFBQSw2QkFBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVc7QUFBQSxNQUVYLHVCQUFDLGlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBWTtBQUFBLFNBVGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVVBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLE9BQU87QUFBQSxNQUFFTCxTQUFTO0FBQUEsTUFBUUksWUFBWTtBQUFBLE1BQVVDLEtBQUs7QUFBQSxJQUFNLEdBQzlEO0FBQUEsNkJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFlO0FBQUEsTUFFZix1QkFBQyx5QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9CO0FBQUEsTUFFcEIsdUJBQUMsV0FBUSxNQUFLLFlBQVcsT0FBTztBQUFBLFFBQUVDLFFBQVE7QUFBQSxNQUFFLEtBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOEM7QUFBQSxNQUU5Qyx1QkFBQyx1QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtCO0FBQUEsU0FQcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFBO0FBQUEsT0E5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQStCQTtBQUVKO0FBQUVYLEdBckNJRCxRQUFNO0FBQUEsVUFDUUQsUUFBUTtBQUFBO0FBQUFjLEtBRHRCYjtBQXVDTixlQUFlQTtBQUFPLElBQUFhO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJEaXZpZGVyIiwidGhlbWUiLCJIZWFkZXIiLCJSZWFjdCIsIkRhcmtNb2RlU3dpdGNoIiwiTG9nb0J1dHRvbiIsIlBvcG92ZXJOb3RpZmljYXRpb24iLCJTZWFyY2hGaWVsZCIsIlVzZXJQcm9maWxlQXZhdGFyIiwidXNlVG9rZW4iLCJUb3BiYXIiLCJfcyIsInRva2VuIiwicGFkZGluZyIsImJhY2tncm91bmRDb2xvciIsImNvbG9yQmdDb250YWluZXIiLCJkaXNwbGF5IiwiZmxleERpcmVjdGlvbiIsImp1c3RpZnlDb250ZW50Iiwid2lkdGgiLCJhbGlnbkl0ZW1zIiwiZ2FwIiwibWFyZ2luIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJUb3BiYXIuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IERpdmlkZXIsIHRoZW1lIH0gZnJvbSBcImFudGRcIjtcbmltcG9ydCB7IEhlYWRlciB9IGZyb20gXCJhbnRkL2VzL2xheW91dC9sYXlvdXRcIjtcbmltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCBEYXJrTW9kZVN3aXRjaCBmcm9tIFwiLi9jb21wb25lbnRzL0RhcmtNb2RlU3dpdGNoXCI7XG5pbXBvcnQgTG9nb0J1dHRvbiBmcm9tIFwiLi9jb21wb25lbnRzL0xvZ29CdXR0b25cIjtcbmltcG9ydCBQb3BvdmVyTm90aWZpY2F0aW9uIGZyb20gXCIuL2NvbXBvbmVudHMvUG9wb3Zlck5vdGlmaWNhdGlvblwiO1xuaW1wb3J0IFNlYXJjaEZpZWxkIGZyb20gXCIuL2NvbXBvbmVudHMvU2VhcmNoRmllbGRcIjtcbmltcG9ydCBVc2VyUHJvZmlsZUF2YXRhciBmcm9tIFwiLi9jb21wb25lbnRzL1VzZXJQcm9maWxlQXZhdGFyXCI7XG5cbmNvbnN0IHsgdXNlVG9rZW4gfSA9IHRoZW1lO1xuXG5jb25zdCBUb3BiYXIgPSAoKSA9PiB7XG4gIGNvbnN0IHsgdG9rZW4gfSA9IHVzZVRva2VuKCk7XG5cbiAgcmV0dXJuIChcbiAgICA8SGVhZGVyXG4gICAgICBzdHlsZT17e1xuICAgICAgICBwYWRkaW5nOiBcIjAgMTBweFwiLFxuICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IHRva2VuLmNvbG9yQmdDb250YWluZXIsXG4gICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxuICAgICAgICBmbGV4RGlyZWN0aW9uOiBcInJvd1wiLFxuICAgICAgICBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIsXG4gICAgICAgIHdpZHRoOiBcIjEwMCVcIixcbiAgICAgIH19XG4gICAgPlxuICAgICAgPGRpdlxuICAgICAgICBzdHlsZT17e1xuICAgICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxuICAgICAgICAgIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsXG4gICAgICAgICAgZ2FwOiBcIjE2cHhcIixcbiAgICAgICAgfX1cbiAgICAgID5cbiAgICAgICAgPExvZ29CdXR0b24gLz5cblxuICAgICAgICA8U2VhcmNoRmllbGQgLz5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLCBnYXA6IFwiOHB4XCIgfX0+XG4gICAgICAgIDxEYXJrTW9kZVN3aXRjaCAvPlxuXG4gICAgICAgIDxQb3BvdmVyTm90aWZpY2F0aW9uIC8+XG5cbiAgICAgICAgPERpdmlkZXIgdHlwZT1cInZlcnRpY2FsXCIgc3R5bGU9e3sgbWFyZ2luOiAwIH19IC8+XG5cbiAgICAgICAgPFVzZXJQcm9maWxlQXZhdGFyIC8+XG4gICAgICA8L2Rpdj5cbiAgICA8L0hlYWRlcj5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IFRvcGJhcjtcbiJdLCJmaWxlIjoiL2hvbWUvZGhhcm1hL1dvcmsvcmVhY3QtYm9pbGVycGxhdGUvc3JjL2xheW91dHMvVG9wYmFyLmpzeCJ9