import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/assets/svg/sunSvg.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f9dec5ba"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/dharma/Work/react-boilerplate/src/assets/svg/sunSvg.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import Icon from "/node_modules/.vite/deps/@ant-design_icons.js?v=7a8c6384";
const SunSvg = (stroke) => /* @__PURE__ */ jsxDEV("svg", { width: "20px", height: "20px", viewBox: "0 0 24 24", fill: "none", xmlns: "http://www.w3.org/2000/svg", children: /* @__PURE__ */ jsxDEV("g", { id: "Environment / Sun", children: /* @__PURE__ */ jsxDEV("path", { id: "Vector", d: "M12 4V2M12 20V22M6.41421 6.41421L5 5M17.728 17.728L19.1422 19.1422M4 12H2M20 12H22M17.7285 6.41421L19.1427 5M6.4147 17.728L5.00049 19.1422M12 17C9.23858 17 7 14.7614 7 12C7 9.23858 9.23858 7 12 7C14.7614 7 17 9.23858 17 12C17 14.7614 14.7614 17 12 17Z", stroke, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, void 0, false, {
  fileName: "/home/dharma/Work/react-boilerplate/src/assets/svg/sunSvg.jsx",
  lineNumber: 4,
  columnNumber: 7
}, this) }, void 0, false, {
  fileName: "/home/dharma/Work/react-boilerplate/src/assets/svg/sunSvg.jsx",
  lineNumber: 3,
  columnNumber: 5
}, this) }, void 0, false, {
  fileName: "/home/dharma/Work/react-boilerplate/src/assets/svg/sunSvg.jsx",
  lineNumber: 2,
  columnNumber: 26
}, this);
_c = SunSvg;
export const SunIcon = (props) => /* @__PURE__ */ jsxDEV(Icon, { component: () => SunSvg(props.stroke), ...props }, void 0, false, {
  fileName: "/home/dharma/Work/react-boilerplate/src/assets/svg/sunSvg.jsx",
  lineNumber: 8,
  columnNumber: 33
}, this);
_c2 = SunIcon;
var _c, _c2;
$RefreshReg$(_c, "SunSvg");
$RefreshReg$(_c2, "SunIcon");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/dharma/Work/react-boilerplate/src/assets/svg/sunSvg.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBV007QUFYTixPQUFPQSxvQkFBVTtBQUFtQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFcEMsTUFBTUMsU0FBVUMsWUFDZCx1QkFBQyxTQUNDLE9BQU0sUUFDTixRQUFPLFFBQ1AsU0FBUSxhQUNSLE1BQUssUUFDTCxPQUFNLDhCQUVOLGlDQUFDLE9BQUUsSUFBRyxxQkFDSixpQ0FBQyxVQUNDLElBQUcsVUFDSCxHQUFFLCtQQUNGLFFBQ0EsYUFBWSxLQUNaLGVBQWMsU0FDZCxnQkFBZSxXQU5qQjtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BTXdCLEtBUDFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FTQSxLQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BaUJBO0FBQ0FDLEtBbkJJRjtBQXFCQyxhQUFNRyxVQUFXQyxXQUN0Qix1QkFBQyxRQUFLLFdBQVcsTUFBTUosT0FBT0ksTUFBTUgsTUFBTSxHQUFHLEdBQUlHLFNBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FBdUQ7QUFDdkRDLE1BRldGO0FBQU8sSUFBQUQsSUFBQUc7QUFBQUMsYUFBQUosSUFBQTtBQUFBSSxhQUFBRCxLQUFBIiwibmFtZXMiOlsiSWNvbiIsIlN1blN2ZyIsInN0cm9rZSIsIl9jIiwiU3VuSWNvbiIsInByb3BzIiwiX2MyIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsic3VuU3ZnLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgSWNvbiBmcm9tIFwiQGFudC1kZXNpZ24vaWNvbnNcIjtcclxuXHJcbmNvbnN0IFN1blN2ZyA9IChzdHJva2UpID0+IChcclxuICA8c3ZnXHJcbiAgICB3aWR0aD1cIjIwcHhcIlxyXG4gICAgaGVpZ2h0PVwiMjBweFwiXHJcbiAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuICAgIGZpbGw9XCJub25lXCJcclxuICAgIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIlxyXG4gID5cclxuICAgIDxnIGlkPVwiRW52aXJvbm1lbnQgLyBTdW5cIj5cclxuICAgICAgPHBhdGhcclxuICAgICAgICBpZD1cIlZlY3RvclwiXHJcbiAgICAgICAgZD1cIk0xMiA0VjJNMTIgMjBWMjJNNi40MTQyMSA2LjQxNDIxTDUgNU0xNy43MjggMTcuNzI4TDE5LjE0MjIgMTkuMTQyMk00IDEySDJNMjAgMTJIMjJNMTcuNzI4NSA2LjQxNDIxTDE5LjE0MjcgNU02LjQxNDcgMTcuNzI4TDUuMDAwNDkgMTkuMTQyMk0xMiAxN0M5LjIzODU4IDE3IDcgMTQuNzYxNCA3IDEyQzcgOS4yMzg1OCA5LjIzODU4IDcgMTIgN0MxNC43NjE0IDcgMTcgOS4yMzg1OCAxNyAxMkMxNyAxNC43NjE0IDE0Ljc2MTQgMTcgMTIgMTdaXCJcclxuICAgICAgICBzdHJva2U9e3N0cm9rZX1cclxuICAgICAgICBzdHJva2VXaWR0aD1cIjJcIlxyXG4gICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXHJcbiAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXHJcbiAgICAgIC8+XHJcbiAgICA8L2c+XHJcbiAgPC9zdmc+XHJcbik7XHJcblxyXG5leHBvcnQgY29uc3QgU3VuSWNvbiA9IChwcm9wcykgPT4gKFxyXG4gIDxJY29uIGNvbXBvbmVudD17KCkgPT4gU3VuU3ZnKHByb3BzLnN0cm9rZSl9IHsuLi5wcm9wc30gLz5cclxuKTtcclxuIl0sImZpbGUiOiIvaG9tZS9kaGFybWEvV29yay9yZWFjdC1ib2lsZXJwbGF0ZS9zcmMvYXNzZXRzL3N2Zy9zdW5TdmcuanN4In0=