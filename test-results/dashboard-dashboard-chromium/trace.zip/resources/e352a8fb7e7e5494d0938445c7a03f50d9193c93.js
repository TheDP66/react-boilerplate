import {
  require_react_dom
} from "/node_modules/.vite/deps/chunk-GSZ7ISAW.js?v=97c9eb9a";
import {
  _arrayLikeToArray,
  _arrayWithHoles,
  _nonIterableRest,
  _objectWithoutProperties,
  _slicedToArray,
  _unsupportedIterableToArray,
  canUseDom,
  fillRef,
  init_arrayLikeToArray,
  init_arrayWithHoles,
  init_canUseDom,
  init_dynamicCSS,
  init_nonIterableRest,
  init_objectWithoutProperties,
  init_ref,
  init_slicedToArray,
  init_unsupportedIterableToArray,
  init_useMemo,
  init_warning,
  removeCSS,
  require_classnames,
  supportRef,
  updateCSS,
  useMemo,
  warning,
  warning_default
} from "/node_modules/.vite/deps/chunk-7WPSNT37.js?v=97c9eb9a";
import {
  _extends,
  init_extends
} from "/node_modules/.vite/deps/chunk-VLJ7Q36Z.js?v=97c9eb9a";
import {
  _defineProperty,
  _objectSpread2,
  _toPropertyKey,
  _typeof,
  init_defineProperty,
  init_objectSpread2,
  init_toPropertyKey,
  init_typeof
} from "/node_modules/.vite/deps/chunk-3QQTPB3K.js?v=97c9eb9a";
import {
  require_react
} from "/node_modules/.vite/deps/chunk-ZGRSIX2Q.js?v=97c9eb9a";
import {
  __esm,
  __export,
  __toESM
} from "/node_modules/.vite/deps/chunk-ROME4SDB.js?v=97c9eb9a";

// node_modules/@babel/runtime/helpers/esm/arrayWithoutHoles.js
function _arrayWithoutHoles(arr) {
  if (Array.isArray(arr))
    return _arrayLikeToArray(arr);
}
var init_arrayWithoutHoles = __esm({
  "node_modules/@babel/runtime/helpers/esm/arrayWithoutHoles.js"() {
    init_arrayLikeToArray();
  }
});

// node_modules/@babel/runtime/helpers/esm/iterableToArray.js
function _iterableToArray(iter) {
  if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null)
    return Array.from(iter);
}
var init_iterableToArray = __esm({
  "node_modules/@babel/runtime/helpers/esm/iterableToArray.js"() {
  }
});

// node_modules/@babel/runtime/helpers/esm/nonIterableSpread.js
function _nonIterableSpread() {
  throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
var init_nonIterableSpread = __esm({
  "node_modules/@babel/runtime/helpers/esm/nonIterableSpread.js"() {
  }
});

// node_modules/@babel/runtime/helpers/esm/toConsumableArray.js
function _toConsumableArray(arr) {
  return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread();
}
var init_toConsumableArray = __esm({
  "node_modules/@babel/runtime/helpers/esm/toConsumableArray.js"() {
    init_arrayWithoutHoles();
    init_iterableToArray();
    init_unsupportedIterableToArray();
    init_nonIterableSpread();
  }
});

// node_modules/@babel/runtime/helpers/esm/classCallCheck.js
function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
var init_classCallCheck = __esm({
  "node_modules/@babel/runtime/helpers/esm/classCallCheck.js"() {
  }
});

// node_modules/@babel/runtime/helpers/esm/createClass.js
function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor)
      descriptor.writable = true;
    Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor);
  }
}
function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps)
    _defineProperties(Constructor.prototype, protoProps);
  if (staticProps)
    _defineProperties(Constructor, staticProps);
  Object.defineProperty(Constructor, "prototype", {
    writable: false
  });
  return Constructor;
}
var init_createClass = __esm({
  "node_modules/@babel/runtime/helpers/esm/createClass.js"() {
    init_toPropertyKey();
  }
});

// node_modules/@ant-design/cssinjs/es/theme/ThemeCache.js
function sameDerivativeOption(left, right) {
  if (left.length !== right.length) {
    return false;
  }
  for (var i = 0; i < left.length; i++) {
    if (left[i] !== right[i]) {
      return false;
    }
  }
  return true;
}
var ThemeCache;
var init_ThemeCache = __esm({
  "node_modules/@ant-design/cssinjs/es/theme/ThemeCache.js"() {
    init_slicedToArray();
    init_classCallCheck();
    init_createClass();
    init_defineProperty();
    ThemeCache = function() {
      function ThemeCache2() {
        _classCallCheck(this, ThemeCache2);
        _defineProperty(this, "cache", void 0);
        _defineProperty(this, "keys", void 0);
        _defineProperty(this, "cacheCallTimes", void 0);
        this.cache = /* @__PURE__ */ new Map();
        this.keys = [];
        this.cacheCallTimes = 0;
      }
      _createClass(ThemeCache2, [{
        key: "size",
        value: function size() {
          return this.keys.length;
        }
      }, {
        key: "internalGet",
        value: function internalGet(derivativeOption) {
          var _cache2, _cache3;
          var updateCallTimes = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : false;
          var cache = {
            map: this.cache
          };
          derivativeOption.forEach(function(derivative) {
            if (!cache) {
              cache = void 0;
            } else {
              var _cache, _cache$map;
              cache = (_cache = cache) === null || _cache === void 0 ? void 0 : (_cache$map = _cache.map) === null || _cache$map === void 0 ? void 0 : _cache$map.get(derivative);
            }
          });
          if ((_cache2 = cache) !== null && _cache2 !== void 0 && _cache2.value && updateCallTimes) {
            cache.value[1] = this.cacheCallTimes++;
          }
          return (_cache3 = cache) === null || _cache3 === void 0 ? void 0 : _cache3.value;
        }
      }, {
        key: "get",
        value: function get2(derivativeOption) {
          var _this$internalGet;
          return (_this$internalGet = this.internalGet(derivativeOption, true)) === null || _this$internalGet === void 0 ? void 0 : _this$internalGet[0];
        }
      }, {
        key: "has",
        value: function has(derivativeOption) {
          return !!this.internalGet(derivativeOption);
        }
      }, {
        key: "set",
        value: function set2(derivativeOption, value) {
          var _this = this;
          if (!this.has(derivativeOption)) {
            if (this.size() + 1 > ThemeCache2.MAX_CACHE_SIZE + ThemeCache2.MAX_CACHE_OFFSET) {
              var _this$keys$reduce = this.keys.reduce(function(result, key) {
                var _result = _slicedToArray(result, 2), callTimes = _result[1];
                if (_this.internalGet(key)[1] < callTimes) {
                  return [key, _this.internalGet(key)[1]];
                }
                return result;
              }, [this.keys[0], this.cacheCallTimes]), _this$keys$reduce2 = _slicedToArray(_this$keys$reduce, 1), targetKey = _this$keys$reduce2[0];
              this.delete(targetKey);
            }
            this.keys.push(derivativeOption);
          }
          var cache = this.cache;
          derivativeOption.forEach(function(derivative, index) {
            if (index === derivativeOption.length - 1) {
              cache.set(derivative, {
                value: [value, _this.cacheCallTimes++]
              });
            } else {
              var cacheValue = cache.get(derivative);
              if (!cacheValue) {
                cache.set(derivative, {
                  map: /* @__PURE__ */ new Map()
                });
              } else if (!cacheValue.map) {
                cacheValue.map = /* @__PURE__ */ new Map();
              }
              cache = cache.get(derivative).map;
            }
          });
        }
      }, {
        key: "deleteByPath",
        value: function deleteByPath(currentCache, derivatives) {
          var cache = currentCache.get(derivatives[0]);
          if (derivatives.length === 1) {
            var _cache$value;
            if (!cache.map) {
              currentCache.delete(derivatives[0]);
            } else {
              currentCache.set(derivatives[0], {
                map: cache.map
              });
            }
            return (_cache$value = cache.value) === null || _cache$value === void 0 ? void 0 : _cache$value[0];
          }
          var result = this.deleteByPath(cache.map, derivatives.slice(1));
          if ((!cache.map || cache.map.size === 0) && !cache.value) {
            currentCache.delete(derivatives[0]);
          }
          return result;
        }
      }, {
        key: "delete",
        value: function _delete(derivativeOption) {
          if (this.has(derivativeOption)) {
            this.keys = this.keys.filter(function(item) {
              return !sameDerivativeOption(item, derivativeOption);
            });
            return this.deleteByPath(this.cache, derivativeOption);
          }
          return void 0;
        }
      }]);
      return ThemeCache2;
    }();
    _defineProperty(ThemeCache, "MAX_CACHE_SIZE", 20);
    _defineProperty(ThemeCache, "MAX_CACHE_OFFSET", 5);
  }
});

// node_modules/@ant-design/cssinjs/es/theme/Theme.js
var uuid, Theme;
var init_Theme = __esm({
  "node_modules/@ant-design/cssinjs/es/theme/Theme.js"() {
    init_classCallCheck();
    init_createClass();
    init_defineProperty();
    init_warning();
    uuid = 0;
    Theme = function() {
      function Theme2(derivatives) {
        _classCallCheck(this, Theme2);
        _defineProperty(this, "derivatives", void 0);
        _defineProperty(this, "id", void 0);
        this.derivatives = Array.isArray(derivatives) ? derivatives : [derivatives];
        this.id = uuid;
        if (derivatives.length === 0) {
          warning(derivatives.length > 0, "[Ant Design CSS-in-JS] Theme should have at least one derivative function.");
        }
        uuid += 1;
      }
      _createClass(Theme2, [{
        key: "getDerivativeToken",
        value: function getDerivativeToken(token2) {
          return this.derivatives.reduce(function(result, derivative) {
            return derivative(token2, result);
          }, void 0);
        }
      }]);
      return Theme2;
    }();
  }
});

// node_modules/@ant-design/cssinjs/es/theme/createTheme.js
function createTheme(derivatives) {
  var derivativeArr = Array.isArray(derivatives) ? derivatives : [derivatives];
  if (!cacheThemes.has(derivativeArr)) {
    cacheThemes.set(derivativeArr, new Theme(derivativeArr));
  }
  return cacheThemes.get(derivativeArr);
}
var cacheThemes;
var init_createTheme = __esm({
  "node_modules/@ant-design/cssinjs/es/theme/createTheme.js"() {
    init_ThemeCache();
    init_Theme();
    cacheThemes = new ThemeCache();
  }
});

// node_modules/@ant-design/cssinjs/es/theme/index.js
var init_theme = __esm({
  "node_modules/@ant-design/cssinjs/es/theme/index.js"() {
    init_createTheme();
    init_Theme();
    init_ThemeCache();
  }
});

// node_modules/@emotion/hash/dist/hash.browser.esm.js
function murmur2(str) {
  var h = 0;
  var k, i = 0, len = str.length;
  for (; len >= 4; ++i, len -= 4) {
    k = str.charCodeAt(i) & 255 | (str.charCodeAt(++i) & 255) << 8 | (str.charCodeAt(++i) & 255) << 16 | (str.charCodeAt(++i) & 255) << 24;
    k = /* Math.imul(k, m): */
    (k & 65535) * 1540483477 + ((k >>> 16) * 59797 << 16);
    k ^= /* k >>> r: */
    k >>> 24;
    h = /* Math.imul(k, m): */
    (k & 65535) * 1540483477 + ((k >>> 16) * 59797 << 16) ^ /* Math.imul(h, m): */
    (h & 65535) * 1540483477 + ((h >>> 16) * 59797 << 16);
  }
  switch (len) {
    case 3:
      h ^= (str.charCodeAt(i + 2) & 255) << 16;
    case 2:
      h ^= (str.charCodeAt(i + 1) & 255) << 8;
    case 1:
      h ^= str.charCodeAt(i) & 255;
      h = /* Math.imul(h, m): */
      (h & 65535) * 1540483477 + ((h >>> 16) * 59797 << 16);
  }
  h ^= h >>> 13;
  h = /* Math.imul(h, m): */
  (h & 65535) * 1540483477 + ((h >>> 16) * 59797 << 16);
  return ((h ^ h >>> 15) >>> 0).toString(36);
}
var hash_browser_esm_default;
var init_hash_browser_esm = __esm({
  "node_modules/@emotion/hash/dist/hash.browser.esm.js"() {
    hash_browser_esm_default = murmur2;
  }
});

// node_modules/rc-util/es/isEqual.js
function isEqual(obj1, obj2) {
  var shallow = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : false;
  var refSet = /* @__PURE__ */ new Set();
  function deepEqual(a, b) {
    var level = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 1;
    var circular = refSet.has(a);
    warning_default(!circular, "Warning: There may be circular references");
    if (circular) {
      return false;
    }
    if (a === b) {
      return true;
    }
    if (shallow && level > 1) {
      return false;
    }
    refSet.add(a);
    var newLevel = level + 1;
    if (Array.isArray(a)) {
      if (!Array.isArray(b) || a.length !== b.length) {
        return false;
      }
      for (var i = 0; i < a.length; i++) {
        if (!deepEqual(a[i], b[i], newLevel)) {
          return false;
        }
      }
      return true;
    }
    if (a && b && _typeof(a) === "object" && _typeof(b) === "object") {
      var keys = Object.keys(a);
      if (keys.length !== Object.keys(b).length) {
        return false;
      }
      return keys.every(function(key) {
        return deepEqual(a[key], b[key], newLevel);
      });
    }
    return false;
  }
  return deepEqual(obj1, obj2);
}
var isEqual_default;
var init_isEqual = __esm({
  "node_modules/rc-util/es/isEqual.js"() {
    init_typeof();
    init_warning();
    isEqual_default = isEqual;
  }
});

// node_modules/@ant-design/cssinjs/es/Cache.js
var Entity, Cache_default;
var init_Cache = __esm({
  "node_modules/@ant-design/cssinjs/es/Cache.js"() {
    init_classCallCheck();
    init_createClass();
    init_defineProperty();
    Entity = function() {
      function Entity2(instanceId) {
        _classCallCheck(this, Entity2);
        _defineProperty(this, "instanceId", void 0);
        _defineProperty(this, "cache", /* @__PURE__ */ new Map());
        this.instanceId = instanceId;
      }
      _createClass(Entity2, [{
        key: "get",
        value: function get2(keys) {
          return this.cache.get(keys.join("%")) || null;
        }
      }, {
        key: "update",
        value: function update(keys, valueFn) {
          var path = keys.join("%");
          var prevValue = this.cache.get(path);
          var nextValue = valueFn(prevValue);
          if (nextValue === null) {
            this.cache.delete(path);
          } else {
            this.cache.set(path, nextValue);
          }
        }
      }]);
      return Entity2;
    }();
    Cache_default = Entity;
  }
});

// node_modules/@ant-design/cssinjs/es/StyleContext.js
function createCache() {
  var cssinjsInstanceId = Math.random().toString(12).slice(2);
  if (typeof document !== "undefined" && document.head && document.body) {
    var styles = document.body.querySelectorAll("style[".concat(ATTR_MARK, "]")) || [];
    var firstChild = document.head.firstChild;
    Array.from(styles).forEach(function(style2) {
      style2[CSS_IN_JS_INSTANCE] = style2[CSS_IN_JS_INSTANCE] || cssinjsInstanceId;
      if (style2[CSS_IN_JS_INSTANCE] === cssinjsInstanceId) {
        document.head.insertBefore(style2, firstChild);
      }
    });
    var styleHash = {};
    Array.from(document.querySelectorAll("style[".concat(ATTR_MARK, "]"))).forEach(function(style2) {
      var hash2 = style2.getAttribute(ATTR_MARK);
      if (styleHash[hash2]) {
        if (style2[CSS_IN_JS_INSTANCE] === cssinjsInstanceId) {
          var _style$parentNode;
          (_style$parentNode = style2.parentNode) === null || _style$parentNode === void 0 ? void 0 : _style$parentNode.removeChild(style2);
        }
      } else {
        styleHash[hash2] = true;
      }
    });
  }
  return new Cache_default(cssinjsInstanceId);
}
var React, _excluded, ATTR_TOKEN, ATTR_MARK, ATTR_DEV_CACHE_PATH, CSS_IN_JS_INSTANCE, StyleContext, StyleProvider, StyleContext_default;
var init_StyleContext = __esm({
  "node_modules/@ant-design/cssinjs/es/StyleContext.js"() {
    init_objectSpread2();
    init_objectWithoutProperties();
    init_useMemo();
    init_isEqual();
    React = __toESM(require_react());
    init_Cache();
    _excluded = ["children"];
    ATTR_TOKEN = "data-token-hash";
    ATTR_MARK = "data-css-hash";
    ATTR_DEV_CACHE_PATH = "data-dev-cache-path";
    CSS_IN_JS_INSTANCE = "__cssinjs_instance__";
    StyleContext = React.createContext({
      hashPriority: "low",
      cache: createCache(),
      defaultCache: true
    });
    StyleProvider = function StyleProvider2(props) {
      var children = props.children, restProps = _objectWithoutProperties(props, _excluded);
      var parentContext = React.useContext(StyleContext);
      var context = useMemo(function() {
        var mergedContext = _objectSpread2({}, parentContext);
        Object.keys(restProps).forEach(function(key) {
          var value = restProps[key];
          if (restProps[key] !== void 0) {
            mergedContext[key] = value;
          }
        });
        var cache = restProps.cache;
        mergedContext.cache = mergedContext.cache || createCache();
        mergedContext.defaultCache = !cache && parentContext.defaultCache;
        return mergedContext;
      }, [parentContext, restProps], function(prev2, next2) {
        return !isEqual_default(prev2[0], next2[0], true) || !isEqual_default(prev2[1], next2[1], true);
      });
      return React.createElement(StyleContext.Provider, {
        value: context
      }, children);
    };
    StyleContext_default = StyleContext;
  }
});

// node_modules/@ant-design/cssinjs/es/util.js
function flattenToken(token2) {
  var str = "";
  Object.keys(token2).forEach(function(key) {
    var value = token2[key];
    str += key;
    if (value && _typeof(value) === "object") {
      str += flattenToken(value);
    } else {
      str += value;
    }
  });
  return str;
}
function token2key(token2, salt) {
  return hash_browser_esm_default("".concat(salt, "_").concat(flattenToken(token2)));
}
function supportSelector(styleStr, handleElement) {
  if (canUseDom()) {
    var _ele$parentNode;
    updateCSS(styleStr, layerKey);
    var _ele = document.createElement("div");
    _ele.style.position = "fixed";
    _ele.style.left = "0";
    _ele.style.top = "0";
    handleElement === null || handleElement === void 0 ? void 0 : handleElement(_ele);
    document.body.appendChild(_ele);
    if (true) {
      _ele.innerHTML = "Test";
      _ele.style.zIndex = "9999999";
    }
    var support = getComputedStyle(_ele).width === layerWidth;
    (_ele$parentNode = _ele.parentNode) === null || _ele$parentNode === void 0 ? void 0 : _ele$parentNode.removeChild(_ele);
    removeCSS(layerKey);
    return support;
  }
  return false;
}
function supportLayer() {
  if (canLayer === void 0) {
    canLayer = supportSelector("@layer ".concat(layerKey, " { .").concat(layerKey, " { width: ").concat(layerWidth, "!important; } }"), function(ele) {
      ele.className = layerKey;
    });
  }
  return canLayer;
}
var layerKey, layerWidth, canLayer;
var init_util = __esm({
  "node_modules/@ant-design/cssinjs/es/util.js"() {
    init_typeof();
    init_hash_browser_esm();
    init_canUseDom();
    init_dynamicCSS();
    layerKey = "layer-".concat(Date.now(), "-").concat(Math.random()).replace(/\./g, "");
    layerWidth = "903px";
    canLayer = void 0;
  }
});

// node_modules/@ant-design/cssinjs/es/hooks/useHMR.js
function useDevHMR() {
  return webpackHMR;
}
var webpackHMR, useHMR_default, win, originWebpackHotUpdate;
var init_useHMR = __esm({
  "node_modules/@ant-design/cssinjs/es/hooks/useHMR.js"() {
    webpackHMR = false;
    useHMR_default = false ? useProdHMR : useDevHMR;
    if (typeof module !== "undefined" && module && module.hot) {
      win = window;
      if (typeof win.webpackHotUpdate === "function") {
        originWebpackHotUpdate = win.webpackHotUpdate;
        win.webpackHotUpdate = function() {
          webpackHMR = true;
          setTimeout(function() {
            webpackHMR = false;
          }, 0);
          return originWebpackHotUpdate.apply(void 0, arguments);
        };
      }
    }
  }
});

// node_modules/@ant-design/cssinjs/es/hooks/useGlobalCache.js
function useClientCache(prefix2, keyPath, cacheFn, onCacheRemove) {
  var _React$useContext = React2.useContext(StyleContext_default), globalCache = _React$useContext.cache;
  var fullPath = [prefix2].concat(_toConsumableArray(keyPath));
  var HMRUpdate = useHMR_default();
  React2.useMemo(
    function() {
      globalCache.update(fullPath, function(prevCache) {
        var _ref = prevCache || [], _ref2 = _slicedToArray(_ref, 2), _ref2$ = _ref2[0], times = _ref2$ === void 0 ? 0 : _ref2$, cache = _ref2[1];
        var tmpCache = cache;
        if (cache && HMRUpdate) {
          onCacheRemove === null || onCacheRemove === void 0 ? void 0 : onCacheRemove(tmpCache, HMRUpdate);
          tmpCache = null;
        }
        var mergedCache = tmpCache || cacheFn();
        return [times + 1, mergedCache];
      });
    },
    /* eslint-disable react-hooks/exhaustive-deps */
    [fullPath.join("_")]
    /* eslint-enable */
  );
  React2.useEffect(function() {
    return function() {
      globalCache.update(fullPath, function(prevCache) {
        var _ref3 = prevCache || [], _ref4 = _slicedToArray(_ref3, 2), _ref4$ = _ref4[0], times = _ref4$ === void 0 ? 0 : _ref4$, cache = _ref4[1];
        var nextCount = times - 1;
        if (nextCount === 0) {
          onCacheRemove === null || onCacheRemove === void 0 ? void 0 : onCacheRemove(cache, false);
          return null;
        }
        return [times - 1, cache];
      });
    };
  }, fullPath);
  return globalCache.get(fullPath)[1];
}
var React2;
var init_useGlobalCache = __esm({
  "node_modules/@ant-design/cssinjs/es/hooks/useGlobalCache.js"() {
    init_slicedToArray();
    init_toConsumableArray();
    React2 = __toESM(require_react());
    init_StyleContext();
    init_useHMR();
  }
});

// node_modules/@ant-design/cssinjs/es/hooks/useCacheToken.js
function recordCleanToken(tokenKey) {
  tokenKeys.set(tokenKey, (tokenKeys.get(tokenKey) || 0) + 1);
}
function removeStyleTags(key, instanceId) {
  if (typeof document !== "undefined") {
    var styles = document.querySelectorAll("style[".concat(ATTR_TOKEN, '="').concat(key, '"]'));
    styles.forEach(function(style2) {
      if (style2[CSS_IN_JS_INSTANCE] === instanceId) {
        var _style$parentNode;
        (_style$parentNode = style2.parentNode) === null || _style$parentNode === void 0 ? void 0 : _style$parentNode.removeChild(style2);
      }
    });
  }
}
function cleanTokenStyle(tokenKey, instanceId) {
  tokenKeys.set(tokenKey, (tokenKeys.get(tokenKey) || 0) - 1);
  var tokenKeyList = Array.from(tokenKeys.keys());
  var cleanableKeyList = tokenKeyList.filter(function(key) {
    var count = tokenKeys.get(key) || 0;
    return count <= 0;
  });
  if (cleanableKeyList.length < tokenKeyList.length) {
    cleanableKeyList.forEach(function(key) {
      removeStyleTags(key, instanceId);
      tokenKeys.delete(key);
    });
  }
}
function useCacheToken(theme, tokens) {
  var option = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
  var _useContext = (0, import_react.useContext)(StyleContext_default), instanceId = _useContext.cache.instanceId;
  var _option$salt = option.salt, salt = _option$salt === void 0 ? "" : _option$salt, _option$override = option.override, override = _option$override === void 0 ? EMPTY_OVERRIDE : _option$override, formatToken = option.formatToken;
  var mergedToken = React3.useMemo(function() {
    return Object.assign.apply(Object, [{}].concat(_toConsumableArray(tokens)));
  }, [tokens]);
  var tokenStr = React3.useMemo(function() {
    return flattenToken(mergedToken);
  }, [mergedToken]);
  var overrideTokenStr = React3.useMemo(function() {
    return flattenToken(override);
  }, [override]);
  var cachedToken = useClientCache("token", [salt, theme.id, tokenStr, overrideTokenStr], function() {
    var mergedDerivativeToken = getComputedToken(mergedToken, override, theme, formatToken);
    var tokenKey = token2key(mergedDerivativeToken, salt);
    mergedDerivativeToken._tokenKey = tokenKey;
    recordCleanToken(tokenKey);
    var hashId = "".concat(hashPrefix, "-").concat(hash_browser_esm_default(tokenKey));
    mergedDerivativeToken._hashId = hashId;
    return [mergedDerivativeToken, hashId];
  }, function(cache) {
    cleanTokenStyle(cache[0]._tokenKey, instanceId);
  });
  return cachedToken;
}
var React3, import_react, EMPTY_OVERRIDE, hashPrefix, tokenKeys, getComputedToken;
var init_useCacheToken = __esm({
  "node_modules/@ant-design/cssinjs/es/hooks/useCacheToken.js"() {
    init_toConsumableArray();
    init_objectSpread2();
    init_hash_browser_esm();
    React3 = __toESM(require_react());
    import_react = __toESM(require_react());
    init_StyleContext();
    init_util();
    init_useGlobalCache();
    EMPTY_OVERRIDE = {};
    hashPrefix = true ? "css-dev-only-do-not-override" : "css";
    tokenKeys = /* @__PURE__ */ new Map();
    getComputedToken = function getComputedToken2(originToken, overrideToken, theme, format) {
      var derivativeToken = theme.getDerivativeToken(originToken);
      var mergedDerivativeToken = _objectSpread2(_objectSpread2({}, derivativeToken), overrideToken);
      if (format) {
        mergedDerivativeToken = format(mergedDerivativeToken);
      }
      return mergedDerivativeToken;
    };
  }
});

// node_modules/@emotion/unitless/dist/unitless.browser.esm.js
var unitlessKeys, unitless_browser_esm_default;
var init_unitless_browser_esm = __esm({
  "node_modules/@emotion/unitless/dist/unitless.browser.esm.js"() {
    unitlessKeys = {
      animationIterationCount: 1,
      borderImageOutset: 1,
      borderImageSlice: 1,
      borderImageWidth: 1,
      boxFlex: 1,
      boxFlexGroup: 1,
      boxOrdinalGroup: 1,
      columnCount: 1,
      columns: 1,
      flex: 1,
      flexGrow: 1,
      flexPositive: 1,
      flexShrink: 1,
      flexNegative: 1,
      flexOrder: 1,
      gridRow: 1,
      gridRowEnd: 1,
      gridRowSpan: 1,
      gridRowStart: 1,
      gridColumn: 1,
      gridColumnEnd: 1,
      gridColumnSpan: 1,
      gridColumnStart: 1,
      msGridRow: 1,
      msGridRowSpan: 1,
      msGridColumn: 1,
      msGridColumnSpan: 1,
      fontWeight: 1,
      lineHeight: 1,
      opacity: 1,
      order: 1,
      orphans: 1,
      tabSize: 1,
      widows: 1,
      zIndex: 1,
      zoom: 1,
      WebkitLineClamp: 1,
      // SVG-related properties
      fillOpacity: 1,
      floodOpacity: 1,
      stopOpacity: 1,
      strokeDasharray: 1,
      strokeDashoffset: 1,
      strokeMiterlimit: 1,
      strokeOpacity: 1,
      strokeWidth: 1
    };
    unitless_browser_esm_default = unitlessKeys;
  }
});

// node_modules/stylis/src/Enum.js
var COMMENT, RULESET, DECLARATION, IMPORT, KEYFRAMES, LAYER;
var init_Enum = __esm({
  "node_modules/stylis/src/Enum.js"() {
    COMMENT = "comm";
    RULESET = "rule";
    DECLARATION = "decl";
    IMPORT = "@import";
    KEYFRAMES = "@keyframes";
    LAYER = "@layer";
  }
});

// node_modules/stylis/src/Utility.js
function trim(value) {
  return value.trim();
}
function replace(value, pattern, replacement) {
  return value.replace(pattern, replacement);
}
function indexof(value, search) {
  return value.indexOf(search);
}
function charat(value, index) {
  return value.charCodeAt(index) | 0;
}
function substr(value, begin, end) {
  return value.slice(begin, end);
}
function strlen(value) {
  return value.length;
}
function sizeof(value) {
  return value.length;
}
function append(value, array) {
  return array.push(value), value;
}
var abs, from;
var init_Utility = __esm({
  "node_modules/stylis/src/Utility.js"() {
    abs = Math.abs;
    from = String.fromCharCode;
  }
});

// node_modules/stylis/src/Tokenizer.js
function node(value, root, parent, type, props, children, length2) {
  return { value, root, parent, type, props, children, line, column, length: length2, return: "" };
}
function char() {
  return character;
}
function prev() {
  character = position > 0 ? charat(characters, --position) : 0;
  if (column--, character === 10)
    column = 1, line--;
  return character;
}
function next() {
  character = position < length ? charat(characters, position++) : 0;
  if (column++, character === 10)
    column = 1, line++;
  return character;
}
function peek() {
  return charat(characters, position);
}
function caret() {
  return position;
}
function slice(begin, end) {
  return substr(characters, begin, end);
}
function token(type) {
  switch (type) {
    case 0:
    case 9:
    case 10:
    case 13:
    case 32:
      return 5;
    case 33:
    case 43:
    case 44:
    case 47:
    case 62:
    case 64:
    case 126:
    case 59:
    case 123:
    case 125:
      return 4;
    case 58:
      return 3;
    case 34:
    case 39:
    case 40:
    case 91:
      return 2;
    case 41:
    case 93:
      return 1;
  }
  return 0;
}
function alloc(value) {
  return line = column = 1, length = strlen(characters = value), position = 0, [];
}
function dealloc(value) {
  return characters = "", value;
}
function delimit(type) {
  return trim(slice(position - 1, delimiter(type === 91 ? type + 2 : type === 40 ? type + 1 : type)));
}
function whitespace(type) {
  while (character = peek())
    if (character < 33)
      next();
    else
      break;
  return token(type) > 2 || token(character) > 3 ? "" : " ";
}
function escaping(index, count) {
  while (--count && next())
    if (character < 48 || character > 102 || character > 57 && character < 65 || character > 70 && character < 97)
      break;
  return slice(index, caret() + (count < 6 && peek() == 32 && next() == 32));
}
function delimiter(type) {
  while (next())
    switch (character) {
      case type:
        return position;
      case 34:
      case 39:
        if (type !== 34 && type !== 39)
          delimiter(character);
        break;
      case 40:
        if (type === 41)
          delimiter(type);
        break;
      case 92:
        next();
        break;
    }
  return position;
}
function commenter(type, index) {
  while (next())
    if (type + character === 47 + 10)
      break;
    else if (type + character === 42 + 42 && peek() === 47)
      break;
  return "/*" + slice(index, position - 1) + "*" + from(type === 47 ? type : next());
}
function identifier(index) {
  while (!token(peek()))
    next();
  return slice(index, position);
}
var line, column, length, position, character, characters;
var init_Tokenizer = __esm({
  "node_modules/stylis/src/Tokenizer.js"() {
    init_Utility();
    line = 1;
    column = 1;
    length = 0;
    position = 0;
    character = 0;
    characters = "";
  }
});

// node_modules/stylis/src/Parser.js
function compile(value) {
  return dealloc(parse("", null, null, null, [""], value = alloc(value), 0, [0], value));
}
function parse(value, root, parent, rule, rules, rulesets, pseudo, points, declarations) {
  var index = 0;
  var offset = 0;
  var length2 = pseudo;
  var atrule = 0;
  var property = 0;
  var previous = 0;
  var variable = 1;
  var scanning = 1;
  var ampersand = 1;
  var character2 = 0;
  var type = "";
  var props = rules;
  var children = rulesets;
  var reference = rule;
  var characters2 = type;
  while (scanning)
    switch (previous = character2, character2 = next()) {
      case 40:
        if (previous != 108 && charat(characters2, length2 - 1) == 58) {
          if (indexof(characters2 += replace(delimit(character2), "&", "&\f"), "&\f") != -1)
            ampersand = -1;
          break;
        }
      case 34:
      case 39:
      case 91:
        characters2 += delimit(character2);
        break;
      case 9:
      case 10:
      case 13:
      case 32:
        characters2 += whitespace(previous);
        break;
      case 92:
        characters2 += escaping(caret() - 1, 7);
        continue;
      case 47:
        switch (peek()) {
          case 42:
          case 47:
            append(comment(commenter(next(), caret()), root, parent), declarations);
            break;
          default:
            characters2 += "/";
        }
        break;
      case 123 * variable:
        points[index++] = strlen(characters2) * ampersand;
      case 125 * variable:
      case 59:
      case 0:
        switch (character2) {
          case 0:
          case 125:
            scanning = 0;
          case 59 + offset:
            if (ampersand == -1)
              characters2 = replace(characters2, /\f/g, "");
            if (property > 0 && strlen(characters2) - length2)
              append(property > 32 ? declaration(characters2 + ";", rule, parent, length2 - 1) : declaration(replace(characters2, " ", "") + ";", rule, parent, length2 - 2), declarations);
            break;
          case 59:
            characters2 += ";";
          default:
            append(reference = ruleset(characters2, root, parent, index, offset, rules, points, type, props = [], children = [], length2), rulesets);
            if (character2 === 123)
              if (offset === 0)
                parse(characters2, root, reference, reference, props, rulesets, length2, points, children);
              else
                switch (atrule === 99 && charat(characters2, 3) === 110 ? 100 : atrule) {
                  case 100:
                  case 108:
                  case 109:
                  case 115:
                    parse(value, reference, reference, rule && append(ruleset(value, reference, reference, 0, 0, rules, points, type, rules, props = [], length2), children), rules, children, length2, points, rule ? props : children);
                    break;
                  default:
                    parse(characters2, reference, reference, reference, [""], children, 0, points, children);
                }
        }
        index = offset = property = 0, variable = ampersand = 1, type = characters2 = "", length2 = pseudo;
        break;
      case 58:
        length2 = 1 + strlen(characters2), property = previous;
      default:
        if (variable < 1) {
          if (character2 == 123)
            --variable;
          else if (character2 == 125 && variable++ == 0 && prev() == 125)
            continue;
        }
        switch (characters2 += from(character2), character2 * variable) {
          case 38:
            ampersand = offset > 0 ? 1 : (characters2 += "\f", -1);
            break;
          case 44:
            points[index++] = (strlen(characters2) - 1) * ampersand, ampersand = 1;
            break;
          case 64:
            if (peek() === 45)
              characters2 += delimit(next());
            atrule = peek(), offset = length2 = strlen(type = characters2 += identifier(caret())), character2++;
            break;
          case 45:
            if (previous === 45 && strlen(characters2) == 2)
              variable = 0;
        }
    }
  return rulesets;
}
function ruleset(value, root, parent, index, offset, rules, points, type, props, children, length2) {
  var post = offset - 1;
  var rule = offset === 0 ? rules : [""];
  var size = sizeof(rule);
  for (var i = 0, j = 0, k = 0; i < index; ++i)
    for (var x = 0, y = substr(value, post + 1, post = abs(j = points[i])), z = value; x < size; ++x)
      if (z = trim(j > 0 ? rule[x] + " " + y : replace(y, /&\f/g, rule[x])))
        props[k++] = z;
  return node(value, root, parent, offset === 0 ? RULESET : type, props, children, length2);
}
function comment(value, root, parent) {
  return node(value, root, parent, COMMENT, from(char()), substr(value, 2, -2), 0);
}
function declaration(value, root, parent, length2) {
  return node(value, root, parent, DECLARATION, substr(value, 0, length2), substr(value, length2 + 1, -1), length2);
}
var init_Parser = __esm({
  "node_modules/stylis/src/Parser.js"() {
    init_Enum();
    init_Utility();
    init_Tokenizer();
  }
});

// node_modules/stylis/src/Prefixer.js
var init_Prefixer = __esm({
  "node_modules/stylis/src/Prefixer.js"() {
    init_Enum();
    init_Utility();
  }
});

// node_modules/stylis/src/Serializer.js
function serialize(children, callback) {
  var output = "";
  var length2 = sizeof(children);
  for (var i = 0; i < length2; i++)
    output += callback(children[i], i, children, callback) || "";
  return output;
}
function stringify(element, index, children, callback) {
  switch (element.type) {
    case LAYER:
      if (element.children.length)
        break;
    case IMPORT:
    case DECLARATION:
      return element.return = element.return || element.value;
    case COMMENT:
      return "";
    case KEYFRAMES:
      return element.return = element.value + "{" + serialize(element.children, callback) + "}";
    case RULESET:
      element.value = element.props.join(",");
  }
  return strlen(children = serialize(element.children, callback)) ? element.return = element.value + "{" + children + "}" : "";
}
var init_Serializer = __esm({
  "node_modules/stylis/src/Serializer.js"() {
    init_Enum();
    init_Utility();
  }
});

// node_modules/stylis/src/Middleware.js
var init_Middleware = __esm({
  "node_modules/stylis/src/Middleware.js"() {
    init_Enum();
    init_Utility();
    init_Tokenizer();
    init_Serializer();
    init_Prefixer();
  }
});

// node_modules/stylis/index.js
var init_stylis = __esm({
  "node_modules/stylis/index.js"() {
    init_Enum();
    init_Utility();
    init_Parser();
    init_Prefixer();
    init_Tokenizer();
    init_Serializer();
    init_Middleware();
  }
});

// node_modules/@ant-design/cssinjs/es/linters/utils.js
function lintWarning(message, info) {
  var path = info.path, parentSelectors = info.parentSelectors;
  warning_default(false, "[Ant Design CSS-in-JS] ".concat(path ? "Error in ".concat(path, ": ") : "").concat(message).concat(parentSelectors.length ? " Selector: ".concat(parentSelectors.join(" | ")) : ""));
}
var init_utils = __esm({
  "node_modules/@ant-design/cssinjs/es/linters/utils.js"() {
    init_warning();
  }
});

// node_modules/@ant-design/cssinjs/es/linters/contentQuotesLinter.js
var linter, contentQuotesLinter_default;
var init_contentQuotesLinter = __esm({
  "node_modules/@ant-design/cssinjs/es/linters/contentQuotesLinter.js"() {
    init_utils();
    linter = function linter2(key, value, info) {
      if (key === "content") {
        var contentValuePattern = /(attr|counters?|url|(((repeating-)?(linear|radial))|conic)-gradient)\(|(no-)?(open|close)-quote/;
        var contentValues = ["normal", "none", "initial", "inherit", "unset"];
        if (typeof value !== "string" || contentValues.indexOf(value) === -1 && !contentValuePattern.test(value) && (value.charAt(0) !== value.charAt(value.length - 1) || value.charAt(0) !== '"' && value.charAt(0) !== "'")) {
          lintWarning("You seem to be using a value for 'content' without quotes, try replacing it with `content: '\"".concat(value, "\"'`."), info);
        }
      }
    };
    contentQuotesLinter_default = linter;
  }
});

// node_modules/@ant-design/cssinjs/es/linters/hashedAnimationLinter.js
var linter3, hashedAnimationLinter_default;
var init_hashedAnimationLinter = __esm({
  "node_modules/@ant-design/cssinjs/es/linters/hashedAnimationLinter.js"() {
    init_utils();
    linter3 = function linter4(key, value, info) {
      if (key === "animation") {
        if (info.hashId && value !== "none") {
          lintWarning("You seem to be using hashed animation '".concat(value, "', in which case 'animationName' with Keyframe as value is recommended."), info);
        }
      }
    };
    hashedAnimationLinter_default = linter3;
  }
});

// node_modules/@ant-design/cssinjs/es/linters/legacyNotSelectorLinter.js
function isConcatSelector(selector) {
  var _selector$match;
  var notContent = ((_selector$match = selector.match(/:not\(([^)]*)\)/)) === null || _selector$match === void 0 ? void 0 : _selector$match[1]) || "";
  var splitCells = notContent.split(/(\[[^[]*])|(?=[.#])/).filter(function(str) {
    return str;
  });
  return splitCells.length > 1;
}
function parsePath(info) {
  return info.parentSelectors.reduce(function(prev2, cur) {
    if (!prev2) {
      return cur;
    }
    return cur.includes("&") ? cur.replace(/&/g, prev2) : "".concat(prev2, " ").concat(cur);
  }, "");
}
var linter5, legacyNotSelectorLinter_default;
var init_legacyNotSelectorLinter = __esm({
  "node_modules/@ant-design/cssinjs/es/linters/legacyNotSelectorLinter.js"() {
    init_utils();
    linter5 = function linter6(key, value, info) {
      var parentSelectorPath = parsePath(info);
      var notList = parentSelectorPath.match(/:not\([^)]*\)/g) || [];
      if (notList.length > 0 && notList.some(isConcatSelector)) {
        lintWarning("Concat ':not' selector not support in legacy browsers.", info);
      }
    };
    legacyNotSelectorLinter_default = linter5;
  }
});

// node_modules/@ant-design/cssinjs/es/linters/logicalPropertiesLinter.js
var linter7, logicalPropertiesLinter_default;
var init_logicalPropertiesLinter = __esm({
  "node_modules/@ant-design/cssinjs/es/linters/logicalPropertiesLinter.js"() {
    init_utils();
    linter7 = function linter8(key, value, info) {
      switch (key) {
        case "marginLeft":
        case "marginRight":
        case "paddingLeft":
        case "paddingRight":
        case "left":
        case "right":
        case "borderLeft":
        case "borderLeftWidth":
        case "borderLeftStyle":
        case "borderLeftColor":
        case "borderRight":
        case "borderRightWidth":
        case "borderRightStyle":
        case "borderRightColor":
        case "borderTopLeftRadius":
        case "borderTopRightRadius":
        case "borderBottomLeftRadius":
        case "borderBottomRightRadius":
          lintWarning("You seem to be using non-logical property '".concat(key, "' which is not compatible with RTL mode. Please use logical properties and values instead. For more information: https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_Logical_Properties."), info);
          return;
        case "margin":
        case "padding":
        case "borderWidth":
        case "borderStyle":
          if (typeof value === "string") {
            var valueArr = value.split(" ").map(function(item) {
              return item.trim();
            });
            if (valueArr.length === 4 && valueArr[1] !== valueArr[3]) {
              lintWarning("You seem to be using '".concat(key, "' property with different left ").concat(key, " and right ").concat(key, ", which is not compatible with RTL mode. Please use logical properties and values instead. For more information: https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_Logical_Properties."), info);
            }
          }
          return;
        case "clear":
        case "textAlign":
          if (value === "left" || value === "right") {
            lintWarning("You seem to be using non-logical value '".concat(value, "' of ").concat(key, ", which is not compatible with RTL mode. Please use logical properties and values instead. For more information: https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_Logical_Properties."), info);
          }
          return;
        case "borderRadius":
          if (typeof value === "string") {
            var radiusGroups = value.split("/").map(function(item) {
              return item.trim();
            });
            var invalid = radiusGroups.reduce(function(result, group) {
              if (result) {
                return result;
              }
              var radiusArr = group.split(" ").map(function(item) {
                return item.trim();
              });
              if (radiusArr.length >= 2 && radiusArr[0] !== radiusArr[1]) {
                return true;
              }
              if (radiusArr.length === 3 && radiusArr[1] !== radiusArr[2]) {
                return true;
              }
              if (radiusArr.length === 4 && radiusArr[2] !== radiusArr[3]) {
                return true;
              }
              return result;
            }, false);
            if (invalid) {
              lintWarning("You seem to be using non-logical value '".concat(value, "' of ").concat(key, ", which is not compatible with RTL mode. Please use logical properties and values instead. For more information: https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_Logical_Properties."), info);
            }
          }
          return;
        default:
      }
    };
    logicalPropertiesLinter_default = linter7;
  }
});

// node_modules/@ant-design/cssinjs/es/linters/parentSelectorLinter.js
var linter9, parentSelectorLinter_default;
var init_parentSelectorLinter = __esm({
  "node_modules/@ant-design/cssinjs/es/linters/parentSelectorLinter.js"() {
    init_utils();
    linter9 = function linter10(key, value, info) {
      if (info.parentSelectors.some(function(selector) {
        var selectors = selector.split(",");
        return selectors.some(function(item) {
          return item.split("&").length > 2;
        });
      })) {
        lintWarning("Should not use more than one `&` in a selector.", info);
      }
    };
    parentSelectorLinter_default = linter9;
  }
});

// node_modules/@ant-design/cssinjs/es/linters/index.js
var init_linters = __esm({
  "node_modules/@ant-design/cssinjs/es/linters/index.js"() {
    init_contentQuotesLinter();
    init_hashedAnimationLinter();
    init_legacyNotSelectorLinter();
    init_logicalPropertiesLinter();
    init_parentSelectorLinter();
  }
});

// node_modules/@ant-design/cssinjs/es/hooks/useStyleRegister.js
function normalizeStyle(styleStr) {
  var serialized = serialize(compile(styleStr), stringify);
  return serialized.replace(/\{%%%\:[^;];}/g, ";");
}
function isCompoundCSSProperty(value) {
  return _typeof(value) === "object" && value && (SKIP_CHECK in value || MULTI_VALUE in value);
}
function injectSelectorHash(key, hashId, hashPriority) {
  if (!hashId) {
    return key;
  }
  var hashClassName = ".".concat(hashId);
  var hashSelector = hashPriority === "low" ? ":where(".concat(hashClassName, ")") : hashClassName;
  var keys = key.split(",").map(function(k) {
    var _firstPath$match;
    var fullPath = k.trim().split(/\s+/);
    var firstPath = fullPath[0] || "";
    var htmlElement = ((_firstPath$match = firstPath.match(/^\w+/)) === null || _firstPath$match === void 0 ? void 0 : _firstPath$match[0]) || "";
    firstPath = "".concat(htmlElement).concat(hashSelector).concat(firstPath.slice(htmlElement.length));
    return [firstPath].concat(_toConsumableArray(fullPath.slice(1))).join(" ");
  });
  return keys.join(",");
}
function uniqueHash(path, styleStr) {
  return hash_browser_esm_default("".concat(path.join("%")).concat(styleStr));
}
function Empty() {
  return null;
}
function useStyleRegister(info, styleFn) {
  var token2 = info.token, path = info.path, hashId = info.hashId, layer = info.layer, nonce = info.nonce;
  var _React$useContext = React4.useContext(StyleContext_default), autoClear = _React$useContext.autoClear, mock = _React$useContext.mock, defaultCache = _React$useContext.defaultCache, hashPriority = _React$useContext.hashPriority, container = _React$useContext.container, ssrInline = _React$useContext.ssrInline, transformers = _React$useContext.transformers, linters = _React$useContext.linters, cache = _React$useContext.cache;
  var tokenKey = token2._tokenKey;
  var fullPath = [tokenKey].concat(_toConsumableArray(path));
  var isMergedClientSide = isClientSide;
  if (mock !== void 0) {
    isMergedClientSide = mock === "client";
  }
  var _useGlobalCache = useClientCache(
    "style",
    fullPath,
    // Create cache if needed
    function() {
      var styleObj = styleFn();
      var _parseStyle5 = parseStyle(styleObj, {
        hashId,
        hashPriority,
        layer,
        path: path.join("-"),
        transformers,
        linters
      }), _parseStyle6 = _slicedToArray(_parseStyle5, 2), parsedStyle = _parseStyle6[0], effectStyle = _parseStyle6[1];
      var styleStr = normalizeStyle(parsedStyle);
      var styleId = uniqueHash(fullPath, styleStr);
      if (isMergedClientSide) {
        var mergedCSSConfig = {
          mark: ATTR_MARK,
          prepend: "queue",
          attachTo: container
        };
        var nonceStr = typeof nonce === "function" ? nonce() : nonce;
        if (nonceStr) {
          mergedCSSConfig.csp = {
            nonce: nonceStr
          };
        }
        var style2 = updateCSS(styleStr, styleId, mergedCSSConfig);
        style2[CSS_IN_JS_INSTANCE] = cache.instanceId;
        style2.setAttribute(ATTR_TOKEN, tokenKey);
        if (true) {
          style2.setAttribute(ATTR_DEV_CACHE_PATH, fullPath.join("|"));
        }
        Object.keys(effectStyle).forEach(function(effectKey) {
          updateCSS(normalizeStyle(effectStyle[effectKey]), "_effect-".concat(effectKey), mergedCSSConfig);
        });
      }
      return [styleStr, tokenKey, styleId];
    },
    // Remove cache if no need
    function(_ref2, fromHMR) {
      var _ref3 = _slicedToArray(_ref2, 3), styleId = _ref3[2];
      if ((fromHMR || autoClear) && isClientSide) {
        removeCSS(styleId, {
          mark: ATTR_MARK
        });
      }
    }
  ), _useGlobalCache2 = _slicedToArray(_useGlobalCache, 3), cachedStyleStr = _useGlobalCache2[0], cachedTokenKey = _useGlobalCache2[1], cachedStyleId = _useGlobalCache2[2];
  return function(node2) {
    var styleNode;
    if (!ssrInline || isMergedClientSide || !defaultCache) {
      styleNode = React4.createElement(Empty, null);
    } else {
      var _ref4;
      styleNode = React4.createElement("style", _extends({}, (_ref4 = {}, _defineProperty(_ref4, ATTR_TOKEN, cachedTokenKey), _defineProperty(_ref4, ATTR_MARK, cachedStyleId), _ref4), {
        dangerouslySetInnerHTML: {
          __html: cachedStyleStr
        }
      }));
    }
    return React4.createElement(React4.Fragment, null, styleNode, node2);
  };
}
function extractStyle(cache) {
  var plain = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : false;
  var styleKeys = Array.from(cache.cache.keys()).filter(function(key) {
    return key.startsWith("style%");
  });
  var styleText = "";
  styleKeys.forEach(function(key) {
    var _ = _slicedToArray(cache.cache.get(key)[1], 3), styleStr = _[0], tokenKey = _[1], styleId = _[2];
    styleText += plain ? styleStr : "<style ".concat(ATTR_TOKEN, '="').concat(tokenKey, '" ').concat(ATTR_MARK, '="').concat(styleId, '">').concat(styleStr, "</style>");
  });
  return styleText;
}
var React4, isClientSide, SKIP_CHECK, MULTI_VALUE, parseStyle;
var init_useStyleRegister = __esm({
  "node_modules/@ant-design/cssinjs/es/hooks/useStyleRegister.js"() {
    init_extends();
    init_defineProperty();
    init_objectSpread2();
    init_slicedToArray();
    init_toConsumableArray();
    init_typeof();
    init_hash_browser_esm();
    init_canUseDom();
    init_dynamicCSS();
    React4 = __toESM(require_react());
    init_unitless_browser_esm();
    init_stylis();
    init_linters();
    init_StyleContext();
    init_util();
    init_useGlobalCache();
    isClientSide = canUseDom();
    SKIP_CHECK = "_skip_check_";
    MULTI_VALUE = "_multi_value_";
    parseStyle = function parseStyle2(interpolation) {
      var config = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
      var _ref = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {
        root: true,
        parentSelectors: []
      }, root = _ref.root, injectHash = _ref.injectHash, parentSelectors = _ref.parentSelectors;
      var hashId = config.hashId, layer = config.layer, path = config.path, hashPriority = config.hashPriority, _config$transformers = config.transformers, transformers = _config$transformers === void 0 ? [] : _config$transformers, _config$linters = config.linters, linters = _config$linters === void 0 ? [] : _config$linters;
      var styleStr = "";
      var effectStyle = {};
      function parseKeyframes(keyframes) {
        var animationName = keyframes.getName(hashId);
        if (!effectStyle[animationName]) {
          var _parseStyle = parseStyle2(keyframes.style, config, {
            root: false,
            parentSelectors
          }), _parseStyle2 = _slicedToArray(_parseStyle, 1), _parsedStr = _parseStyle2[0];
          effectStyle[animationName] = "@keyframes ".concat(keyframes.getName(hashId)).concat(_parsedStr);
        }
      }
      function flattenList(list) {
        var fullList = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : [];
        list.forEach(function(item) {
          if (Array.isArray(item)) {
            flattenList(item, fullList);
          } else if (item) {
            fullList.push(item);
          }
        });
        return fullList;
      }
      var flattenStyleList = flattenList(Array.isArray(interpolation) ? interpolation : [interpolation]);
      flattenStyleList.forEach(function(originStyle) {
        var style2 = typeof originStyle === "string" && !root ? {} : originStyle;
        if (typeof style2 === "string") {
          styleStr += "".concat(style2, "\n");
        } else if (style2._keyframe) {
          parseKeyframes(style2);
        } else {
          var mergedStyle = transformers.reduce(function(prev2, trans) {
            var _trans$visit;
            return (trans === null || trans === void 0 ? void 0 : (_trans$visit = trans.visit) === null || _trans$visit === void 0 ? void 0 : _trans$visit.call(trans, prev2)) || prev2;
          }, style2);
          Object.keys(mergedStyle).forEach(function(key) {
            var value = mergedStyle[key];
            if (_typeof(value) === "object" && value && (key !== "animationName" || !value._keyframe) && !isCompoundCSSProperty(value)) {
              var subInjectHash = false;
              var mergedKey = key.trim();
              var nextRoot = false;
              if ((root || injectHash) && hashId) {
                if (mergedKey.startsWith("@")) {
                  subInjectHash = true;
                } else {
                  mergedKey = injectSelectorHash(key, hashId, hashPriority);
                }
              } else if (root && !hashId && (mergedKey === "&" || mergedKey === "")) {
                mergedKey = "";
                nextRoot = true;
              }
              var _parseStyle3 = parseStyle2(value, config, {
                root: nextRoot,
                injectHash: subInjectHash,
                parentSelectors: [].concat(_toConsumableArray(parentSelectors), [mergedKey])
              }), _parseStyle4 = _slicedToArray(_parseStyle3, 2), _parsedStr2 = _parseStyle4[0], childEffectStyle = _parseStyle4[1];
              effectStyle = _objectSpread2(_objectSpread2({}, effectStyle), childEffectStyle);
              styleStr += "".concat(mergedKey).concat(_parsedStr2);
            } else {
              let appendStyle = function(cssKey, cssValue) {
                if (_typeof(value) !== "object" || !(value !== null && value !== void 0 && value[SKIP_CHECK])) {
                  [contentQuotesLinter_default, hashedAnimationLinter_default].concat(_toConsumableArray(linters)).forEach(function(linter11) {
                    return linter11(cssKey, cssValue, {
                      path,
                      hashId,
                      parentSelectors
                    });
                  });
                }
                var styleName = cssKey.replace(/[A-Z]/g, function(match2) {
                  return "-".concat(match2.toLowerCase());
                });
                var formatValue = cssValue;
                if (!unitless_browser_esm_default[cssKey] && typeof formatValue === "number" && formatValue !== 0) {
                  formatValue = "".concat(formatValue, "px");
                }
                if (cssKey === "animationName" && cssValue !== null && cssValue !== void 0 && cssValue._keyframe) {
                  parseKeyframes(cssValue);
                  formatValue = cssValue.getName(hashId);
                }
                styleStr += "".concat(styleName, ":").concat(formatValue, ";");
              };
              var _value;
              var actualValue = (_value = value === null || value === void 0 ? void 0 : value.value) !== null && _value !== void 0 ? _value : value;
              if (_typeof(value) === "object" && value !== null && value !== void 0 && value[MULTI_VALUE] && Array.isArray(actualValue)) {
                actualValue.forEach(function(item) {
                  appendStyle(key, item);
                });
              } else {
                appendStyle(key, actualValue);
              }
            }
          });
        }
      });
      if (!root) {
        styleStr = "{".concat(styleStr, "}");
      } else if (layer && supportLayer()) {
        var layerCells = layer.split(",");
        var layerName = layerCells[layerCells.length - 1].trim();
        styleStr = "@layer ".concat(layerName, " {").concat(styleStr, "}");
        if (layerCells.length > 1) {
          styleStr = "@layer ".concat(layer, "{%%%:%}").concat(styleStr);
        }
      }
      return [styleStr, effectStyle];
    };
  }
});

// node_modules/@ant-design/cssinjs/es/Keyframes.js
var Keyframe, Keyframes_default;
var init_Keyframes = __esm({
  "node_modules/@ant-design/cssinjs/es/Keyframes.js"() {
    init_classCallCheck();
    init_createClass();
    init_defineProperty();
    Keyframe = function() {
      function Keyframe2(name, style2) {
        _classCallCheck(this, Keyframe2);
        _defineProperty(this, "name", void 0);
        _defineProperty(this, "style", void 0);
        _defineProperty(this, "_keyframe", true);
        this.name = name;
        this.style = style2;
      }
      _createClass(Keyframe2, [{
        key: "getName",
        value: function getName() {
          var hashId = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "";
          return hashId ? "".concat(hashId, "-").concat(this.name) : this.name;
        }
      }]);
      return Keyframe2;
    }();
    Keyframes_default = Keyframe;
  }
});

// node_modules/@ant-design/cssinjs/es/transformers/legacyLogicalProperties.js
function splitValues(value) {
  if (typeof value === "number") {
    return [[value], false];
  }
  var rawStyle = String(value).trim();
  var importantCells = rawStyle.match(/(.*)(!important)/);
  var splitStyle = (importantCells ? importantCells[1] : rawStyle).trim().split(/\s+/);
  var temp = "";
  var brackets = 0;
  return [splitStyle.reduce(function(list, item) {
    if (item.includes("(")) {
      temp += item;
      brackets += item.split("(").length - 1;
    } else if (item.includes(")")) {
      temp += item;
      brackets -= item.split(")").length - 1;
      if (brackets === 0) {
        list.push(temp);
        temp = "";
      }
    } else if (brackets > 0) {
      temp += item;
    } else {
      list.push(item);
    }
    return list;
  }, []), !!importantCells];
}
function noSplit(list) {
  list.notSplit = true;
  return list;
}
function wrapImportantAndSkipCheck(value, important) {
  var parsedValue = value;
  if (important) {
    parsedValue = "".concat(parsedValue, " !important");
  }
  return {
    _skip_check_: true,
    value: parsedValue
  };
}
var keyMap, transform, legacyLogicalProperties_default;
var init_legacyLogicalProperties = __esm({
  "node_modules/@ant-design/cssinjs/es/transformers/legacyLogicalProperties.js"() {
    init_slicedToArray();
    keyMap = {
      // Inset
      inset: ["top", "right", "bottom", "left"],
      insetBlock: ["top", "bottom"],
      insetBlockStart: ["top"],
      insetBlockEnd: ["bottom"],
      insetInline: ["left", "right"],
      insetInlineStart: ["left"],
      insetInlineEnd: ["right"],
      // Margin
      marginBlock: ["marginTop", "marginBottom"],
      marginBlockStart: ["marginTop"],
      marginBlockEnd: ["marginBottom"],
      marginInline: ["marginLeft", "marginRight"],
      marginInlineStart: ["marginLeft"],
      marginInlineEnd: ["marginRight"],
      // Padding
      paddingBlock: ["paddingTop", "paddingBottom"],
      paddingBlockStart: ["paddingTop"],
      paddingBlockEnd: ["paddingBottom"],
      paddingInline: ["paddingLeft", "paddingRight"],
      paddingInlineStart: ["paddingLeft"],
      paddingInlineEnd: ["paddingRight"],
      // Border
      borderBlock: noSplit(["borderTop", "borderBottom"]),
      borderBlockStart: noSplit(["borderTop"]),
      borderBlockEnd: noSplit(["borderBottom"]),
      borderInline: noSplit(["borderLeft", "borderRight"]),
      borderInlineStart: noSplit(["borderLeft"]),
      borderInlineEnd: noSplit(["borderRight"]),
      // Border width
      borderBlockWidth: ["borderTopWidth", "borderBottomWidth"],
      borderBlockStartWidth: ["borderTopWidth"],
      borderBlockEndWidth: ["borderBottomWidth"],
      borderInlineWidth: ["borderLeftWidth", "borderRightWidth"],
      borderInlineStartWidth: ["borderLeftWidth"],
      borderInlineEndWidth: ["borderRightWidth"],
      // Border style
      borderBlockStyle: ["borderTopStyle", "borderBottomStyle"],
      borderBlockStartStyle: ["borderTopStyle"],
      borderBlockEndStyle: ["borderBottomStyle"],
      borderInlineStyle: ["borderLeftStyle", "borderRightStyle"],
      borderInlineStartStyle: ["borderLeftStyle"],
      borderInlineEndStyle: ["borderRightStyle"],
      // Border color
      borderBlockColor: ["borderTopColor", "borderBottomColor"],
      borderBlockStartColor: ["borderTopColor"],
      borderBlockEndColor: ["borderBottomColor"],
      borderInlineColor: ["borderLeftColor", "borderRightColor"],
      borderInlineStartColor: ["borderLeftColor"],
      borderInlineEndColor: ["borderRightColor"],
      // Border radius
      borderStartStartRadius: ["borderTopLeftRadius"],
      borderStartEndRadius: ["borderTopRightRadius"],
      borderEndStartRadius: ["borderBottomLeftRadius"],
      borderEndEndRadius: ["borderBottomRightRadius"]
    };
    transform = {
      visit: function visit(cssObj) {
        var clone = {};
        Object.keys(cssObj).forEach(function(key) {
          var value = cssObj[key];
          var matchValue = keyMap[key];
          if (matchValue && (typeof value === "number" || typeof value === "string")) {
            var _splitValues = splitValues(value), _splitValues2 = _slicedToArray(_splitValues, 2), _values = _splitValues2[0], _important = _splitValues2[1];
            if (matchValue.length && matchValue.notSplit) {
              matchValue.forEach(function(matchKey) {
                clone[matchKey] = wrapImportantAndSkipCheck(value, _important);
              });
            } else if (matchValue.length === 1) {
              clone[matchValue[0]] = wrapImportantAndSkipCheck(value, _important);
            } else if (matchValue.length === 2) {
              matchValue.forEach(function(matchKey, index) {
                var _values$index;
                clone[matchKey] = wrapImportantAndSkipCheck((_values$index = _values[index]) !== null && _values$index !== void 0 ? _values$index : _values[0], _important);
              });
            } else if (matchValue.length === 4) {
              matchValue.forEach(function(matchKey, index) {
                var _ref, _values$index2;
                clone[matchKey] = wrapImportantAndSkipCheck((_ref = (_values$index2 = _values[index]) !== null && _values$index2 !== void 0 ? _values$index2 : _values[index - 2]) !== null && _ref !== void 0 ? _ref : _values[0], _important);
              });
            } else {
              clone[key] = value;
            }
          } else {
            clone[key] = value;
          }
        });
        return clone;
      }
    };
    legacyLogicalProperties_default = transform;
  }
});

// node_modules/@ant-design/cssinjs/es/transformers/px2rem.js
function toFixed(number, precision) {
  var multiplier = Math.pow(10, precision + 1), wholeNumber = Math.floor(number * multiplier);
  return Math.round(wholeNumber / 10) * 10 / multiplier;
}
var pxRegex, transform2, px2rem_default;
var init_px2rem = __esm({
  "node_modules/@ant-design/cssinjs/es/transformers/px2rem.js"() {
    init_slicedToArray();
    init_objectSpread2();
    init_unitless_browser_esm();
    pxRegex = /url\([^)]+\)|var\([^)]+\)|(\d*\.?\d+)px/g;
    transform2 = function transform3() {
      var options = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
      var _options$rootValue = options.rootValue, rootValue = _options$rootValue === void 0 ? 16 : _options$rootValue, _options$precision = options.precision, precision = _options$precision === void 0 ? 5 : _options$precision, _options$mediaQuery = options.mediaQuery, mediaQuery = _options$mediaQuery === void 0 ? false : _options$mediaQuery;
      var pxReplace = function pxReplace2(m, $1) {
        if (!$1)
          return m;
        var pixels = parseFloat($1);
        if (pixels <= 1)
          return m;
        var fixedVal = toFixed(pixels / rootValue, precision);
        return "".concat(fixedVal, "rem");
      };
      var visit2 = function visit3(cssObj) {
        var clone = _objectSpread2({}, cssObj);
        Object.entries(cssObj).forEach(function(_ref) {
          var _ref2 = _slicedToArray(_ref, 2), key = _ref2[0], value = _ref2[1];
          if (typeof value === "string" && value.includes("px")) {
            var newValue = value.replace(pxRegex, pxReplace);
            clone[key] = newValue;
          }
          if (!unitless_browser_esm_default[key] && typeof value === "number" && value !== 0) {
            clone[key] = "".concat(value, "px").replace(pxRegex, pxReplace);
          }
          var mergedKey = key.trim();
          if (mergedKey.startsWith("@") && mergedKey.includes("px") && mediaQuery) {
            var newKey = key.replace(pxRegex, pxReplace);
            clone[newKey] = clone[key];
            delete clone[key];
          }
        });
        return clone;
      };
      return {
        visit: visit2
      };
    };
    px2rem_default = transform2;
  }
});

// node_modules/@ant-design/cssinjs/es/index.js
var es_exports = {};
__export(es_exports, {
  Keyframes: () => Keyframes_default,
  StyleProvider: () => StyleProvider,
  Theme: () => Theme,
  createCache: () => createCache,
  createTheme: () => createTheme,
  extractStyle: () => extractStyle,
  getComputedToken: () => getComputedToken,
  legacyLogicalPropertiesTransformer: () => legacyLogicalProperties_default,
  legacyNotSelectorLinter: () => legacyNotSelectorLinter_default,
  logicalPropertiesLinter: () => logicalPropertiesLinter_default,
  parentSelectorLinter: () => parentSelectorLinter_default,
  px2remTransformer: () => px2rem_default,
  useCacheToken: () => useCacheToken,
  useStyleRegister: () => useStyleRegister
});
var init_es = __esm({
  "node_modules/@ant-design/cssinjs/es/index.js"() {
    init_useCacheToken();
    init_useStyleRegister();
    init_Keyframes();
    init_linters();
    init_StyleContext();
    init_theme();
    init_legacyLogicalProperties();
    init_px2rem();
  }
});

// node_modules/@babel/runtime/helpers/esm/toArray.js
function _toArray(arr) {
  return _arrayWithHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableRest();
}
var init_toArray = __esm({
  "node_modules/@babel/runtime/helpers/esm/toArray.js"() {
    init_arrayWithHoles();
    init_iterableToArray();
    init_unsupportedIterableToArray();
    init_nonIterableRest();
  }
});

// node_modules/rc-util/es/utils/get.js
function get(entity, path) {
  var current = entity;
  for (var i = 0; i < path.length; i += 1) {
    if (current === null || current === void 0) {
      return void 0;
    }
    current = current[path[i]];
  }
  return current;
}
var init_get = __esm({
  "node_modules/rc-util/es/utils/get.js"() {
  }
});

// node_modules/rc-util/es/utils/set.js
function internalSet(entity, paths, value, removeIfUndefined) {
  if (!paths.length) {
    return value;
  }
  var _paths = _toArray(paths), path = _paths[0], restPath = _paths.slice(1);
  var clone;
  if (!entity && typeof path === "number") {
    clone = [];
  } else if (Array.isArray(entity)) {
    clone = _toConsumableArray(entity);
  } else {
    clone = _objectSpread2({}, entity);
  }
  if (removeIfUndefined && value === void 0 && restPath.length === 1) {
    delete clone[path][restPath[0]];
  } else {
    clone[path] = internalSet(clone[path], restPath, value, removeIfUndefined);
  }
  return clone;
}
function set(entity, paths, value) {
  var removeIfUndefined = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : false;
  if (paths.length && removeIfUndefined && value === void 0 && !get(entity, paths.slice(0, -1))) {
    return entity;
  }
  return internalSet(entity, paths, value, removeIfUndefined);
}
function isObject(obj) {
  return _typeof(obj) === "object" && obj !== null && Object.getPrototypeOf(obj) === Object.prototype;
}
function createEmpty(source) {
  return Array.isArray(source) ? [] : {};
}
function merge() {
  for (var _len = arguments.length, sources = new Array(_len), _key = 0; _key < _len; _key++) {
    sources[_key] = arguments[_key];
  }
  var clone = createEmpty(sources[0]);
  sources.forEach(function(src) {
    function internalMerge(path, parentLoopSet) {
      var loopSet = new Set(parentLoopSet);
      var value = get(src, path);
      var isArr = Array.isArray(value);
      if (isArr || isObject(value)) {
        if (!loopSet.has(value)) {
          loopSet.add(value);
          var originValue = get(clone, path);
          if (isArr) {
            clone = set(clone, path, []);
          } else if (!originValue || _typeof(originValue) !== "object") {
            clone = set(clone, path, createEmpty(value));
          }
          Object.keys(value).forEach(function(key) {
            internalMerge([].concat(_toConsumableArray(path), [key]), loopSet);
          });
        }
      } else {
        clone = set(clone, path, value);
      }
    }
    internalMerge([]);
  });
  return clone;
}
var init_set = __esm({
  "node_modules/rc-util/es/utils/set.js"() {
    init_typeof();
    init_objectSpread2();
    init_toConsumableArray();
    init_toArray();
    init_get();
  }
});

// node_modules/rc-util/es/hooks/useEvent.js
function useEvent(callback) {
  var fnRef = React5.useRef();
  fnRef.current = callback;
  var memoFn = React5.useCallback(function() {
    var _fnRef$current;
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }
    return (_fnRef$current = fnRef.current) === null || _fnRef$current === void 0 ? void 0 : _fnRef$current.call.apply(_fnRef$current, [fnRef].concat(args));
  }, []);
  return memoFn;
}
var React5;
var init_useEvent = __esm({
  "node_modules/rc-util/es/hooks/useEvent.js"() {
    React5 = __toESM(require_react());
  }
});

// node_modules/rc-util/es/hooks/useLayoutEffect.js
var React6, useInternalLayoutEffect, useLayoutEffect2, useLayoutUpdateEffect, useLayoutEffect_default;
var init_useLayoutEffect = __esm({
  "node_modules/rc-util/es/hooks/useLayoutEffect.js"() {
    React6 = __toESM(require_react());
    init_canUseDom();
    useInternalLayoutEffect = canUseDom() ? React6.useLayoutEffect : React6.useEffect;
    useLayoutEffect2 = function useLayoutEffect3(callback, deps) {
      var firstMountRef = React6.useRef(true);
      useInternalLayoutEffect(function() {
        return callback(firstMountRef.current);
      }, deps);
      useInternalLayoutEffect(function() {
        firstMountRef.current = false;
        return function() {
          firstMountRef.current = true;
        };
      }, []);
    };
    useLayoutUpdateEffect = function useLayoutUpdateEffect2(callback, deps) {
      useLayoutEffect2(function(firstMount) {
        if (!firstMount) {
          return callback();
        }
      }, deps);
    };
    useLayoutEffect_default = useLayoutEffect2;
  }
});

// node_modules/rc-util/es/hooks/useState.js
function useSafeState(defaultValue) {
  var destroyRef = React7.useRef(false);
  var _React$useState = React7.useState(defaultValue), _React$useState2 = _slicedToArray(_React$useState, 2), value = _React$useState2[0], setValue = _React$useState2[1];
  React7.useEffect(function() {
    destroyRef.current = false;
    return function() {
      destroyRef.current = true;
    };
  }, []);
  function safeSetState(updater, ignoreDestroy) {
    if (ignoreDestroy && destroyRef.current) {
      return;
    }
    setValue(updater);
  }
  return [value, safeSetState];
}
var React7;
var init_useState = __esm({
  "node_modules/rc-util/es/hooks/useState.js"() {
    init_slicedToArray();
    React7 = __toESM(require_react());
  }
});

// node_modules/rc-util/es/hooks/useMergedState.js
function hasValue(value) {
  return value !== void 0;
}
function useMergedState(defaultStateValue, option) {
  var _ref = option || {}, defaultValue = _ref.defaultValue, value = _ref.value, onChange = _ref.onChange, postState = _ref.postState;
  var _useState = useSafeState(function() {
    if (hasValue(value)) {
      return value;
    } else if (hasValue(defaultValue)) {
      return typeof defaultValue === "function" ? defaultValue() : defaultValue;
    } else {
      return typeof defaultStateValue === "function" ? defaultStateValue() : defaultStateValue;
    }
  }), _useState2 = _slicedToArray(_useState, 2), innerValue = _useState2[0], setInnerValue = _useState2[1];
  var mergedValue = value !== void 0 ? value : innerValue;
  var postMergedValue = postState ? postState(mergedValue) : mergedValue;
  var onChangeFn = useEvent(onChange);
  var _useState3 = useSafeState([mergedValue]), _useState4 = _slicedToArray(_useState3, 2), prevValue = _useState4[0], setPrevValue = _useState4[1];
  useLayoutUpdateEffect(function() {
    var prev2 = prevValue[0];
    if (innerValue !== prev2) {
      onChangeFn(innerValue, prev2);
    }
  }, [prevValue]);
  useLayoutUpdateEffect(function() {
    if (!hasValue(value)) {
      setInnerValue(value);
    }
  }, [value]);
  var triggerChange = useEvent(function(updater, ignoreDestroy) {
    setInnerValue(updater, ignoreDestroy);
    setPrevValue([mergedValue], ignoreDestroy);
  });
  return [postMergedValue, triggerChange];
}
var init_useMergedState = __esm({
  "node_modules/rc-util/es/hooks/useMergedState.js"() {
    init_slicedToArray();
    init_useEvent();
    init_useLayoutEffect();
    init_useState();
  }
});

// node_modules/@babel/runtime/helpers/esm/setPrototypeOf.js
function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf2(o2, p2) {
    o2.__proto__ = p2;
    return o2;
  };
  return _setPrototypeOf(o, p);
}
var init_setPrototypeOf = __esm({
  "node_modules/@babel/runtime/helpers/esm/setPrototypeOf.js"() {
  }
});

// node_modules/@babel/runtime/helpers/esm/inherits.js
function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  Object.defineProperty(subClass, "prototype", {
    writable: false
  });
  if (superClass)
    _setPrototypeOf(subClass, superClass);
}
var init_inherits = __esm({
  "node_modules/@babel/runtime/helpers/esm/inherits.js"() {
    init_setPrototypeOf();
  }
});

// node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js
function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf2(o2) {
    return o2.__proto__ || Object.getPrototypeOf(o2);
  };
  return _getPrototypeOf(o);
}
var init_getPrototypeOf = __esm({
  "node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js"() {
  }
});

// node_modules/@babel/runtime/helpers/esm/isNativeReflectConstruct.js
function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct)
    return false;
  if (Reflect.construct.sham)
    return false;
  if (typeof Proxy === "function")
    return true;
  try {
    Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
    return true;
  } catch (e) {
    return false;
  }
}
var init_isNativeReflectConstruct = __esm({
  "node_modules/@babel/runtime/helpers/esm/isNativeReflectConstruct.js"() {
  }
});

// node_modules/@babel/runtime/helpers/esm/assertThisInitialized.js
function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return self;
}
var init_assertThisInitialized = __esm({
  "node_modules/@babel/runtime/helpers/esm/assertThisInitialized.js"() {
  }
});

// node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js
function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  } else if (call !== void 0) {
    throw new TypeError("Derived constructors may only return object or undefined");
  }
  return _assertThisInitialized(self);
}
var init_possibleConstructorReturn = __esm({
  "node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js"() {
    init_typeof();
    init_assertThisInitialized();
  }
});

// node_modules/@babel/runtime/helpers/esm/createSuper.js
function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();
  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived), result;
    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;
      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }
    return _possibleConstructorReturn(this, result);
  };
}
var init_createSuper = __esm({
  "node_modules/@babel/runtime/helpers/esm/createSuper.js"() {
    init_getPrototypeOf();
    init_isNativeReflectConstruct();
    init_possibleConstructorReturn();
  }
});

// node_modules/rc-util/es/Dom/findDOMNode.js
function isDOM(node2) {
  return node2 instanceof HTMLElement || node2 instanceof SVGElement;
}
function findDOMNode(node2) {
  if (isDOM(node2)) {
    return node2;
  }
  if (node2 instanceof import_react2.default.Component) {
    return import_react_dom.default.findDOMNode(node2);
  }
  return null;
}
var import_react2, import_react_dom;
var init_findDOMNode = __esm({
  "node_modules/rc-util/es/Dom/findDOMNode.js"() {
    import_react2 = __toESM(require_react());
    import_react_dom = __toESM(require_react_dom());
  }
});

// node_modules/rc-motion/es/context.js
function MotionProvider(_ref) {
  var children = _ref.children, props = _objectWithoutProperties(_ref, _excluded2);
  return React9.createElement(Context.Provider, {
    value: props
  }, children);
}
var React9, _excluded2, Context;
var init_context = __esm({
  "node_modules/rc-motion/es/context.js"() {
    init_objectWithoutProperties();
    React9 = __toESM(require_react());
    _excluded2 = ["children"];
    Context = React9.createContext({});
  }
});

// node_modules/rc-motion/es/DomWrapper.js
var React10, DomWrapper, DomWrapper_default;
var init_DomWrapper = __esm({
  "node_modules/rc-motion/es/DomWrapper.js"() {
    init_classCallCheck();
    init_createClass();
    init_inherits();
    init_createSuper();
    React10 = __toESM(require_react());
    DomWrapper = function(_React$Component) {
      _inherits(DomWrapper2, _React$Component);
      var _super = _createSuper(DomWrapper2);
      function DomWrapper2() {
        _classCallCheck(this, DomWrapper2);
        return _super.apply(this, arguments);
      }
      _createClass(DomWrapper2, [{
        key: "render",
        value: function render() {
          return this.props.children;
        }
      }]);
      return DomWrapper2;
    }(React10.Component);
    DomWrapper_default = DomWrapper;
  }
});

// node_modules/rc-motion/es/interface.js
var STATUS_NONE, STATUS_APPEAR, STATUS_ENTER, STATUS_LEAVE, STEP_NONE, STEP_PREPARE, STEP_START, STEP_ACTIVE, STEP_ACTIVATED, STEP_PREPARED;
var init_interface = __esm({
  "node_modules/rc-motion/es/interface.js"() {
    STATUS_NONE = "none";
    STATUS_APPEAR = "appear";
    STATUS_ENTER = "enter";
    STATUS_LEAVE = "leave";
    STEP_NONE = "none";
    STEP_PREPARE = "prepare";
    STEP_START = "start";
    STEP_ACTIVE = "active";
    STEP_ACTIVATED = "end";
    STEP_PREPARED = "prepared";
  }
});

// node_modules/rc-motion/es/util/motion.js
function makePrefixMap(styleProp, eventName) {
  var prefixes = {};
  prefixes[styleProp.toLowerCase()] = eventName.toLowerCase();
  prefixes["Webkit".concat(styleProp)] = "webkit".concat(eventName);
  prefixes["Moz".concat(styleProp)] = "moz".concat(eventName);
  prefixes["ms".concat(styleProp)] = "MS".concat(eventName);
  prefixes["O".concat(styleProp)] = "o".concat(eventName.toLowerCase());
  return prefixes;
}
function getVendorPrefixes(domSupport, win) {
  var prefixes = {
    animationend: makePrefixMap("Animation", "AnimationEnd"),
    transitionend: makePrefixMap("Transition", "TransitionEnd")
  };
  if (domSupport) {
    if (!("AnimationEvent" in win)) {
      delete prefixes.animationend.animation;
    }
    if (!("TransitionEvent" in win)) {
      delete prefixes.transitionend.transition;
    }
  }
  return prefixes;
}
function getVendorPrefixedEventName(eventName) {
  if (prefixedEventNames[eventName]) {
    return prefixedEventNames[eventName];
  }
  var prefixMap = vendorPrefixes[eventName];
  if (prefixMap) {
    var stylePropList = Object.keys(prefixMap);
    var len = stylePropList.length;
    for (var i = 0; i < len; i += 1) {
      var styleProp = stylePropList[i];
      if (Object.prototype.hasOwnProperty.call(prefixMap, styleProp) && styleProp in style) {
        prefixedEventNames[eventName] = prefixMap[styleProp];
        return prefixedEventNames[eventName];
      }
    }
  }
  return "";
}
function getTransitionName(transitionName, transitionType) {
  if (!transitionName)
    return null;
  if (_typeof(transitionName) === "object") {
    var type = transitionType.replace(/-\w/g, function(match2) {
      return match2[1].toUpperCase();
    });
    return transitionName[type];
  }
  return "".concat(transitionName, "-").concat(transitionType);
}
var vendorPrefixes, style, _document$createEleme, prefixedEventNames, internalAnimationEndName, internalTransitionEndName, supportTransition, animationEndName, transitionEndName;
var init_motion = __esm({
  "node_modules/rc-motion/es/util/motion.js"() {
    init_typeof();
    init_canUseDom();
    vendorPrefixes = getVendorPrefixes(canUseDom(), typeof window !== "undefined" ? window : {});
    style = {};
    if (canUseDom()) {
      _document$createEleme = document.createElement("div");
      style = _document$createEleme.style;
    }
    prefixedEventNames = {};
    internalAnimationEndName = getVendorPrefixedEventName("animationend");
    internalTransitionEndName = getVendorPrefixedEventName("transitionend");
    supportTransition = !!(internalAnimationEndName && internalTransitionEndName);
    animationEndName = internalAnimationEndName || "animationend";
    transitionEndName = internalTransitionEndName || "transitionend";
  }
});

// node_modules/rc-motion/es/hooks/useDomMotionEvents.js
var React11, import_react3, useDomMotionEvents_default;
var init_useDomMotionEvents = __esm({
  "node_modules/rc-motion/es/hooks/useDomMotionEvents.js"() {
    React11 = __toESM(require_react());
    import_react3 = __toESM(require_react());
    init_motion();
    useDomMotionEvents_default = function(callback) {
      var cacheElementRef = (0, import_react3.useRef)();
      var callbackRef = (0, import_react3.useRef)(callback);
      callbackRef.current = callback;
      var onInternalMotionEnd = React11.useCallback(function(event) {
        callbackRef.current(event);
      }, []);
      function removeMotionEvents(element) {
        if (element) {
          element.removeEventListener(transitionEndName, onInternalMotionEnd);
          element.removeEventListener(animationEndName, onInternalMotionEnd);
        }
      }
      function patchMotionEvents(element) {
        if (cacheElementRef.current && cacheElementRef.current !== element) {
          removeMotionEvents(cacheElementRef.current);
        }
        if (element && element !== cacheElementRef.current) {
          element.addEventListener(transitionEndName, onInternalMotionEnd);
          element.addEventListener(animationEndName, onInternalMotionEnd);
          cacheElementRef.current = element;
        }
      }
      React11.useEffect(function() {
        return function() {
          removeMotionEvents(cacheElementRef.current);
        };
      }, []);
      return [patchMotionEvents, removeMotionEvents];
    };
  }
});

// node_modules/rc-motion/es/hooks/useIsomorphicLayoutEffect.js
var import_react4, useIsomorphicLayoutEffect, useIsomorphicLayoutEffect_default;
var init_useIsomorphicLayoutEffect = __esm({
  "node_modules/rc-motion/es/hooks/useIsomorphicLayoutEffect.js"() {
    import_react4 = __toESM(require_react());
    init_canUseDom();
    useIsomorphicLayoutEffect = canUseDom() ? import_react4.useLayoutEffect : import_react4.useEffect;
    useIsomorphicLayoutEffect_default = useIsomorphicLayoutEffect;
  }
});

// node_modules/rc-util/es/raf.js
function cleanup(id) {
  rafIds.delete(id);
}
var raf, caf, rafUUID, rafIds, wrapperRaf, raf_default;
var init_raf = __esm({
  "node_modules/rc-util/es/raf.js"() {
    raf = function raf2(callback) {
      return +setTimeout(callback, 16);
    };
    caf = function caf2(num) {
      return clearTimeout(num);
    };
    if (typeof window !== "undefined" && "requestAnimationFrame" in window) {
      raf = function raf3(callback) {
        return window.requestAnimationFrame(callback);
      };
      caf = function caf3(handle) {
        return window.cancelAnimationFrame(handle);
      };
    }
    rafUUID = 0;
    rafIds = /* @__PURE__ */ new Map();
    wrapperRaf = function wrapperRaf2(callback) {
      var times = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 1;
      rafUUID += 1;
      var id = rafUUID;
      function callRef(leftTimes) {
        if (leftTimes === 0) {
          cleanup(id);
          callback();
        } else {
          var realId = raf(function() {
            callRef(leftTimes - 1);
          });
          rafIds.set(id, realId);
        }
      }
      callRef(times);
      return id;
    };
    wrapperRaf.cancel = function(id) {
      var realId = rafIds.get(id);
      cleanup(realId);
      return caf(realId);
    };
    raf_default = wrapperRaf;
  }
});

// node_modules/rc-motion/es/hooks/useNextFrame.js
var React12, useNextFrame_default;
var init_useNextFrame = __esm({
  "node_modules/rc-motion/es/hooks/useNextFrame.js"() {
    React12 = __toESM(require_react());
    init_raf();
    useNextFrame_default = function() {
      var nextFrameRef = React12.useRef(null);
      function cancelNextFrame() {
        raf_default.cancel(nextFrameRef.current);
      }
      function nextFrame(callback) {
        var delay = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 2;
        cancelNextFrame();
        var nextFrameId = raf_default(function() {
          if (delay <= 1) {
            callback({
              isCanceled: function isCanceled() {
                return nextFrameId !== nextFrameRef.current;
              }
            });
          } else {
            nextFrame(callback, delay - 1);
          }
        });
        nextFrameRef.current = nextFrameId;
      }
      React12.useEffect(function() {
        return function() {
          cancelNextFrame();
        };
      }, []);
      return [nextFrame, cancelNextFrame];
    };
  }
});

// node_modules/rc-motion/es/hooks/useStepQueue.js
function isActive(step) {
  return step === STEP_ACTIVE || step === STEP_ACTIVATED;
}
var React13, FULL_STEP_QUEUE, SIMPLE_STEP_QUEUE, SkipStep, DoStep, useStepQueue_default;
var init_useStepQueue = __esm({
  "node_modules/rc-motion/es/hooks/useStepQueue.js"() {
    init_slicedToArray();
    init_useState();
    React13 = __toESM(require_react());
    init_interface();
    init_useIsomorphicLayoutEffect();
    init_useNextFrame();
    FULL_STEP_QUEUE = [STEP_PREPARE, STEP_START, STEP_ACTIVE, STEP_ACTIVATED];
    SIMPLE_STEP_QUEUE = [STEP_PREPARE, STEP_PREPARED];
    SkipStep = false;
    DoStep = true;
    useStepQueue_default = function(status, prepareOnly, callback) {
      var _useState = useSafeState(STEP_NONE), _useState2 = _slicedToArray(_useState, 2), step = _useState2[0], setStep = _useState2[1];
      var _useNextFrame = useNextFrame_default(), _useNextFrame2 = _slicedToArray(_useNextFrame, 2), nextFrame = _useNextFrame2[0], cancelNextFrame = _useNextFrame2[1];
      function startQueue() {
        setStep(STEP_PREPARE, true);
      }
      var STEP_QUEUE = prepareOnly ? SIMPLE_STEP_QUEUE : FULL_STEP_QUEUE;
      useIsomorphicLayoutEffect_default(function() {
        if (step !== STEP_NONE && step !== STEP_ACTIVATED) {
          var index = STEP_QUEUE.indexOf(step);
          var nextStep = STEP_QUEUE[index + 1];
          var result = callback(step);
          if (result === SkipStep) {
            setStep(nextStep, true);
          } else if (nextStep) {
            nextFrame(function(info) {
              function doNext() {
                if (info.isCanceled())
                  return;
                setStep(nextStep, true);
              }
              if (result === true) {
                doNext();
              } else {
                Promise.resolve(result).then(doNext);
              }
            });
          }
        }
      }, [status, step]);
      React13.useEffect(function() {
        return function() {
          cancelNextFrame();
        };
      }, []);
      return [startQueue, step];
    };
  }
});

// node_modules/rc-motion/es/hooks/useStatus.js
function useStatus(supportMotion, visible, getElement, _ref) {
  var _ref$motionEnter = _ref.motionEnter, motionEnter = _ref$motionEnter === void 0 ? true : _ref$motionEnter, _ref$motionAppear = _ref.motionAppear, motionAppear = _ref$motionAppear === void 0 ? true : _ref$motionAppear, _ref$motionLeave = _ref.motionLeave, motionLeave = _ref$motionLeave === void 0 ? true : _ref$motionLeave, motionDeadline = _ref.motionDeadline, motionLeaveImmediately = _ref.motionLeaveImmediately, onAppearPrepare = _ref.onAppearPrepare, onEnterPrepare = _ref.onEnterPrepare, onLeavePrepare = _ref.onLeavePrepare, onAppearStart = _ref.onAppearStart, onEnterStart = _ref.onEnterStart, onLeaveStart = _ref.onLeaveStart, onAppearActive = _ref.onAppearActive, onEnterActive = _ref.onEnterActive, onLeaveActive = _ref.onLeaveActive, onAppearEnd = _ref.onAppearEnd, onEnterEnd = _ref.onEnterEnd, onLeaveEnd = _ref.onLeaveEnd, onVisibleChanged = _ref.onVisibleChanged;
  var _useState = useSafeState(), _useState2 = _slicedToArray(_useState, 2), asyncVisible = _useState2[0], setAsyncVisible = _useState2[1];
  var _useState3 = useSafeState(STATUS_NONE), _useState4 = _slicedToArray(_useState3, 2), status = _useState4[0], setStatus = _useState4[1];
  var _useState5 = useSafeState(null), _useState6 = _slicedToArray(_useState5, 2), style2 = _useState6[0], setStyle = _useState6[1];
  var mountedRef = (0, import_react5.useRef)(false);
  var deadlineRef = (0, import_react5.useRef)(null);
  function getDomElement() {
    return getElement();
  }
  var activeRef = (0, import_react5.useRef)(false);
  function updateMotionEndStatus() {
    setStatus(STATUS_NONE, true);
    setStyle(null, true);
  }
  function onInternalMotionEnd(event) {
    var element = getDomElement();
    if (event && !event.deadline && event.target !== element) {
      return;
    }
    var currentActive = activeRef.current;
    var canEnd;
    if (status === STATUS_APPEAR && currentActive) {
      canEnd = onAppearEnd === null || onAppearEnd === void 0 ? void 0 : onAppearEnd(element, event);
    } else if (status === STATUS_ENTER && currentActive) {
      canEnd = onEnterEnd === null || onEnterEnd === void 0 ? void 0 : onEnterEnd(element, event);
    } else if (status === STATUS_LEAVE && currentActive) {
      canEnd = onLeaveEnd === null || onLeaveEnd === void 0 ? void 0 : onLeaveEnd(element, event);
    }
    if (status !== STATUS_NONE && currentActive && canEnd !== false) {
      updateMotionEndStatus();
    }
  }
  var _useDomMotionEvents = useDomMotionEvents_default(onInternalMotionEnd), _useDomMotionEvents2 = _slicedToArray(_useDomMotionEvents, 1), patchMotionEvents = _useDomMotionEvents2[0];
  var getEventHandlers = function getEventHandlers2(targetStatus) {
    var _ref2, _ref3, _ref4;
    switch (targetStatus) {
      case STATUS_APPEAR:
        return _ref2 = {}, _defineProperty(_ref2, STEP_PREPARE, onAppearPrepare), _defineProperty(_ref2, STEP_START, onAppearStart), _defineProperty(_ref2, STEP_ACTIVE, onAppearActive), _ref2;
      case STATUS_ENTER:
        return _ref3 = {}, _defineProperty(_ref3, STEP_PREPARE, onEnterPrepare), _defineProperty(_ref3, STEP_START, onEnterStart), _defineProperty(_ref3, STEP_ACTIVE, onEnterActive), _ref3;
      case STATUS_LEAVE:
        return _ref4 = {}, _defineProperty(_ref4, STEP_PREPARE, onLeavePrepare), _defineProperty(_ref4, STEP_START, onLeaveStart), _defineProperty(_ref4, STEP_ACTIVE, onLeaveActive), _ref4;
      default:
        return {};
    }
  };
  var eventHandlers = React14.useMemo(function() {
    return getEventHandlers(status);
  }, [status]);
  var _useStepQueue = useStepQueue_default(status, !supportMotion, function(newStep) {
    if (newStep === STEP_PREPARE) {
      var onPrepare = eventHandlers[STEP_PREPARE];
      if (!onPrepare) {
        return SkipStep;
      }
      return onPrepare(getDomElement());
    }
    if (step in eventHandlers) {
      var _eventHandlers$step;
      setStyle(((_eventHandlers$step = eventHandlers[step]) === null || _eventHandlers$step === void 0 ? void 0 : _eventHandlers$step.call(eventHandlers, getDomElement(), null)) || null);
    }
    if (step === STEP_ACTIVE) {
      patchMotionEvents(getDomElement());
      if (motionDeadline > 0) {
        clearTimeout(deadlineRef.current);
        deadlineRef.current = setTimeout(function() {
          onInternalMotionEnd({
            deadline: true
          });
        }, motionDeadline);
      }
    }
    if (step === STEP_PREPARED) {
      updateMotionEndStatus();
    }
    return DoStep;
  }), _useStepQueue2 = _slicedToArray(_useStepQueue, 2), startStep = _useStepQueue2[0], step = _useStepQueue2[1];
  var active = isActive(step);
  activeRef.current = active;
  useIsomorphicLayoutEffect_default(function() {
    setAsyncVisible(visible);
    var isMounted = mountedRef.current;
    mountedRef.current = true;
    var nextStatus;
    if (!isMounted && visible && motionAppear) {
      nextStatus = STATUS_APPEAR;
    }
    if (isMounted && visible && motionEnter) {
      nextStatus = STATUS_ENTER;
    }
    if (isMounted && !visible && motionLeave || !isMounted && motionLeaveImmediately && !visible && motionLeave) {
      nextStatus = STATUS_LEAVE;
    }
    var nextEventHandlers = getEventHandlers(nextStatus);
    if (nextStatus && (supportMotion || nextEventHandlers[STEP_PREPARE])) {
      setStatus(nextStatus);
      startStep();
    } else {
      setStatus(STATUS_NONE);
    }
  }, [visible]);
  (0, import_react5.useEffect)(function() {
    if (
      // Cancel appear
      status === STATUS_APPEAR && !motionAppear || // Cancel enter
      status === STATUS_ENTER && !motionEnter || // Cancel leave
      status === STATUS_LEAVE && !motionLeave
    ) {
      setStatus(STATUS_NONE);
    }
  }, [motionAppear, motionEnter, motionLeave]);
  (0, import_react5.useEffect)(function() {
    return function() {
      mountedRef.current = false;
      clearTimeout(deadlineRef.current);
    };
  }, []);
  var firstMountChangeRef = React14.useRef(false);
  (0, import_react5.useEffect)(function() {
    if (asyncVisible) {
      firstMountChangeRef.current = true;
    }
    if (asyncVisible !== void 0 && status === STATUS_NONE) {
      if (firstMountChangeRef.current || asyncVisible) {
        onVisibleChanged === null || onVisibleChanged === void 0 ? void 0 : onVisibleChanged(asyncVisible);
      }
      firstMountChangeRef.current = true;
    }
  }, [asyncVisible, status]);
  var mergedStyle = style2;
  if (eventHandlers[STEP_PREPARE] && step === STEP_START) {
    mergedStyle = _objectSpread2({
      transition: "none"
    }, mergedStyle);
  }
  return [status, step, mergedStyle, asyncVisible !== null && asyncVisible !== void 0 ? asyncVisible : visible];
}
var React14, import_react5;
var init_useStatus = __esm({
  "node_modules/rc-motion/es/hooks/useStatus.js"() {
    init_objectSpread2();
    init_defineProperty();
    init_slicedToArray();
    init_useState();
    React14 = __toESM(require_react());
    import_react5 = __toESM(require_react());
    init_interface();
    init_useDomMotionEvents();
    init_useIsomorphicLayoutEffect();
    init_useStepQueue();
  }
});

// node_modules/rc-motion/es/CSSMotion.js
function genCSSMotion(config) {
  var transitionSupport = config;
  if (_typeof(config) === "object") {
    transitionSupport = config.transitionSupport;
  }
  function isSupportTransition(props, contextMotion) {
    return !!(props.motionName && transitionSupport && contextMotion !== false);
  }
  var CSSMotion = React15.forwardRef(function(props, ref) {
    var _props$visible = props.visible, visible = _props$visible === void 0 ? true : _props$visible, _props$removeOnLeave = props.removeOnLeave, removeOnLeave = _props$removeOnLeave === void 0 ? true : _props$removeOnLeave, forceRender = props.forceRender, children = props.children, motionName = props.motionName, leavedClassName = props.leavedClassName, eventProps = props.eventProps;
    var _React$useContext = React15.useContext(Context), contextMotion = _React$useContext.motion;
    var supportMotion = isSupportTransition(props, contextMotion);
    var nodeRef = (0, import_react6.useRef)();
    var wrapperNodeRef = (0, import_react6.useRef)();
    function getDomElement() {
      try {
        return nodeRef.current instanceof HTMLElement ? nodeRef.current : findDOMNode(wrapperNodeRef.current);
      } catch (e) {
        return null;
      }
    }
    var _useStatus = useStatus(supportMotion, visible, getDomElement, props), _useStatus2 = _slicedToArray(_useStatus, 4), status = _useStatus2[0], statusStep = _useStatus2[1], statusStyle = _useStatus2[2], mergedVisible = _useStatus2[3];
    var renderedRef = React15.useRef(mergedVisible);
    if (mergedVisible) {
      renderedRef.current = true;
    }
    var setNodeRef = React15.useCallback(function(node2) {
      nodeRef.current = node2;
      fillRef(ref, node2);
    }, [ref]);
    var motionChildren;
    var mergedProps = _objectSpread2(_objectSpread2({}, eventProps), {}, {
      visible
    });
    if (!children) {
      motionChildren = null;
    } else if (status === STATUS_NONE) {
      if (mergedVisible) {
        motionChildren = children(_objectSpread2({}, mergedProps), setNodeRef);
      } else if (!removeOnLeave && renderedRef.current && leavedClassName) {
        motionChildren = children(_objectSpread2(_objectSpread2({}, mergedProps), {}, {
          className: leavedClassName
        }), setNodeRef);
      } else if (forceRender || !removeOnLeave && !leavedClassName) {
        motionChildren = children(_objectSpread2(_objectSpread2({}, mergedProps), {}, {
          style: {
            display: "none"
          }
        }), setNodeRef);
      } else {
        motionChildren = null;
      }
    } else {
      var _classNames;
      var statusSuffix;
      if (statusStep === STEP_PREPARE) {
        statusSuffix = "prepare";
      } else if (isActive(statusStep)) {
        statusSuffix = "active";
      } else if (statusStep === STEP_START) {
        statusSuffix = "start";
      }
      var motionCls = getTransitionName(motionName, "".concat(status, "-").concat(statusSuffix));
      motionChildren = children(_objectSpread2(_objectSpread2({}, mergedProps), {}, {
        className: (0, import_classnames.default)(getTransitionName(motionName, status), (_classNames = {}, _defineProperty(_classNames, motionCls, motionCls && statusSuffix), _defineProperty(_classNames, motionName, typeof motionName === "string"), _classNames)),
        style: statusStyle
      }), setNodeRef);
    }
    if (React15.isValidElement(motionChildren) && supportRef(motionChildren)) {
      var _ref = motionChildren, originNodeRef = _ref.ref;
      if (!originNodeRef) {
        motionChildren = React15.cloneElement(motionChildren, {
          ref: setNodeRef
        });
      }
    }
    return React15.createElement(DomWrapper_default, {
      ref: wrapperNodeRef
    }, motionChildren);
  });
  CSSMotion.displayName = "CSSMotion";
  return CSSMotion;
}
var import_classnames, React15, import_react6, CSSMotion_default;
var init_CSSMotion = __esm({
  "node_modules/rc-motion/es/CSSMotion.js"() {
    init_defineProperty();
    init_objectSpread2();
    init_slicedToArray();
    init_typeof();
    import_classnames = __toESM(require_classnames());
    init_findDOMNode();
    init_ref();
    React15 = __toESM(require_react());
    import_react6 = __toESM(require_react());
    init_context();
    init_DomWrapper();
    init_useStatus();
    init_useStepQueue();
    init_interface();
    init_motion();
    CSSMotion_default = genCSSMotion(supportTransition);
  }
});

// node_modules/rc-motion/es/util/diff.js
function wrapKeyToObject(key) {
  var keyObj;
  if (key && _typeof(key) === "object" && "key" in key) {
    keyObj = key;
  } else {
    keyObj = {
      key
    };
  }
  return _objectSpread2(_objectSpread2({}, keyObj), {}, {
    key: String(keyObj.key)
  });
}
function parseKeys() {
  var keys = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : [];
  return keys.map(wrapKeyToObject);
}
function diffKeys() {
  var prevKeys = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : [];
  var currentKeys = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : [];
  var list = [];
  var currentIndex = 0;
  var currentLen = currentKeys.length;
  var prevKeyObjects = parseKeys(prevKeys);
  var currentKeyObjects = parseKeys(currentKeys);
  prevKeyObjects.forEach(function(keyObj) {
    var hit = false;
    for (var i = currentIndex; i < currentLen; i += 1) {
      var currentKeyObj = currentKeyObjects[i];
      if (currentKeyObj.key === keyObj.key) {
        if (currentIndex < i) {
          list = list.concat(currentKeyObjects.slice(currentIndex, i).map(function(obj) {
            return _objectSpread2(_objectSpread2({}, obj), {}, {
              status: STATUS_ADD
            });
          }));
          currentIndex = i;
        }
        list.push(_objectSpread2(_objectSpread2({}, currentKeyObj), {}, {
          status: STATUS_KEEP
        }));
        currentIndex += 1;
        hit = true;
        break;
      }
    }
    if (!hit) {
      list.push(_objectSpread2(_objectSpread2({}, keyObj), {}, {
        status: STATUS_REMOVE
      }));
    }
  });
  if (currentIndex < currentLen) {
    list = list.concat(currentKeyObjects.slice(currentIndex).map(function(obj) {
      return _objectSpread2(_objectSpread2({}, obj), {}, {
        status: STATUS_ADD
      });
    }));
  }
  var keys = {};
  list.forEach(function(_ref) {
    var key = _ref.key;
    keys[key] = (keys[key] || 0) + 1;
  });
  var duplicatedKeys = Object.keys(keys).filter(function(key) {
    return keys[key] > 1;
  });
  duplicatedKeys.forEach(function(matchKey) {
    list = list.filter(function(_ref2) {
      var key = _ref2.key, status = _ref2.status;
      return key !== matchKey || status !== STATUS_REMOVE;
    });
    list.forEach(function(node2) {
      if (node2.key === matchKey) {
        node2.status = STATUS_KEEP;
      }
    });
  });
  return list;
}
var STATUS_ADD, STATUS_KEEP, STATUS_REMOVE, STATUS_REMOVED;
var init_diff = __esm({
  "node_modules/rc-motion/es/util/diff.js"() {
    init_objectSpread2();
    init_typeof();
    STATUS_ADD = "add";
    STATUS_KEEP = "keep";
    STATUS_REMOVE = "remove";
    STATUS_REMOVED = "removed";
  }
});

// node_modules/rc-motion/es/CSSMotionList.js
function genCSSMotionList(transitionSupport) {
  var CSSMotion = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : CSSMotion_default;
  var CSSMotionList = function(_React$Component) {
    _inherits(CSSMotionList2, _React$Component);
    var _super = _createSuper(CSSMotionList2);
    function CSSMotionList2() {
      var _this;
      _classCallCheck(this, CSSMotionList2);
      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }
      _this = _super.call.apply(_super, [this].concat(args));
      _defineProperty(_assertThisInitialized(_this), "state", {
        keyEntities: []
      });
      _defineProperty(_assertThisInitialized(_this), "removeKey", function(removeKey) {
        var keyEntities = _this.state.keyEntities;
        var nextKeyEntities = keyEntities.map(function(entity) {
          if (entity.key !== removeKey)
            return entity;
          return _objectSpread2(_objectSpread2({}, entity), {}, {
            status: STATUS_REMOVED
          });
        });
        _this.setState({
          keyEntities: nextKeyEntities
        });
        return nextKeyEntities.filter(function(_ref) {
          var status = _ref.status;
          return status !== STATUS_REMOVED;
        }).length;
      });
      return _this;
    }
    _createClass(CSSMotionList2, [{
      key: "render",
      value: function render() {
        var _this2 = this;
        var keyEntities = this.state.keyEntities;
        var _this$props = this.props, component = _this$props.component, children = _this$props.children, _onVisibleChanged = _this$props.onVisibleChanged, onAllRemoved = _this$props.onAllRemoved, restProps = _objectWithoutProperties(_this$props, _excluded3);
        var Component3 = component || React16.Fragment;
        var motionProps = {};
        MOTION_PROP_NAMES.forEach(function(prop) {
          motionProps[prop] = restProps[prop];
          delete restProps[prop];
        });
        delete restProps.keys;
        return React16.createElement(Component3, restProps, keyEntities.map(function(_ref2) {
          var status = _ref2.status, eventProps = _objectWithoutProperties(_ref2, _excluded22);
          var visible = status === STATUS_ADD || status === STATUS_KEEP;
          return React16.createElement(CSSMotion, _extends({}, motionProps, {
            key: eventProps.key,
            visible,
            eventProps,
            onVisibleChanged: function onVisibleChanged(changedVisible) {
              _onVisibleChanged === null || _onVisibleChanged === void 0 ? void 0 : _onVisibleChanged(changedVisible, {
                key: eventProps.key
              });
              if (!changedVisible) {
                var restKeysCount = _this2.removeKey(eventProps.key);
                if (restKeysCount === 0 && onAllRemoved) {
                  onAllRemoved();
                }
              }
            }
          }), children);
        }));
      }
    }], [{
      key: "getDerivedStateFromProps",
      value: function getDerivedStateFromProps(_ref3, _ref4) {
        var keys = _ref3.keys;
        var keyEntities = _ref4.keyEntities;
        var parsedKeyObjects = parseKeys(keys);
        var mixedKeyEntities = diffKeys(keyEntities, parsedKeyObjects);
        return {
          keyEntities: mixedKeyEntities.filter(function(entity) {
            var prevEntity = keyEntities.find(function(_ref5) {
              var key = _ref5.key;
              return entity.key === key;
            });
            if (prevEntity && prevEntity.status === STATUS_REMOVED && entity.status === STATUS_REMOVE) {
              return false;
            }
            return true;
          })
        };
      }
      // ZombieJ: Return the count of rest keys. It's safe to refactor if need more info.
    }]);
    return CSSMotionList2;
  }(React16.Component);
  _defineProperty(CSSMotionList, "defaultProps", {
    component: "div"
  });
  return CSSMotionList;
}
var React16, _excluded3, _excluded22, MOTION_PROP_NAMES, CSSMotionList_default;
var init_CSSMotionList = __esm({
  "node_modules/rc-motion/es/CSSMotionList.js"() {
    init_extends();
    init_objectWithoutProperties();
    init_objectSpread2();
    init_classCallCheck();
    init_createClass();
    init_assertThisInitialized();
    init_inherits();
    init_createSuper();
    init_defineProperty();
    React16 = __toESM(require_react());
    init_CSSMotion();
    init_motion();
    init_diff();
    _excluded3 = ["component", "children", "onVisibleChanged", "onAllRemoved"];
    _excluded22 = ["status"];
    MOTION_PROP_NAMES = ["eventProps", "visible", "children", "motionName", "motionAppear", "motionEnter", "motionLeave", "motionLeaveImmediately", "motionDeadline", "removeOnLeave", "leavedClassName", "onAppearStart", "onAppearActive", "onAppearEnd", "onEnterStart", "onEnterActive", "onEnterEnd", "onLeaveStart", "onLeaveActive", "onLeaveEnd"];
    CSSMotionList_default = genCSSMotionList(supportTransition);
  }
});

// node_modules/rc-motion/es/index.js
var es_exports2 = {};
__export(es_exports2, {
  CSSMotionList: () => CSSMotionList_default,
  Provider: () => MotionProvider,
  default: () => es_default
});
var es_default;
var init_es2 = __esm({
  "node_modules/rc-motion/es/index.js"() {
    init_CSSMotion();
    init_CSSMotionList();
    init_context();
    es_default = CSSMotion_default;
  }
});

// node_modules/rc-util/es/index.js
var es_exports3 = {};
__export(es_exports3, {
  get: () => get,
  set: () => set,
  useMergedState: () => useMergedState,
  warning: () => warning_default
});
var init_es3 = __esm({
  "node_modules/rc-util/es/index.js"() {
    init_useMergedState();
    init_get();
    init_set();
    init_warning();
  }
});

export {
  _toConsumableArray,
  init_toConsumableArray,
  isEqual_default,
  init_isEqual,
  _classCallCheck,
  init_classCallCheck,
  _createClass,
  init_createClass,
  getComputedToken,
  useCacheToken,
  useStyleRegister,
  Keyframes_default,
  createTheme,
  es_exports,
  init_es,
  _toArray,
  init_toArray,
  get,
  init_get,
  set,
  merge,
  init_set,
  useEvent,
  init_useEvent,
  useLayoutUpdateEffect,
  useLayoutEffect_default,
  init_useLayoutEffect,
  useSafeState,
  init_useState,
  useMergedState,
  init_useMergedState,
  es_exports3 as es_exports2,
  init_es3 as init_es2,
  isDOM,
  findDOMNode,
  init_findDOMNode,
  MotionProvider,
  _inherits,
  init_inherits,
  _assertThisInitialized,
  init_assertThisInitialized,
  _createSuper,
  init_createSuper,
  raf_default,
  init_raf,
  CSSMotionList_default,
  es_default,
  es_exports2 as es_exports3,
  init_es2 as init_es3
};
//# sourceMappingURL=chunk-KXJUBSWK.js.map
