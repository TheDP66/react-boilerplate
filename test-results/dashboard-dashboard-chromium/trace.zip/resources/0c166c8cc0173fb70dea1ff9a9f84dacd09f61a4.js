export const v = "4.7.0";
export const fr = 25;
export const ip = 0;
export const op = 50;
export const w = 120;
export const h = 120;
export const nm = "Comp 1";
export const ddd = 0;
export const assets = [
];
export const layers = [
	{
		ddd: 0,
		ind: 1,
		ty: 4,
		nm: "ruoi",
		ks: {
			o: {
				a: 1,
				k: [
					{
						i: {
							x: [
								0.833
							],
							y: [
								0.967
							]
						},
						o: {
							x: [
								0.167
							],
							y: [
								0.033
							]
						},
						n: [
							"0p833_0p967_0p167_0p033"
						],
						t: 35,
						s: [
							100
						],
						e: [
							0
						]
					},
					{
						t: 49
					}
				]
			},
			r: {
				a: 0,
				k: 0
			},
			p: {
				a: 1,
				k: [
					{
						i: {
							x: 0.833,
							y: 0.833
						},
						o: {
							x: 0,
							y: 0
						},
						n: "0p833_0p833_0_0",
						t: 0,
						s: [
							57.361,
							61.016,
							0
						],
						e: [
							57.699,
							41.796,
							0
						],
						to: [
							-4.67500305175781,
							-4.12800598144531,
							0
						],
						ti: [
							-13.9099960327148,
							5.27300262451172,
							0
						]
					},
					{
						i: {
							x: 0.833,
							y: 0.833
						},
						o: {
							x: 0.167,
							y: 0.167
						},
						n: "0p833_0p833_0p167_0p167",
						t: 10.219,
						s: [
							57.699,
							41.796,
							0
						],
						e: [
							79.084,
							33.982,
							0
						],
						to: [
							12.8159942626953,
							-4.85800170898438,
							0
						],
						ti: [
							-4.54498291015625,
							3.73400115966797,
							0
						]
					},
					{
						i: {
							x: 0.833,
							y: 0.833
						},
						o: {
							x: 0.167,
							y: 0.167
						},
						n: "0p833_0p833_0p167_0p167",
						t: 19.445,
						s: [
							79.084,
							33.982,
							0
						],
						e: [
							59.691,
							9.121,
							0
						],
						to: [
							6.61601257324219,
							-5.43799591064453,
							0
						],
						ti: [
							20.0290069580078,
							1.20700073242188,
							0
						]
					},
					{
						t: 35
					}
				]
			},
			a: {
				a: 0,
				k: [
					60.531,
					10.945,
					0
				]
			},
			s: {
				a: 0,
				k: [
					100,
					100,
					100
				]
			}
		},
		ao: 0,
		shapes: [
			{
				ty: "gr",
				it: [
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												-0.994,
												0
											],
											[
												0,
												-0.994
											],
											[
												0.995,
												0
											],
											[
												0,
												0.994
											]
										],
										o: [
											[
												0.995,
												0
											],
											[
												0,
												0.994
											],
											[
												-0.994,
												0
											],
											[
												0,
												-0.994
											]
										],
										v: [
											[
												-0.001,
												-1.801
											],
											[
												1.801,
												-0.001
											],
											[
												-0.001,
												1.801
											],
											[
												-1.801,
												-0.001
											]
										],
										c: true
									}
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group"
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										0.4235294117647059,
										0.4235294117647059,
										0.4235294117647059,
										1
									]
								},
								o: {
									a: 0,
									k: 100
								},
								r: 1,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill"
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										62.4,
										13.144
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 1",
						np: 2,
						cix: 2,
						ix: 1,
						mn: "ADBE Vector Group"
					},
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												-1.422,
												0
											],
											[
												0,
												-1.422
											],
											[
												1.421,
												0
											],
											[
												0,
												1.422
											]
										],
										o: [
											[
												1.421,
												0
											],
											[
												0,
												1.422
											],
											[
												-1.422,
												0
											],
											[
												0,
												-1.422
											]
										],
										v: [
											[
												0.001,
												-2.574
											],
											[
												2.574,
												0
											],
											[
												0.001,
												2.574
											],
											[
												-2.574,
												0
											]
										],
										c: true
									}
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group"
							},
							{
								ty: "st",
								c: {
									a: 0,
									k: [
										0.4235294117647059,
										0.4235294117647059,
										0.4235294117647059,
										1
									]
								},
								o: {
									a: 0,
									k: 100
								},
								w: {
									a: 0,
									k: 0.7
								},
								lc: 1,
								lj: 1,
								ml: 10,
								nm: "Stroke 1",
								mn: "ADBE Vector Graphic - Stroke"
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										1,
										1,
										1,
										1
									]
								},
								o: {
									a: 0,
									k: 100
								},
								r: 1,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill"
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										64.145,
										9.606
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 2",
						np: 3,
						cix: 2,
						ix: 2,
						mn: "ADBE Vector Group"
					},
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												-1.996,
												0
											],
											[
												0,
												-1.996
											],
											[
												1.996,
												0
											],
											[
												0,
												1.996
											]
										],
										o: [
											[
												1.996,
												0
											],
											[
												0,
												1.996
											],
											[
												-1.996,
												0
											],
											[
												0,
												-1.996
											]
										],
										v: [
											[
												0,
												-3.614
											],
											[
												3.614,
												0
											],
											[
												0,
												3.614
											],
											[
												-3.614,
												0
											]
										],
										c: true
									}
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group"
							},
							{
								ty: "st",
								c: {
									a: 0,
									k: [
										0.4235294117647059,
										0.4235294117647059,
										0.4235294117647059,
										1
									]
								},
								o: {
									a: 0,
									k: 100
								},
								w: {
									a: 0,
									k: 0.7
								},
								lc: 1,
								lj: 1,
								ml: 10,
								nm: "Stroke 1",
								mn: "ADBE Vector Graphic - Stroke"
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										1,
										1,
										1,
										1
									]
								},
								o: {
									a: 0,
									k: 100
								},
								r: 1,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill"
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										57.957,
										10.552
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 3",
						np: 3,
						cix: 2,
						ix: 3,
						mn: "ADBE Vector Group"
					},
					{
						ty: "tr",
						p: {
							a: 0,
							k: [
								60.531,
								10.941
							],
							ix: 2
						},
						a: {
							a: 0,
							k: [
								60.531,
								10.941
							],
							ix: 1
						},
						s: {
							a: 0,
							k: [
								100,
								100
							],
							ix: 3
						},
						r: {
							a: 0,
							k: 0,
							ix: 6
						},
						o: {
							a: 0,
							k: 100,
							ix: 7
						},
						sk: {
							a: 0,
							k: 0,
							ix: 4
						},
						sa: {
							a: 0,
							k: 0,
							ix: 5
						},
						nm: "Transform"
					}
				],
				nm: "ruoi",
				np: 3,
				cix: 2,
				ix: 1,
				mn: "ADBE Vector Group"
			}
		],
		ip: 0,
		op: 50,
		st: 0,
		bm: 0,
		sr: 1
	},
	{
		ddd: 0,
		ind: 2,
		ty: 4,
		nm: "Shape Layer 2",
		ks: {
			o: {
				a: 1,
				k: [
					{
						i: {
							x: [
								0.833
							],
							y: [
								0.967
							]
						},
						o: {
							x: [
								0.167
							],
							y: [
								0.033
							]
						},
						n: [
							"0p833_0p967_0p167_0p033"
						],
						t: 35,
						s: [
							100
						],
						e: [
							0
						]
					},
					{
						t: 49
					}
				]
			},
			r: {
				a: 0,
				k: 0
			},
			p: {
				a: 0,
				k: [
					-0.75,
					-0.75,
					0
				]
			},
			a: {
				a: 0,
				k: [
					0,
					0,
					0
				]
			},
			s: {
				a: 0,
				k: [
					100,
					100,
					100
				]
			}
		},
		ao: 0,
		shapes: [
			{
				ty: "gr",
				it: [
					{
						ind: 0,
						ty: "sh",
						ix: 1,
						ks: {
							a: 0,
							k: {
								i: [
									[
										0,
										0
									],
									[
										-13.91,
										5.273
									],
									[
										-4.545,
										3.734
									],
									[
										20.029,
										1.207
									]
								],
								o: [
									[
										-4.675,
										-4.128
									],
									[
										12.816,
										-4.858
									],
									[
										6.616,
										-5.438
									],
									[
										0,
										0
									]
								],
								v: [
									[
										-7.383,
										24.76
									],
									[
										-7.046,
										5.54
									],
									[
										14.34,
										-2.273
									],
									[
										-3.178,
										-24.76
									]
								],
								c: false
							}
						},
						nm: "Path 1",
						mn: "ADBE Vector Shape - Group"
					},
					{
						ty: "st",
						c: {
							a: 0,
							k: [
								0.34901960784313724,
								0.3686274509803922,
								0.4,
								1
							]
						},
						o: {
							a: 0,
							k: 100
						},
						w: {
							a: 0,
							k: 1
						},
						lc: 2,
						lj: 2,
						d: [
							{
								n: "d",
								nm: "dash",
								v: {
									a: 0,
									k: 2.028
								}
							},
							{
								n: "g",
								nm: "gap",
								v: {
									a: 0,
									k: 2.028
								}
							},
							{
								n: "o",
								nm: "offset",
								v: {
									a: 0,
									k: 0
								}
							}
						],
						nm: "Stroke 1",
						mn: "ADBE Vector Graphic - Stroke"
					},
					{
						ty: "tr",
						p: {
							a: 0,
							k: [
								67.87,
								37.631
							],
							ix: 2
						},
						a: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 1
						},
						s: {
							a: 0,
							k: [
								100,
								100
							],
							ix: 3
						},
						r: {
							a: 0,
							k: 0,
							ix: 6
						},
						o: {
							a: 0,
							k: 100,
							ix: 7
						},
						sk: {
							a: 0,
							k: 0,
							ix: 4
						},
						sa: {
							a: 0,
							k: 0,
							ix: 5
						},
						nm: "Transform"
					}
				],
				nm: "Group 6",
				np: 2,
				cix: 2,
				ix: 1,
				mn: "ADBE Vector Group"
			},
			{
				ty: "tm",
				s: {
					a: 0,
					k: 0,
					ix: 1
				},
				e: {
					a: 1,
					k: [
						{
							i: {
								x: [
									0.833
								],
								y: [
									0.953
								]
							},
							o: {
								x: [
									0.167
								],
								y: [
									0.033
								]
							},
							n: [
								"0p833_0p953_0p167_0p033"
							],
							t: 0,
							s: [
								0
							],
							e: [
								100
							]
						},
						{
							t: 35
						}
					],
					ix: 2
				},
				o: {
					a: 0,
					k: 0,
					ix: 3
				},
				m: 1,
				ix: 2,
				nm: "Trim Paths 1",
				mn: "ADBE Vector Filter - Trim"
			}
		],
		ip: 0,
		op: 50,
		st: 0,
		bm: 0,
		sr: 1
	},
	{
		ddd: 0,
		ind: 3,
		ty: 4,
		nm: "im_emptyBox Outlines",
		ks: {
			o: {
				a: 0,
				k: 100
			},
			r: {
				a: 0,
				k: 0
			},
			p: {
				a: 0,
				k: [
					60,
					60,
					0
				]
			},
			a: {
				a: 0,
				k: [
					60,
					60,
					0
				]
			},
			s: {
				a: 0,
				k: [
					100,
					100,
					100
				]
			}
		},
		ao: 0,
		shapes: [
			{
				ty: "gr",
				it: [
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											]
										],
										o: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											]
										],
										v: [
											[
												-0.001,
												-16.607
											],
											[
												-32.143,
												-0.002
											],
											[
												-0.001,
												16.607
											],
											[
												32.144,
												-0.002
											]
										],
										c: true
									}
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group"
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										0.8,
										0.82,
										0.851,
										1
									]
								},
								o: {
									a: 0,
									k: 100
								},
								r: 1,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill"
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										60,
										55.75
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 7",
						np: 2,
						cix: 2,
						ix: 1,
						mn: "ADBE Vector Group"
					},
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											]
										],
										o: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											]
										],
										v: [
											[
												12.856,
												-23.249
											],
											[
												0,
												-16.605
											],
											[
												-12.857,
												-23.249
											],
											[
												-45,
												-6.641
											],
											[
												-32.144,
												0.001
											],
											[
												-45,
												6.645
											],
											[
												-12.857,
												23.249
											],
											[
												0,
												16.609
											],
											[
												12.856,
												23.249
											],
											[
												45,
												6.645
											],
											[
												32.143,
												0.001
											],
											[
												45,
												-6.641
											]
										],
										c: true
									}
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group"
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										0.9372549019607843,
										0.9372549019607843,
										0.9372549019607843,
										1
									]
								},
								o: {
									a: 0,
									k: 100
								},
								r: 1,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill"
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										60,
										55.748
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 8",
						np: 2,
						cix: 2,
						ix: 2,
						mn: "ADBE Vector Group"
					},
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											]
										],
										o: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											]
										],
										v: [
											[
												-16.072,
												24.171
											],
											[
												16.072,
												11.312
											],
											[
												16.072,
												-24.171
											],
											[
												-16.072,
												-24.171
											]
										],
										c: true
									}
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group"
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										0.9529411764705882,
										0.9529411764705882,
										0.9529411764705882,
										1
									]
								},
								o: {
									a: 0,
									k: 100
								},
								r: 1,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill"
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										76.072,
										83.33
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 9",
						np: 2,
						cix: 2,
						ix: 3,
						mn: "ADBE Vector Group"
					},
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											]
										],
										o: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											]
										],
										v: [
											[
												-32.143,
												-24.171
											],
											[
												-32.143,
												11.311
											],
											[
												-0.001,
												24.171
											],
											[
												32.144,
												11.311
											],
											[
												32.144,
												-24.171
											]
										],
										c: true
									}
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group"
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										0.8,
										0.82,
										0.851,
										1
									]
								},
								o: {
									a: 0,
									k: 100
								},
								r: 1,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill"
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										60,
										83.33
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 10",
						np: 2,
						cix: 2,
						ix: 4,
						mn: "ADBE Vector Group"
					},
					{
						ty: "tr",
						p: {
							a: 0,
							k: [
								60,
								60.186
							],
							ix: 2
						},
						a: {
							a: 0,
							k: [
								60,
								60.186
							],
							ix: 1
						},
						s: {
							a: 0,
							k: [
								100,
								100
							],
							ix: 3
						},
						r: {
							a: 0,
							k: 0,
							ix: 6
						},
						o: {
							a: 0,
							k: 100,
							ix: 7
						},
						sk: {
							a: 0,
							k: 0,
							ix: 4
						},
						sa: {
							a: 0,
							k: 0,
							ix: 5
						},
						nm: "Transform"
					}
				],
				nm: "box",
				np: 4,
				cix: 2,
				ix: 1,
				mn: "ADBE Vector Group"
			}
		],
		ip: 0,
		op: 50,
		st: 0,
		bm: 0,
		sr: 1
	}
];
export default {
	v: v,
	fr: fr,
	ip: ip,
	op: op,
	w: w,
	h: h,
	nm: nm,
	ddd: ddd,
	assets: assets,
	layers: layers
};
