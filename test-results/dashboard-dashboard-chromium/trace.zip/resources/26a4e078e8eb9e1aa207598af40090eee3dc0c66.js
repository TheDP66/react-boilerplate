import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/layouts/components/LogoButton.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f9dec5ba"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/dharma/Work/react-boilerplate/src/layouts/components/LogoButton.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Button, theme } from "/node_modules/.vite/deps/antd.js?v=26d7e361";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=f9dec5ba"; const React = __vite__cjsImport4_react.__esModule ? __vite__cjsImport4_react.default : __vite__cjsImport4_react;
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=f16f2ff9";
import logo from "/src/assets/images/logo512.png?import";
const {
  useToken
} = theme;
const LogoButton = () => {
  _s();
  const navigate = useNavigate();
  const token = useToken();
  return /* @__PURE__ */ jsxDEV(Button, { icon: /* @__PURE__ */ jsxDEV("img", { src: logo, alt: "logo", height: "25px", style: {
    margin: "0 7px"
  } }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/LogoButton.jsx",
    lineNumber: 13,
    columnNumber: 24
  }, this), type: "primary", size: "large", style: {
    backgroundColor: token.colorPrimaryBg
  }, onClick: () => navigate("/") }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/LogoButton.jsx",
    lineNumber: 13,
    columnNumber: 10
  }, this);
};
_s(LogoButton, "ojwSnr6uK918zRJ+vZw2X4OVKeA=", false, function() {
  return [useNavigate, useToken];
});
_c = LogoButton;
export default LogoButton;
var _c;
$RefreshReg$(_c, "LogoButton");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/dharma/Work/react-boilerplate/src/layouts/components/LogoButton.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZVE7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBZlIsU0FBU0EsUUFBUUMsYUFBYTtBQUM5QixPQUFPQyxXQUFXO0FBQ2xCLFNBQVNDLG1CQUFtQjtBQUU1QixPQUFPQyxVQUFVO0FBRWpCLE1BQU07QUFBQSxFQUFFQztBQUFTLElBQUlKO0FBRXJCLE1BQU1LLGFBQWFBLE1BQU07QUFBQUMsS0FBQTtBQUN2QixRQUFNQyxXQUFXTCxZQUFZO0FBQzdCLFFBQU1NLFFBQVFKLFNBQVM7QUFFdkIsU0FDRSx1QkFBQyxVQUNDLE1BQ0UsdUJBQUMsU0FBSSxLQUFLRCxNQUFNLEtBQUksUUFBTyxRQUFPLFFBQU8sT0FBTztBQUFBLElBQUVNLFFBQVE7QUFBQSxFQUFRLEtBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBb0UsR0FFdEUsTUFBSyxXQUNMLE1BQUssU0FDTCxPQUFPO0FBQUEsSUFBRUMsaUJBQWlCRixNQUFNRztBQUFBQSxFQUFlLEdBQy9DLFNBQVMsTUFBTUosU0FBUyxHQUFHLEtBUDdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FPK0I7QUFHbkM7QUFBRUQsR0FmSUQsWUFBVTtBQUFBLFVBQ0dILGFBQ0hFLFFBQVE7QUFBQTtBQUFBUSxLQUZsQlA7QUFpQk4sZUFBZUE7QUFBVyxJQUFBTztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiQnV0dG9uIiwidGhlbWUiLCJSZWFjdCIsInVzZU5hdmlnYXRlIiwibG9nbyIsInVzZVRva2VuIiwiTG9nb0J1dHRvbiIsIl9zIiwibmF2aWdhdGUiLCJ0b2tlbiIsIm1hcmdpbiIsImJhY2tncm91bmRDb2xvciIsImNvbG9yUHJpbWFyeUJnIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJMb2dvQnV0dG9uLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBCdXR0b24sIHRoZW1lIH0gZnJvbSBcImFudGRcIjtcbmltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcblxuaW1wb3J0IGxvZ28gZnJvbSBcIi4uLy4uL2Fzc2V0cy9pbWFnZXMvbG9nbzUxMi5wbmdcIjtcblxuY29uc3QgeyB1c2VUb2tlbiB9ID0gdGhlbWU7XG5cbmNvbnN0IExvZ29CdXR0b24gPSAoKSA9PiB7XG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgY29uc3QgdG9rZW4gPSB1c2VUb2tlbigpO1xuXG4gIHJldHVybiAoXG4gICAgPEJ1dHRvblxuICAgICAgaWNvbj17XG4gICAgICAgIDxpbWcgc3JjPXtsb2dvfSBhbHQ9XCJsb2dvXCIgaGVpZ2h0PVwiMjVweFwiIHN0eWxlPXt7IG1hcmdpbjogXCIwIDdweFwiIH19IC8+XG4gICAgICB9XG4gICAgICB0eXBlPVwicHJpbWFyeVwiXG4gICAgICBzaXplPVwibGFyZ2VcIlxuICAgICAgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiB0b2tlbi5jb2xvclByaW1hcnlCZyB9fVxuICAgICAgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoXCIvXCIpfVxuICAgIC8+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBMb2dvQnV0dG9uO1xuIl0sImZpbGUiOiIvaG9tZS9kaGFybWEvV29yay9yZWFjdC1ib2lsZXJwbGF0ZS9zcmMvbGF5b3V0cy9jb21wb25lbnRzL0xvZ29CdXR0b24uanN4In0=