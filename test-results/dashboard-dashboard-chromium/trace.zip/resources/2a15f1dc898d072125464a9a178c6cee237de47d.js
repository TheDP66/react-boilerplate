import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/layouts/AppLayout.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f9dec5ba"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/dharma/Work/react-boilerplate/src/layouts/AppLayout.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Alert, Layout, theme } from "/node_modules/.vite/deps/antd.js?v=26d7e361";
import { Content } from "/node_modules/.vite/deps/antd_es_layout_layout.js?v=bb8c6b63";
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=f9dec5ba"; const React = __vite__cjsImport5_react.__esModule ? __vite__cjsImport5_react.default : __vite__cjsImport5_react;
import { useSelector } from "/node_modules/.vite/deps/react-redux.js?v=3db4bc54";
import Bottombar from "/src/layouts/Bottombar.jsx";
import Sidebar from "/src/layouts/Sidebar.jsx";
import Topbar from "/src/layouts/Topbar.jsx";
const {
  useToken
} = theme;
const AppLayout = ({
  children,
  alertApi,
  handleCloseAlert,
  messageHolder,
  notificationHolder
}) => {
  _s();
  const {
    auth
  } = useSelector((state) => state);
  const {
    token
  } = useToken();
  return /* @__PURE__ */ jsxDEV(Layout, { className: "app", children: [
    alertApi.open && /* @__PURE__ */ jsxDEV(
      Alert,
      {
        type: alertApi.type,
        message: alertApi.message,
        banner: true,
        closable: true,
        onClose: handleCloseAlert
      },
      void 0,
      false,
      {
        fileName: "/home/dharma/Work/react-boilerplate/src/layouts/AppLayout.jsx",
        lineNumber: 27,
        columnNumber: 25
      },
      this
    ),
    auth.accessToken && /* @__PURE__ */ jsxDEV(Topbar, {}, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/layouts/AppLayout.jsx",
      lineNumber: 30,
      columnNumber: 28
    }, this),
    messageHolder,
    notificationHolder,
    /* @__PURE__ */ jsxDEV(Layout, { children: [
      auth.accessToken && /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "/home/dharma/Work/react-boilerplate/src/layouts/AppLayout.jsx",
        lineNumber: 36,
        columnNumber: 30
      }, this),
      /* @__PURE__ */ jsxDEV(Layout, { children: [
        /* @__PURE__ */ jsxDEV(Content, { style: {
          minHeight: 280,
          display: "flex",
          justifyContent: "center",
          color: token.colorText
        }, children }, void 0, false, {
          fileName: "/home/dharma/Work/react-boilerplate/src/layouts/AppLayout.jsx",
          lineNumber: 39,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Bottombar, {}, void 0, false, {
          fileName: "/home/dharma/Work/react-boilerplate/src/layouts/AppLayout.jsx",
          lineNumber: 48,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/home/dharma/Work/react-boilerplate/src/layouts/AppLayout.jsx",
        lineNumber: 38,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/home/dharma/Work/react-boilerplate/src/layouts/AppLayout.jsx",
      lineNumber: 35,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/dharma/Work/react-boilerplate/src/layouts/AppLayout.jsx",
    lineNumber: 26,
    columnNumber: 10
  }, this);
};
_s(AppLayout, "9DK0fofkdWTes3/9soQ7xFYhJYs=", false, function() {
  return [useSelector, useToken];
});
_c = AppLayout;
export default AppLayout;
var _c;
$RefreshReg$(_c, "AppLayout");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/dharma/Work/react-boilerplate/src/layouts/AppLayout.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0JROzs7Ozs7Ozs7Ozs7Ozs7OztBQXhCUixTQUFTQSxPQUFPQyxRQUFRQyxhQUFhO0FBQ3JDLFNBQVNDLGVBQWU7QUFDeEIsT0FBT0MsV0FBVztBQUVsQixTQUFTQyxtQkFBbUI7QUFDNUIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxhQUFhO0FBQ3BCLE9BQU9DLFlBQVk7QUFFbkIsTUFBTTtBQUFBLEVBQUNDO0FBQVEsSUFBSVA7QUFFbkIsTUFBTVEsWUFBWUEsQ0FBQztBQUFBLEVBQ2pCQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUNGLE1BQU07QUFBQUMsS0FBQTtBQUNKLFFBQU07QUFBQSxJQUFFQztBQUFBQSxFQUFLLElBQUlaLFlBQWFhLFdBQVVBLEtBQUs7QUFDN0MsUUFBTTtBQUFBLElBQUNDO0FBQUFBLEVBQUssSUFBSVYsU0FBUztBQUV6QixTQUNFLHVCQUFDLFVBQU8sV0FBVSxPQUNmRztBQUFBQSxhQUFTUSxRQUNSO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFNUixTQUFTUztBQUFBQSxRQUNmLFNBQVNULFNBQVNVO0FBQUFBLFFBQ2xCLFFBQU07QUFBQSxRQUNOLFVBQVE7QUFBQSxRQUNSLFNBQVNUO0FBQUFBO0FBQUFBLE1BTFg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBSzRCO0FBQUEsSUFJN0JJLEtBQUtNLGVBQWUsdUJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQU87QUFBQSxJQUUzQlQ7QUFBQUEsSUFDQUM7QUFBQUEsSUFFRCx1QkFBQyxVQUNFRTtBQUFBQSxXQUFLTSxlQUFlLHVCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFRO0FBQUEsTUFFN0IsdUJBQUMsVUFDQztBQUFBLCtCQUFDLFdBQ0MsT0FBTztBQUFBLFVBQ0xDLFdBQVc7QUFBQSxVQUNYQyxTQUFTO0FBQUEsVUFDVEMsZ0JBQWdCO0FBQUEsVUFDaEJDLE9BQU9SLE1BQU1TO0FBQUFBLFFBQ2YsR0FFQ2pCLFlBUkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsUUFFQSx1QkFBQyxlQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBVTtBQUFBLFdBWlo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWFBO0FBQUEsU0FoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlCQTtBQUFBLE9BakNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrQ0E7QUFFSjtBQUFFSyxHQS9DSU4sV0FBUztBQUFBLFVBT0lMLGFBQ0RJLFFBQVE7QUFBQTtBQUFBb0IsS0FScEJuQjtBQWlETixlQUFlQTtBQUFVLElBQUFtQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiQWxlcnQiLCJMYXlvdXQiLCJ0aGVtZSIsIkNvbnRlbnQiLCJSZWFjdCIsInVzZVNlbGVjdG9yIiwiQm90dG9tYmFyIiwiU2lkZWJhciIsIlRvcGJhciIsInVzZVRva2VuIiwiQXBwTGF5b3V0IiwiY2hpbGRyZW4iLCJhbGVydEFwaSIsImhhbmRsZUNsb3NlQWxlcnQiLCJtZXNzYWdlSG9sZGVyIiwibm90aWZpY2F0aW9uSG9sZGVyIiwiX3MiLCJhdXRoIiwic3RhdGUiLCJ0b2tlbiIsIm9wZW4iLCJ0eXBlIiwibWVzc2FnZSIsImFjY2Vzc1Rva2VuIiwibWluSGVpZ2h0IiwiZGlzcGxheSIsImp1c3RpZnlDb250ZW50IiwiY29sb3IiLCJjb2xvclRleHQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkFwcExheW91dC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQWxlcnQsIExheW91dCwgdGhlbWUgfSBmcm9tIFwiYW50ZFwiO1xuaW1wb3J0IHsgQ29udGVudCB9IGZyb20gXCJhbnRkL2VzL2xheW91dC9sYXlvdXRcIjtcbmltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcblxuaW1wb3J0IHsgdXNlU2VsZWN0b3IgfSBmcm9tIFwicmVhY3QtcmVkdXhcIjtcbmltcG9ydCBCb3R0b21iYXIgZnJvbSBcIi4vQm90dG9tYmFyXCI7XG5pbXBvcnQgU2lkZWJhciBmcm9tIFwiLi9TaWRlYmFyXCI7XG5pbXBvcnQgVG9wYmFyIGZyb20gXCIuL1RvcGJhclwiO1xuXG5jb25zdCB7dXNlVG9rZW59ID0gdGhlbWVcblxuY29uc3QgQXBwTGF5b3V0ID0gKHtcbiAgY2hpbGRyZW4sXG4gIGFsZXJ0QXBpLFxuICBoYW5kbGVDbG9zZUFsZXJ0LFxuICBtZXNzYWdlSG9sZGVyLFxuICBub3RpZmljYXRpb25Ib2xkZXIsXG59KSA9PiB7XG4gIGNvbnN0IHsgYXV0aCB9ID0gdXNlU2VsZWN0b3IoKHN0YXRlKSA9PiBzdGF0ZSk7XG4gIGNvbnN0IHt0b2tlbn0gPSB1c2VUb2tlbigpXG5cbiAgcmV0dXJuIChcbiAgICA8TGF5b3V0IGNsYXNzTmFtZT1cImFwcFwiPlxuICAgICAge2FsZXJ0QXBpLm9wZW4gJiYgKFxuICAgICAgICA8QWxlcnRcbiAgICAgICAgICB0eXBlPXthbGVydEFwaS50eXBlfSAvLyBzdWNjZXNzLCBpbmZvLCB3YXJuaW5nLCBlcnJvclxuICAgICAgICAgIG1lc3NhZ2U9e2FsZXJ0QXBpLm1lc3NhZ2V9XG4gICAgICAgICAgYmFubmVyXG4gICAgICAgICAgY2xvc2FibGVcbiAgICAgICAgICBvbkNsb3NlPXtoYW5kbGVDbG9zZUFsZXJ0fVxuICAgICAgICAvPlxuICAgICAgKX1cblxuICAgICAge2F1dGguYWNjZXNzVG9rZW4gJiYgPFRvcGJhciAvPn1cblxuICAgICAge21lc3NhZ2VIb2xkZXJ9XG4gICAgICB7bm90aWZpY2F0aW9uSG9sZGVyfVxuXG4gICAgICA8TGF5b3V0PlxuICAgICAgICB7YXV0aC5hY2Nlc3NUb2tlbiAmJiA8U2lkZWJhciAvPn1cblxuICAgICAgICA8TGF5b3V0PlxuICAgICAgICAgIDxDb250ZW50XG4gICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICBtaW5IZWlnaHQ6IDI4MCxcbiAgICAgICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXG4gICAgICAgICAgICAgIGp1c3RpZnlDb250ZW50OiBcImNlbnRlclwiLFxuICAgICAgICAgICAgICBjb2xvcjogdG9rZW4uY29sb3JUZXh0XG4gICAgICAgICAgICB9fVxuICAgICAgICAgID5cbiAgICAgICAgICAgIHtjaGlsZHJlbn1cbiAgICAgICAgICA8L0NvbnRlbnQ+XG5cbiAgICAgICAgICA8Qm90dG9tYmFyIC8+XG4gICAgICAgIDwvTGF5b3V0PlxuICAgICAgPC9MYXlvdXQ+XG4gICAgPC9MYXlvdXQ+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBBcHBMYXlvdXQ7XG4iXSwiZmlsZSI6Ii9ob21lL2RoYXJtYS9Xb3JrL3JlYWN0LWJvaWxlcnBsYXRlL3NyYy9sYXlvdXRzL0FwcExheW91dC5qc3gifQ==