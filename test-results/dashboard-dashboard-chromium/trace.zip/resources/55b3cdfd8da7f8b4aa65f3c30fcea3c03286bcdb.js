import {
  require_react
} from "/node_modules/.vite/deps/chunk-ZGRSIX2Q.js?v=97c9eb9a";
import {
  __toESM
} from "/node_modules/.vite/deps/chunk-ROME4SDB.js?v=97c9eb9a";

// node_modules/adblock-detect-react/esm/components/AdBlockDetectedWrapper.js
var import_react2 = __toESM(require_react());

// node_modules/adblock-detect-react/esm/hooks/useDetectAdBlock.js
var import_react = __toESM(require_react());
var useDetectAdBlock = () => {
  const [adBlockDetected, setAdBlockDetected] = (0, import_react.useState)(false);
  (0, import_react.useEffect)(() => {
    const url = "https://www3.doubleclick.net";
    fetch(url, {
      method: "HEAD",
      mode: "no-cors",
      cache: "no-store"
    }).catch(() => {
      setAdBlockDetected(true);
    });
  }, []);
  return adBlockDetected;
};

// node_modules/adblock-detect-react/esm/components/AdBlockDetectedWrapper.js
var AdBlockDetectedWrapper = ({ children }) => {
  const adBlockDetected = useDetectAdBlock();
  return import_react2.default.createElement(import_react2.default.Fragment, null, adBlockDetected && children);
};
export {
  AdBlockDetectedWrapper,
  useDetectAdBlock
};
//# sourceMappingURL=adblock-detect-react.js.map
