import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f9dec5ba"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { Button } from "/node_modules/.vite/deps/antd.js?v=26d7e361";
import Cookies from "/node_modules/.vite/deps/js-cookie.js?v=ea88deea";
export const cookiesMessage = () => {
  return "We use cookies to ensure you get the best experience on our website. By clicking accept, you agree to our use of cookies.";
};
export const cookiesButton = (notificationApi, key) => {
  const handleAccept = () => {
    Cookies.set("allow_cookies", true);
    notificationApi.destroy(key);
  };
  return /* @__PURE__ */ jsxDEV(Button, { block: true, type: "primary", size: "small", onClick: handleAccept, children: "Accept all cookies" }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/constant/cookiesNotification.jsx",
    lineNumber: 11,
    columnNumber: 10
  }, this);
};

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBY0k7QUFkSixTQUFTQSxjQUFjO0FBQ3ZCLE9BQU9DLGFBQWE7QUFFYixhQUFNQyxpQkFBaUJBLE1BQU07QUFDbEMsU0FBTztBQUNUO0FBRU8sYUFBTUMsZ0JBQWdCQSxDQUFDQyxpQkFBaUJDLFFBQVE7QUFDckQsUUFBTUMsZUFBZUEsTUFBTTtBQUN6QkwsWUFBUU0sSUFBSSxpQkFBaUIsSUFBSTtBQUNqQ0gsb0JBQWdCSSxRQUFRSCxHQUFHO0FBQUEsRUFDN0I7QUFFQSxTQUNFLHVCQUFDLFVBQU8sT0FBSyxNQUFDLE1BQUssV0FBVSxNQUFLLFNBQVEsU0FBU0MsY0FBYSxrQ0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBO0FBRUoiLCJuYW1lcyI6WyJCdXR0b24iLCJDb29raWVzIiwiY29va2llc01lc3NhZ2UiLCJjb29raWVzQnV0dG9uIiwibm90aWZpY2F0aW9uQXBpIiwia2V5IiwiaGFuZGxlQWNjZXB0Iiwic2V0IiwiZGVzdHJveSJdLCJzb3VyY2VzIjpbImNvb2tpZXNOb3RpZmljYXRpb24uanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEJ1dHRvbiB9IGZyb20gXCJhbnRkXCI7XG5pbXBvcnQgQ29va2llcyBmcm9tIFwianMtY29va2llXCI7XG5cbmV4cG9ydCBjb25zdCBjb29raWVzTWVzc2FnZSA9ICgpID0+IHtcbiAgcmV0dXJuIFwiV2UgdXNlIGNvb2tpZXMgdG8gZW5zdXJlIHlvdSBnZXQgdGhlIGJlc3QgZXhwZXJpZW5jZSBvbiBvdXIgd2Vic2l0ZS4gQnkgY2xpY2tpbmcgYWNjZXB0LCB5b3UgYWdyZWUgdG8gb3VyIHVzZSBvZiBjb29raWVzLlwiO1xufTtcblxuZXhwb3J0IGNvbnN0IGNvb2tpZXNCdXR0b24gPSAobm90aWZpY2F0aW9uQXBpLCBrZXkpID0+IHtcbiAgY29uc3QgaGFuZGxlQWNjZXB0ID0gKCkgPT4ge1xuICAgIENvb2tpZXMuc2V0KFwiYWxsb3dfY29va2llc1wiLCB0cnVlKTtcbiAgICBub3RpZmljYXRpb25BcGkuZGVzdHJveShrZXkpO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPEJ1dHRvbiBibG9jayB0eXBlPVwicHJpbWFyeVwiIHNpemU9XCJzbWFsbFwiIG9uQ2xpY2s9e2hhbmRsZUFjY2VwdH0+XG4gICAgICBBY2NlcHQgYWxsIGNvb2tpZXNcbiAgICA8L0J1dHRvbj5cbiAgKTtcbn07XG4iXSwiZmlsZSI6Ii9ob21lL2RoYXJtYS9Xb3JrL3JlYWN0LWJvaWxlcnBsYXRlL3NyYy9jb25zdGFudC9jb29raWVzTm90aWZpY2F0aW9uLmpzeCJ9