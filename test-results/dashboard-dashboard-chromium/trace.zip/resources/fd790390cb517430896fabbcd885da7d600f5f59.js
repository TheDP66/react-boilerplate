import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/layouts/components/NotificationList.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f9dec5ba"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/dharma/Work/react-boilerplate/src/layouts/components/NotificationList.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Avatar, Badge, Divider, Empty, List, Skeleton } from "/node_modules/.vite/deps/antd.js?v=26d7e361";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=f9dec5ba"; const React = __vite__cjsImport4_react.__esModule ? __vite__cjsImport4_react.default : __vite__cjsImport4_react; const useEffect = __vite__cjsImport4_react["useEffect"]; const useState = __vite__cjsImport4_react["useState"];
import InfiniteScroll from "/node_modules/.vite/deps/react-infinite-scroll-component.js?v=ab74f5b1";
const NotificationList = ({
  type
}) => {
  _s();
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState([]);
  const loadMoreData = () => {
    if (loading) {
      return;
    }
    setLoading(true);
    fetch("https://randomuser.me/api/?results=10&inc=name,gender,email,nat,picture&noinfo").then((res) => res.json()).then((body) => {
      setData([...data, ...body.results]);
      setLoading(false);
    }).catch(() => {
      setLoading(false);
    });
  };
  useEffect(() => {
    loadMoreData();
  }, []);
  return /* @__PURE__ */ jsxDEV("div", { children: type === "general" ? /* @__PURE__ */ jsxDEV(Empty, {}, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/NotificationList.jsx",
    lineNumber: 29,
    columnNumber: 29
  }, this) : /* @__PURE__ */ jsxDEV("div", { id: "scrollableDiv", style: {
    height: 400,
    overflow: "auto"
    // padding: "0 16px",
  }, children: /* @__PURE__ */ jsxDEV(InfiniteScroll, { dataLength: data.length, next: loadMoreData, hasMore: data.length < 50, loader: /* @__PURE__ */ jsxDEV(Skeleton, { avatar: true, paragraph: {
    rows: 1
  }, active: true }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/NotificationList.jsx",
    lineNumber: 34,
    columnNumber: 107
  }, this), endMessage: /* @__PURE__ */ jsxDEV(Divider, { plain: true, children: "It is all, nothing more 🤐" }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/NotificationList.jsx",
    lineNumber: 36,
    columnNumber: 33
  }, this), scrollableTarget: "scrollableDiv", children: /* @__PURE__ */ jsxDEV(List, { dataSource: data, renderItem: (item) => /* @__PURE__ */ jsxDEV(List.Item, { onClick: () => console.log("email", item.email), style: {
    cursor: "pointer",
    padding: "6px 8px"
  }, children: /* @__PURE__ */ jsxDEV(List.Item.Meta, { avatar: /* @__PURE__ */ jsxDEV(Badge, { dotb: true, offset: [-2, 2], children: /* @__PURE__ */ jsxDEV(Avatar, { src: item.picture.large, shape: "square" }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/NotificationList.jsx",
    lineNumber: 42,
    columnNumber: 25
  }, this) }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/NotificationList.jsx",
    lineNumber: 41,
    columnNumber: 43
  }, this), title: /* @__PURE__ */ jsxDEV("span", { children: item.name.last }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/NotificationList.jsx",
    lineNumber: 43,
    columnNumber: 40
  }, this), description: item.email }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/NotificationList.jsx",
    lineNumber: 41,
    columnNumber: 19
  }, this) }, item.email, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/NotificationList.jsx",
    lineNumber: 37,
    columnNumber: 57
  }, this) }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/NotificationList.jsx",
    lineNumber: 37,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/NotificationList.jsx",
    lineNumber: 34,
    columnNumber: 11
  }, this) }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/NotificationList.jsx",
    lineNumber: 29,
    columnNumber: 41
  }, this) }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/NotificationList.jsx",
    lineNumber: 28,
    columnNumber: 10
  }, this);
};
_s(NotificationList, "gGYstEUzFphqz50KeZWwSPB/q0c=");
_c = NotificationList;
export default NotificationList;
var _c;
$RefreshReg$(_c, "NotificationList");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/dharma/Work/react-boilerplate/src/layouts/components/NotificationList.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0NROzs7Ozs7Ozs7Ozs7Ozs7OztBQWxDUixTQUFTQSxRQUFRQyxPQUFPQyxTQUFTQyxPQUFPQyxNQUFNQyxnQkFBZ0I7QUFDOUQsT0FBT0MsU0FBU0MsV0FBV0MsZ0JBQWdCO0FBQzNDLE9BQU9DLG9CQUFvQjtBQUUzQixNQUFNQyxtQkFBbUJBLENBQUM7QUFBQSxFQUFFQztBQUFLLE1BQU07QUFBQUMsS0FBQTtBQUNyQyxRQUFNLENBQUNDLFNBQVNDLFVBQVUsSUFBSU4sU0FBUyxLQUFLO0FBQzVDLFFBQU0sQ0FBQ08sTUFBTUMsT0FBTyxJQUFJUixTQUFTLEVBQUU7QUFDbkMsUUFBTVMsZUFBZUEsTUFBTTtBQUN6QixRQUFJSixTQUFTO0FBQ1g7QUFBQSxJQUNGO0FBQ0FDLGVBQVcsSUFBSTtBQUNmSSxVQUNFLGdGQUNGLEVBQ0dDLEtBQU1DLFNBQVFBLElBQUlDLEtBQUssQ0FBQyxFQUN4QkYsS0FBTUcsVUFBUztBQUNkTixjQUFRLENBQUMsR0FBR0QsTUFBTSxHQUFHTyxLQUFLQyxPQUFPLENBQUM7QUFDbENULGlCQUFXLEtBQUs7QUFBQSxJQUNsQixDQUFDLEVBQ0FVLE1BQU0sTUFBTTtBQUNYVixpQkFBVyxLQUFLO0FBQUEsSUFDbEIsQ0FBQztBQUFBLEVBQ0w7QUFFQVAsWUFBVSxNQUFNO0FBQ2RVLGlCQUFhO0FBQUEsRUFHZixHQUFHLEVBQUU7QUFFTCxTQUNFLHVCQUFDLFNBQ0VOLG1CQUFTLFlBQ1IsdUJBQUMsV0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQU0sSUFFTix1QkFBQyxTQUNDLElBQUcsaUJBQ0gsT0FBTztBQUFBLElBQ0xjLFFBQVE7QUFBQSxJQUNSQyxVQUFVO0FBQUE7QUFBQSxFQUVaLEdBRUEsaUNBQUMsa0JBQ0MsWUFBWVgsS0FBS1ksUUFDakIsTUFBTVYsY0FDTixTQUFTRixLQUFLWSxTQUFTLElBQ3ZCLFFBQ0UsdUJBQUMsWUFDQyxRQUFNLE1BQ04sV0FBVztBQUFBLElBQ1RDLE1BQU07QUFBQSxFQUNSLEdBQ0EsUUFBTSxRQUxSO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FLUSxHQUdWLFlBQVksdUJBQUMsV0FBUSxPQUFLLE1BQUMsMENBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUF5QyxHQUNyRCxrQkFBaUIsaUJBRWpCLGlDQUFDLFFBQ0MsWUFBWWIsTUFDWixZQUFhYyxVQUNYLHVCQUFDLEtBQUssTUFBTCxFQUVDLFNBQVMsTUFBTUMsUUFBUUMsSUFBSSxTQUFTRixLQUFLRyxLQUFLLEdBQzlDLE9BQU87QUFBQSxJQUNMQyxRQUFRO0FBQUEsSUFDUkMsU0FBUztBQUFBLEVBQ1gsR0FFQSxpQ0FBQyxLQUFLLEtBQUssTUFBVixFQUNDLFFBQ0UsdUJBQUMsU0FBTSxNQUFJLE1BQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUN4QixpQ0FBQyxVQUFPLEtBQUtMLEtBQUtNLFFBQVFDLE9BQU8sT0FBTSxZQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQStDLEtBRGpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFQSxHQUVGLE9BQU8sdUJBQUMsVUFBTVAsZUFBS1EsS0FBS0MsUUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFzQixHQUM3QixhQUFhVCxLQUFLRyxTQVBwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBTzBCLEtBZHJCSCxLQUFLRyxPQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FpQkEsS0FwQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXFCSSxLQXJDTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBdUNBLEtBL0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnREEsS0FwREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXNEQTtBQUVKO0FBQUVwQixHQXBGSUYsa0JBQWdCO0FBQUE2QixLQUFoQjdCO0FBc0ZOLGVBQWVBO0FBQWlCLElBQUE2QjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiQXZhdGFyIiwiQmFkZ2UiLCJEaXZpZGVyIiwiRW1wdHkiLCJMaXN0IiwiU2tlbGV0b24iLCJSZWFjdCIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiSW5maW5pdGVTY3JvbGwiLCJOb3RpZmljYXRpb25MaXN0IiwidHlwZSIsIl9zIiwibG9hZGluZyIsInNldExvYWRpbmciLCJkYXRhIiwic2V0RGF0YSIsImxvYWRNb3JlRGF0YSIsImZldGNoIiwidGhlbiIsInJlcyIsImpzb24iLCJib2R5IiwicmVzdWx0cyIsImNhdGNoIiwiaGVpZ2h0Iiwib3ZlcmZsb3ciLCJsZW5ndGgiLCJyb3dzIiwiaXRlbSIsImNvbnNvbGUiLCJsb2ciLCJlbWFpbCIsImN1cnNvciIsInBhZGRpbmciLCJwaWN0dXJlIiwibGFyZ2UiLCJuYW1lIiwibGFzdCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiTm90aWZpY2F0aW9uTGlzdC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQXZhdGFyLCBCYWRnZSwgRGl2aWRlciwgRW1wdHksIExpc3QsIFNrZWxldG9uIH0gZnJvbSBcImFudGRcIjtcbmltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgSW5maW5pdGVTY3JvbGwgZnJvbSBcInJlYWN0LWluZmluaXRlLXNjcm9sbC1jb21wb25lbnRcIjtcblxuY29uc3QgTm90aWZpY2F0aW9uTGlzdCA9ICh7IHR5cGUgfSkgPT4ge1xuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtkYXRhLCBzZXREYXRhXSA9IHVzZVN0YXRlKFtdKTtcbiAgY29uc3QgbG9hZE1vcmVEYXRhID0gKCkgPT4ge1xuICAgIGlmIChsb2FkaW5nKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHNldExvYWRpbmcodHJ1ZSk7XG4gICAgZmV0Y2goXG4gICAgICBcImh0dHBzOi8vcmFuZG9tdXNlci5tZS9hcGkvP3Jlc3VsdHM9MTAmaW5jPW5hbWUsZ2VuZGVyLGVtYWlsLG5hdCxwaWN0dXJlJm5vaW5mb1wiXG4gICAgKVxuICAgICAgLnRoZW4oKHJlcykgPT4gcmVzLmpzb24oKSlcbiAgICAgIC50aGVuKChib2R5KSA9PiB7XG4gICAgICAgIHNldERhdGEoWy4uLmRhdGEsIC4uLmJvZHkucmVzdWx0c10pO1xuICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICAgIH0pXG4gICAgICAuY2F0Y2goKCkgPT4ge1xuICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICAgIH0pO1xuICB9O1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgbG9hZE1vcmVEYXRhKCk7XG5cbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lXG4gIH0sIFtdKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXY+XG4gICAgICB7dHlwZSA9PT0gXCJnZW5lcmFsXCIgPyAoXG4gICAgICAgIDxFbXB0eSAvPlxuICAgICAgKSA6IChcbiAgICAgICAgPGRpdlxuICAgICAgICAgIGlkPVwic2Nyb2xsYWJsZURpdlwiXG4gICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgIGhlaWdodDogNDAwLFxuICAgICAgICAgICAgb3ZlcmZsb3c6IFwiYXV0b1wiLFxuICAgICAgICAgICAgLy8gcGFkZGluZzogXCIwIDE2cHhcIixcbiAgICAgICAgICB9fVxuICAgICAgICA+XG4gICAgICAgICAgPEluZmluaXRlU2Nyb2xsXG4gICAgICAgICAgICBkYXRhTGVuZ3RoPXtkYXRhLmxlbmd0aH1cbiAgICAgICAgICAgIG5leHQ9e2xvYWRNb3JlRGF0YX1cbiAgICAgICAgICAgIGhhc01vcmU9e2RhdGEubGVuZ3RoIDwgNTB9XG4gICAgICAgICAgICBsb2FkZXI9e1xuICAgICAgICAgICAgICA8U2tlbGV0b25cbiAgICAgICAgICAgICAgICBhdmF0YXJcbiAgICAgICAgICAgICAgICBwYXJhZ3JhcGg9e3tcbiAgICAgICAgICAgICAgICAgIHJvd3M6IDEsXG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICBhY3RpdmVcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVuZE1lc3NhZ2U9ezxEaXZpZGVyIHBsYWluPkl0IGlzIGFsbCwgbm90aGluZyBtb3JlIPCfpJA8L0RpdmlkZXI+fVxuICAgICAgICAgICAgc2Nyb2xsYWJsZVRhcmdldD1cInNjcm9sbGFibGVEaXZcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxMaXN0XG4gICAgICAgICAgICAgIGRhdGFTb3VyY2U9e2RhdGF9XG4gICAgICAgICAgICAgIHJlbmRlckl0ZW09eyhpdGVtKSA9PiAoXG4gICAgICAgICAgICAgICAgPExpc3QuSXRlbVxuICAgICAgICAgICAgICAgICAga2V5PXtpdGVtLmVtYWlsfVxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gY29uc29sZS5sb2coXCJlbWFpbFwiLCBpdGVtLmVtYWlsKX1cbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgICAgIGN1cnNvcjogXCJwb2ludGVyXCIsXG4gICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6IFwiNnB4IDhweFwiLFxuICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8TGlzdC5JdGVtLk1ldGFcbiAgICAgICAgICAgICAgICAgICAgYXZhdGFyPXtcbiAgICAgICAgICAgICAgICAgICAgICA8QmFkZ2UgZG90YiBvZmZzZXQ9e1stMiwgMl19PlxuICAgICAgICAgICAgICAgICAgICAgICAgPEF2YXRhciBzcmM9e2l0ZW0ucGljdHVyZS5sYXJnZX0gc2hhcGU9XCJzcXVhcmVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvQmFkZ2U+XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgdGl0bGU9ezxzcGFuPntpdGVtLm5hbWUubGFzdH08L3NwYW4+fVxuICAgICAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbj17aXRlbS5lbWFpbH1cbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9MaXN0Lkl0ZW0+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvSW5maW5pdGVTY3JvbGw+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IE5vdGlmaWNhdGlvbkxpc3Q7XG4iXSwiZmlsZSI6Ii9ob21lL2RoYXJtYS9Xb3JrL3JlYWN0LWJvaWxlcnBsYXRlL3NyYy9sYXlvdXRzL2NvbXBvbmVudHMvTm90aWZpY2F0aW9uTGlzdC5qc3gifQ==