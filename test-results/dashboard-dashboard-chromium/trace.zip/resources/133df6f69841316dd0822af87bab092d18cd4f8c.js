import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/assets/svg/moonSvg.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f9dec5ba"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/dharma/Work/react-boilerplate/src/assets/svg/moonSvg.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import Icon from "/node_modules/.vite/deps/@ant-design_icons.js?v=7a8c6384";
const MoonSvg = (stroke) => /* @__PURE__ */ jsxDEV("svg", { width: "20px", height: "20px", viewBox: "0 0 24 24", fill: "none", xmlns: "http://www.w3.org/2000/svg", children: /* @__PURE__ */ jsxDEV("g", { id: "Environment / Moon", children: /* @__PURE__ */ jsxDEV("path", { id: "Vector", d: "M9 6C9 10.9706 13.0294 15 18 15C18.9093 15 19.787 14.8655 20.6144 14.6147C19.4943 18.3103 16.0613 20.9999 12 20.9999C7.02944 20.9999 3 16.9707 3 12.0001C3 7.93883 5.69007 4.50583 9.38561 3.38574C9.13484 4.21311 9 5.09074 9 6Z", stroke, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, void 0, false, {
  fileName: "/home/dharma/Work/react-boilerplate/src/assets/svg/moonSvg.jsx",
  lineNumber: 4,
  columnNumber: 7
}, this) }, void 0, false, {
  fileName: "/home/dharma/Work/react-boilerplate/src/assets/svg/moonSvg.jsx",
  lineNumber: 3,
  columnNumber: 5
}, this) }, void 0, false, {
  fileName: "/home/dharma/Work/react-boilerplate/src/assets/svg/moonSvg.jsx",
  lineNumber: 2,
  columnNumber: 27
}, this);
_c = MoonSvg;
export const MoonIcon = (props) => /* @__PURE__ */ jsxDEV(Icon, { component: () => MoonSvg(props.stroke), ...props }, void 0, false, {
  fileName: "/home/dharma/Work/react-boilerplate/src/assets/svg/moonSvg.jsx",
  lineNumber: 8,
  columnNumber: 34
}, this);
_c2 = MoonIcon;
var _c, _c2;
$RefreshReg$(_c, "MoonSvg");
$RefreshReg$(_c2, "MoonIcon");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/dharma/Work/react-boilerplate/src/assets/svg/moonSvg.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBV007QUFYTixPQUFPQSxvQkFBVTtBQUFtQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFcEMsTUFBTUMsVUFBV0MsWUFDZix1QkFBQyxTQUNDLE9BQU0sUUFDTixRQUFPLFFBQ1AsU0FBUSxhQUNSLE1BQUssUUFDTCxPQUFNLDhCQUVOLGlDQUFDLE9BQUUsSUFBRyxzQkFDSixpQ0FBQyxVQUNDLElBQUcsVUFDSCxHQUFFLHFPQUNGLFFBQ0EsYUFBWSxLQUNaLGVBQWMsU0FDZCxnQkFBZSxXQU5qQjtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BTXdCLEtBUDFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FTQSxLQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BaUJBO0FBQ0FDLEtBbkJJRjtBQXFCQyxhQUFNRyxXQUFZQyxXQUN2Qix1QkFBQyxRQUFLLFdBQVcsTUFBTUosUUFBUUksTUFBTUgsTUFBTSxHQUFHLEdBQUlHLFNBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FBd0Q7QUFDeERDLE1BRldGO0FBQVEsSUFBQUQsSUFBQUc7QUFBQUMsYUFBQUosSUFBQTtBQUFBSSxhQUFBRCxLQUFBIiwibmFtZXMiOlsiSWNvbiIsIk1vb25TdmciLCJzdHJva2UiLCJfYyIsIk1vb25JY29uIiwicHJvcHMiLCJfYzIiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJtb29uU3ZnLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgSWNvbiBmcm9tIFwiQGFudC1kZXNpZ24vaWNvbnNcIjtcclxuXHJcbmNvbnN0IE1vb25TdmcgPSAoc3Ryb2tlKSA9PiAoXHJcbiAgPHN2Z1xyXG4gICAgd2lkdGg9XCIyMHB4XCJcclxuICAgIGhlaWdodD1cIjIwcHhcIlxyXG4gICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXHJcbiAgICBmaWxsPVwibm9uZVwiXHJcbiAgICB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCJcclxuICA+XHJcbiAgICA8ZyBpZD1cIkVudmlyb25tZW50IC8gTW9vblwiPlxyXG4gICAgICA8cGF0aFxyXG4gICAgICAgIGlkPVwiVmVjdG9yXCJcclxuICAgICAgICBkPVwiTTkgNkM5IDEwLjk3MDYgMTMuMDI5NCAxNSAxOCAxNUMxOC45MDkzIDE1IDE5Ljc4NyAxNC44NjU1IDIwLjYxNDQgMTQuNjE0N0MxOS40OTQzIDE4LjMxMDMgMTYuMDYxMyAyMC45OTk5IDEyIDIwLjk5OTlDNy4wMjk0NCAyMC45OTk5IDMgMTYuOTcwNyAzIDEyLjAwMDFDMyA3LjkzODgzIDUuNjkwMDcgNC41MDU4MyA5LjM4NTYxIDMuMzg1NzRDOS4xMzQ4NCA0LjIxMzExIDkgNS4wOTA3NCA5IDZaXCJcclxuICAgICAgICBzdHJva2U9e3N0cm9rZX1cclxuICAgICAgICBzdHJva2VXaWR0aD1cIjJcIlxyXG4gICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXHJcbiAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXHJcbiAgICAgIC8+XHJcbiAgICA8L2c+XHJcbiAgPC9zdmc+XHJcbik7XHJcblxyXG5leHBvcnQgY29uc3QgTW9vbkljb24gPSAocHJvcHMpID0+IChcclxuICA8SWNvbiBjb21wb25lbnQ9eygpID0+IE1vb25TdmcocHJvcHMuc3Ryb2tlKX0gey4uLnByb3BzfSAvPlxyXG4pO1xyXG4iXSwiZmlsZSI6Ii9ob21lL2RoYXJtYS9Xb3JrL3JlYWN0LWJvaWxlcnBsYXRlL3NyYy9hc3NldHMvc3ZnL21vb25TdmcuanN4In0=