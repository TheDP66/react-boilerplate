import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/login/Login.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f9dec5ba"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/dharma/Work/react-boilerplate/src/pages/login/Login.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Col, Grid, Row, theme } from "/node_modules/.vite/deps/antd.js?v=26d7e361";
import Lottie from "/node_modules/.vite/deps/lottie-react.js?v=f06392c1";
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=f9dec5ba"; const React = __vite__cjsImport5_react.__esModule ? __vite__cjsImport5_react.default : __vite__cjsImport5_react;
import welcomeAnimation from "/src/assets/lottie/welcome.json?import";
import LoginForm from "/src/pages/login/components/LoginForm.jsx";
const {
  useBreakpoint
} = Grid;
const {
  useToken
} = theme;
const Login = () => {
  _s();
  const screens = useBreakpoint();
  const {
    token
  } = useToken();
  return /* @__PURE__ */ jsxDEV(Row, { justify: {
    xs: "center",
    sm: "start"
  }, style: {
    backgroundColor: token.colorBgContainer,
    minHeight: "calc(100vh - 100px)",
    borderRadius: "12px",
    maxWidth: "900px",
    marginTop: "14px"
  }, children: [
    /* @__PURE__ */ jsxDEV(Col, { xs: {
      span: 24
    }, sm: {
      span: 12
    }, style: {
      padding: "1rem"
    }, children: /* @__PURE__ */ jsxDEV("div", { style: {
      backgroundColor: token.colorBgContainerDisabled,
      borderRadius: "12px",
      height: screens.sm ? "100%" : "",
      alignItems: "center",
      display: "flex"
    }, children: /* @__PURE__ */ jsxDEV(Lottie, { animationData: welcomeAnimation, loop: true }, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/pages/login/Login.jsx",
      lineNumber: 43,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/pages/login/Login.jsx",
      lineNumber: 36,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/pages/login/Login.jsx",
      lineNumber: 29,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Col, { xs: {
      span: 24
    }, sm: {
      span: 12
    }, style: {
      padding: "1rem",
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }, children: /* @__PURE__ */ jsxDEV(LoginForm, {}, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/pages/login/Login.jsx",
      lineNumber: 56,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/pages/login/Login.jsx",
      lineNumber: 46,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/dharma/Work/react-boilerplate/src/pages/login/Login.jsx",
    lineNumber: 19,
    columnNumber: 10
  }, this);
};
_s(Login, "QTKVMO/xc3sekaAZWx3kbGyQVkk=", false, function() {
  return [useBreakpoint, useToken];
});
_c = Login;
export default Login;
var _c;
$RefreshReg$(_c, "Login");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/dharma/Work/react-boilerplate/src/pages/login/Login.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0NVOzs7Ozs7Ozs7Ozs7Ozs7OztBQXhDVixTQUFTQSxLQUFLQyxNQUFNQyxLQUFLQyxhQUFhO0FBQ3RDLE9BQU9DLFlBQVk7QUFDbkIsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxzQkFBc0I7QUFDN0IsT0FBT0MsZUFBZTtBQUV0QixNQUFNO0FBQUEsRUFBRUM7QUFBYyxJQUFJUDtBQUMxQixNQUFNO0FBQUEsRUFBQ1E7QUFBUSxJQUFJTjtBQUVuQixNQUFNTyxRQUFRQSxNQUFNO0FBQUFDLEtBQUE7QUFDbEIsUUFBTUMsVUFBVUosY0FBYztBQUM5QixRQUFNO0FBQUEsSUFBQ0s7QUFBQUEsRUFBSyxJQUFJSixTQUFTO0FBRXpCLFNBQ0UsdUJBQUMsT0FDQyxTQUFTO0FBQUEsSUFBRUssSUFBSTtBQUFBLElBQVVDLElBQUk7QUFBQSxFQUFRLEdBQ3JDLE9BQU87QUFBQSxJQUNMQyxpQkFBaUJILE1BQU1JO0FBQUFBLElBQ3ZCQyxXQUFXO0FBQUEsSUFDWEMsY0FBYztBQUFBLElBQ2RDLFVBQVU7QUFBQSxJQUNWQyxXQUFXO0FBQUEsRUFDYixHQUVBO0FBQUEsMkJBQUMsT0FDQyxJQUFJO0FBQUEsTUFBRUMsTUFBTTtBQUFBLElBQUcsR0FDZixJQUFJO0FBQUEsTUFBRUEsTUFBTTtBQUFBLElBQUcsR0FDZixPQUFPO0FBQUEsTUFDTEMsU0FBUztBQUFBLElBQ1gsR0FFQSxpQ0FBQyxTQUNDLE9BQU87QUFBQSxNQUNMUCxpQkFBaUJILE1BQU1XO0FBQUFBLE1BQ3ZCTCxjQUFjO0FBQUEsTUFDZE0sUUFBUWIsUUFBUUcsS0FBSyxTQUFTO0FBQUEsTUFDOUJXLFlBQVk7QUFBQSxNQUNaQyxTQUFTO0FBQUEsSUFDWCxHQUVBLGlDQUFDLFVBQU8sZUFBZXJCLGtCQUFrQixNQUFNLFFBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0QsS0FUdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVVBLEtBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FrQkE7QUFBQSxJQUNBLHVCQUFDLE9BQ0MsSUFBSTtBQUFBLE1BQUVnQixNQUFNO0FBQUEsSUFBRyxHQUNmLElBQUk7QUFBQSxNQUFFQSxNQUFNO0FBQUEsSUFBRyxHQUNmLE9BQU87QUFBQSxNQUNMQyxTQUFTO0FBQUEsTUFDVEksU0FBUztBQUFBLE1BQ1RELFlBQVk7QUFBQSxNQUNaRSxnQkFBZ0I7QUFBQSxJQUNsQixHQUVBLGlDQUFDLGVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFVLEtBVlo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVdBO0FBQUEsT0F4Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXlDQTtBQUVKO0FBQUVqQixHQWhESUQsT0FBSztBQUFBLFVBQ09GLGVBQ0FDLFFBQVE7QUFBQTtBQUFBb0IsS0FGcEJuQjtBQWtETixlQUFlQTtBQUFNLElBQUFtQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiQ29sIiwiR3JpZCIsIlJvdyIsInRoZW1lIiwiTG90dGllIiwiUmVhY3QiLCJ3ZWxjb21lQW5pbWF0aW9uIiwiTG9naW5Gb3JtIiwidXNlQnJlYWtwb2ludCIsInVzZVRva2VuIiwiTG9naW4iLCJfcyIsInNjcmVlbnMiLCJ0b2tlbiIsInhzIiwic20iLCJiYWNrZ3JvdW5kQ29sb3IiLCJjb2xvckJnQ29udGFpbmVyIiwibWluSGVpZ2h0IiwiYm9yZGVyUmFkaXVzIiwibWF4V2lkdGgiLCJtYXJnaW5Ub3AiLCJzcGFuIiwicGFkZGluZyIsImNvbG9yQmdDb250YWluZXJEaXNhYmxlZCIsImhlaWdodCIsImFsaWduSXRlbXMiLCJkaXNwbGF5IiwianVzdGlmeUNvbnRlbnQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkxvZ2luLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb2wsIEdyaWQsIFJvdywgdGhlbWUgfSBmcm9tIFwiYW50ZFwiO1xuaW1wb3J0IExvdHRpZSBmcm9tIFwibG90dGllLXJlYWN0XCI7XG5pbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgd2VsY29tZUFuaW1hdGlvbiBmcm9tIFwiLi4vLi4vYXNzZXRzL2xvdHRpZS93ZWxjb21lLmpzb25cIjtcbmltcG9ydCBMb2dpbkZvcm0gZnJvbSBcIi4vY29tcG9uZW50cy9Mb2dpbkZvcm1cIjtcblxuY29uc3QgeyB1c2VCcmVha3BvaW50IH0gPSBHcmlkO1xuY29uc3Qge3VzZVRva2VufSA9IHRoZW1lXG5cbmNvbnN0IExvZ2luID0gKCkgPT4ge1xuICBjb25zdCBzY3JlZW5zID0gdXNlQnJlYWtwb2ludCgpO1xuICBjb25zdCB7dG9rZW59ID0gdXNlVG9rZW4oKVxuXG4gIHJldHVybiAoXG4gICAgPFJvd1xuICAgICAganVzdGlmeT17eyB4czogXCJjZW50ZXJcIiwgc206IFwic3RhcnRcIiB9fVxuICAgICAgc3R5bGU9e3tcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiB0b2tlbi5jb2xvckJnQ29udGFpbmVyLFxuICAgICAgICBtaW5IZWlnaHQ6IFwiY2FsYygxMDB2aCAtIDEwMHB4KVwiLFxuICAgICAgICBib3JkZXJSYWRpdXM6IFwiMTJweFwiLFxuICAgICAgICBtYXhXaWR0aDogXCI5MDBweFwiLFxuICAgICAgICBtYXJnaW5Ub3A6IFwiMTRweFwiLFxuICAgICAgfX1cbiAgICA+XG4gICAgICA8Q29sXG4gICAgICAgIHhzPXt7IHNwYW46IDI0IH19XG4gICAgICAgIHNtPXt7IHNwYW46IDEyIH19XG4gICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgcGFkZGluZzogXCIxcmVtXCIsXG4gICAgICAgIH19XG4gICAgICA+XG4gICAgICAgIDxkaXZcbiAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiB0b2tlbi5jb2xvckJnQ29udGFpbmVyRGlzYWJsZWQsXG4gICAgICAgICAgICBib3JkZXJSYWRpdXM6IFwiMTJweFwiLFxuICAgICAgICAgICAgaGVpZ2h0OiBzY3JlZW5zLnNtID8gXCIxMDAlXCIgOiBcIlwiLFxuICAgICAgICAgICAgYWxpZ25JdGVtczogXCJjZW50ZXJcIixcbiAgICAgICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxuICAgICAgICAgIH19XG4gICAgICAgID5cbiAgICAgICAgICA8TG90dGllIGFuaW1hdGlvbkRhdGE9e3dlbGNvbWVBbmltYXRpb259IGxvb3A9e3RydWV9IC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9Db2w+XG4gICAgICA8Q29sXG4gICAgICAgIHhzPXt7IHNwYW46IDI0IH19XG4gICAgICAgIHNtPXt7IHNwYW46IDEyIH19XG4gICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgcGFkZGluZzogXCIxcmVtXCIsXG4gICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXG4gICAgICAgICAgYWxpZ25JdGVtczogXCJjZW50ZXJcIixcbiAgICAgICAgICBqdXN0aWZ5Q29udGVudDogXCJjZW50ZXJcIixcbiAgICAgICAgfX1cbiAgICAgID5cbiAgICAgICAgPExvZ2luRm9ybSAvPlxuICAgICAgPC9Db2w+XG4gICAgPC9Sb3c+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBMb2dpbjtcbiJdLCJmaWxlIjoiL2hvbWUvZGhhcm1hL1dvcmsvcmVhY3QtYm9pbGVycGxhdGUvc3JjL3BhZ2VzL2xvZ2luL0xvZ2luLmpzeCJ9