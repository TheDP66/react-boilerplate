import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f9dec5ba"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { BarChartOutlined, CheckSquareOutlined, CustomerServiceOutlined, FileTextOutlined, HomeOutlined, SettingOutlined, TeamOutlined } from "/node_modules/.vite/deps/@ant-design_icons.js?v=7a8c6384";
import Dashboard from "/src/pages/dashboard/Dashboard.jsx";
import DetailDashboard from "/src/pages/dashboard/DetailDashboard.jsx";
import Login from "/src/pages/login/Login.jsx";
import Users from "/src/pages/users/Users.jsx";
import { generateAuthPage, generateAuthParentPage } from "/src/utils/pages.jsx";
export const unauthenticatedPageList = [{
  path: "login",
  element: /* @__PURE__ */ jsxDEV(Login, {}, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/constant/pageList.jsx",
    lineNumber: 9,
    columnNumber: 12
  }, this),
  key: "Login"
}, {
  path: "signup",
  element: /* @__PURE__ */ jsxDEV(Fragment, { children: "Sign Up" }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/constant/pageList.jsx",
    lineNumber: 13,
    columnNumber: 12
  }, this),
  key: "Signup"
}, {
  path: "forgot_password",
  element: /* @__PURE__ */ jsxDEV(Fragment, { children: "Forgot Password" }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/constant/pageList.jsx",
    lineNumber: 17,
    columnNumber: 12
  }, this),
  key: "forgot_password"
}];
export const authenticatedPageList = () => [
  generateAuthPage({
    element: /* @__PURE__ */ jsxDEV(Dashboard, {}, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/constant/pageList.jsx",
      lineNumber: 23,
      columnNumber: 12
    }, this),
    icon: /* @__PURE__ */ jsxDEV(HomeOutlined, {}, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/constant/pageList.jsx",
      lineNumber: 24,
      columnNumber: 9
    }, this),
    key: "dashboard",
    label: "Dashboard",
    description: "Provides administrators direct access to important Encompass tools."
  }),
  generateAuthPage({
    element: /* @__PURE__ */ jsxDEV(Fragment, { children: "Activity" }, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/constant/pageList.jsx",
      lineNumber: 29,
      columnNumber: 12
    }, this),
    icon: /* @__PURE__ */ jsxDEV(BarChartOutlined, {}, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/constant/pageList.jsx",
      lineNumber: 30,
      columnNumber: 9
    }, this),
    key: "activity",
    label: "Activity",
    description: "Provides activity information."
  }),
  generateAuthPage({
    element: /* @__PURE__ */ jsxDEV(Fragment, { children: "Task" }, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/constant/pageList.jsx",
      lineNumber: 35,
      columnNumber: 12
    }, this),
    icon: /* @__PURE__ */ jsxDEV(CheckSquareOutlined, {}, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/constant/pageList.jsx",
      lineNumber: 36,
      columnNumber: 9
    }, this),
    key: "task",
    label: "Task",
    description: "Provides task information."
  }),
  generateAuthPage({
    element: /* @__PURE__ */ jsxDEV(Users, {}, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/constant/pageList.jsx",
      lineNumber: 41,
      columnNumber: 12
    }, this),
    icon: /* @__PURE__ */ jsxDEV(TeamOutlined, {}, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/constant/pageList.jsx",
      lineNumber: 42,
      columnNumber: 9
    }, this),
    key: "users",
    label: "Users",
    description: "Provides user information and activity log."
  }),
  {
    type: "divider",
    style: {
      margin: "10px 0"
    }
  },
  generateAuthPage({
    element: /* @__PURE__ */ jsxDEV(Fragment, { children: "Setting" }, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/constant/pageList.jsx",
      lineNumber: 52,
      columnNumber: 12
    }, this),
    icon: /* @__PURE__ */ jsxDEV(SettingOutlined, {}, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/constant/pageList.jsx",
      lineNumber: 53,
      columnNumber: 9
    }, this),
    key: "setting",
    label: "Setting",
    description: "Provides account profile and configuration."
  }),
  // ? Use generateAuthParentPage() if menu has submenu
  generateAuthParentPage({
    key: "report",
    label: "Report",
    icon: /* @__PURE__ */ jsxDEV(FileTextOutlined, {}, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/constant/pageList.jsx",
      lineNumber: 62,
      columnNumber: 9
    }, this),
    children: [generateAuthPage({
      element: /* @__PURE__ */ jsxDEV(Fragment, { children: "Activity Report" }, void 0, false, {
        fileName: "/home/dharma/Work/react-boilerplate/src/constant/pageList.jsx",
        lineNumber: 64,
        columnNumber: 14
      }, this),
      key: "activity_report",
      label: "Activity",
      icon: /* @__PURE__ */ jsxDEV(FileTextOutlined, {}, void 0, false, {
        fileName: "/home/dharma/Work/react-boilerplate/src/constant/pageList.jsx",
        lineNumber: 67,
        columnNumber: 11
      }, this),
      description: "Provides activity report."
    }), generateAuthPage({
      element: /* @__PURE__ */ jsxDEV(Fragment, { children: "Task Report" }, void 0, false, {
        fileName: "/home/dharma/Work/react-boilerplate/src/constant/pageList.jsx",
        lineNumber: 70,
        columnNumber: 14
      }, this),
      key: "task_report",
      label: "Task",
      icon: /* @__PURE__ */ jsxDEV(FileTextOutlined, {}, void 0, false, {
        fileName: "/home/dharma/Work/react-boilerplate/src/constant/pageList.jsx",
        lineNumber: 73,
        columnNumber: 11
      }, this),
      description: "Provides task report."
    }), generateAuthPage({
      element: /* @__PURE__ */ jsxDEV(Fragment, { children: "Users Report" }, void 0, false, {
        fileName: "/home/dharma/Work/react-boilerplate/src/constant/pageList.jsx",
        lineNumber: 76,
        columnNumber: 14
      }, this),
      key: "users_report",
      label: "Users",
      icon: /* @__PURE__ */ jsxDEV(FileTextOutlined, {}, void 0, false, {
        fileName: "/home/dharma/Work/react-boilerplate/src/constant/pageList.jsx",
        lineNumber: 79,
        columnNumber: 11
      }, this),
      description: "Provides users report."
    })]
  }),
  generateAuthPage({
    element: /* @__PURE__ */ jsxDEV(Fragment, { children: "Support" }, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/constant/pageList.jsx",
      lineNumber: 83,
      columnNumber: 12
    }, this),
    icon: /* @__PURE__ */ jsxDEV(CustomerServiceOutlined, {}, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/constant/pageList.jsx",
      lineNumber: 84,
      columnNumber: 9
    }, this),
    key: "support",
    label: "Support",
    description: "Answer questions by customers and help them in using the product and get the most out of it."
  })
].filter((page) => !page.unauthorized || page?.children?.length < 0);
export const authenticatedDetailPageList = () => [generateAuthPage({
  element: /* @__PURE__ */ jsxDEV(DetailDashboard, {}, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/constant/pageList.jsx",
    lineNumber: 90,
    columnNumber: 12
  }, this),
  key: "dashboard/:id"
})];

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0JhLFNBS0EsVUFMQTtBQWxCYixTQUNFQSxrQkFDQUMscUJBQ0FDLHlCQUNBQyxrQkFDQUMsY0FDQUMsaUJBQ0FDLG9CQUNLO0FBQ1AsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxxQkFBcUI7QUFDNUIsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxXQUFXO0FBQ2xCLFNBQVNDLGtCQUFrQkMsOEJBQThCO0FBRWxELGFBQU1DLDBCQUEwQixDQUNyQztBQUFBLEVBQ0VDLE1BQU07QUFBQSxFQUNOQyxTQUFTLHVCQUFDLFdBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFNO0FBQUEsRUFDZkMsS0FBSztBQUNQLEdBQ0E7QUFBQSxFQUNFRixNQUFNO0FBQUEsRUFDTkMsU0FBUyxtQ0FBRSx1QkFBRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQVM7QUFBQSxFQUNsQkMsS0FBSztBQUNQLEdBQ0E7QUFBQSxFQUNFRixNQUFNO0FBQUEsRUFDTkMsU0FBUyxtQ0FBRSwrQkFBRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWlCO0FBQUEsRUFDMUJDLEtBQUs7QUFDUCxDQUFDO0FBSUksYUFBTUMsd0JBQXdCQSxNQUNuQztBQUFBLEVBQ0VOLGlCQUFpQjtBQUFBLElBQ2ZJLFNBQVMsdUJBQUMsZUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVU7QUFBQSxJQUNuQkcsTUFBTSx1QkFBQyxrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWE7QUFBQSxJQUNuQkYsS0FBSztBQUFBLElBQ0xHLE9BQU87QUFBQSxJQUNQQyxhQUNFO0FBQUEsRUFDSixDQUFDO0FBQUEsRUFDRFQsaUJBQWlCO0FBQUEsSUFDZkksU0FBUyxtQ0FBRSx3QkFBRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVU7QUFBQSxJQUNuQkcsTUFBTSx1QkFBQyxzQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlCO0FBQUEsSUFDdkJGLEtBQUs7QUFBQSxJQUNMRyxPQUFPO0FBQUEsSUFDUEMsYUFBYTtBQUFBLEVBQ2YsQ0FBQztBQUFBLEVBQ0RULGlCQUFpQjtBQUFBLElBQ2ZJLFNBQVMsbUNBQUUsb0JBQUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFNO0FBQUEsSUFDZkcsTUFBTSx1QkFBQyx5QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW9CO0FBQUEsSUFDMUJGLEtBQUs7QUFBQSxJQUNMRyxPQUFPO0FBQUEsSUFDUEMsYUFBYTtBQUFBLEVBQ2YsQ0FBQztBQUFBLEVBQ0RULGlCQUFpQjtBQUFBLElBQ2ZJLFNBQVMsdUJBQUMsV0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQU07QUFBQSxJQUNmRyxNQUFNLHVCQUFDLGtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBYTtBQUFBLElBQ25CRixLQUFLO0FBQUEsSUFDTEcsT0FBTztBQUFBLElBQ1BDLGFBQWE7QUFBQSxFQUNmLENBQUM7QUFBQSxFQUNEO0FBQUEsSUFDRUMsTUFBTTtBQUFBLElBQ05DLE9BQU87QUFBQSxNQUFFQyxRQUFRO0FBQUEsSUFBUztBQUFBLEVBQzVCO0FBQUEsRUFDQVosaUJBQWlCO0FBQUEsSUFDZkksU0FBUyxtQ0FBRSx1QkFBRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVM7QUFBQSxJQUNsQkcsTUFBTSx1QkFBQyxxQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdCO0FBQUEsSUFDdEJGLEtBQUs7QUFBQSxJQUNMRyxPQUFPO0FBQUEsSUFDUEMsYUFBYTtBQUFBLEVBQ2YsQ0FBQztBQUFBO0FBQUEsRUFFRFIsdUJBQXVCO0FBQUEsSUFDckJJLEtBQUs7QUFBQSxJQUNMRyxPQUFPO0FBQUEsSUFDUEQsTUFBTSx1QkFBQyxzQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlCO0FBQUEsSUFDdkJNLFVBQVUsQ0FDUmIsaUJBQWlCO0FBQUEsTUFDZkksU0FBUyxtQ0FBRSwrQkFBRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlCO0FBQUEsTUFDMUJDLEtBQUs7QUFBQSxNQUNMRyxPQUFPO0FBQUEsTUFDUEQsTUFBTSx1QkFBQyxzQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlCO0FBQUEsTUFDdkJFLGFBQWE7QUFBQSxJQUNmLENBQUMsR0FDRFQsaUJBQWlCO0FBQUEsTUFDZkksU0FBUyxtQ0FBRSwyQkFBRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWE7QUFBQSxNQUN0QkMsS0FBSztBQUFBLE1BQ0xHLE9BQU87QUFBQSxNQUNQRCxNQUFNLHVCQUFDLHNCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUI7QUFBQSxNQUN2QkUsYUFBYTtBQUFBLElBQ2YsQ0FBQyxHQUNEVCxpQkFBaUI7QUFBQSxNQUNmSSxTQUFTLG1DQUFFLDRCQUFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBYztBQUFBLE1BQ3ZCQyxLQUFLO0FBQUEsTUFDTEcsT0FBTztBQUFBLE1BQ1BELE1BQU0sdUJBQUMsc0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQjtBQUFBLE1BQ3ZCRSxhQUFhO0FBQUEsSUFDZixDQUFDLENBQUM7QUFBQSxFQUVOLENBQUM7QUFBQSxFQUNEVCxpQkFBaUI7QUFBQSxJQUNmSSxTQUFTLG1DQUFFLHVCQUFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUztBQUFBLElBQ2xCRyxNQUFNLHVCQUFDLDZCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0I7QUFBQSxJQUM5QkYsS0FBSztBQUFBLElBQ0xHLE9BQU87QUFBQSxJQUNQQyxhQUNFO0FBQUEsRUFDSixDQUFDO0FBQUMsRUFDRkssT0FBUUMsVUFBUyxDQUFDQSxLQUFLQyxnQkFBZ0JELE1BQU1GLFVBQVVJLFNBQVMsQ0FBQztBQUU5RCxhQUFNQyw4QkFBOEJBLE1BQU0sQ0FDL0NsQixpQkFBaUI7QUFBQSxFQUNmSSxTQUFTLHVCQUFDLHFCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBZ0I7QUFBQSxFQUN6QkMsS0FBSztBQUNQLENBQUMsQ0FBQyIsIm5hbWVzIjpbIkJhckNoYXJ0T3V0bGluZWQiLCJDaGVja1NxdWFyZU91dGxpbmVkIiwiQ3VzdG9tZXJTZXJ2aWNlT3V0bGluZWQiLCJGaWxlVGV4dE91dGxpbmVkIiwiSG9tZU91dGxpbmVkIiwiU2V0dGluZ091dGxpbmVkIiwiVGVhbU91dGxpbmVkIiwiRGFzaGJvYXJkIiwiRGV0YWlsRGFzaGJvYXJkIiwiTG9naW4iLCJVc2VycyIsImdlbmVyYXRlQXV0aFBhZ2UiLCJnZW5lcmF0ZUF1dGhQYXJlbnRQYWdlIiwidW5hdXRoZW50aWNhdGVkUGFnZUxpc3QiLCJwYXRoIiwiZWxlbWVudCIsImtleSIsImF1dGhlbnRpY2F0ZWRQYWdlTGlzdCIsImljb24iLCJsYWJlbCIsImRlc2NyaXB0aW9uIiwidHlwZSIsInN0eWxlIiwibWFyZ2luIiwiY2hpbGRyZW4iLCJmaWx0ZXIiLCJwYWdlIiwidW5hdXRob3JpemVkIiwibGVuZ3RoIiwiYXV0aGVudGljYXRlZERldGFpbFBhZ2VMaXN0Il0sInNvdXJjZXMiOlsicGFnZUxpc3QuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIEJhckNoYXJ0T3V0bGluZWQsXG4gIENoZWNrU3F1YXJlT3V0bGluZWQsXG4gIEN1c3RvbWVyU2VydmljZU91dGxpbmVkLFxuICBGaWxlVGV4dE91dGxpbmVkLFxuICBIb21lT3V0bGluZWQsXG4gIFNldHRpbmdPdXRsaW5lZCxcbiAgVGVhbU91dGxpbmVkLFxufSBmcm9tIFwiQGFudC1kZXNpZ24vaWNvbnNcIjtcbmltcG9ydCBEYXNoYm9hcmQgZnJvbSBcIi4uL3BhZ2VzL2Rhc2hib2FyZC9EYXNoYm9hcmRcIjtcbmltcG9ydCBEZXRhaWxEYXNoYm9hcmQgZnJvbSBcIi4uL3BhZ2VzL2Rhc2hib2FyZC9EZXRhaWxEYXNoYm9hcmRcIjtcbmltcG9ydCBMb2dpbiBmcm9tIFwiLi4vcGFnZXMvbG9naW4vTG9naW5cIjtcbmltcG9ydCBVc2VycyBmcm9tIFwiLi4vcGFnZXMvdXNlcnMvVXNlcnNcIjtcbmltcG9ydCB7IGdlbmVyYXRlQXV0aFBhZ2UsIGdlbmVyYXRlQXV0aFBhcmVudFBhZ2UgfSBmcm9tIFwiLi4vdXRpbHMvcGFnZXNcIjtcblxuZXhwb3J0IGNvbnN0IHVuYXV0aGVudGljYXRlZFBhZ2VMaXN0ID0gW1xuICB7XG4gICAgcGF0aDogXCJsb2dpblwiLFxuICAgIGVsZW1lbnQ6IDxMb2dpbiAvPixcbiAgICBrZXk6IFwiTG9naW5cIixcbiAgfSxcbiAge1xuICAgIHBhdGg6IFwic2lnbnVwXCIsXG4gICAgZWxlbWVudDogPD5TaWduIFVwPC8+LFxuICAgIGtleTogXCJTaWdudXBcIixcbiAgfSxcbiAge1xuICAgIHBhdGg6IFwiZm9yZ290X3Bhc3N3b3JkXCIsXG4gICAgZWxlbWVudDogPD5Gb3Jnb3QgUGFzc3dvcmQ8Lz4sXG4gICAga2V5OiBcImZvcmdvdF9wYXNzd29yZFwiLFxuICB9LFxuXTtcblxuLy8gPyBEb2N1bWVudGF0aW9uIGluIHNyYy91dGlscy9wYWdlcy5qc1xuZXhwb3J0IGNvbnN0IGF1dGhlbnRpY2F0ZWRQYWdlTGlzdCA9ICgpID0+XG4gIFtcbiAgICBnZW5lcmF0ZUF1dGhQYWdlKHtcbiAgICAgIGVsZW1lbnQ6IDxEYXNoYm9hcmQgLz4sXG4gICAgICBpY29uOiA8SG9tZU91dGxpbmVkIC8+LFxuICAgICAga2V5OiBcImRhc2hib2FyZFwiLFxuICAgICAgbGFiZWw6IFwiRGFzaGJvYXJkXCIsXG4gICAgICBkZXNjcmlwdGlvbjpcbiAgICAgICAgXCJQcm92aWRlcyBhZG1pbmlzdHJhdG9ycyBkaXJlY3QgYWNjZXNzIHRvIGltcG9ydGFudCBFbmNvbXBhc3MgdG9vbHMuXCIsXG4gICAgfSksXG4gICAgZ2VuZXJhdGVBdXRoUGFnZSh7XG4gICAgICBlbGVtZW50OiA8PkFjdGl2aXR5PC8+LFxuICAgICAgaWNvbjogPEJhckNoYXJ0T3V0bGluZWQgLz4sXG4gICAgICBrZXk6IFwiYWN0aXZpdHlcIixcbiAgICAgIGxhYmVsOiBcIkFjdGl2aXR5XCIsXG4gICAgICBkZXNjcmlwdGlvbjogXCJQcm92aWRlcyBhY3Rpdml0eSBpbmZvcm1hdGlvbi5cIixcbiAgICB9KSxcbiAgICBnZW5lcmF0ZUF1dGhQYWdlKHtcbiAgICAgIGVsZW1lbnQ6IDw+VGFzazwvPixcbiAgICAgIGljb246IDxDaGVja1NxdWFyZU91dGxpbmVkIC8+LFxuICAgICAga2V5OiBcInRhc2tcIixcbiAgICAgIGxhYmVsOiBcIlRhc2tcIixcbiAgICAgIGRlc2NyaXB0aW9uOiBcIlByb3ZpZGVzIHRhc2sgaW5mb3JtYXRpb24uXCIsXG4gICAgfSksXG4gICAgZ2VuZXJhdGVBdXRoUGFnZSh7XG4gICAgICBlbGVtZW50OiA8VXNlcnMgLz4sXG4gICAgICBpY29uOiA8VGVhbU91dGxpbmVkIC8+LFxuICAgICAga2V5OiBcInVzZXJzXCIsXG4gICAgICBsYWJlbDogXCJVc2Vyc1wiLFxuICAgICAgZGVzY3JpcHRpb246IFwiUHJvdmlkZXMgdXNlciBpbmZvcm1hdGlvbiBhbmQgYWN0aXZpdHkgbG9nLlwiLFxuICAgIH0pLFxuICAgIHtcbiAgICAgIHR5cGU6IFwiZGl2aWRlclwiLFxuICAgICAgc3R5bGU6IHsgbWFyZ2luOiBcIjEwcHggMFwiIH0sXG4gICAgfSxcbiAgICBnZW5lcmF0ZUF1dGhQYWdlKHtcbiAgICAgIGVsZW1lbnQ6IDw+U2V0dGluZzwvPixcbiAgICAgIGljb246IDxTZXR0aW5nT3V0bGluZWQgLz4sXG4gICAgICBrZXk6IFwic2V0dGluZ1wiLFxuICAgICAgbGFiZWw6IFwiU2V0dGluZ1wiLFxuICAgICAgZGVzY3JpcHRpb246IFwiUHJvdmlkZXMgYWNjb3VudCBwcm9maWxlIGFuZCBjb25maWd1cmF0aW9uLlwiLFxuICAgIH0pLFxuICAgIC8vID8gVXNlIGdlbmVyYXRlQXV0aFBhcmVudFBhZ2UoKSBpZiBtZW51IGhhcyBzdWJtZW51XG4gICAgZ2VuZXJhdGVBdXRoUGFyZW50UGFnZSh7XG4gICAgICBrZXk6IFwicmVwb3J0XCIsXG4gICAgICBsYWJlbDogXCJSZXBvcnRcIixcbiAgICAgIGljb246IDxGaWxlVGV4dE91dGxpbmVkIC8+LFxuICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgZ2VuZXJhdGVBdXRoUGFnZSh7XG4gICAgICAgICAgZWxlbWVudDogPD5BY3Rpdml0eSBSZXBvcnQ8Lz4sXG4gICAgICAgICAga2V5OiBcImFjdGl2aXR5X3JlcG9ydFwiLFxuICAgICAgICAgIGxhYmVsOiBcIkFjdGl2aXR5XCIsXG4gICAgICAgICAgaWNvbjogPEZpbGVUZXh0T3V0bGluZWQgLz4sXG4gICAgICAgICAgZGVzY3JpcHRpb246IFwiUHJvdmlkZXMgYWN0aXZpdHkgcmVwb3J0LlwiLFxuICAgICAgICB9KSxcbiAgICAgICAgZ2VuZXJhdGVBdXRoUGFnZSh7XG4gICAgICAgICAgZWxlbWVudDogPD5UYXNrIFJlcG9ydDwvPixcbiAgICAgICAgICBrZXk6IFwidGFza19yZXBvcnRcIixcbiAgICAgICAgICBsYWJlbDogXCJUYXNrXCIsXG4gICAgICAgICAgaWNvbjogPEZpbGVUZXh0T3V0bGluZWQgLz4sXG4gICAgICAgICAgZGVzY3JpcHRpb246IFwiUHJvdmlkZXMgdGFzayByZXBvcnQuXCIsXG4gICAgICAgIH0pLFxuICAgICAgICBnZW5lcmF0ZUF1dGhQYWdlKHtcbiAgICAgICAgICBlbGVtZW50OiA8PlVzZXJzIFJlcG9ydDwvPixcbiAgICAgICAgICBrZXk6IFwidXNlcnNfcmVwb3J0XCIsXG4gICAgICAgICAgbGFiZWw6IFwiVXNlcnNcIixcbiAgICAgICAgICBpY29uOiA8RmlsZVRleHRPdXRsaW5lZCAvPixcbiAgICAgICAgICBkZXNjcmlwdGlvbjogXCJQcm92aWRlcyB1c2VycyByZXBvcnQuXCIsXG4gICAgICAgIH0pLFxuICAgICAgXSxcbiAgICB9KSxcbiAgICBnZW5lcmF0ZUF1dGhQYWdlKHtcbiAgICAgIGVsZW1lbnQ6IDw+U3VwcG9ydDwvPixcbiAgICAgIGljb246IDxDdXN0b21lclNlcnZpY2VPdXRsaW5lZCAvPixcbiAgICAgIGtleTogXCJzdXBwb3J0XCIsXG4gICAgICBsYWJlbDogXCJTdXBwb3J0XCIsXG4gICAgICBkZXNjcmlwdGlvbjpcbiAgICAgICAgXCJBbnN3ZXIgcXVlc3Rpb25zIGJ5IGN1c3RvbWVycyBhbmQgaGVscCB0aGVtIGluIHVzaW5nIHRoZSBwcm9kdWN0IGFuZCBnZXQgdGhlIG1vc3Qgb3V0IG9mIGl0LlwiLFxuICAgIH0pLFxuICBdLmZpbHRlcigocGFnZSkgPT4gIXBhZ2UudW5hdXRob3JpemVkIHx8IHBhZ2U/LmNoaWxkcmVuPy5sZW5ndGggPCAwKTtcblxuZXhwb3J0IGNvbnN0IGF1dGhlbnRpY2F0ZWREZXRhaWxQYWdlTGlzdCA9ICgpID0+IFtcbiAgZ2VuZXJhdGVBdXRoUGFnZSh7XG4gICAgZWxlbWVudDogPERldGFpbERhc2hib2FyZCAvPixcbiAgICBrZXk6IFwiZGFzaGJvYXJkLzppZFwiLFxuICB9KSxcbl07XG4iXSwiZmlsZSI6Ii9ob21lL2RoYXJtYS9Xb3JrL3JlYWN0LWJvaWxlcnBsYXRlL3NyYy9jb25zdGFudC9wYWdlTGlzdC5qc3gifQ==