import { gql } from "/node_modules/.vite/deps/@apollo_client.js?v=6e4ae227";
export const GET_CHARACTERS = gql`
  query GetCharacters {
    characters {
      results {
        id
        name
        status
        species
        image
        gender
      }
    }
  }
`;
export const GET_CHARACTER = gql`
  query GetCharacter($id: ID!) {
    character(id: $id) {
      id
      name
      image
      episode {
        name
        episode
      }
    }
  }
`;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUEsU0FBU0EsV0FBVztBQUViLGFBQU1DLGlCQUFpQkQ7QUFBQUE7QUFBQUE7QUFBQUE7QUFBQUE7QUFBQUE7QUFBQUE7QUFBQUE7QUFBQUE7QUFBQUE7QUFBQUE7QUFBQUE7QUFBQUE7QUFBQUE7QUFldkIsYUFBTUUsZ0JBQWdCRjtBQUFBQTtBQUFBQTtBQUFBQTtBQUFBQTtBQUFBQTtBQUFBQTtBQUFBQTtBQUFBQTtBQUFBQTtBQUFBQTtBQUFBQTtBQUFBQSIsIm5hbWVzIjpbImdxbCIsIkdFVF9DSEFSQUNURVJTIiwiR0VUX0NIQVJBQ1RFUiJdLCJzb3VyY2VzIjpbImNoYXJhY3Rlci5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgZ3FsIH0gZnJvbSBcIkBhcG9sbG8vY2xpZW50XCI7XG5cbmV4cG9ydCBjb25zdCBHRVRfQ0hBUkFDVEVSUyA9IGdxbGBcbiAgcXVlcnkgR2V0Q2hhcmFjdGVycyB7XG4gICAgY2hhcmFjdGVycyB7XG4gICAgICByZXN1bHRzIHtcbiAgICAgICAgaWRcbiAgICAgICAgbmFtZVxuICAgICAgICBzdGF0dXNcbiAgICAgICAgc3BlY2llc1xuICAgICAgICBpbWFnZVxuICAgICAgICBnZW5kZXJcbiAgICAgIH1cbiAgICB9XG4gIH1cbmA7XG5cbmV4cG9ydCBjb25zdCBHRVRfQ0hBUkFDVEVSID0gZ3FsYFxuICBxdWVyeSBHZXRDaGFyYWN0ZXIoJGlkOiBJRCEpIHtcbiAgICBjaGFyYWN0ZXIoaWQ6ICRpZCkge1xuICAgICAgaWRcbiAgICAgIG5hbWVcbiAgICAgIGltYWdlXG4gICAgICBlcGlzb2RlIHtcbiAgICAgICAgbmFtZVxuICAgICAgICBlcGlzb2RlXG4gICAgICB9XG4gICAgfVxuICB9XG5gO1xuIl0sImZpbGUiOiIvaG9tZS9kaGFybWEvV29yay9yZWFjdC1ib2lsZXJwbGF0ZS9zcmMvY29uc3RhbnQvcXVlcmllcy9jaGFyYWN0ZXIuanN4In0=