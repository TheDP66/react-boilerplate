export const v = "5.7.0";
export const fr = 30;
export const ip = 0;
export const op = 180;
export const w = 800;
export const h = 600;
export const nm = "Contact Us 2";
export const ddd = 0;
export const assets = [
	{
		id: "comp_0",
		layers: [
			{
				ddd: 0,
				ind: 1,
				ty: 4,
				nm: "eyebrow _r",
				parent: 5,
				sr: 1,
				ks: {
					o: {
						a: 0,
						k: 100,
						ix: 11
					},
					r: {
						a: 0,
						k: 0,
						ix: 10
					},
					p: {
						a: 1,
						k: [
							{
								i: {
									x: 0.667,
									y: 1
								},
								o: {
									x: 0.333,
									y: 0
								},
								t: 0,
								s: [
									-8.747,
									-157.781,
									0
								],
								to: [
									0,
									-0.333,
									0
								],
								ti: [
									0,
									0.333,
									0
								]
							},
							{
								i: {
									x: 0.667,
									y: 0.667
								},
								o: {
									x: 0.333,
									y: 0.333
								},
								t: 24.286,
								s: [
									-8.747,
									-159.781,
									0
								],
								to: [
									0,
									0,
									0
								],
								ti: [
									0,
									0,
									0
								]
							},
							{
								i: {
									x: 0.667,
									y: 1
								},
								o: {
									x: 0.333,
									y: 0
								},
								t: 133.571,
								s: [
									-8.747,
									-159.781,
									0
								],
								to: [
									0,
									0.333,
									0
								],
								ti: [
									0,
									-0.333,
									0
								]
							},
							{
								t: 157.857421875,
								s: [
									-8.747,
									-157.781,
									0
								]
							}
						],
						ix: 2
					},
					a: {
						a: 0,
						k: [
							-8.747,
							-155.781,
							0
						],
						ix: 1
					},
					s: {
						a: 0,
						k: [
							100,
							100,
							100
						],
						ix: 6
					}
				},
				ao: 0,
				shapes: [
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												-8.993,
												2.241
											]
										],
										o: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												8.993,
												-2.241
											]
										],
										v: [
											[
												2.244,
												-156.966
											],
											[
												-19.739,
												-151.287
											],
											[
												-9.747,
												-159.694
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										0.156862750649,
										0.156862750649,
										0.156862750649,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 1",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 1,
						mn: "ADBE Vector Group",
						hd: false
					}
				],
				ip: 0,
				op: 180,
				st: 0,
				bm: 0
			},
			{
				ddd: 0,
				ind: 2,
				ty: 4,
				nm: "eye brow _l",
				parent: 5,
				sr: 1,
				ks: {
					o: {
						a: 0,
						k: 100,
						ix: 11
					},
					r: {
						a: 0,
						k: 0,
						ix: 10
					},
					p: {
						a: 1,
						k: [
							{
								i: {
									x: 0.667,
									y: 1
								},
								o: {
									x: 0.333,
									y: 0
								},
								t: 0,
								s: [
									26.895,
									-157.781,
									0
								],
								to: [
									0,
									-0.333,
									0
								],
								ti: [
									0,
									0.333,
									0
								]
							},
							{
								i: {
									x: 0.667,
									y: 0.667
								},
								o: {
									x: 0.333,
									y: 0.333
								},
								t: 24.286,
								s: [
									26.895,
									-159.781,
									0
								],
								to: [
									0,
									0,
									0
								],
								ti: [
									0,
									0,
									0
								]
							},
							{
								i: {
									x: 0.667,
									y: 1
								},
								o: {
									x: 0.333,
									y: 0
								},
								t: 133.571,
								s: [
									26.895,
									-159.781,
									0
								],
								to: [
									0,
									0.333,
									0
								],
								ti: [
									0,
									-0.333,
									0
								]
							},
							{
								t: 157.857421875,
								s: [
									26.895,
									-157.781,
									0
								]
							}
						],
						ix: 2
					},
					a: {
						a: 0,
						k: [
							26.895,
							-155.781,
							0
						],
						ix: 1
					},
					s: {
						a: 0,
						k: [
							100,
							100,
							100
						],
						ix: 6
					}
				},
				ao: 0,
				shapes: [
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												8.993,
												2.241
											]
										],
										o: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												-8.993,
												-2.241
											]
										],
										v: [
											[
												15.904,
												-156.966
											],
											[
												37.887,
												-151.287
											],
											[
												27.895,
												-159.694
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										0.156862750649,
										0.156862750649,
										0.156862750649,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 1",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 1,
						mn: "ADBE Vector Group",
						hd: false
					}
				],
				ip: 0,
				op: 180,
				st: 0,
				bm: 0
			},
			{
				ddd: 0,
				ind: 3,
				ty: 4,
				nm: "eye _l",
				parent: 5,
				sr: 1,
				ks: {
					o: {
						a: 0,
						k: 100,
						ix: 11
					},
					r: {
						a: 0,
						k: 0,
						ix: 10
					},
					p: {
						a: 0,
						k: [
							24.273,
							-140.7,
							0
						],
						ix: 2
					},
					a: {
						a: 0,
						k: [
							24.273,
							-140.7,
							0
						],
						ix: 1
					},
					s: {
						a: 1,
						k: [
							{
								i: {
									x: [
										0.667,
										0.667,
										0.667
									],
									y: [
										1,
										1,
										1
									]
								},
								o: {
									x: [
										0.333,
										0.333,
										0.333
									],
									y: [
										0,
										0,
										0
									]
								},
								t: 42.5,
								s: [
									100,
									100,
									100
								]
							},
							{
								i: {
									x: [
										0.667,
										0.667,
										0.667
									],
									y: [
										1,
										1,
										1
									]
								},
								o: {
									x: [
										0.333,
										0.333,
										0.333
									],
									y: [
										0,
										0,
										0
									]
								},
								t: 60.714,
								s: [
									100,
									5,
									100
								]
							},
							{
								i: {
									x: [
										0.667,
										0.667,
										0.667
									],
									y: [
										1,
										1,
										1
									]
								},
								o: {
									x: [
										0.333,
										0.333,
										0.333
									],
									y: [
										0,
										0,
										0
									]
								},
								t: 78.929,
								s: [
									100,
									100,
									100
								]
							},
							{
								i: {
									x: [
										0.667,
										0.667,
										0.667
									],
									y: [
										1,
										1,
										1
									]
								},
								o: {
									x: [
										0.333,
										0.333,
										0.333
									],
									y: [
										0,
										0,
										0
									]
								},
								t: 133.571,
								s: [
									100,
									100,
									100
								]
							},
							{
								i: {
									x: [
										0.667,
										0.667,
										0.667
									],
									y: [
										1,
										1,
										1
									]
								},
								o: {
									x: [
										0.333,
										0.333,
										0.333
									],
									y: [
										0,
										0,
										0
									]
								},
								t: 151.786,
								s: [
									100,
									5,
									100
								]
							},
							{
								t: 170,
								s: [
									100,
									100,
									100
								]
							}
						],
						ix: 6
					}
				},
				ao: 0,
				shapes: [
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												-1.806
											],
											[
												1.806,
												0
											],
											[
												0,
												1.806
											],
											[
												-1.806,
												0
											]
										],
										o: [
											[
												0,
												1.806
											],
											[
												-1.806,
												0
											],
											[
												0,
												-1.806
											],
											[
												1.806,
												0
											]
										],
										v: [
											[
												27.542,
												-140.7
											],
											[
												24.273,
												-137.431
											],
											[
												21.003,
												-140.7
											],
											[
												24.273,
												-143.97
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										0.156862750649,
										0.156862750649,
										0.156862750649,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 1",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 1,
						mn: "ADBE Vector Group",
						hd: false
					}
				],
				ip: 0,
				op: 180,
				st: 0,
				bm: 0
			},
			{
				ddd: 0,
				ind: 4,
				ty: 4,
				nm: "eye _r",
				parent: 5,
				sr: 1,
				ks: {
					o: {
						a: 0,
						k: 100,
						ix: 11
					},
					r: {
						a: 0,
						k: 0,
						ix: 10
					},
					p: {
						a: 0,
						k: [
							-6.381,
							-140.7,
							0
						],
						ix: 2
					},
					a: {
						a: 0,
						k: [
							-6.381,
							-140.7,
							0
						],
						ix: 1
					},
					s: {
						a: 1,
						k: [
							{
								i: {
									x: [
										0.667,
										0.667,
										0.667
									],
									y: [
										1,
										1,
										1
									]
								},
								o: {
									x: [
										0.333,
										0.333,
										0.333
									],
									y: [
										0,
										0,
										0
									]
								},
								t: 42.5,
								s: [
									100,
									100,
									100
								]
							},
							{
								i: {
									x: [
										0.667,
										0.667,
										0.667
									],
									y: [
										1,
										1,
										1
									]
								},
								o: {
									x: [
										0.333,
										0.333,
										0.333
									],
									y: [
										0,
										0,
										0
									]
								},
								t: 60.714,
								s: [
									100,
									5,
									100
								]
							},
							{
								i: {
									x: [
										0.667,
										0.667,
										0.667
									],
									y: [
										1,
										1,
										1
									]
								},
								o: {
									x: [
										0.333,
										0.333,
										0.333
									],
									y: [
										0,
										0,
										0
									]
								},
								t: 78.929,
								s: [
									100,
									100,
									100
								]
							},
							{
								i: {
									x: [
										0.667,
										0.667,
										0.667
									],
									y: [
										1,
										1,
										1
									]
								},
								o: {
									x: [
										0.333,
										0.333,
										0.333
									],
									y: [
										0,
										0,
										0
									]
								},
								t: 133.571,
								s: [
									100,
									100,
									100
								]
							},
							{
								i: {
									x: [
										0.667,
										0.667,
										0.667
									],
									y: [
										1,
										1,
										1
									]
								},
								o: {
									x: [
										0.333,
										0.333,
										0.333
									],
									y: [
										0,
										0,
										0
									]
								},
								t: 151.786,
								s: [
									100,
									5,
									100
								]
							},
							{
								t: 170,
								s: [
									100,
									100,
									100
								]
							}
						],
						ix: 6
					}
				},
				ao: 0,
				shapes: [
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												-1.806
											],
											[
												1.806,
												0
											],
											[
												0,
												1.806
											],
											[
												-1.806,
												0
											]
										],
										o: [
											[
												0,
												1.806
											],
											[
												-1.806,
												0
											],
											[
												0,
												-1.806
											],
											[
												1.806,
												0
											]
										],
										v: [
											[
												-3.112,
												-140.7
											],
											[
												-6.381,
												-137.431
											],
											[
												-9.651,
												-140.7
											],
											[
												-6.381,
												-143.97
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										0.156862750649,
										0.156862750649,
										0.156862750649,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 1",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 1,
						mn: "ADBE Vector Group",
						hd: false
					}
				],
				ip: 0,
				op: 180,
				st: 0,
				bm: 0
			},
			{
				ddd: 0,
				ind: 5,
				ty: 4,
				nm: "head",
				parent: 6,
				sr: 1,
				ks: {
					o: {
						a: 0,
						k: 100,
						ix: 11
					},
					r: {
						a: 1,
						k: [
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 0,
								s: [
									0
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 24.286,
								s: [
									5
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 42.5,
								s: [
									-5
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 60.714,
								s: [
									5
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 78.929,
								s: [
									-5
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 97.143,
								s: [
									5
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 115.357,
								s: [
									-5
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 133.571,
								s: [
									5
								]
							},
							{
								t: 157.857421875,
								s: [
									0
								]
							}
						],
						ix: 10
					},
					p: {
						a: 0,
						k: [
							10.108,
							-105.967,
							0
						],
						ix: 2
					},
					a: {
						a: 0,
						k: [
							10.108,
							-105.967,
							0
						],
						ix: 1
					},
					s: {
						a: 0,
						k: [
							100,
							100,
							100
						],
						ix: 6
					}
				},
				ao: 0,
				shapes: [
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												0
											],
											[
												-30.106,
												0.582
											],
											[
												0,
												0
											],
											[
												0.936,
												-0.312
											],
											[
												0,
												0
											]
										],
										o: [
											[
												0,
												0
											],
											[
												20.457,
												-0.395
											],
											[
												0,
												0
											],
											[
												-0.936,
												0.312
											],
											[
												0,
												0
											]
										],
										v: [
											[
												-14.532,
												-183.375
											],
											[
												22.247,
												-165.001
											],
											[
												47.593,
												-150.593
											],
											[
												43.096,
												-183.375
											],
											[
												11.967,
												-191.431
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										0.156862750649,
										0.156862750649,
										0.156862750649,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 1",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 1,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "gr",
						it: [
							{
								ty: "gr",
								it: [
									{
										ind: 0,
										ty: "sh",
										ix: 1,
										ks: {
											a: 0,
											k: {
												i: [
													[
														0,
														0
													],
													[
														0,
														0
													]
												],
												o: [
													[
														0,
														0
													],
													[
														0,
														0
													]
												],
												v: [
													[
														40.762,
														-139.745
													],
													[
														45.963,
														-139.83
													]
												],
												c: false
											},
											ix: 2
										},
										nm: "Path 1",
										mn: "ADBE Vector Shape - Group",
										hd: false
									},
									{
										ty: "st",
										c: {
											a: 0,
											k: [
												1,
												1,
												1,
												1
											],
											ix: 3
										},
										o: {
											a: 0,
											k: 100,
											ix: 4
										},
										w: {
											a: 0,
											k: 1.951,
											ix: 5
										},
										lc: 1,
										lj: 1,
										ml: 10,
										bm: 0,
										nm: "Stroke 1",
										mn: "ADBE Vector Graphic - Stroke",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 1",
								np: 2,
								cix: 2,
								bm: 0,
								ix: 1,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "gr",
								it: [
									{
										ind: 0,
										ty: "sh",
										ix: 1,
										ks: {
											a: 0,
											k: {
												i: [
													[
														0,
														0
													],
													[
														0,
														0
													]
												],
												o: [
													[
														0,
														0
													],
													[
														0,
														0
													]
												],
												v: [
													[
														-21.154,
														-139.745
													],
													[
														-25.813,
														-139.863
													]
												],
												c: false
											},
											ix: 2
										},
										nm: "Path 1",
										mn: "ADBE Vector Shape - Group",
										hd: false
									},
									{
										ty: "st",
										c: {
											a: 0,
											k: [
												1,
												1,
												1,
												1
											],
											ix: 3
										},
										o: {
											a: 0,
											k: 100,
											ix: 4
										},
										w: {
											a: 0,
											k: 1.951,
											ix: 5
										},
										lc: 1,
										lj: 1,
										ml: 10,
										bm: 0,
										nm: "Stroke 1",
										mn: "ADBE Vector Graphic - Stroke",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 2",
								np: 2,
								cix: 2,
								bm: 0,
								ix: 2,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "gr",
								it: [
									{
										ind: 0,
										ty: "sh",
										ix: 1,
										ks: {
											a: 0,
											k: {
												i: [
													[
														0,
														0
													],
													[
														-3.053,
														-3.071
													]
												],
												o: [
													[
														0,
														0
													],
													[
														0,
														0
													]
												],
												v: [
													[
														6.632,
														-139.745
													],
													[
														12.976,
														-139.745
													]
												],
												c: false
											},
											ix: 2
										},
										nm: "Path 1",
										mn: "ADBE Vector Shape - Group",
										hd: false
									},
									{
										ty: "st",
										c: {
											a: 0,
											k: [
												1,
												1,
												1,
												1
											],
											ix: 3
										},
										o: {
											a: 0,
											k: 100,
											ix: 4
										},
										w: {
											a: 0,
											k: 1.951,
											ix: 5
										},
										lc: 1,
										lj: 1,
										ml: 10,
										bm: 0,
										nm: "Stroke 1",
										mn: "ADBE Vector Graphic - Stroke",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 3",
								np: 2,
								cix: 2,
								bm: 0,
								ix: 3,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "gr",
								it: [
									{
										ind: 0,
										ty: "sh",
										ix: 1,
										ks: {
											a: 0,
											k: {
												i: [
													[
														0,
														-7.673
													],
													[
														7.673,
														0
													],
													[
														0,
														7.673
													],
													[
														-7.673,
														0
													]
												],
												o: [
													[
														0,
														7.673
													],
													[
														-7.673,
														0
													],
													[
														0,
														-7.673
													],
													[
														7.673,
														0
													]
												],
												v: [
													[
														40.762,
														-139.745
													],
													[
														26.869,
														-125.852
													],
													[
														12.976,
														-139.745
													],
													[
														26.869,
														-153.638
													]
												],
												c: true
											},
											ix: 2
										},
										nm: "Path 1",
										mn: "ADBE Vector Shape - Group",
										hd: false
									},
									{
										ty: "st",
										c: {
											a: 0,
											k: [
												1,
												1,
												1,
												1
											],
											ix: 3
										},
										o: {
											a: 0,
											k: 100,
											ix: 4
										},
										w: {
											a: 0,
											k: 1.951,
											ix: 5
										},
										lc: 1,
										lj: 1,
										ml: 10,
										bm: 0,
										nm: "Stroke 1",
										mn: "ADBE Vector Graphic - Stroke",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 4",
								np: 2,
								cix: 2,
								bm: 0,
								ix: 4,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "gr",
								it: [
									{
										ind: 0,
										ty: "sh",
										ix: 1,
										ks: {
											a: 0,
											k: {
												i: [
													[
														0,
														-7.673
													],
													[
														7.673,
														0
													],
													[
														0,
														7.673
													],
													[
														-7.673,
														0
													]
												],
												o: [
													[
														0,
														7.673
													],
													[
														-7.673,
														0
													],
													[
														0,
														-7.673
													],
													[
														7.673,
														0
													]
												],
												v: [
													[
														6.632,
														-139.745
													],
													[
														-7.261,
														-125.852
													],
													[
														-21.154,
														-139.745
													],
													[
														-7.261,
														-153.638
													]
												],
												c: true
											},
											ix: 2
										},
										nm: "Path 1",
										mn: "ADBE Vector Shape - Group",
										hd: false
									},
									{
										ty: "st",
										c: {
											a: 0,
											k: [
												1,
												1,
												1,
												1
											],
											ix: 3
										},
										o: {
											a: 0,
											k: 100,
											ix: 4
										},
										w: {
											a: 0,
											k: 1.951,
											ix: 5
										},
										lc: 1,
										lj: 1,
										ml: 10,
										bm: 0,
										nm: "Stroke 1",
										mn: "ADBE Vector Graphic - Stroke",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 5",
								np: 2,
								cix: 2,
								bm: 0,
								ix: 5,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 2",
						np: 5,
						cix: 2,
						bm: 0,
						ix: 2,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												0
											],
											[
												-8.528,
												0
											],
											[
												0,
												0
											]
										],
										o: [
											[
												0,
												0
											],
											[
												7.756,
												0
											],
											[
												0,
												0
											]
										],
										v: [
											[
												-2.128,
												-119.801
											],
											[
												9.643,
												-117.315
											],
											[
												22.242,
												-119.801
											]
										],
										c: false
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "st",
								c: {
									a: 0,
									k: [
										0.156862750649,
										0.156862750649,
										0.156862750649,
										1
									],
									ix: 3
								},
								o: {
									a: 0,
									k: 100,
									ix: 4
								},
								w: {
									a: 0,
									k: 1.397,
									ix: 5
								},
								lc: 2,
								lj: 2,
								bm: 0,
								nm: "Stroke 1",
								mn: "ADBE Vector Graphic - Stroke",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 3",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 3,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												-0.127,
												-0.317
											],
											[
												-1.297,
												0.345
											],
											[
												0,
												0
											]
										],
										o: [
											[
												0,
												0
											],
											[
												0,
												0.361
											],
											[
												0.498,
												1.246
											],
											[
												0,
												0
											],
											[
												0,
												0
											]
										],
										v: [
											[
												7.495,
												-136.684
											],
											[
												7.495,
												-128.274
											],
											[
												7.691,
												-127.249
											],
											[
												10.92,
												-125.752
											],
											[
												13.707,
												-126.493
											]
										],
										c: false
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "st",
								c: {
									a: 0,
									k: [
										0.156862750649,
										0.156862750649,
										0.156862750649,
										1
									],
									ix: 3
								},
								o: {
									a: 0,
									k: 100,
									ix: 4
								},
								w: {
									a: 0,
									k: 1.397,
									ix: 5
								},
								lc: 2,
								lj: 2,
								bm: 0,
								nm: "Stroke 1",
								mn: "ADBE Vector Graphic - Stroke",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 4",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 4,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												0
											],
											[
												6.254,
												-12.632
											],
											[
												12.732,
												-0.38
											],
											[
												7.601,
												15.392
											],
											[
												0,
												0
											],
											[
												-35.915,
												0
											]
										],
										o: [
											[
												0.003,
												10.172
											],
											[
												-5.872,
												11.86
											],
											[
												-12.732,
												0.38
											],
											[
												-7.601,
												-15.392
											],
											[
												0,
												0
											],
											[
												37.828,
												0
											]
										],
										v: [
											[
												46.366,
												-151.771
											],
											[
												39.117,
												-107.685
											],
											[
												10.803,
												-89.062
											],
											[
												-19.015,
												-108.981
											],
											[
												-26.253,
												-151.582
											],
											[
												9.662,
												-187.921
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										1,
										0.694117665291,
										0.647058844566,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 5",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 5,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "gr",
						it: [
							{
								ty: "gr",
								it: [
									{
										ty: "gr",
										it: [
											{
												ty: "gr",
												it: [
													{
														ind: 0,
														ty: "sh",
														ix: 1,
														ks: {
															a: 0,
															k: {
																i: [
																	[
																		0,
																		0
																	],
																	[
																		-4.131,
																		-8.571
																	]
																],
																o: [
																	[
																		0,
																		0
																	],
																	[
																		0,
																		0
																	]
																],
																v: [
																	[
																		-34.393,
																		-132.528
																	],
																	[
																		-24.442,
																		-125.899
																	]
																],
																c: false
															},
															ix: 2
														},
														nm: "Path 1",
														mn: "ADBE Vector Shape - Group",
														hd: false
													},
													{
														ty: "st",
														c: {
															a: 0,
															k: [
																0.156862750649,
																0.156862750649,
																0.156862750649,
																1
															],
															ix: 3
														},
														o: {
															a: 0,
															k: 100,
															ix: 4
														},
														w: {
															a: 0,
															k: 1.397,
															ix: 5
														},
														lc: 2,
														lj: 2,
														bm: 0,
														nm: "Stroke 1",
														mn: "ADBE Vector Graphic - Stroke",
														hd: false
													},
													{
														ty: "tr",
														p: {
															a: 0,
															k: [
																0,
																0
															],
															ix: 2
														},
														a: {
															a: 0,
															k: [
																0,
																0
															],
															ix: 1
														},
														s: {
															a: 0,
															k: [
																100,
																100
															],
															ix: 3
														},
														r: {
															a: 0,
															k: 0,
															ix: 6
														},
														o: {
															a: 0,
															k: 100,
															ix: 7
														},
														sk: {
															a: 0,
															k: 0,
															ix: 4
														},
														sa: {
															a: 0,
															k: 0,
															ix: 5
														},
														nm: "Transform"
													}
												],
												nm: "Group 1",
												np: 2,
												cix: 2,
												bm: 0,
												ix: 1,
												mn: "ADBE Vector Group",
												hd: false
											},
											{
												ty: "tr",
												p: {
													a: 0,
													k: [
														0,
														0
													],
													ix: 2
												},
												a: {
													a: 0,
													k: [
														0,
														0
													],
													ix: 1
												},
												s: {
													a: 0,
													k: [
														100,
														100
													],
													ix: 3
												},
												r: {
													a: 0,
													k: 0,
													ix: 6
												},
												o: {
													a: 0,
													k: 100,
													ix: 7
												},
												sk: {
													a: 0,
													k: 0,
													ix: 4
												},
												sa: {
													a: 0,
													k: 0,
													ix: 5
												},
												nm: "Transform"
											}
										],
										nm: "Group 1",
										np: 1,
										cix: 2,
										bm: 0,
										ix: 1,
										mn: "ADBE Vector Group",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 1",
								np: 1,
								cix: 2,
								bm: 0,
								ix: 1,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "gr",
								it: [
									{
										ind: 0,
										ty: "sh",
										ix: 1,
										ks: {
											a: 0,
											k: {
												i: [
													[
														0.403,
														4.73
													],
													[
														6.948,
														-2.635
													],
													[
														-10.422,
														-2.151
													],
													[
														-2.929,
														2.558
													]
												],
												o: [
													[
														0,
														0
													],
													[
														-6.948,
														2.635
													],
													[
														0,
														0
													],
													[
														0,
														0
													]
												],
												v: [
													[
														-25.454,
														-135.758
													],
													[
														-35.771,
														-138.481
													],
													[
														-29.154,
														-116.821
													],
													[
														-22.488,
														-118.564
													]
												],
												c: true
											},
											ix: 2
										},
										nm: "Path 1",
										mn: "ADBE Vector Shape - Group",
										hd: false
									},
									{
										ty: "fl",
										c: {
											a: 0,
											k: [
												1,
												0.6941176470588235,
												0.6470588235294118,
												1
											],
											ix: 4
										},
										o: {
											a: 0,
											k: 100,
											ix: 5
										},
										r: 1,
										bm: 0,
										nm: "Fill 1",
										mn: "ADBE Vector Graphic - Fill",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 2",
								np: 2,
								cix: 2,
								bm: 0,
								ix: 2,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 6",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 6,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "gr",
						it: [
							{
								ty: "gr",
								it: [
									{
										ty: "gr",
										it: [
											{
												ty: "gr",
												it: [
													{
														ind: 0,
														ty: "sh",
														ix: 1,
														ks: {
															a: 0,
															k: {
																i: [
																	[
																		0,
																		0
																	],
																	[
																		4.131,
																		-8.571
																	]
																],
																o: [
																	[
																		0,
																		0
																	],
																	[
																		0,
																		0
																	]
																],
																v: [
																	[
																		54.609,
																		-132.528
																	],
																	[
																		44.658,
																		-125.899
																	]
																],
																c: false
															},
															ix: 2
														},
														nm: "Path 1",
														mn: "ADBE Vector Shape - Group",
														hd: false
													},
													{
														ty: "st",
														c: {
															a: 0,
															k: [
																0.156862750649,
																0.156862750649,
																0.156862750649,
																1
															],
															ix: 3
														},
														o: {
															a: 0,
															k: 100,
															ix: 4
														},
														w: {
															a: 0,
															k: 1.397,
															ix: 5
														},
														lc: 2,
														lj: 2,
														bm: 0,
														nm: "Stroke 1",
														mn: "ADBE Vector Graphic - Stroke",
														hd: false
													},
													{
														ty: "tr",
														p: {
															a: 0,
															k: [
																0,
																0
															],
															ix: 2
														},
														a: {
															a: 0,
															k: [
																0,
																0
															],
															ix: 1
														},
														s: {
															a: 0,
															k: [
																100,
																100
															],
															ix: 3
														},
														r: {
															a: 0,
															k: 0,
															ix: 6
														},
														o: {
															a: 0,
															k: 100,
															ix: 7
														},
														sk: {
															a: 0,
															k: 0,
															ix: 4
														},
														sa: {
															a: 0,
															k: 0,
															ix: 5
														},
														nm: "Transform"
													}
												],
												nm: "Group 1",
												np: 2,
												cix: 2,
												bm: 0,
												ix: 1,
												mn: "ADBE Vector Group",
												hd: false
											},
											{
												ty: "tr",
												p: {
													a: 0,
													k: [
														0,
														0
													],
													ix: 2
												},
												a: {
													a: 0,
													k: [
														0,
														0
													],
													ix: 1
												},
												s: {
													a: 0,
													k: [
														100,
														100
													],
													ix: 3
												},
												r: {
													a: 0,
													k: 0,
													ix: 6
												},
												o: {
													a: 0,
													k: 100,
													ix: 7
												},
												sk: {
													a: 0,
													k: 0,
													ix: 4
												},
												sa: {
													a: 0,
													k: 0,
													ix: 5
												},
												nm: "Transform"
											}
										],
										nm: "Group 1",
										np: 1,
										cix: 2,
										bm: 0,
										ix: 1,
										mn: "ADBE Vector Group",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 1",
								np: 1,
								cix: 2,
								bm: 0,
								ix: 1,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "gr",
								it: [
									{
										ind: 0,
										ty: "sh",
										ix: 1,
										ks: {
											a: 0,
											k: {
												i: [
													[
														-0.403,
														4.73
													],
													[
														-6.948,
														-2.635
													],
													[
														10.422,
														-2.151
													],
													[
														2.929,
														2.558
													]
												],
												o: [
													[
														0,
														0
													],
													[
														6.948,
														2.635
													],
													[
														0,
														0
													],
													[
														0,
														0
													]
												],
												v: [
													[
														45.67,
														-135.758
													],
													[
														55.987,
														-138.481
													],
													[
														49.37,
														-116.821
													],
													[
														42.704,
														-118.564
													]
												],
												c: true
											},
											ix: 2
										},
										nm: "Path 1",
										mn: "ADBE Vector Shape - Group",
										hd: false
									},
									{
										ty: "fl",
										c: {
											a: 0,
											k: [
												1,
												0.6941176470588235,
												0.6470588235294118,
												1
											],
											ix: 4
										},
										o: {
											a: 0,
											k: 100,
											ix: 5
										},
										r: 1,
										bm: 0,
										nm: "Fill 1",
										mn: "ADBE Vector Graphic - Fill",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 2",
								np: 2,
								cix: 2,
								bm: 0,
								ix: 2,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 7",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 7,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												0
											],
											[
												-28.278,
												-12.861
											],
											[
												-2.04,
												-7.395
											],
											[
												0.185,
												-2.298
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											]
										],
										o: [
											[
												0,
												0
											],
											[
												17.116,
												7.784
											],
											[
												0.678,
												2.457
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											]
										],
										v: [
											[
												-9.651,
												-190.793
											],
											[
												27.798,
												-202.124
											],
											[
												51.747,
												-176.509
											],
											[
												52.511,
												-167.883
											],
											[
												45.67,
												-135.758
											],
											[
												18.966,
												-180.205
											],
											[
												-6.876,
												-178.155
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										0.156862750649,
										0.156862750649,
										0.156862750649,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 8",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 8,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												-28.351,
												4.784
											],
											[
												13.015,
												-6.686
											]
										],
										o: [
											[
												-0.234,
												4.194
											],
											[
												0,
												0
											]
										],
										v: [
											[
												-10.596,
												-184.204
											],
											[
												-27.547,
												-154.973
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										0.156862750649,
										0.156862750649,
										0.156862750649,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 9",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 9,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												-1.235,
												3.77
											],
											[
												-12.838,
												-5.485
											],
											[
												0,
												0
											],
											[
												5.348,
												-17.441
											]
										],
										o: [
											[
												0,
												0
											],
											[
												-0.363,
												-2.6
											],
											[
												2.044,
												-6.238
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											]
										],
										v: [
											[
												-25.454,
												-135.758
											],
											[
												-31.907,
												-167.679
											],
											[
												-32.043,
												-178.061
											],
											[
												-9.651,
												-190.793
											],
											[
												-6.876,
												-178.155
											],
											[
												-25.555,
												-158.024
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										0.156862750649,
										0.156862750649,
										0.156862750649,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 10",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 10,
						mn: "ADBE Vector Group",
						hd: false
					}
				],
				ip: 0,
				op: 180,
				st: 0,
				bm: 0
			},
			{
				ddd: 0,
				ind: 6,
				ty: 4,
				nm: "body",
				sr: 1,
				ks: {
					o: {
						a: 0,
						k: 100,
						ix: 11
					},
					r: {
						a: 1,
						k: [
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 0,
								s: [
									0
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 24.286,
								s: [
									2
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 42.5,
								s: [
									-2
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 60.714,
								s: [
									2
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 78.929,
								s: [
									-2
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 97.143,
								s: [
									2
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 115.357,
								s: [
									-2
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 133.571,
								s: [
									2
								]
							},
							{
								t: 157.857421875,
								s: [
									0
								]
							}
						],
						ix: 10
					},
					p: {
						a: 0,
						k: [
							551.606,
							754.197,
							0
						],
						ix: 2
					},
					a: {
						a: 0,
						k: [
							11.606,
							214.197,
							0
						],
						ix: 1
					},
					s: {
						a: 0,
						k: [
							100,
							100,
							100
						],
						ix: 6
					}
				},
				ao: 0,
				shapes: [
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												0
											],
											[
												-18.478,
												-2.439
											],
											[
												0,
												0
											],
											[
												14.861,
												-0.018
											]
										],
										o: [
											[
												0,
												0
											],
											[
												21.266,
												2.807
											],
											[
												0,
												0
											],
											[
												-16.575,
												0.02
											]
										],
										v: [
											[
												-14.532,
												-101.395
											],
											[
												8.131,
												-77.723
											],
											[
												35.061,
												-100.855
											],
											[
												10.803,
												-89.062
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										0.156862750649,
										0.156862750649,
										0.156862750649,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 1",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 1,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												-36.894,
												-0.498
											],
											[
												0,
												0
											]
										],
										o: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												36.894,
												0.498
											],
											[
												0,
												0
											]
										],
										v: [
											[
												35.061,
												-63.614
											],
											[
												35.061,
												-63.614
											],
											[
												35.061,
												-117.817
											],
											[
												-14.907,
												-117.817
											],
											[
												-14.907,
												-63.614
											],
											[
												-29.781,
												-56.833
											],
											[
												10.601,
												-33.87
											],
											[
												51.201,
												-55.728
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										1,
										0.694117665291,
										0.647058844566,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 2",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 2,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "gr",
						it: [
							{
								ty: "gr",
								it: [
									{
										ind: 0,
										ty: "sh",
										ix: 1,
										ks: {
											a: 0,
											k: {
												i: [
													[
														0,
														0
													],
													[
														0,
														0
													]
												],
												o: [
													[
														0,
														0
													],
													[
														0,
														0
													]
												],
												v: [
													[
														-64.893,
														66.379
													],
													[
														-68.238,
														5.805
													]
												],
												c: false
											},
											ix: 2
										},
										nm: "Path 1",
										mn: "ADBE Vector Shape - Group",
										hd: false
									},
									{
										ty: "st",
										c: {
											a: 0,
											k: [
												0.156862750649,
												0.156862750649,
												0.156862750649,
												1
											],
											ix: 3
										},
										o: {
											a: 0,
											k: 100,
											ix: 4
										},
										w: {
											a: 0,
											k: 1.397,
											ix: 5
										},
										lc: 2,
										lj: 2,
										bm: 0,
										nm: "Stroke 1",
										mn: "ADBE Vector Graphic - Stroke",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 1",
								np: 2,
								cix: 2,
								bm: 0,
								ix: 1,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "gr",
								it: [
									{
										ind: 0,
										ty: "sh",
										ix: 1,
										ks: {
											a: 0,
											k: {
												i: [
													[
														0,
														0
													],
													[
														0,
														0
													]
												],
												o: [
													[
														0,
														0
													],
													[
														0,
														0
													]
												],
												v: [
													[
														92.107,
														78.025
													],
													[
														94.115,
														8.146
													]
												],
												c: false
											},
											ix: 2
										},
										nm: "Path 1",
										mn: "ADBE Vector Shape - Group",
										hd: false
									},
									{
										ty: "st",
										c: {
											a: 0,
											k: [
												0.156862750649,
												0.156862750649,
												0.156862750649,
												1
											],
											ix: 3
										},
										o: {
											a: 0,
											k: 100,
											ix: 4
										},
										w: {
											a: 0,
											k: 1.397,
											ix: 5
										},
										lc: 2,
										lj: 2,
										bm: 0,
										nm: "Stroke 1",
										mn: "ADBE Vector Graphic - Stroke",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 2",
								np: 2,
								cix: 2,
								bm: 0,
								ix: 2,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "gr",
								it: [
									{
										ind: 0,
										ty: "sh",
										ix: 1,
										ks: {
											a: 0,
											k: {
												i: [
													[
														9.243,
														0
													],
													[
														0,
														0
													],
													[
														0,
														9.243
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													]
												],
												o: [
													[
														0,
														0
													],
													[
														-9.243,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														9.243
													]
												],
												v: [
													[
														50.767,
														46.352
													],
													[
														41.182,
														46.352
													],
													[
														24.445,
														29.616
													],
													[
														24.445,
														3.294
													],
													[
														67.504,
														3.294
													],
													[
														67.504,
														29.616
													]
												],
												c: true
											},
											ix: 2
										},
										nm: "Path 1",
										mn: "ADBE Vector Shape - Group",
										hd: false
									},
									{
										ty: "st",
										c: {
											a: 0,
											k: [
												0.156862750649,
												0.156862750649,
												0.156862750649,
												1
											],
											ix: 3
										},
										o: {
											a: 0,
											k: 100,
											ix: 4
										},
										w: {
											a: 0,
											k: 1.397,
											ix: 5
										},
										lc: 2,
										lj: 2,
										bm: 0,
										nm: "Stroke 1",
										mn: "ADBE Vector Graphic - Stroke",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 3",
								np: 2,
								cix: 2,
								bm: 0,
								ix: 3,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "gr",
								it: [
									{
										ind: 0,
										ty: "sh",
										ix: 1,
										ks: {
											a: 0,
											k: {
												i: [
													[
														17.461,
														-8.956
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														21.145,
														9.308
													]
												],
												o: [
													[
														-24.562,
														12.599
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														-17.961,
														-7.906
													]
												],
												v: [
													[
														-27.268,
														-57.736
													],
													[
														-67.271,
														-28.429
													],
													[
														-62.425,
														185.185
													],
													[
														92.36,
														185.185
													],
													[
														91.858,
														-27.327
													],
													[
														51.201,
														-55.728
													]
												],
												c: true
											},
											ix: 2
										},
										nm: "Path 1",
										mn: "ADBE Vector Shape - Group",
										hd: false
									},
									{
										ty: "fl",
										c: {
											a: 0,
											k: [
												0.8941176470588236,
												0.4666666666666667,
												0.3764705882352941,
												1
											],
											ix: 4
										},
										o: {
											a: 0,
											k: 100,
											ix: 5
										},
										r: 1,
										bm: 0,
										nm: "Fill 1",
										mn: "ADBE Vector Graphic - Fill",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 4",
								np: 2,
								cix: 2,
								bm: 0,
								ix: 4,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 3",
						np: 4,
						cix: 2,
						bm: 0,
						ix: 3,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "gr",
						it: [
							{
								ty: "gr",
								it: [
									{
										ind: 0,
										ty: "sh",
										ix: 1,
										ks: {
											a: 0,
											k: {
												i: [
													[
														0,
														0
													],
													[
														-14.675,
														-102.799
													],
													[
														39.723,
														7.392
													],
													[
														0,
														0
													]
												],
												o: [
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													]
												],
												v: [
													[
														51.201,
														-55.728
													],
													[
														146.865,
														67.439
													],
													[
														67.504,
														77.232
													],
													[
														76.44,
														42.849
													]
												],
												c: true
											},
											ix: 2
										},
										nm: "Path 1",
										mn: "ADBE Vector Shape - Group",
										hd: false
									},
									{
										ty: "fl",
										c: {
											a: 0,
											k: [
												0.8941176470588236,
												0.4666666666666667,
												0.3764705882352941,
												1
											],
											ix: 4
										},
										o: {
											a: 0,
											k: 100,
											ix: 5
										},
										r: 1,
										bm: 0,
										nm: "Fill 1",
										mn: "ADBE Vector Graphic - Fill",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 1",
								np: 2,
								cix: 2,
								bm: 0,
								ix: 1,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "gr",
								it: [
									{
										ty: "gr",
										it: [
											{
												ind: 0,
												ty: "sh",
												ix: 1,
												ks: {
													a: 0,
													k: {
														i: [
															[
																0,
																0
															],
															[
																-17.432,
																11.499
															],
															[
																0,
																0
															],
															[
																0,
																0
															]
														],
														o: [
															[
																0,
																0
															],
															[
																0,
																0
															],
															[
																0,
																0
															],
															[
																0,
																0
															]
														],
														v: [
															[
																92.107,
																89.94
															],
															[
																135.037,
																76.107
															],
															[
																134.578,
																65.987
															],
															[
																92.092,
																71.773
															]
														],
														c: true
													},
													ix: 2
												},
												nm: "Path 1",
												mn: "ADBE Vector Shape - Group",
												hd: false
											},
											{
												ty: "fl",
												c: {
													a: 0,
													k: [
														0.952941179276,
														0.592156887054,
														0.556862771511,
														1
													],
													ix: 4
												},
												o: {
													a: 0,
													k: 100,
													ix: 5
												},
												r: 1,
												bm: 0,
												nm: "Fill 1",
												mn: "ADBE Vector Graphic - Fill",
												hd: false
											},
											{
												ty: "tr",
												p: {
													a: 0,
													k: [
														0,
														0
													],
													ix: 2
												},
												a: {
													a: 0,
													k: [
														0,
														0
													],
													ix: 1
												},
												s: {
													a: 0,
													k: [
														100,
														100
													],
													ix: 3
												},
												r: {
													a: 0,
													k: 0,
													ix: 6
												},
												o: {
													a: 0,
													k: 100,
													ix: 7
												},
												sk: {
													a: 0,
													k: 0,
													ix: 4
												},
												sa: {
													a: 0,
													k: 0,
													ix: 5
												},
												nm: "Transform"
											}
										],
										nm: "Group 1",
										np: 2,
										cix: 2,
										bm: 0,
										ix: 1,
										mn: "ADBE Vector Group",
										hd: false
									},
									{
										ty: "gr",
										it: [
											{
												ind: 0,
												ty: "sh",
												ix: 1,
												ks: {
													a: 0,
													k: {
														i: [
															[
																0,
																0
															],
															[
																-1.248,
																-86.949
															],
															[
																0,
																0
															],
															[
																0,
																0
															]
														],
														o: [
															[
																4.277,
																47.253
															],
															[
																0,
																0
															],
															[
																0,
																0
															],
															[
																0,
																0
															]
														],
														v: [
															[
																133.325,
																53.066
															],
															[
																134.338,
																221.698
															],
															[
																93.163,
																223.423
															],
															[
																87.028,
																60.669
															]
														],
														c: true
													},
													ix: 2
												},
												nm: "Path 1",
												mn: "ADBE Vector Shape - Group",
												hd: false
											},
											{
												ty: "fl",
												c: {
													a: 0,
													k: [
														1,
														0.694117665291,
														0.647058844566,
														1
													],
													ix: 4
												},
												o: {
													a: 0,
													k: 100,
													ix: 5
												},
												r: 1,
												bm: 0,
												nm: "Fill 1",
												mn: "ADBE Vector Graphic - Fill",
												hd: false
											},
											{
												ty: "tr",
												p: {
													a: 0,
													k: [
														0,
														0
													],
													ix: 2
												},
												a: {
													a: 0,
													k: [
														0,
														0
													],
													ix: 1
												},
												s: {
													a: 0,
													k: [
														100,
														100
													],
													ix: 3
												},
												r: {
													a: 0,
													k: 0,
													ix: 6
												},
												o: {
													a: 0,
													k: 100,
													ix: 7
												},
												sk: {
													a: 0,
													k: 0,
													ix: 4
												},
												sa: {
													a: 0,
													k: 0,
													ix: 5
												},
												nm: "Transform"
											}
										],
										nm: "Group 2",
										np: 2,
										cix: 2,
										bm: 0,
										ix: 2,
										mn: "ADBE Vector Group",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 2",
								np: 2,
								cix: 2,
								bm: 0,
								ix: 2,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 5",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 4,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "gr",
						it: [
							{
								ty: "gr",
								it: [
									{
										ind: 0,
										ty: "sh",
										ix: 1,
										ks: {
											a: 0,
											k: {
												i: [
													[
														0,
														0
													],
													[
														0,
														0
													]
												],
												o: [
													[
														0,
														0
													],
													[
														0,
														0
													]
												],
												v: [
													[
														-9.299,
														223.208
													],
													[
														39.899,
														223.208
													]
												],
												c: false
											},
											ix: 2
										},
										nm: "Path 1",
										mn: "ADBE Vector Shape - Group",
										hd: false
									},
									{
										ty: "st",
										c: {
											a: 0,
											k: [
												0.156862750649,
												0.156862750649,
												0.156862750649,
												1
											],
											ix: 3
										},
										o: {
											a: 0,
											k: 100,
											ix: 4
										},
										w: {
											a: 0,
											k: 1.397,
											ix: 5
										},
										lc: 2,
										lj: 2,
										bm: 0,
										nm: "Stroke 1",
										mn: "ADBE Vector Graphic - Stroke",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 1",
								np: 2,
								cix: 2,
								bm: 0,
								ix: 1,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "gr",
								it: [
									{
										ty: "gr",
										it: [
											{
												ind: 0,
												ty: "sh",
												ix: 1,
												ks: {
													a: 0,
													k: {
														i: [
															[
																0,
																0
															],
															[
																0,
																0
															],
															[
																0,
																0
															],
															[
																0,
																0
															]
														],
														o: [
															[
																0,
																0
															],
															[
																0,
																0
															],
															[
																0,
																0
															],
															[
																0,
																0
															]
														],
														v: [
															[
																52.066,
																223.208
															],
															[
																-19.262,
																223.208
															],
															[
																-19.262,
																174.762
															],
															[
																52.066,
																174.762
															]
														],
														c: true
													},
													ix: 2
												},
												nm: "Path 1",
												mn: "ADBE Vector Shape - Group",
												hd: false
											},
											{
												ty: "fl",
												c: {
													a: 0,
													k: [
														0,
														0.337254911661,
														0.51372551918,
														1
													],
													ix: 4
												},
												o: {
													a: 0,
													k: 100,
													ix: 5
												},
												r: 1,
												bm: 0,
												nm: "Fill 1",
												mn: "ADBE Vector Graphic - Fill",
												hd: false
											},
											{
												ty: "tr",
												p: {
													a: 0,
													k: [
														0,
														0
													],
													ix: 2
												},
												a: {
													a: 0,
													k: [
														0,
														0
													],
													ix: 1
												},
												s: {
													a: 0,
													k: [
														100,
														100
													],
													ix: 3
												},
												r: {
													a: 0,
													k: 0,
													ix: 6
												},
												o: {
													a: 0,
													k: 100,
													ix: 7
												},
												sk: {
													a: 0,
													k: 0,
													ix: 4
												},
												sa: {
													a: 0,
													k: 0,
													ix: 5
												},
												nm: "Transform"
											}
										],
										nm: "Group 1",
										np: 2,
										cix: 2,
										bm: 0,
										ix: 1,
										mn: "ADBE Vector Group",
										hd: false
									},
									{
										ty: "gr",
										it: [
											{
												ind: 0,
												ty: "sh",
												ix: 1,
												ks: {
													a: 0,
													k: {
														i: [
															[
																0,
																0
															],
															[
																0,
																0
															],
															[
																0,
																0
															],
															[
																0,
																0
															]
														],
														o: [
															[
																0,
																0
															],
															[
																0,
																0
															],
															[
																0,
																0
															],
															[
																0,
																0
															]
														],
														v: [
															[
																89.744,
																174.762
															],
															[
																89.667,
																314.211
															],
															[
																20.681,
																314.211
															],
															[
																15.379,
																174.762
															]
														],
														c: true
													},
													ix: 2
												},
												nm: "Path 1",
												mn: "ADBE Vector Shape - Group",
												hd: false
											},
											{
												ty: "fl",
												c: {
													a: 0,
													k: [
														0,
														0.337254911661,
														0.51372551918,
														1
													],
													ix: 4
												},
												o: {
													a: 0,
													k: 100,
													ix: 5
												},
												r: 1,
												bm: 0,
												nm: "Fill 1",
												mn: "ADBE Vector Graphic - Fill",
												hd: false
											},
											{
												ty: "tr",
												p: {
													a: 0,
													k: [
														0,
														0
													],
													ix: 2
												},
												a: {
													a: 0,
													k: [
														0,
														0
													],
													ix: 1
												},
												s: {
													a: 0,
													k: [
														100,
														100
													],
													ix: 3
												},
												r: {
													a: 0,
													k: 0,
													ix: 6
												},
												o: {
													a: 0,
													k: 100,
													ix: 7
												},
												sk: {
													a: 0,
													k: 0,
													ix: 4
												},
												sa: {
													a: 0,
													k: 0,
													ix: 5
												},
												nm: "Transform"
											}
										],
										nm: "Group 2",
										np: 2,
										cix: 2,
										bm: 0,
										ix: 2,
										mn: "ADBE Vector Group",
										hd: false
									},
									{
										ty: "gr",
										it: [
											{
												ind: 0,
												ty: "sh",
												ix: 1,
												ks: {
													a: 0,
													k: {
														i: [
															[
																0,
																0
															],
															[
																0,
																0
															],
															[
																0,
																0
															],
															[
																0,
																0
															]
														],
														o: [
															[
																0,
																0
															],
															[
																0,
																0
															],
															[
																0,
																0
															],
															[
																0,
																0
															]
														],
														v: [
															[
																-60.043,
																174.762
															],
															[
																-59.967,
																314.211
															],
															[
																9.02,
																314.211
															],
															[
																14.321,
																174.762
															]
														],
														c: true
													},
													ix: 2
												},
												nm: "Path 1",
												mn: "ADBE Vector Shape - Group",
												hd: false
											},
											{
												ty: "fl",
												c: {
													a: 0,
													k: [
														0,
														0.337254911661,
														0.51372551918,
														1
													],
													ix: 4
												},
												o: {
													a: 0,
													k: 100,
													ix: 5
												},
												r: 1,
												bm: 0,
												nm: "Fill 1",
												mn: "ADBE Vector Graphic - Fill",
												hd: false
											},
											{
												ty: "tr",
												p: {
													a: 0,
													k: [
														0,
														0
													],
													ix: 2
												},
												a: {
													a: 0,
													k: [
														0,
														0
													],
													ix: 1
												},
												s: {
													a: 0,
													k: [
														100,
														100
													],
													ix: 3
												},
												r: {
													a: 0,
													k: 0,
													ix: 6
												},
												o: {
													a: 0,
													k: 100,
													ix: 7
												},
												sk: {
													a: 0,
													k: 0,
													ix: 4
												},
												sa: {
													a: 0,
													k: 0,
													ix: 5
												},
												nm: "Transform"
											}
										],
										nm: "Group 3",
										np: 2,
										cix: 2,
										bm: 0,
										ix: 3,
										mn: "ADBE Vector Group",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 2",
								np: 3,
								cix: 2,
								bm: 0,
								ix: 2,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 6",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 5,
						mn: "ADBE Vector Group",
						hd: false
					}
				],
				ip: 0,
				op: 180,
				st: 0,
				bm: 0
			},
			{
				ddd: 0,
				ind: 7,
				ty: 4,
				nm: "arm up",
				parent: 6,
				sr: 1,
				ks: {
					o: {
						a: 0,
						k: 100,
						ix: 11
					},
					r: {
						a: 1,
						k: [
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 0,
								s: [
									-14
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 24.286,
								s: [
									0
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 133.571,
								s: [
									0
								]
							},
							{
								t: 157.857421875,
								s: [
									-14
								]
							}
						],
						ix: 10
					},
					p: {
						a: 0,
						k: [
							-29.46,
							-40.854,
							0
						],
						ix: 2
					},
					a: {
						a: 0,
						k: [
							-29.46,
							-40.854,
							0
						],
						ix: 1
					},
					s: {
						a: 0,
						k: [
							100,
							100,
							100
						],
						ix: 6
					}
				},
				ao: 0,
				shapes: [
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												0
											],
											[
												33.507,
												-73.076
											],
											[
												-32.455,
												-13.558
											],
											[
												0,
												0
											],
											[
												-3.942,
												10.647
											]
										],
										o: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												20.581,
												-55.588
											]
										],
										v: [
											[
												-27.268,
												-57.51
											],
											[
												-123.653,
												29.739
											],
											[
												-70.952,
												73.802
											],
											[
												-49.223,
												47.182
											],
											[
												-22.081,
												10.088
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										0.8941176470588236,
										0.4666666666666667,
										0.3764705882352941,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 4",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 1,
						mn: "ADBE Vector Group",
						hd: false
					}
				],
				ip: 0,
				op: 180,
				st: 0,
				bm: 0
			},
			{
				ddd: 0,
				ind: 8,
				ty: 4,
				nm: "wrist",
				parent: 9,
				sr: 1,
				ks: {
					o: {
						a: 0,
						k: 100,
						ix: 11
					},
					r: {
						a: 1,
						k: [
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 24.286,
								s: [
									6
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 42.5,
								s: [
									-11
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 60.714,
								s: [
									6
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 78.929,
								s: [
									-11
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 97.143,
								s: [
									6
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 115.357,
								s: [
									-11
								]
							},
							{
								t: 133.5712890625,
								s: [
									6
								]
							}
						],
						ix: 10
					},
					p: {
						a: 0,
						k: [
							-200.762,
							-6.876,
							0
						],
						ix: 2
					},
					a: {
						a: 0,
						k: [
							-200.762,
							-6.876,
							0
						],
						ix: 1
					},
					s: {
						a: 0,
						k: [
							100,
							100,
							100
						],
						ix: 6
					}
				},
				ao: 0,
				shapes: [
					{
						ty: "gr",
						it: [
							{
								ty: "gr",
								it: [
									{
										ind: 0,
										ty: "sh",
										ix: 1,
										ks: {
											a: 0,
											k: {
												i: [
													[
														0,
														0
													],
													[
														1.418,
														-18.4
													]
												],
												o: [
													[
														0,
														0
													],
													[
														0,
														0
													]
												],
												v: [
													[
														-191.31,
														-37.823
													],
													[
														-206.535,
														-20.872
													]
												],
												c: false
											},
											ix: 2
										},
										nm: "Path 1",
										mn: "ADBE Vector Shape - Group",
										hd: false
									},
									{
										ty: "st",
										c: {
											a: 0,
											k: [
												0.156862750649,
												0.156862750649,
												0.156862750649,
												1
											],
											ix: 3
										},
										o: {
											a: 0,
											k: 100,
											ix: 4
										},
										w: {
											a: 0,
											k: 1.532,
											ix: 5
										},
										lc: 2,
										lj: 2,
										bm: 0,
										nm: "Stroke 1",
										mn: "ADBE Vector Graphic - Stroke",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 1",
								np: 2,
								cix: 2,
								bm: 0,
								ix: 1,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "gr",
								it: [
									{
										ty: "gr",
										it: [
											{
												ty: "gr",
												it: [
													{
														ind: 0,
														ty: "sh",
														ix: 1,
														ks: {
															a: 0,
															k: {
																i: [
																	[
																		0,
																		0
																	],
																	[
																		0,
																		0
																	],
																	[
																		-1.666,
																		0.761
																	],
																	[
																		0,
																		0
																	],
																	[
																		-1.032,
																		-1.492
																	],
																	[
																		0,
																		0
																	]
																],
																o: [
																	[
																		0,
																		0
																	],
																	[
																		-0.762,
																		-1.716
																	],
																	[
																		0,
																		0
																	],
																	[
																		1.594,
																		-0.728
																	],
																	[
																		0,
																		0
																	],
																	[
																		0,
																		0
																	]
																],
																v: [
																	[
																		-232.482,
																		-38.023
																	],
																	[
																		-241.676,
																		-52.606
																	],
																	[
																		-240.069,
																		-57.006
																	],
																	[
																		-240.069,
																		-57.006
																	],
																	[
																		-235.475,
																		-55.669
																	],
																	[
																		-223.385,
																		-38.897
																	]
																],
																c: true
															},
															ix: 2
														},
														nm: "Path 1",
														mn: "ADBE Vector Shape - Group",
														hd: false
													},
													{
														ty: "fl",
														c: {
															a: 0,
															k: [
																1,
																0.694117665291,
																0.647058844566,
																1
															],
															ix: 4
														},
														o: {
															a: 0,
															k: 100,
															ix: 5
														},
														r: 1,
														bm: 0,
														nm: "Fill 1",
														mn: "ADBE Vector Graphic - Fill",
														hd: false
													},
													{
														ty: "tr",
														p: {
															a: 0,
															k: [
																0,
																0
															],
															ix: 2
														},
														a: {
															a: 0,
															k: [
																0,
																0
															],
															ix: 1
														},
														s: {
															a: 0,
															k: [
																100,
																100
															],
															ix: 3
														},
														r: {
															a: 0,
															k: 0,
															ix: 6
														},
														o: {
															a: 0,
															k: 100,
															ix: 7
														},
														sk: {
															a: 0,
															k: 0,
															ix: 4
														},
														sa: {
															a: 0,
															k: 0,
															ix: 5
														},
														nm: "Transform"
													}
												],
												nm: "Group 1",
												np: 2,
												cix: 2,
												bm: 0,
												ix: 1,
												mn: "ADBE Vector Group",
												hd: false
											},
											{
												ty: "gr",
												it: [
													{
														ind: 0,
														ty: "sh",
														ix: 1,
														ks: {
															a: 0,
															k: {
																i: [
																	[
																		0,
																		0
																	],
																	[
																		0,
																		0
																	],
																	[
																		2.196,
																		-0.955
																	],
																	[
																		0,
																		0
																	],
																	[
																		-0.883,
																		-2.124
																	],
																	[
																		0,
																		0
																	]
																],
																o: [
																	[
																		0,
																		0
																	],
																	[
																		-1.075,
																		-2.209
																	],
																	[
																		0,
																		0
																	],
																	[
																		-2.063,
																		0.897
																	],
																	[
																		0,
																		0
																	],
																	[
																		0,
																		0
																	]
																],
																v: [
																	[
																		-212.969,
																		-40.645
																	],
																	[
																		-224.685,
																		-64.449
																	],
																	[
																		-230.632,
																		-66.729
																	],
																	[
																		-230.632,
																		-66.729
																	],
																	[
																		-232.725,
																		-61.37
																	],
																	[
																		-223.385,
																		-38.897
																	]
																],
																c: true
															},
															ix: 2
														},
														nm: "Path 1",
														mn: "ADBE Vector Shape - Group",
														hd: false
													},
													{
														ty: "fl",
														c: {
															a: 0,
															k: [
																1,
																0.694117665291,
																0.647058844566,
																1
															],
															ix: 4
														},
														o: {
															a: 0,
															k: 100,
															ix: 5
														},
														r: 1,
														bm: 0,
														nm: "Fill 1",
														mn: "ADBE Vector Graphic - Fill",
														hd: false
													},
													{
														ty: "tr",
														p: {
															a: 0,
															k: [
																0,
																0
															],
															ix: 2
														},
														a: {
															a: 0,
															k: [
																0,
																0
															],
															ix: 1
														},
														s: {
															a: 0,
															k: [
																100,
																100
															],
															ix: 3
														},
														r: {
															a: 0,
															k: 0,
															ix: 6
														},
														o: {
															a: 0,
															k: 100,
															ix: 7
														},
														sk: {
															a: 0,
															k: 0,
															ix: 4
														},
														sa: {
															a: 0,
															k: 0,
															ix: 5
														},
														nm: "Transform"
													}
												],
												nm: "Group 2",
												np: 2,
												cix: 2,
												bm: 0,
												ix: 2,
												mn: "ADBE Vector Group",
												hd: false
											},
											{
												ty: "gr",
												it: [
													{
														ind: 0,
														ty: "sh",
														ix: 1,
														ks: {
															a: 0,
															k: {
																i: [
																	[
																		0,
																		0
																	],
																	[
																		0,
																		0
																	],
																	[
																		2.108,
																		-0.706
																	],
																	[
																		0,
																		0
																	],
																	[
																		-0.433,
																		-1.892
																	],
																	[
																		0,
																		0
																	]
																],
																o: [
																	[
																		0,
																		0
																	],
																	[
																		-0.766,
																		-2.121
																	],
																	[
																		0,
																		0
																	],
																	[
																		-1.828,
																		0.612
																	],
																	[
																		0,
																		0
																	],
																	[
																		0,
																		0
																	]
																],
																v: [
																	[
																		-203.017,
																		-47.788
																	],
																	[
																		-212.277,
																		-72.014
																	],
																	[
																		-217.539,
																		-74.604
																	],
																	[
																		-217.539,
																		-74.604
																	],
																	[
																		-219.959,
																		-70.259
																	],
																	[
																		-213.088,
																		-42.265
																	]
																],
																c: true
															},
															ix: 2
														},
														nm: "Path 1",
														mn: "ADBE Vector Shape - Group",
														hd: false
													},
													{
														ty: "fl",
														c: {
															a: 0,
															k: [
																1,
																0.694117665291,
																0.647058844566,
																1
															],
															ix: 4
														},
														o: {
															a: 0,
															k: 100,
															ix: 5
														},
														r: 1,
														bm: 0,
														nm: "Fill 1",
														mn: "ADBE Vector Graphic - Fill",
														hd: false
													},
													{
														ty: "tr",
														p: {
															a: 0,
															k: [
																0,
																0
															],
															ix: 2
														},
														a: {
															a: 0,
															k: [
																0,
																0
															],
															ix: 1
														},
														s: {
															a: 0,
															k: [
																100,
																100
															],
															ix: 3
														},
														r: {
															a: 0,
															k: 0,
															ix: 6
														},
														o: {
															a: 0,
															k: 100,
															ix: 7
														},
														sk: {
															a: 0,
															k: 0,
															ix: 4
														},
														sa: {
															a: 0,
															k: 0,
															ix: 5
														},
														nm: "Transform"
													}
												],
												nm: "Group 3",
												np: 2,
												cix: 2,
												bm: 0,
												ix: 3,
												mn: "ADBE Vector Group",
												hd: false
											},
											{
												ty: "gr",
												it: [
													{
														ind: 0,
														ty: "sh",
														ix: 1,
														ks: {
															a: 0,
															k: {
																i: [
																	[
																		0,
																		0
																	],
																	[
																		0,
																		0
																	],
																	[
																		2.263,
																		-0.428
																	],
																	[
																		0,
																		0
																	],
																	[
																		-0.231,
																		-1.964
																	],
																	[
																		0,
																		0
																	]
																],
																o: [
																	[
																		0,
																		0
																	],
																	[
																		-0.405,
																		-2.257
																	],
																	[
																		0,
																		0
																	],
																	[
																		-1.958,
																		0.37
																	],
																	[
																		0,
																		0
																	],
																	[
																		0,
																		0
																	]
																],
																v: [
																	[
																		-189.457,
																		-35.274
																	],
																	[
																		-196.275,
																		-69.2
																	],
																	[
																		-201.212,
																		-72.585
																	],
																	[
																		-201.212,
																		-72.585
																	],
																	[
																		-204.231,
																		-68.506
																	],
																	[
																		-201.259,
																		-43.245
																	]
																],
																c: true
															},
															ix: 2
														},
														nm: "Path 1",
														mn: "ADBE Vector Shape - Group",
														hd: false
													},
													{
														ty: "fl",
														c: {
															a: 0,
															k: [
																1,
																0.694117665291,
																0.647058844566,
																1
															],
															ix: 4
														},
														o: {
															a: 0,
															k: 100,
															ix: 5
														},
														r: 1,
														bm: 0,
														nm: "Fill 1",
														mn: "ADBE Vector Graphic - Fill",
														hd: false
													},
													{
														ty: "tr",
														p: {
															a: 0,
															k: [
																0,
																0
															],
															ix: 2
														},
														a: {
															a: 0,
															k: [
																0,
																0
															],
															ix: 1
														},
														s: {
															a: 0,
															k: [
																100,
																100
															],
															ix: 3
														},
														r: {
															a: 0,
															k: 0,
															ix: 6
														},
														o: {
															a: 0,
															k: 100,
															ix: 7
														},
														sk: {
															a: 0,
															k: 0,
															ix: 4
														},
														sa: {
															a: 0,
															k: 0,
															ix: 5
														},
														nm: "Transform"
													}
												],
												nm: "Group 4",
												np: 2,
												cix: 2,
												bm: 0,
												ix: 4,
												mn: "ADBE Vector Group",
												hd: false
											},
											{
												ty: "gr",
												it: [
													{
														ind: 0,
														ty: "sh",
														ix: 1,
														ks: {
															a: 0,
															k: {
																i: [
																	[
																		0,
																		0
																	],
																	[
																		-2.82,
																		8.624
																	],
																	[
																		2.258,
																		0.432
																	],
																	[
																		0,
																		0
																	],
																	[
																		1.1,
																		-2.108
																	],
																	[
																		0,
																		0
																	]
																],
																o: [
																	[
																		-0.375,
																		-2.132
																	],
																	[
																		0.68,
																		-2.08
																	],
																	[
																		0,
																		0
																	],
																	[
																		-1.47,
																		-0.282
																	],
																	[
																		0,
																		0
																	],
																	[
																		0,
																		0
																	]
																],
																v: [
																	[
																		-188.731,
																		-10.413
																	],
																	[
																		-178.059,
																		-44.166
																	],
																	[
																		-181.07,
																		-48.959
																	],
																	[
																		-181.07,
																		-48.959
																	],
																	[
																		-185.969,
																		-46.952
																	],
																	[
																		-195.901,
																		-29.977
																	]
																],
																c: true
															},
															ix: 2
														},
														nm: "Path 1",
														mn: "ADBE Vector Shape - Group",
														hd: false
													},
													{
														ty: "fl",
														c: {
															a: 0,
															k: [
																1,
																0.694117665291,
																0.647058844566,
																1
															],
															ix: 4
														},
														o: {
															a: 0,
															k: 100,
															ix: 5
														},
														r: 1,
														bm: 0,
														nm: "Fill 1",
														mn: "ADBE Vector Graphic - Fill",
														hd: false
													},
													{
														ty: "tr",
														p: {
															a: 0,
															k: [
																0,
																0
															],
															ix: 2
														},
														a: {
															a: 0,
															k: [
																0,
																0
															],
															ix: 1
														},
														s: {
															a: 0,
															k: [
																100,
																100
															],
															ix: 3
														},
														r: {
															a: 0,
															k: 0,
															ix: 6
														},
														o: {
															a: 0,
															k: 100,
															ix: 7
														},
														sk: {
															a: 0,
															k: 0,
															ix: 4
														},
														sa: {
															a: 0,
															k: 0,
															ix: 5
														},
														nm: "Transform"
													}
												],
												nm: "Group 5",
												np: 2,
												cix: 2,
												bm: 0,
												ix: 5,
												mn: "ADBE Vector Group",
												hd: false
											},
											{
												ty: "gr",
												it: [
													{
														ind: 0,
														ty: "sh",
														ix: 1,
														ks: {
															a: 0,
															k: {
																i: [
																	[
																		0,
																		0
																	],
																	[
																		5.386,
																		4.328
																	],
																	[
																		0,
																		0
																	],
																	[
																		0.372,
																		-0.583
																	]
																],
																o: [
																	[
																		0,
																		0
																	],
																	[
																		-9.412,
																		-7.563
																	],
																	[
																		0,
																		0
																	],
																	[
																		-0.372,
																		0.583
																	]
																],
																v: [
																	[
																		-188.731,
																		-10.413
																	],
																	[
																		-215.292,
																		-2.777
																	],
																	[
																		-232.482,
																		-38.023
																	],
																	[
																		-193.257,
																		-52.368
																	]
																],
																c: true
															},
															ix: 2
														},
														nm: "Path 1",
														mn: "ADBE Vector Shape - Group",
														hd: false
													},
													{
														ty: "fl",
														c: {
															a: 0,
															k: [
																1,
																0.694117665291,
																0.647058844566,
																1
															],
															ix: 4
														},
														o: {
															a: 0,
															k: 100,
															ix: 5
														},
														r: 1,
														bm: 0,
														nm: "Fill 1",
														mn: "ADBE Vector Graphic - Fill",
														hd: false
													},
													{
														ty: "tr",
														p: {
															a: 0,
															k: [
																0,
																0
															],
															ix: 2
														},
														a: {
															a: 0,
															k: [
																0,
																0
															],
															ix: 1
														},
														s: {
															a: 0,
															k: [
																100,
																100
															],
															ix: 3
														},
														r: {
															a: 0,
															k: 0,
															ix: 6
														},
														o: {
															a: 0,
															k: 100,
															ix: 7
														},
														sk: {
															a: 0,
															k: 0,
															ix: 4
														},
														sa: {
															a: 0,
															k: 0,
															ix: 5
														},
														nm: "Transform"
													}
												],
												nm: "Group 6",
												np: 2,
												cix: 2,
												bm: 0,
												ix: 6,
												mn: "ADBE Vector Group",
												hd: false
											},
											{
												ty: "tr",
												p: {
													a: 0,
													k: [
														0,
														0
													],
													ix: 2
												},
												a: {
													a: 0,
													k: [
														0,
														0
													],
													ix: 1
												},
												s: {
													a: 0,
													k: [
														100,
														100
													],
													ix: 3
												},
												r: {
													a: 0,
													k: 0,
													ix: 6
												},
												o: {
													a: 0,
													k: 100,
													ix: 7
												},
												sk: {
													a: 0,
													k: 0,
													ix: 4
												},
												sa: {
													a: 0,
													k: 0,
													ix: 5
												},
												nm: "Transform"
											}
										],
										nm: "Group 1",
										np: 6,
										cix: 2,
										bm: 0,
										ix: 1,
										mn: "ADBE Vector Group",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 2",
								np: 1,
								cix: 2,
								bm: 0,
								ix: 2,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 1",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 1,
						mn: "ADBE Vector Group",
						hd: false
					}
				],
				ip: 0,
				op: 180,
				st: 0,
				bm: 0
			},
			{
				ddd: 0,
				ind: 9,
				ty: 4,
				nm: "r_hand",
				parent: 10,
				sr: 1,
				ks: {
					o: {
						a: 0,
						k: 100,
						ix: 11
					},
					r: {
						a: 1,
						k: [
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 0,
								s: [
									-67
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 24.286,
								s: [
									0
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 42.5,
								s: [
									-10
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 60.714,
								s: [
									0
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 78.929,
								s: [
									-10
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 97.143,
								s: [
									0
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 115.357,
								s: [
									-10
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 133.571,
								s: [
									0
								]
							},
							{
								t: 158,
								s: [
									-67
								]
							}
						],
						ix: 10
					},
					p: {
						a: 1,
						k: [
							{
								i: {
									x: 0.667,
									y: 1
								},
								o: {
									x: 0.333,
									y: 0
								},
								t: 0,
								s: [
									-133.07,
									95.387,
									0
								],
								to: [
									0,
									0,
									0
								],
								ti: [
									0,
									0,
									0
								]
							},
							{
								i: {
									x: 0.667,
									y: 1
								},
								o: {
									x: 0.333,
									y: 0
								},
								t: 24.286,
								s: [
									-134.159,
									88.827,
									0
								],
								to: [
									0,
									0,
									0
								],
								ti: [
									0,
									0,
									0
								]
							},
							{
								i: {
									x: 0.667,
									y: 1
								},
								o: {
									x: 0.333,
									y: 0
								},
								t: 133.571,
								s: [
									-134.159,
									88.827,
									0
								],
								to: [
									0,
									0,
									0
								],
								ti: [
									0,
									0,
									0
								]
							},
							{
								t: 157.857421875,
								s: [
									-133.07,
									95.387,
									0
								]
							}
						],
						ix: 2
					},
					a: {
						a: 0,
						k: [
							-135.697,
							89.194,
							0
						],
						ix: 1
					},
					s: {
						a: 0,
						k: [
							100,
							100,
							100
						],
						ix: 6
					}
				},
				ao: 0,
				shapes: [
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												15.669,
												-22.411
											],
											[
												0,
												0
											],
											[
												20.595,
												49.253
											]
										],
										o: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												-12.213,
												17.469
											],
											[
												0,
												0
											],
											[
												0,
												0
											]
										],
										v: [
											[
												-190.713,
												-12.984
											],
											[
												-130.411,
												58.232
											],
											[
												-126.382,
												93.792
											],
											[
												-150.865,
												110.988
											],
											[
												-215.292,
												-2.777
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										1,
										0.694117665291,
										0.647058844566,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 2",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 1,
						mn: "ADBE Vector Group",
						hd: false
					}
				],
				ip: 0,
				op: 180,
				st: 0,
				bm: 0
			},
			{
				ddd: 0,
				ind: 10,
				ty: 4,
				nm: "r_arm",
				parent: 7,
				sr: 1,
				ks: {
					o: {
						a: 0,
						k: 100,
						ix: 11
					},
					r: {
						a: 0,
						k: -5,
						ix: 10
					},
					p: {
						a: 0,
						k: [
							-79.71,
							17.208,
							0
						],
						ix: 2
					},
					a: {
						a: 0,
						k: [
							-79.71,
							17.208,
							0
						],
						ix: 1
					},
					s: {
						a: 0,
						k: [
							100,
							100,
							100
						],
						ix: 6
					}
				},
				ao: 0,
				shapes: [
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												0
											],
											[
												-18.27,
												-11.391
											],
											[
												0,
												0
											],
											[
												0,
												0
											]
										],
										o: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											]
										],
										v: [
											[
												-120.969,
												37.835
											],
											[
												-81.283,
												81.531
											],
											[
												-69.326,
												66.436
											],
											[
												-115.456,
												30.751
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										1,
										0.6941176470588235,
										0.6470588235294118,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 1",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 1,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												0
											],
											[
												-22.601,
												5.219
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											]
										],
										o: [
											[
												0,
												0
											],
											[
												22.601,
												-5.219
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											]
										],
										v: [
											[
												-161.094,
												85.893
											],
											[
												-127.151,
												119.925
											],
											[
												-69.326,
												66.436
											],
											[
												-77.209,
												-15.987
											],
											[
												-140.645,
												62.087
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										1,
										0.694117665291,
										0.647058844566,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 2",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 2,
						mn: "ADBE Vector Group",
						hd: false
					}
				],
				ip: 0,
				op: 180,
				st: 0,
				bm: 0
			}
		]
	},
	{
		id: "comp_1",
		layers: [
			{
				ddd: 0,
				ind: 1,
				ty: 4,
				nm: "Layer 24",
				parent: 3,
				sr: 1,
				ks: {
					o: {
						a: 0,
						k: 100,
						ix: 11
					},
					r: {
						a: 0,
						k: 0,
						ix: 10
					},
					p: {
						a: 0,
						k: [
							-117.047,
							-116.699,
							0
						],
						ix: 2
					},
					a: {
						a: 0,
						k: [
							-117.047,
							-116.699,
							0
						],
						ix: 1
					},
					s: {
						a: 1,
						k: [
							{
								i: {
									x: [
										0.833,
										0.833,
										0.833
									],
									y: [
										0.833,
										0.833,
										0.833
									]
								},
								o: {
									x: [
										0.167,
										0.167,
										0.167
									],
									y: [
										0.167,
										0.167,
										0.167
									]
								},
								t: 56,
								s: [
									100,
									100,
									100
								]
							},
							{
								i: {
									x: [
										0.833,
										0.833,
										0.833
									],
									y: [
										0.833,
										0.833,
										0.833
									]
								},
								o: {
									x: [
										0.167,
										0.167,
										0.167
									],
									y: [
										0.167,
										0.167,
										0.167
									]
								},
								t: 66,
								s: [
									100,
									5,
									100
								]
							},
							{
								i: {
									x: [
										0.833,
										0.833,
										0.833
									],
									y: [
										0.833,
										0.833,
										0.833
									]
								},
								o: {
									x: [
										0.167,
										0.167,
										0.167
									],
									y: [
										0.167,
										0.167,
										0.167
									]
								},
								t: 76,
								s: [
									100,
									100,
									100
								]
							},
							{
								i: {
									x: [
										0.833,
										0.833,
										0.833
									],
									y: [
										0.833,
										0.833,
										0.833
									]
								},
								o: {
									x: [
										0.167,
										0.167,
										0.167
									],
									y: [
										0.167,
										0.167,
										0.167
									]
								},
								t: 104,
								s: [
									100,
									100,
									100
								]
							},
							{
								i: {
									x: [
										0.833,
										0.833,
										0.833
									],
									y: [
										0.833,
										0.833,
										0.833
									]
								},
								o: {
									x: [
										0.167,
										0.167,
										0.167
									],
									y: [
										0.167,
										0.167,
										0.167
									]
								},
								t: 114,
								s: [
									100,
									5,
									100
								]
							},
							{
								t: 124,
								s: [
									100,
									100,
									100
								]
							}
						],
						ix: 6
					}
				},
				ao: 0,
				shapes: [
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												-1.479
											],
											[
												1.488,
												0
											],
											[
												0,
												1.479
											],
											[
												-1.488,
												0
											]
										],
										o: [
											[
												0,
												1.479
											],
											[
												-1.488,
												0
											],
											[
												0,
												-1.479
											],
											[
												1.488,
												0
											]
										],
										v: [
											[
												-114.353,
												-116.699
											],
											[
												-117.047,
												-114.021
											],
											[
												-119.741,
												-116.699
											],
											[
												-117.047,
												-119.377
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										0.156862750649,
										0.156862750649,
										0.156862750649,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 1",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 1,
						mn: "ADBE Vector Group",
						hd: false
					}
				],
				ip: 0,
				op: 180,
				st: 0,
				bm: 0
			},
			{
				ddd: 0,
				ind: 2,
				ty: 4,
				nm: "Layer 23",
				parent: 3,
				sr: 1,
				ks: {
					o: {
						a: 0,
						k: 100,
						ix: 11
					},
					r: {
						a: 0,
						k: 0,
						ix: 10
					},
					p: {
						a: 0,
						k: [
							-142.584,
							-116.699,
							0
						],
						ix: 2
					},
					a: {
						a: 0,
						k: [
							-142.584,
							-116.699,
							0
						],
						ix: 1
					},
					s: {
						a: 1,
						k: [
							{
								i: {
									x: [
										0.833,
										0.833,
										0.833
									],
									y: [
										0.833,
										0.833,
										0.833
									]
								},
								o: {
									x: [
										0.167,
										0.167,
										0.167
									],
									y: [
										0.167,
										0.167,
										0.167
									]
								},
								t: 56,
								s: [
									100,
									100,
									100
								]
							},
							{
								i: {
									x: [
										0.833,
										0.833,
										0.833
									],
									y: [
										0.833,
										0.833,
										0.833
									]
								},
								o: {
									x: [
										0.167,
										0.167,
										0.167
									],
									y: [
										0.167,
										0.167,
										0.167
									]
								},
								t: 66,
								s: [
									100,
									5,
									100
								]
							},
							{
								i: {
									x: [
										0.833,
										0.833,
										0.833
									],
									y: [
										0.833,
										0.833,
										0.833
									]
								},
								o: {
									x: [
										0.167,
										0.167,
										0.167
									],
									y: [
										0.167,
										0.167,
										0.167
									]
								},
								t: 76,
								s: [
									100,
									100,
									100
								]
							},
							{
								i: {
									x: [
										0.833,
										0.833,
										0.833
									],
									y: [
										0.833,
										0.833,
										0.833
									]
								},
								o: {
									x: [
										0.167,
										0.167,
										0.167
									],
									y: [
										0.167,
										0.167,
										0.167
									]
								},
								t: 104,
								s: [
									100,
									100,
									100
								]
							},
							{
								i: {
									x: [
										0.833,
										0.833,
										0.833
									],
									y: [
										0.833,
										0.833,
										0.833
									]
								},
								o: {
									x: [
										0.167,
										0.167,
										0.167
									],
									y: [
										0.167,
										0.167,
										0.167
									]
								},
								t: 114,
								s: [
									100,
									5,
									100
								]
							},
							{
								t: 124,
								s: [
									100,
									100,
									100
								]
							}
						],
						ix: 6
					}
				},
				ao: 0,
				shapes: [
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												-1.479
											],
											[
												1.488,
												0
											],
											[
												0,
												1.479
											],
											[
												-1.488,
												0
											]
										],
										o: [
											[
												0,
												1.479
											],
											[
												-1.488,
												0
											],
											[
												0,
												-1.479
											],
											[
												1.488,
												0
											]
										],
										v: [
											[
												-139.891,
												-116.699
											],
											[
												-142.584,
												-114.021
											],
											[
												-145.278,
												-116.699
											],
											[
												-142.584,
												-119.377
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										0.156862750649,
										0.156862750649,
										0.156862750649,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 1",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 1,
						mn: "ADBE Vector Group",
						hd: false
					}
				],
				ip: 0,
				op: 180,
				st: 0,
				bm: 0
			},
			{
				ddd: 0,
				ind: 3,
				ty: 4,
				nm: "head",
				sr: 1,
				ks: {
					o: {
						a: 0,
						k: 100,
						ix: 11
					},
					r: {
						a: 1,
						k: [
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 30,
								s: [
									0
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 50,
								s: [
									-13
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 75,
								s: [
									-13
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 95,
								s: [
									0
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 110,
								s: [
									0
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 130,
								s: [
									-13
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 157,
								s: [
									-13
								]
							},
							{
								t: 179,
								s: [
									0
								]
							}
						],
						ix: 10
					},
					p: {
						a: 0,
						k: [
							410.612,
							461.288,
							0
						],
						ix: 2
					},
					a: {
						a: 0,
						k: [
							-129.388,
							-78.712,
							0
						],
						ix: 1
					},
					s: {
						a: 0,
						k: [
							100,
							100,
							100
						],
						ix: 6
					}
				},
				ao: 0,
				shapes: [
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												7.592,
												-17.374
											],
											[
												-45.143,
												3.092
											],
											[
												21.877,
												2.823
											]
										],
										o: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											]
										],
										v: [
											[
												-157.467,
												-147.519
											],
											[
												-97.58,
												-130.792
											],
											[
												-124.614,
												-161.877
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										0.156862750649,
										0.156862750649,
										0.156862750649,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 1",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 1,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												0
											],
											[
												-2.964,
												17.599
											],
											[
												-2.484,
												-12.388
											]
										],
										o: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												2.484,
												12.388
											]
										],
										v: [
											[
												-99.341,
												-120.058
											],
											[
												-111.304,
												-155.631
											],
											[
												-98.467,
												-137.262
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										0.156862750649,
										0.156862750649,
										0.156862750649,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 2",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 2,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												0
											],
											[
												2.964,
												17.599
											],
											[
												2.484,
												-12.388
											]
										],
										o: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												-2.484,
												12.388
											]
										],
										v: [
											[
												-158.545,
												-119.48
											],
											[
												-148.659,
												-154.45
											],
											[
												-160.68,
												-137.262
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										0.156862750649,
										0.156862750649,
										0.156862750649,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 3",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 3,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												10.721,
												0
											]
										],
										o: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												-8.165,
												0
											]
										],
										v: [
											[
												-141.67,
												-101.38
											],
											[
												-118.028,
												-101.38
											],
											[
												-130.417,
												-94.884
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										1,
										1,
										1,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 4",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 4,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												-7.085,
												1.597
											]
										],
										o: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												7.085,
												-1.597
											]
										],
										v: [
											[
												-133.687,
												-127.312
											],
											[
												-151.006,
												-123.265
											],
											[
												-143.133,
												-129.256
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										0.156862750649,
										0.156862750649,
										0.156862750649,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 5",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 5,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												6.995,
												1.597
											]
										],
										o: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												-6.995,
												-1.597
											]
										],
										v: [
											[
												-124.709,
												-127.312
											],
											[
												-107.61,
												-123.265
											],
											[
												-115.382,
												-129.256
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										0.156862750649,
										0.156862750649,
										0.156862750649,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 6",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 6,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												-0.091,
												-0.226
											],
											[
												-0.929,
												0.246
											],
											[
												0,
												0
											]
										],
										o: [
											[
												0,
												0
											],
											[
												0,
												0.257
											],
											[
												0.357,
												0.888
											],
											[
												0,
												0
											],
											[
												0,
												0
											]
										],
										v: [
											[
												-131.406,
												-110.244
											],
											[
												-131.406,
												-107.656
											],
											[
												-131.265,
												-106.926
											],
											[
												-128.951,
												-105.859
											],
											[
												-126.953,
												-106.387
											]
										],
										c: false
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "st",
								c: {
									a: 0,
									k: [
										0.156862750649,
										0.156862750649,
										0.156862750649,
										1
									],
									ix: 3
								},
								o: {
									a: 0,
									k: 100,
									ix: 4
								},
								w: {
									a: 0,
									k: 1.23,
									ix: 5
								},
								lc: 2,
								lj: 2,
								bm: 0,
								nm: "Stroke 1",
								mn: "ADBE Vector Graphic - Stroke",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 7",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 7,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												0
											],
											[
												1.759,
												-7.639
											],
											[
												6.849,
												-4.207
											],
											[
												0,
												0
											],
											[
												7.358,
												4.289
											],
											[
												0,
												0
											],
											[
												1.599,
												8.025
											],
											[
												0,
												0
											],
											[
												-32.14,
												-0.612
											]
										],
										o: [
											[
												0,
												12.472
											],
											[
												-1.723,
												7.479
											],
											[
												0,
												0
											],
											[
												-7.247,
												4.451
											],
											[
												0,
												0
											],
											[
												-7.421,
												-4.326
											],
											[
												-2.908,
												-14.597
											],
											[
												0,
												0
											],
											[
												32.14,
												0.612
											]
										],
										v: [
											[
												-99.363,
												-129.918
											],
											[
												-102.884,
												-99.044
											],
											[
												-116.302,
												-82.131
											],
											[
												-117.549,
												-81.365
											],
											[
												-141.516,
												-81.099
											],
											[
												-141.516,
												-81.1
											],
											[
												-155.732,
												-99.155
											],
											[
												-158.958,
												-129.918
											],
											[
												-129.585,
												-160.793
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										1,
										0.694117665291,
										0.647058844566,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 8",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 8,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "gr",
						it: [
							{
								ty: "gr",
								it: [
									{
										ind: 0,
										ty: "sh",
										ix: 1,
										ks: {
											a: 0,
											k: {
												i: [
													[
														0,
														-20.317
													],
													[
														19.108,
														0
													],
													[
														0,
														20.317
													],
													[
														-19.108,
														0
													]
												],
												o: [
													[
														0,
														20.317
													],
													[
														-19.108,
														0
													],
													[
														0,
														-20.317
													],
													[
														19.108,
														0
													]
												],
												v: [
													[
														-94.66,
														-131.332
													],
													[
														-129.259,
														-101.38
													],
													[
														-163.857,
														-131.332
													],
													[
														-129.259,
														-165.471
													]
												],
												c: true
											},
											ix: 2
										},
										nm: "Path 1",
										mn: "ADBE Vector Shape - Group",
										hd: false
									},
									{
										ty: "fl",
										c: {
											a: 0,
											k: [
												0.156862750649,
												0.156862750649,
												0.156862750649,
												1
											],
											ix: 4
										},
										o: {
											a: 0,
											k: 100,
											ix: 5
										},
										r: 1,
										bm: 0,
										nm: "Fill 1",
										mn: "ADBE Vector Graphic - Fill",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 1",
								np: 2,
								cix: 2,
								bm: 0,
								ix: 1,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 9",
						np: 1,
						cix: 2,
						bm: 0,
						ix: 9,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "gr",
						it: [
							{
								ty: "gr",
								it: [
									{
										ty: "gr",
										it: [
											{
												ty: "gr",
												it: [
													{
														ind: 0,
														ty: "sh",
														ix: 1,
														ks: {
															a: 0,
															k: {
																i: [
																	[
																		0,
																		0
																	],
																	[
																		-3.403,
																		-4.624
																	]
																],
																o: [
																	[
																		0,
																		0
																	],
																	[
																		0,
																		0
																	]
																],
																v: [
																	[
																		-164.118,
																		-111.002
																	],
																	[
																		-157.478,
																		-108.177
																	]
																],
																c: false
															},
															ix: 2
														},
														nm: "Path 1",
														mn: "ADBE Vector Shape - Group",
														hd: false
													},
													{
														ty: "st",
														c: {
															a: 0,
															k: [
																0.156862750649,
																0.156862750649,
																0.156862750649,
																1
															],
															ix: 3
														},
														o: {
															a: 0,
															k: 100,
															ix: 4
														},
														w: {
															a: 0,
															k: 0.993,
															ix: 5
														},
														lc: 2,
														lj: 2,
														bm: 0,
														nm: "Stroke 1",
														mn: "ADBE Vector Graphic - Stroke",
														hd: false
													},
													{
														ty: "tr",
														p: {
															a: 0,
															k: [
																0,
																0
															],
															ix: 2
														},
														a: {
															a: 0,
															k: [
																0,
																0
															],
															ix: 1
														},
														s: {
															a: 0,
															k: [
																100,
																100
															],
															ix: 3
														},
														r: {
															a: 0,
															k: 0,
															ix: 6
														},
														o: {
															a: 0,
															k: 100,
															ix: 7
														},
														sk: {
															a: 0,
															k: 0,
															ix: 4
														},
														sa: {
															a: 0,
															k: 0,
															ix: 5
														},
														nm: "Transform"
													}
												],
												nm: "Group 1",
												np: 2,
												cix: 2,
												bm: 0,
												ix: 1,
												mn: "ADBE Vector Group",
												hd: false
											},
											{
												ty: "tr",
												p: {
													a: 0,
													k: [
														0,
														0
													],
													ix: 2
												},
												a: {
													a: 0,
													k: [
														0,
														0
													],
													ix: 1
												},
												s: {
													a: 0,
													k: [
														100,
														100
													],
													ix: 3
												},
												r: {
													a: 0,
													k: 0,
													ix: 6
												},
												o: {
													a: 0,
													k: 100,
													ix: 7
												},
												sk: {
													a: 0,
													k: 0,
													ix: 4
												},
												sa: {
													a: 0,
													k: 0,
													ix: 5
												},
												nm: "Transform"
											}
										],
										nm: "Group 1",
										np: 1,
										cix: 2,
										bm: 0,
										ix: 1,
										mn: "ADBE Vector Group",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 1",
								np: 1,
								cix: 2,
								bm: 0,
								ix: 1,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "gr",
								it: [
									{
										ind: 0,
										ty: "sh",
										ix: 1,
										ks: {
											a: 0,
											k: {
												i: [
													[
														0,
														0
													],
													[
														-3.931,
														4.658
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													]
												],
												o: [
													[
														-4.103,
														4.409
													],
													[
														3.931,
														-4.658
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													]
												],
												v: [
													[
														-155.243,
														-101.545
													],
													[
														-166.653,
														-116.243
													],
													[
														-158.874,
														-114.444
													],
													[
														-156.569,
														-110.041
													],
													[
														-154.598,
														-103.981
													],
													[
														-154.116,
														-102.391
													]
												],
												c: true
											},
											ix: 2
										},
										nm: "Path 1",
										mn: "ADBE Vector Shape - Group",
										hd: false
									},
									{
										ty: "fl",
										c: {
											a: 0,
											k: [
												1,
												0.6941176470588235,
												0.6470588235294118,
												1
											],
											ix: 4
										},
										o: {
											a: 0,
											k: 100,
											ix: 5
										},
										r: 1,
										bm: 0,
										nm: "Fill 1",
										mn: "ADBE Vector Graphic - Fill",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 2",
								np: 2,
								cix: 2,
								bm: 0,
								ix: 2,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 10",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 10,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "gr",
						it: [
							{
								ty: "gr",
								it: [
									{
										ty: "gr",
										it: [
											{
												ty: "gr",
												it: [
													{
														ind: 0,
														ty: "sh",
														ix: 1,
														ks: {
															a: 0,
															k: {
																i: [
																	[
																		0,
																		0
																	],
																	[
																		3,
																		-4.895
																	]
																],
																o: [
																	[
																		0,
																		0
																	],
																	[
																		0,
																		0
																	]
																],
																v: [
																	[
																		-94.442,
																		-111.254
																	],
																	[
																		-100.819,
																		-107.877
																	]
																],
																c: false
															},
															ix: 2
														},
														nm: "Path 1",
														mn: "ADBE Vector Shape - Group",
														hd: false
													},
													{
														ty: "st",
														c: {
															a: 0,
															k: [
																0.156862750649,
																0.156862750649,
																0.156862750649,
																1
															],
															ix: 3
														},
														o: {
															a: 0,
															k: 100,
															ix: 4
														},
														w: {
															a: 0,
															k: 0.993,
															ix: 5
														},
														lc: 2,
														lj: 2,
														bm: 0,
														nm: "Stroke 1",
														mn: "ADBE Vector Graphic - Stroke",
														hd: false
													},
													{
														ty: "tr",
														p: {
															a: 0,
															k: [
																0,
																0
															],
															ix: 2
														},
														a: {
															a: 0,
															k: [
																0,
																0
															],
															ix: 1
														},
														s: {
															a: 0,
															k: [
																100,
																100
															],
															ix: 3
														},
														r: {
															a: 0,
															k: 0,
															ix: 6
														},
														o: {
															a: 0,
															k: 100,
															ix: 7
														},
														sk: {
															a: 0,
															k: 0,
															ix: 4
														},
														sa: {
															a: 0,
															k: 0,
															ix: 5
														},
														nm: "Transform"
													}
												],
												nm: "Group 1",
												np: 2,
												cix: 2,
												bm: 0,
												ix: 1,
												mn: "ADBE Vector Group",
												hd: false
											},
											{
												ty: "tr",
												p: {
													a: 0,
													k: [
														0,
														0
													],
													ix: 2
												},
												a: {
													a: 0,
													k: [
														0,
														0
													],
													ix: 1
												},
												s: {
													a: 0,
													k: [
														100,
														100
													],
													ix: 3
												},
												r: {
													a: 0,
													k: 0,
													ix: 6
												},
												o: {
													a: 0,
													k: 100,
													ix: 7
												},
												sk: {
													a: 0,
													k: 0,
													ix: 4
												},
												sa: {
													a: 0,
													k: 0,
													ix: 5
												},
												nm: "Transform"
											}
										],
										nm: "Group 1",
										np: 1,
										cix: 2,
										bm: 0,
										ix: 1,
										mn: "ADBE Vector Group",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 1",
								np: 1,
								cix: 2,
								bm: 0,
								ix: 1,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "gr",
								it: [
									{
										ind: 0,
										ty: "sh",
										ix: 1,
										ks: {
											a: 0,
											k: {
												i: [
													[
														0,
														0
													],
													[
														4.311,
														4.309
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													]
												],
												o: [
													[
														4.461,
														4.046
													],
													[
														-4.311,
														-4.309
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													]
												],
												v: [
													[
														-102.485,
														-101.079
													],
													[
														-92.359,
														-116.69
													],
													[
														-99.957,
														-114.239
													],
													[
														-101.882,
														-109.658
													],
													[
														-103.334,
														-103.452
													],
													[
														-103.679,
														-101.828
													]
												],
												c: true
											},
											ix: 2
										},
										nm: "Path 1",
										mn: "ADBE Vector Shape - Group",
										hd: false
									},
									{
										ty: "fl",
										c: {
											a: 0,
											k: [
												1,
												0.6941176470588235,
												0.6470588235294118,
												1
											],
											ix: 4
										},
										o: {
											a: 0,
											k: 100,
											ix: 5
										},
										r: 1,
										bm: 0,
										nm: "Fill 1",
										mn: "ADBE Vector Graphic - Fill",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 2",
								np: 2,
								cix: 2,
								bm: 0,
								ix: 2,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 11",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 11,
						mn: "ADBE Vector Group",
						hd: false
					}
				],
				ip: 0,
				op: 180,
				st: 0,
				bm: 0
			},
			{
				ddd: 0,
				ind: 4,
				ty: 4,
				nm: "r_arm",
				sr: 1,
				ks: {
					o: {
						a: 0,
						k: 100,
						ix: 11
					},
					r: {
						a: 1,
						k: [
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 30,
								s: [
									0
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 50,
								s: [
									17
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 75,
								s: [
									17
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 95,
								s: [
									0
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 110,
								s: [
									0
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 130,
								s: [
									17
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 157,
								s: [
									17
								]
							},
							{
								t: 179,
								s: [
									0
								]
							}
						],
						ix: 10
					},
					p: {
						a: 1,
						k: [
							{
								i: {
									x: 0.667,
									y: 0.667
								},
								o: {
									x: 0.333,
									y: 0.333
								},
								t: 30,
								s: [
									357.503,
									542.863,
									0
								],
								to: [
									0,
									0,
									0
								],
								ti: [
									0,
									0,
									0
								]
							},
							{
								i: {
									x: 0.667,
									y: 1
								},
								o: {
									x: 0.333,
									y: 0
								},
								t: 50,
								s: [
									357.503,
									542.863,
									0
								],
								to: [
									0,
									0,
									0
								],
								ti: [
									0,
									0,
									0
								]
							},
							{
								i: {
									x: 0.667,
									y: 0.667
								},
								o: {
									x: 0.333,
									y: 0.333
								},
								t: 75,
								s: [
									357.503,
									542.863,
									0
								],
								to: [
									0,
									0,
									0
								],
								ti: [
									0,
									0,
									0
								]
							},
							{
								i: {
									x: 0.667,
									y: 0.667
								},
								o: {
									x: 0.333,
									y: 0.333
								},
								t: 95,
								s: [
									357.503,
									542.863,
									0
								],
								to: [
									0,
									0,
									0
								],
								ti: [
									0,
									0,
									0
								]
							},
							{
								i: {
									x: 0.667,
									y: 0.667
								},
								o: {
									x: 0.333,
									y: 0.333
								},
								t: 110,
								s: [
									357.503,
									542.863,
									0
								],
								to: [
									0,
									0,
									0
								],
								ti: [
									0,
									0,
									0
								]
							},
							{
								i: {
									x: 0.667,
									y: 0.667
								},
								o: {
									x: 0.333,
									y: 0.333
								},
								t: 130,
								s: [
									357.503,
									542.863,
									0
								],
								to: [
									0,
									0,
									0
								],
								ti: [
									0,
									0,
									0
								]
							},
							{
								i: {
									x: 0.667,
									y: 0.667
								},
								o: {
									x: 0.333,
									y: 0.333
								},
								t: 157,
								s: [
									357.503,
									542.863,
									0
								],
								to: [
									0,
									0,
									0
								],
								ti: [
									0,
									0,
									0
								]
							},
							{
								t: 179,
								s: [
									357.503,
									542.863,
									0
								]
							}
						],
						ix: 2
					},
					a: {
						a: 0,
						k: [
							-182.497,
							2.863,
							0
						],
						ix: 1
					},
					s: {
						a: 0,
						k: [
							100,
							100,
							100
						],
						ix: 6
					}
				},
				ao: 0,
				hasMask: true,
				masksProperties: [
					{
						inv: false,
						mode: "a",
						pt: {
							a: 0,
							k: {
								i: [
									[
										0,
										0
									],
									[
										-9,
										-46
									],
									[
										-6.5,
										7
									],
									[
										1,
										6
									],
									[
										12.5,
										11
									]
								],
								o: [
									[
										0,
										0
									],
									[
										9,
										46
									],
									[
										7.698,
										-8.291
									],
									[
										-1,
										-6
									],
									[
										-18.266,
										-16.074
									]
								],
								v: [
									[
										-211.5,
										-34.5
									],
									[
										-230.5,
										14
									],
									[
										-158,
										46
									],
									[
										-128,
										21
									],
									[
										-148.5,
										-32
									]
								],
								c: true
							},
							ix: 1
						},
						o: {
							a: 0,
							k: 100,
							ix: 3
						},
						x: {
							a: 0,
							k: 0,
							ix: 4
						},
						nm: "Mask 1"
					}
				],
				shapes: [
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												0
											],
											[
												-23.294,
												-3.126
											],
											[
												-0.505,
												1.464
											],
											[
												0,
												0
											],
											[
												1.56,
												0.697
											],
											[
												-2.923,
												9.743
											],
											[
												-1.858,
												-6.28
											],
											[
												-1.505,
												0.758
											],
											[
												0,
												0
											],
											[
												0.145,
												1.141
											],
											[
												8.49,
												2.842
											]
										],
										o: [
											[
												0,
												0
											],
											[
												1.534,
												0.206
											],
											[
												0,
												0
											],
											[
												0.557,
												-1.615
											],
											[
												-3.797,
												-1.698
											],
											[
												0,
												0
											],
											[
												0.478,
												1.616
											],
											[
												0,
												0
											],
											[
												1.027,
												-0.517
											],
											[
												-0.558,
												-4.4
											],
											[
												0,
												0
											]
										],
										v: [
											[
												-210.969,
												159.272
											],
											[
												-193.837,
												190.987
											],
											[
												-190.314,
												188.824
											],
											[
												-190.247,
												188.629
											],
											[
												-192.059,
												184.584
											],
											[
												-198.825,
												168.853
											],
											[
												-193.6,
												174.72
											],
											[
												-189.803,
												176.39
											],
											[
												-189.803,
												176.39
											],
											[
												-188.342,
												173.627
											],
											[
												-199.604,
												155.797
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										1,
										0.694117665291,
										0.647058844566,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 1",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 1,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 1,
									k: [
										{
											i: {
												x: 0.667,
												y: 1
											},
											o: {
												x: 0.333,
												y: 0
											},
											t: 30,
											s: [
												{
													i: [
														[
															0,
															0
														],
														[
															11.35,
															-2.53
														],
														[
															0.762,
															-1.822
														],
														[
															0,
															0
														]
													],
													o: [
														[
															-0.656,
															1.033
														],
														[
															-1.036,
															0.231
														],
														[
															-7.491,
															17.9
														],
														[
															0,
															0
														]
													],
													v: [
														[
															-198.617,
															160.542
														],
														[
															-176.894,
															19.801
														],
														[
															-197.762,
															16.572
														],
														[
															-210.969,
															159.272
														]
													],
													c: true
												}
											]
										},
										{
											i: {
												x: 0.667,
												y: 1
											},
											o: {
												x: 0.333,
												y: 0
											},
											t: 50,
											s: [
												{
													i: [
														[
															0,
															0
														],
														[
															11.35,
															-2.53
														],
														[
															1.141,
															-3.053
														],
														[
															0,
															0
														]
													],
													o: [
														[
															-0.656,
															1.033
														],
														[
															-0.47,
															0.448
														],
														[
															-6.79,
															18.177
														],
														[
															0,
															0
														]
													],
													v: [
														[
															-198.617,
															160.542
														],
														[
															-173.879,
															14.969
														],
														[
															-197.359,
															21.757
														],
														[
															-210.969,
															159.272
														]
													],
													c: true
												}
											]
										},
										{
											i: {
												x: 0.667,
												y: 1
											},
											o: {
												x: 0.333,
												y: 0
											},
											t: 75,
											s: [
												{
													i: [
														[
															0,
															0
														],
														[
															11.35,
															-2.53
														],
														[
															1.141,
															-3.053
														],
														[
															0,
															0
														]
													],
													o: [
														[
															-0.656,
															1.033
														],
														[
															-0.47,
															0.448
														],
														[
															-6.79,
															18.177
														],
														[
															0,
															0
														]
													],
													v: [
														[
															-198.617,
															160.542
														],
														[
															-173.879,
															14.969
														],
														[
															-197.359,
															21.757
														],
														[
															-210.969,
															159.272
														]
													],
													c: true
												}
											]
										},
										{
											i: {
												x: 0.667,
												y: 1
											},
											o: {
												x: 0.333,
												y: 0
											},
											t: 95,
											s: [
												{
													i: [
														[
															0,
															0
														],
														[
															11.35,
															-2.53
														],
														[
															0.762,
															-1.822
														],
														[
															0,
															0
														]
													],
													o: [
														[
															-0.656,
															1.033
														],
														[
															-1.036,
															0.231
														],
														[
															-7.491,
															17.9
														],
														[
															0,
															0
														]
													],
													v: [
														[
															-198.617,
															160.542
														],
														[
															-176.894,
															19.801
														],
														[
															-197.762,
															16.572
														],
														[
															-210.969,
															159.272
														]
													],
													c: true
												}
											]
										},
										{
											i: {
												x: 0.667,
												y: 1
											},
											o: {
												x: 0.333,
												y: 0
											},
											t: 110,
											s: [
												{
													i: [
														[
															0,
															0
														],
														[
															11.35,
															-2.53
														],
														[
															0.762,
															-1.822
														],
														[
															0,
															0
														]
													],
													o: [
														[
															-0.656,
															1.033
														],
														[
															-1.036,
															0.231
														],
														[
															-7.491,
															17.9
														],
														[
															0,
															0
														]
													],
													v: [
														[
															-198.617,
															160.542
														],
														[
															-176.894,
															19.801
														],
														[
															-197.762,
															16.572
														],
														[
															-210.969,
															159.272
														]
													],
													c: true
												}
											]
										},
										{
											i: {
												x: 0.667,
												y: 1
											},
											o: {
												x: 0.333,
												y: 0
											},
											t: 130,
											s: [
												{
													i: [
														[
															0,
															0
														],
														[
															11.35,
															-2.53
														],
														[
															1.141,
															-3.053
														],
														[
															0,
															0
														]
													],
													o: [
														[
															-0.656,
															1.033
														],
														[
															-0.47,
															0.448
														],
														[
															-6.79,
															18.177
														],
														[
															0,
															0
														]
													],
													v: [
														[
															-198.617,
															160.542
														],
														[
															-173.879,
															14.969
														],
														[
															-197.359,
															21.757
														],
														[
															-210.969,
															159.272
														]
													],
													c: true
												}
											]
										},
										{
											i: {
												x: 0.667,
												y: 1
											},
											o: {
												x: 0.333,
												y: 0
											},
											t: 157,
											s: [
												{
													i: [
														[
															0,
															0
														],
														[
															11.35,
															-2.53
														],
														[
															1.141,
															-3.053
														],
														[
															0,
															0
														]
													],
													o: [
														[
															-0.656,
															1.033
														],
														[
															-0.47,
															0.448
														],
														[
															-6.79,
															18.177
														],
														[
															0,
															0
														]
													],
													v: [
														[
															-198.617,
															160.542
														],
														[
															-173.879,
															14.969
														],
														[
															-197.359,
															21.757
														],
														[
															-210.969,
															159.272
														]
													],
													c: true
												}
											]
										},
										{
											t: 179,
											s: [
												{
													i: [
														[
															0,
															0
														],
														[
															11.35,
															-2.53
														],
														[
															0.762,
															-1.822
														],
														[
															0,
															0
														]
													],
													o: [
														[
															-0.656,
															1.033
														],
														[
															-1.036,
															0.231
														],
														[
															-7.491,
															17.9
														],
														[
															0,
															0
														]
													],
													v: [
														[
															-198.617,
															160.542
														],
														[
															-176.894,
															19.801
														],
														[
															-197.762,
															16.572
														],
														[
															-210.969,
															159.272
														]
													],
													c: true
												}
											]
										}
									],
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										1,
										0.694117665291,
										0.647058844566,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 2",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 2,
						mn: "ADBE Vector Group",
						hd: false
					}
				],
				ip: 0,
				op: 180,
				st: 0,
				bm: 0
			},
			{
				ddd: 0,
				ind: 5,
				ty: 4,
				nm: "r_hand",
				parent: 4,
				sr: 1,
				ks: {
					o: {
						a: 0,
						k: 100,
						ix: 11
					},
					r: {
						a: 1,
						k: [
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 30,
								s: [
									0
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 50,
								s: [
									-75
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 75,
								s: [
									-75
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 95,
								s: [
									0
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 110,
								s: [
									0
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 130,
								s: [
									-75
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 157,
								s: [
									-75
								]
							},
							{
								t: 179,
								s: [
									0
								]
							}
						],
						ix: 10
					},
					p: {
						a: 1,
						k: [
							{
								i: {
									x: 0.667,
									y: 1
								},
								o: {
									x: 0.333,
									y: 0
								},
								t: 30,
								s: [
									-189.497,
									48.363,
									0
								],
								to: [
									0,
									0,
									0
								],
								ti: [
									0,
									0,
									0
								]
							},
							{
								i: {
									x: 0.667,
									y: 0.667
								},
								o: {
									x: 0.333,
									y: 0.333
								},
								t: 50,
								s: [
									-189.497,
									36.363,
									0
								],
								to: [
									0,
									0,
									0
								],
								ti: [
									0,
									0,
									0
								]
							},
							{
								i: {
									x: 0.667,
									y: 1
								},
								o: {
									x: 0.333,
									y: 0
								},
								t: 75,
								s: [
									-189.497,
									36.363,
									0
								],
								to: [
									0,
									0,
									0
								],
								ti: [
									0,
									0,
									0
								]
							},
							{
								i: {
									x: 0.667,
									y: 0.667
								},
								o: {
									x: 0.333,
									y: 0.333
								},
								t: 95,
								s: [
									-189.497,
									48.363,
									0
								],
								to: [
									0,
									0,
									0
								],
								ti: [
									0,
									0,
									0
								]
							},
							{
								i: {
									x: 0.667,
									y: 1
								},
								o: {
									x: 0.333,
									y: 0
								},
								t: 110,
								s: [
									-189.497,
									48.363,
									0
								],
								to: [
									0,
									0,
									0
								],
								ti: [
									0,
									0,
									0
								]
							},
							{
								i: {
									x: 0.667,
									y: 0.667
								},
								o: {
									x: 0.333,
									y: 0.333
								},
								t: 130,
								s: [
									-189.497,
									36.363,
									0
								],
								to: [
									0,
									0,
									0
								],
								ti: [
									0,
									0,
									0
								]
							},
							{
								i: {
									x: 0.667,
									y: 1
								},
								o: {
									x: 0.333,
									y: 0
								},
								t: 157,
								s: [
									-189.497,
									36.363,
									0
								],
								to: [
									0,
									0,
									0
								],
								ti: [
									0,
									0,
									0
								]
							},
							{
								t: 179,
								s: [
									-189.497,
									48.363,
									0
								]
							}
						],
						ix: 2
					},
					a: {
						a: 0,
						k: [
							-189.497,
							48.363,
							0
						],
						ix: 1
					},
					s: {
						a: 0,
						k: [
							100,
							100,
							100
						],
						ix: 6
					}
				},
				ao: 0,
				hasMask: true,
				masksProperties: [
					{
						inv: false,
						mode: "a",
						pt: {
							a: 0,
							k: {
								i: [
									[
										0,
										0
									],
									[
										-9,
										-46
									],
									[
										4,
										1
									],
									[
										1,
										6
									],
									[
										3.795,
										22.773
									]
								],
								o: [
									[
										0,
										0
									],
									[
										9,
										46
									],
									[
										-4,
										-1
									],
									[
										-1,
										-6
									],
									[
										-4,
										-24
									]
								],
								v: [
									[
										-215,
										49
									],
									[
										-237,
										175
									],
									[
										-174,
										186
									],
									[
										-183,
										141
									],
									[
										-172.5,
										56
									]
								],
								c: true
							},
							ix: 1
						},
						o: {
							a: 0,
							k: 100,
							ix: 3
						},
						x: {
							a: 0,
							k: 0,
							ix: 4
						},
						nm: "Mask 1"
					}
				],
				shapes: [
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												0
											],
											[
												-23.294,
												-3.126
											],
											[
												-0.505,
												1.464
											],
											[
												0,
												0
											],
											[
												1.56,
												0.697
											],
											[
												-2.923,
												9.743
											],
											[
												-1.858,
												-6.28
											],
											[
												-1.505,
												0.758
											],
											[
												0,
												0
											],
											[
												0.145,
												1.141
											],
											[
												8.49,
												2.842
											]
										],
										o: [
											[
												0,
												0
											],
											[
												1.534,
												0.206
											],
											[
												0,
												0
											],
											[
												0.557,
												-1.615
											],
											[
												-3.797,
												-1.698
											],
											[
												0,
												0
											],
											[
												0.478,
												1.616
											],
											[
												0,
												0
											],
											[
												1.027,
												-0.517
											],
											[
												-0.558,
												-4.4
											],
											[
												0,
												0
											]
										],
										v: [
											[
												-210.969,
												159.272
											],
											[
												-193.837,
												190.987
											],
											[
												-190.314,
												188.824
											],
											[
												-190.247,
												188.629
											],
											[
												-192.059,
												184.584
											],
											[
												-198.825,
												168.853
											],
											[
												-193.6,
												174.72
											],
											[
												-189.803,
												176.39
											],
											[
												-189.803,
												176.39
											],
											[
												-188.342,
												173.627
											],
											[
												-199.604,
												155.797
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										1,
										0.694117665291,
										0.647058844566,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 1",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 1,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												0
											],
											[
												11.35,
												-2.53
											],
											[
												2.955,
												-6.007
											],
											[
												0,
												0
											]
										],
										o: [
											[
												-0.656,
												1.033
											],
											[
												-1.036,
												0.231
											],
											[
												-8.564,
												17.412
											],
											[
												0,
												0
											]
										],
										v: [
											[
												-198.617,
												160.542
											],
											[
												-172.394,
												-3.262
											],
											[
												-196.262,
												4.822
											],
											[
												-210.969,
												159.272
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										1,
										0.694117665291,
										0.647058844566,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 2",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 2,
						mn: "ADBE Vector Group",
						hd: false
					}
				],
				ip: 0,
				op: 180,
				st: 0,
				bm: 0
			},
			{
				ddd: 0,
				ind: 6,
				ty: 4,
				nm: "body",
				sr: 1,
				ks: {
					o: {
						a: 0,
						k: 100,
						ix: 11
					},
					r: {
						a: 0,
						k: 0,
						ix: 10
					},
					p: {
						a: 0,
						k: [
							405.837,
							636.388,
							0
						],
						ix: 2
					},
					a: {
						a: 0,
						k: [
							-134.163,
							96.388,
							0
						],
						ix: 1
					},
					s: {
						a: 0,
						k: [
							100,
							100,
							100
						],
						ix: 6
					}
				},
				ao: 0,
				shapes: [
					{
						ty: "gr",
						it: [
							{
								ty: "gr",
								it: [
									{
										ind: 0,
										ty: "sh",
										ix: 1,
										ks: {
											a: 0,
											k: {
												i: [
													[
														19.92,
														-10.936
													],
													[
														-32.065,
														0
													],
													[
														0,
														0
													],
													[
														21.731,
														3.385
													]
												],
												o: [
													[
														0,
														0
													],
													[
														31.767,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													]
												],
												v: [
													[
														-168.996,
														-46.754
													],
													[
														-129.105,
														-36.365
													],
													[
														-89.214,
														-47.299
													],
													[
														-129.672,
														-61.147
													]
												],
												c: true
											},
											ix: 2
										},
										nm: "Path 1",
										mn: "ADBE Vector Shape - Group",
										hd: false
									},
									{
										ty: "fl",
										c: {
											a: 0,
											k: [
												1,
												0.694117665291,
												0.647058844566,
												1
											],
											ix: 4
										},
										o: {
											a: 0,
											k: 100,
											ix: 5
										},
										r: 1,
										bm: 0,
										nm: "Fill 1",
										mn: "ADBE Vector Graphic - Fill",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 1",
								np: 2,
								cix: 2,
								bm: 0,
								ix: 1,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "gr",
								it: [
									{
										ind: 0,
										ty: "sh",
										ix: 1,
										ks: {
											a: 0,
											k: {
												i: [
													[
														0,
														0
													],
													[
														10.12,
														-69.923
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														36.522,
														10.352
													]
												],
												o: [
													[
														0.94,
														-0.005
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													]
												],
												v: [
													[
														-141.929,
														-55.207
													],
													[
														-206.486,
														15.703
													],
													[
														-174.662,
														20.578
													],
													[
														-168.245,
														73.366
													],
													[
														-79.465,
														73.366
													],
													[
														-61.839,
														-24.166
													],
													[
														-110.892,
														-55.649
													]
												],
												c: true
											},
											ix: 2
										},
										nm: "Path 1",
										mn: "ADBE Vector Shape - Group",
										hd: false
									},
									{
										ty: "fl",
										c: {
											a: 0,
											k: [
												0.9686274509803922,
												0.9568627450980393,
												0.7058823529411765,
												1
											],
											ix: 4
										},
										o: {
											a: 0,
											k: 100,
											ix: 5
										},
										r: 1,
										bm: 0,
										nm: "Fill 1",
										mn: "ADBE Vector Graphic - Fill",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 2",
								np: 2,
								cix: 2,
								bm: 0,
								ix: 2,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 1",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 1,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												17.7,
												10.988
											],
											[
												-9.747,
												-2.468
											],
											[
												-2.511,
												0.89
											],
											[
												-0.791,
												6.052
											],
											[
												0,
												0
											]
										],
										o: [
											[
												0,
												0
											],
											[
												2.604,
												0.66
											],
											[
												3.669,
												-1.3
											],
											[
												0,
												0
											],
											[
												0,
												0
											]
										],
										v: [
											[
												-147.777,
												-88.294
											],
											[
												-130.108,
												-70.013
											],
											[
												-122.212,
												-70.47
											],
											[
												-113.1,
												-83.292
											],
											[
												-112.733,
												-86.749
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										0.156862750649,
										0.156862750649,
										0.156862750649,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 2",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 2,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											]
										],
										o: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											]
										],
										v: [
											[
												-115.162,
												-49.139
											],
											[
												-143.624,
												-49.139
											],
											[
												-143.624,
												-85.995
											],
											[
												-115.162,
												-85.995
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										1,
										0.694117665291,
										0.647058844566,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 3",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 3,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												-22.807,
												-142.781
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											]
										],
										o: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												22.807,
												-142.781
											]
										],
										v: [
											[
												-81.512,
												73.366
											],
											[
												-121.657,
												68.021
											],
											[
												-121.291,
												63.358
											],
											[
												-168.245,
												69.61
											],
											[
												-171.066,
												281.07
											],
											[
												-138.409,
												281.07
											],
											[
												-127.025,
												136.291
											],
											[
												-122.851,
												136.291
											],
											[
												-111.098,
												281.07
											],
											[
												-78.441,
												281.07
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										0.156862750649,
										0.156862750649,
										0.156862750649,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 4",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 4,
						mn: "ADBE Vector Group",
						hd: false
					}
				],
				ip: 0,
				op: 180,
				st: 0,
				bm: 0
			},
			{
				ddd: 0,
				ind: 7,
				ty: 4,
				nm: "hair",
				parent: 3,
				sr: 1,
				ks: {
					o: {
						a: 0,
						k: 100,
						ix: 11
					},
					r: {
						a: 1,
						k: [
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 30,
								s: [
									0
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 50,
								s: [
									11
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 75,
								s: [
									11
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 95,
								s: [
									0
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 110,
								s: [
									0
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 130,
								s: [
									11
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 157,
								s: [
									11
								]
							},
							{
								t: 179,
								s: [
									0
								]
							}
						],
						ix: 10
					},
					p: {
						a: 0,
						k: [
							-131.88,
							-153.029,
							0
						],
						ix: 2
					},
					a: {
						a: 0,
						k: [
							-131.88,
							-153.029,
							0
						],
						ix: 1
					},
					s: {
						a: 0,
						k: [
							100,
							100,
							100
						],
						ix: 6
					}
				},
				ao: 0,
				shapes: [
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												21.529,
												25.328
											],
											[
												3.697,
												10.464
											],
											[
												0,
												0
											],
											[
												16.297,
												-4.852
											],
											[
												0.332,
												-13.788
											],
											[
												8.351,
												-15.95
											],
											[
												-45.183,
												6.58
											],
											[
												0,
												0
											],
											[
												-6.657,
												0.395
											]
										],
										o: [
											[
												-5.434,
												-6.393
											],
											[
												-3.969,
												-11.233
											],
											[
												0,
												0
											],
											[
												-16.297,
												4.852
											],
											[
												-0.332,
												13.788
											],
											[
												-14.743,
												28.158
											],
											[
												0,
												0
											],
											[
												4.449,
												1.351
											],
											[
												54.279,
												-3.222
											]
										],
										v: [
											[
												-84.714,
												-121.961
											],
											[
												-98.195,
												-146.275
											],
											[
												-115.162,
												-152.942
											],
											[
												-142.288,
												-162.021
											],
											[
												-164.58,
												-131.784
											],
											[
												-184.108,
												-99.89
											],
											[
												-128.847,
												-54.594
											],
											[
												-128.786,
												-55.032
											],
											[
												-112.227,
												-53.487
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										0.156862750649,
										0.156862750649,
										0.156862750649,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 1",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 1,
						mn: "ADBE Vector Group",
						hd: false
					}
				],
				ip: 0,
				op: 180,
				st: 0,
				bm: 0
			}
		]
	},
	{
		id: "comp_2",
		layers: [
			{
				ddd: 0,
				ind: 1,
				ty: 3,
				nm: "Null 1",
				sr: 1,
				ks: {
					o: {
						a: 0,
						k: 0,
						ix: 11
					},
					r: {
						a: 0,
						k: 0,
						ix: 10
					},
					p: {
						a: 1,
						k: [
							{
								i: {
									x: 0.667,
									y: 1
								},
								o: {
									x: 0.333,
									y: 0
								},
								t: 0,
								s: [
									694.5,
									426.5,
									0
								],
								to: [
									0.833,
									0.583,
									0
								],
								ti: [
									-0.833,
									-0.583,
									0
								]
							},
							{
								i: {
									x: 0.667,
									y: 0.667
								},
								o: {
									x: 0.333,
									y: 0.333
								},
								t: 23,
								s: [
									699.5,
									430,
									0
								],
								to: [
									0,
									0,
									0
								],
								ti: [
									0,
									0,
									0
								]
							},
							{
								i: {
									x: 0.667,
									y: 1
								},
								o: {
									x: 0.333,
									y: 0
								},
								t: 52,
								s: [
									699.5,
									430,
									0
								],
								to: [
									-0.833,
									-0.583,
									0
								],
								ti: [
									0.833,
									0.583,
									0
								]
							},
							{
								i: {
									x: 0.667,
									y: 0.667
								},
								o: {
									x: 0.333,
									y: 0.333
								},
								t: 75,
								s: [
									694.5,
									426.5,
									0
								],
								to: [
									0,
									0,
									0
								],
								ti: [
									0,
									0,
									0
								]
							},
							{
								i: {
									x: 0.667,
									y: 1
								},
								o: {
									x: 0.333,
									y: 0
								},
								t: 97,
								s: [
									694.5,
									426.5,
									0
								],
								to: [
									0.833,
									0.583,
									0
								],
								ti: [
									-0.833,
									-0.583,
									0
								]
							},
							{
								i: {
									x: 0.667,
									y: 0.667
								},
								o: {
									x: 0.333,
									y: 0.333
								},
								t: 120,
								s: [
									699.5,
									430,
									0
								],
								to: [
									0,
									0,
									0
								],
								ti: [
									0,
									0,
									0
								]
							},
							{
								i: {
									x: 0.667,
									y: 1
								},
								o: {
									x: 0.333,
									y: 0
								},
								t: 142,
								s: [
									699.5,
									430,
									0
								],
								to: [
									-0.833,
									-0.583,
									0
								],
								ti: [
									0.833,
									0.583,
									0
								]
							},
							{
								t: 165,
								s: [
									694.5,
									426.5,
									0
								]
							}
						],
						ix: 2
					},
					a: {
						a: 0,
						k: [
							0,
							0,
							0
						],
						ix: 1
					},
					s: {
						a: 0,
						k: [
							39,
							39,
							100
						],
						ix: 6
					}
				},
				ao: 0,
				ip: 0,
				op: 180,
				st: 0,
				bm: 0
			},
			{
				ddd: 0,
				ind: 2,
				ty: 4,
				nm: "eye",
				parent: 1,
				sr: 1,
				ks: {
					o: {
						a: 0,
						k: 100,
						ix: 11
					},
					r: {
						a: 0,
						k: 0,
						ix: 10
					},
					p: {
						a: 0,
						k: [
							31.711,
							0.496,
							0
						],
						ix: 2
					},
					a: {
						a: 0,
						k: [
							166.867,
							-113.306,
							0
						],
						ix: 1
					},
					s: {
						a: 0,
						k: [
							256.41,
							256.41,
							100
						],
						ix: 6
					}
				},
				ao: 0,
				shapes: [
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												-1.484
											],
											[
												1.488,
												0
											],
											[
												0,
												1.484
											],
											[
												-1.488,
												0
											]
										],
										o: [
											[
												0,
												1.484
											],
											[
												-1.488,
												0
											],
											[
												0,
												-1.484
											],
											[
												1.488,
												0
											]
										],
										v: [
											[
												169.561,
												-113.306
											],
											[
												166.867,
												-110.62
											],
											[
												164.173,
												-113.306
											],
											[
												166.867,
												-115.993
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										0.156862750649,
										0.156862750649,
										0.156862750649,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 1",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 1,
						mn: "ADBE Vector Group",
						hd: false
					}
				],
				ip: 0,
				op: 180,
				st: 0,
				bm: 0
			},
			{
				ddd: 0,
				ind: 3,
				ty: 4,
				nm: "eye 2",
				parent: 1,
				sr: 1,
				ks: {
					o: {
						a: 0,
						k: 100,
						ix: 11
					},
					r: {
						a: 0,
						k: 0,
						ix: 10
					},
					p: {
						a: 0,
						k: [
							-33.77,
							0.496,
							0
						],
						ix: 2
					},
					a: {
						a: 0,
						k: [
							141.33,
							-113.306,
							0
						],
						ix: 1
					},
					s: {
						a: 0,
						k: [
							256.41,
							256.41,
							100
						],
						ix: 6
					}
				},
				ao: 0,
				shapes: [
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												-1.484
											],
											[
												1.488,
												0
											],
											[
												0,
												1.484
											],
											[
												-1.488,
												0
											]
										],
										o: [
											[
												0,
												1.484
											],
											[
												-1.488,
												0
											],
											[
												0,
												-1.484
											],
											[
												1.488,
												0
											]
										],
										v: [
											[
												144.024,
												-113.306
											],
											[
												141.33,
												-110.62
											],
											[
												138.636,
												-113.306
											],
											[
												141.33,
												-115.993
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										0.156862750649,
										0.156862750649,
										0.156862750649,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 1",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 1,
						mn: "ADBE Vector Group",
						hd: false
					}
				],
				ip: 0,
				op: 180,
				st: 0,
				bm: 0
			},
			{
				ddd: 0,
				ind: 4,
				ty: 4,
				nm: "Group 5",
				parent: 1,
				sr: 1,
				ks: {
					o: {
						a: 0,
						k: 100,
						ix: 11
					},
					r: {
						a: 0,
						k: 0,
						ix: 10
					},
					p: {
						a: 0,
						k: [
							-0.571,
							3.173,
							0
						],
						ix: 2
					},
					a: {
						a: 0,
						k: [
							154.277,
							-112.263,
							0
						],
						ix: 1
					},
					s: {
						a: 0,
						k: [
							256.41,
							256.41,
							100
						],
						ix: 6
					}
				},
				ao: 0,
				shapes: [
					{
						ty: "gr",
						it: [
							{
								ty: "gr",
								it: [
									{
										ind: 0,
										ty: "sh",
										ix: 1,
										ks: {
											a: 0,
											k: {
												i: [
													[
														0,
														0
													],
													[
														0,
														0
													]
												],
												o: [
													[
														0,
														0
													],
													[
														0,
														0
													]
												],
												v: [
													[
														179.792,
														-112.263
													],
													[
														183.422,
														-112.354
													]
												],
												c: false
											},
											ix: 2
										},
										nm: "Path 1",
										mn: "ADBE Vector Shape - Group",
										hd: false
									},
									{
										ty: "st",
										c: {
											a: 0,
											k: [
												0.8941176470588236,
												0.4666666666666667,
												0.3764705882352941,
												1
											],
											ix: 3
										},
										o: {
											a: 0,
											k: 100,
											ix: 4
										},
										w: {
											a: 0,
											k: 1.342,
											ix: 5
										},
										lc: 1,
										lj: 1,
										ml: 10,
										bm: 0,
										nm: "Stroke 1",
										mn: "ADBE Vector Graphic - Stroke",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 1",
								np: 2,
								cix: 2,
								bm: 0,
								ix: 1,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "gr",
								it: [
									{
										ind: 0,
										ty: "sh",
										ix: 1,
										ks: {
											a: 0,
											k: {
												i: [
													[
														0,
														0
													],
													[
														0,
														0
													]
												],
												o: [
													[
														0,
														0
													],
													[
														0,
														0
													]
												],
												v: [
													[
														128.742,
														-112.263
													],
													[
														125.133,
														-112.354
													]
												],
												c: false
											},
											ix: 2
										},
										nm: "Path 1",
										mn: "ADBE Vector Shape - Group",
										hd: false
									},
									{
										ty: "st",
										c: {
											a: 0,
											k: [
												0.8941176470588236,
												0.4666666666666667,
												0.3764705882352941,
												1
											],
											ix: 3
										},
										o: {
											a: 0,
											k: 100,
											ix: 4
										},
										w: {
											a: 0,
											k: 1.342,
											ix: 5
										},
										lc: 1,
										lj: 1,
										ml: 10,
										bm: 0,
										nm: "Stroke 1",
										mn: "ADBE Vector Graphic - Stroke",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 2",
								np: 2,
								cix: 2,
								bm: 0,
								ix: 2,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "gr",
								it: [
									{
										ind: 0,
										ty: "sh",
										ix: 1,
										ks: {
											a: 0,
											k: {
												i: [
													[
														0,
														0
													],
													[
														-2.517,
														-2.532
													]
												],
												o: [
													[
														0,
														0
													],
													[
														0,
														0
													]
												],
												v: [
													[
														151.651,
														-112.263
													],
													[
														156.882,
														-112.263
													]
												],
												c: false
											},
											ix: 2
										},
										nm: "Path 1",
										mn: "ADBE Vector Shape - Group",
										hd: false
									},
									{
										ty: "st",
										c: {
											a: 0,
											k: [
												0.8941176470588236,
												0.4666666666666667,
												0.3764705882352941,
												1
											],
											ix: 3
										},
										o: {
											a: 0,
											k: 100,
											ix: 4
										},
										w: {
											a: 0,
											k: 1.342,
											ix: 5
										},
										lc: 1,
										lj: 1,
										ml: 10,
										bm: 0,
										nm: "Stroke 1",
										mn: "ADBE Vector Graphic - Stroke",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 3",
								np: 2,
								cix: 2,
								bm: 0,
								ix: 3,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "gr",
								it: [
									{
										ind: 0,
										ty: "sh",
										ix: 1,
										ks: {
											a: 0,
											k: {
												i: [
													[
														0,
														-6.326
													],
													[
														6.326,
														0
													],
													[
														0,
														6.326
													],
													[
														-6.326,
														0
													]
												],
												o: [
													[
														0,
														6.326
													],
													[
														-6.326,
														0
													],
													[
														0,
														-6.326
													],
													[
														6.326,
														0
													]
												],
												v: [
													[
														179.792,
														-112.263
													],
													[
														168.337,
														-100.808
													],
													[
														156.882,
														-112.263
													],
													[
														168.337,
														-123.718
													]
												],
												c: true
											},
											ix: 2
										},
										nm: "Path 1",
										mn: "ADBE Vector Shape - Group",
										hd: false
									},
									{
										ty: "st",
										c: {
											a: 0,
											k: [
												0.8941176470588236,
												0.4666666666666667,
												0.3764705882352941,
												1
											],
											ix: 3
										},
										o: {
											a: 0,
											k: 100,
											ix: 4
										},
										w: {
											a: 0,
											k: 1.342,
											ix: 5
										},
										lc: 1,
										lj: 1,
										ml: 10,
										bm: 0,
										nm: "Stroke 1",
										mn: "ADBE Vector Graphic - Stroke",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 4",
								np: 2,
								cix: 2,
								bm: 0,
								ix: 4,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "gr",
								it: [
									{
										ind: 0,
										ty: "sh",
										ix: 1,
										ks: {
											a: 0,
											k: {
												i: [
													[
														0,
														-6.326
													],
													[
														6.326,
														0
													],
													[
														0,
														6.326
													],
													[
														-6.326,
														0
													]
												],
												o: [
													[
														0,
														6.326
													],
													[
														-6.326,
														0
													],
													[
														0,
														-6.326
													],
													[
														6.326,
														0
													]
												],
												v: [
													[
														151.651,
														-112.263
													],
													[
														140.196,
														-100.808
													],
													[
														128.742,
														-112.263
													],
													[
														140.196,
														-123.718
													]
												],
												c: true
											},
											ix: 2
										},
										nm: "Path 1",
										mn: "ADBE Vector Shape - Group",
										hd: false
									},
									{
										ty: "st",
										c: {
											a: 0,
											k: [
												0.8941176470588236,
												0.4666666666666667,
												0.3764705882352941,
												1
											],
											ix: 3
										},
										o: {
											a: 0,
											k: 100,
											ix: 4
										},
										w: {
											a: 0,
											k: 1.342,
											ix: 5
										},
										lc: 1,
										lj: 1,
										ml: 10,
										bm: 0,
										nm: "Stroke 1",
										mn: "ADBE Vector Graphic - Stroke",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 5",
								np: 2,
								cix: 2,
								bm: 0,
								ix: 5,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 5",
						np: 5,
						cix: 2,
						bm: 0,
						ix: 1,
						mn: "ADBE Vector Group",
						hd: false
					}
				],
				ip: 0,
				op: 180,
				st: 0,
				bm: 0
			},
			{
				ddd: 0,
				ind: 5,
				ty: 4,
				nm: "Group 6",
				parent: 1,
				sr: 1,
				ks: {
					o: {
						a: 0,
						k: 100,
						ix: 11
					},
					r: {
						a: 0,
						k: 0,
						ix: 10
					},
					p: {
						a: 0,
						k: [
							-0.231,
							48.913,
							0
						],
						ix: 2
					},
					a: {
						a: 0,
						k: [
							154.41,
							-94.424,
							0
						],
						ix: 1
					},
					s: {
						a: 0,
						k: [
							256.41,
							256.41,
							100
						],
						ix: 6
					}
				},
				ao: 0,
				shapes: [
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												11.566,
												11.2
											],
											[
												0,
												0
											]
										],
										o: [
											[
												0,
												0
											],
											[
												0,
												0
											]
										],
										v: [
											[
												144.024,
												-96.913
											],
											[
												164.796,
												-96.913
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										1,
										1,
										1,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 6",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 1,
						mn: "ADBE Vector Group",
						hd: false
					}
				],
				ip: 0,
				op: 180,
				st: 0,
				bm: 0
			},
			{
				ddd: 0,
				ind: 6,
				ty: 4,
				nm: "Group 8",
				parent: 1,
				sr: 1,
				ks: {
					o: {
						a: 0,
						k: 100,
						ix: 11
					},
					r: {
						a: 0,
						k: 0,
						ix: 10
					},
					p: {
						a: 0,
						k: [
							-38.688,
							-27.586,
							0
						],
						ix: 2
					},
					a: {
						a: 0,
						k: [
							139.412,
							-124.258,
							0
						],
						ix: 1
					},
					s: {
						a: 0,
						k: [
							256.41,
							256.41,
							100
						],
						ix: 6
					}
				},
				ao: 0,
				shapes: [
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												-6.534,
												1.477
											]
										],
										o: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												6.534,
												-1.477
											]
										],
										v: [
											[
												147.398,
												-125.04
											],
											[
												131.426,
												-121.296
											],
											[
												138.686,
												-126.838
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										0.156862750649,
										0.156862750649,
										0.156862750649,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 8",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 1,
						mn: "ADBE Vector Group",
						hd: false
					}
				],
				ip: 0,
				op: 180,
				st: 0,
				bm: 0
			},
			{
				ddd: 0,
				ind: 7,
				ty: 4,
				nm: "Group 7",
				parent: 1,
				sr: 1,
				ks: {
					o: {
						a: 0,
						k: 100,
						ix: 11
					},
					r: {
						a: 0,
						k: 0,
						ix: 10
					},
					p: {
						a: 0,
						k: [
							37.913,
							-27.586,
							0
						],
						ix: 2
					},
					a: {
						a: 0,
						k: [
							169.286,
							-124.258,
							0
						],
						ix: 1
					},
					s: {
						a: 0,
						k: [
							256.41,
							256.41,
							100
						],
						ix: 6
					}
				},
				ao: 0,
				shapes: [
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												6.309,
												1.477
											]
										],
										o: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												-6.309,
												-1.477
											]
										],
										v: [
											[
												161.575,
												-125.04
											],
											[
												176.998,
												-121.296
											],
											[
												169.987,
												-126.838
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										0.156862750649,
										0.156862750649,
										0.156862750649,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 7",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 1,
						mn: "ADBE Vector Group",
						hd: false
					}
				],
				ip: 0,
				op: 180,
				st: 0,
				bm: 0
			},
			{
				ddd: 0,
				ind: 8,
				ty: 4,
				nm: "Group 9",
				parent: 1,
				sr: 1,
				ks: {
					o: {
						a: 0,
						k: 100,
						ix: 11
					},
					r: {
						a: 0,
						k: 0,
						ix: 10
					},
					p: {
						a: 0,
						k: [
							0.602,
							21.719,
							0
						],
						ix: 2
					},
					a: {
						a: 0,
						k: [
							154.735,
							-105.03,
							0
						],
						ix: 1
					},
					s: {
						a: 0,
						k: [
							256.41,
							256.41,
							100
						],
						ix: 6
					}
				},
				ao: 0,
				shapes: [
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												-0.091,
												-0.227
											],
											[
												-0.929,
												0.246
											],
											[
												0,
												0
											]
										],
										o: [
											[
												0,
												0
											],
											[
												0,
												0.258
											],
											[
												0.357,
												0.89
											],
											[
												0,
												0
											],
											[
												0,
												0
											]
										],
										v: [
											[
												152.508,
												-108.144
											],
											[
												152.508,
												-103.787
											],
											[
												152.649,
												-103.055
											],
											[
												154.963,
												-101.984
											],
											[
												156.961,
												-102.514
											]
										],
										c: false
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "st",
								c: {
									a: 0,
									k: [
										0.156862750649,
										0.156862750649,
										0.156862750649,
										1
									],
									ix: 3
								},
								o: {
									a: 0,
									k: 100,
									ix: 4
								},
								w: {
									a: 0,
									k: 1.232,
									ix: 5
								},
								lc: 2,
								lj: 2,
								bm: 0,
								nm: "Stroke 1",
								mn: "ADBE Vector Graphic - Stroke",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 9",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 1,
						mn: "ADBE Vector Group",
						hd: false
					}
				],
				ip: 0,
				op: 180,
				st: 0,
				bm: 0
			},
			{
				ddd: 0,
				ind: 9,
				ty: 4,
				nm: "hair",
				sr: 1,
				ks: {
					o: {
						a: 0,
						k: 100,
						ix: 11
					},
					r: {
						a: 0,
						k: 0,
						ix: 10
					},
					p: {
						a: 1,
						k: [
							{
								i: {
									x: 0.667,
									y: 1
								},
								o: {
									x: 0.333,
									y: 0
								},
								t: 0,
								s: [
									713.107,
									393.671,
									0
								],
								to: [
									0,
									0,
									0
								],
								ti: [
									0,
									0,
									0
								]
							},
							{
								i: {
									x: 0.667,
									y: 1
								},
								o: {
									x: 0.333,
									y: 0
								},
								t: 23,
								s: [
									674.107,
									385.171,
									0
								],
								to: [
									0,
									0,
									0
								],
								ti: [
									0,
									0,
									0
								]
							},
							{
								i: {
									x: 0.667,
									y: 1
								},
								o: {
									x: 0.333,
									y: 0
								},
								t: 52,
								s: [
									674.107,
									385.171,
									0
								],
								to: [
									0,
									0,
									0
								],
								ti: [
									0,
									0,
									0
								]
							},
							{
								i: {
									x: 0.667,
									y: 0.667
								},
								o: {
									x: 0.333,
									y: 0.333
								},
								t: 75,
								s: [
									713.107,
									393.671,
									0
								],
								to: [
									0,
									0,
									0
								],
								ti: [
									0,
									0,
									0
								]
							},
							{
								i: {
									x: 0.667,
									y: 1
								},
								o: {
									x: 0.333,
									y: 0
								},
								t: 97,
								s: [
									713.107,
									393.671,
									0
								],
								to: [
									0,
									0,
									0
								],
								ti: [
									0,
									0,
									0
								]
							},
							{
								i: {
									x: 0.667,
									y: 0.667
								},
								o: {
									x: 0.333,
									y: 0.333
								},
								t: 120,
								s: [
									674.107,
									385.171,
									0
								],
								to: [
									0,
									0,
									0
								],
								ti: [
									0,
									0,
									0
								]
							},
							{
								i: {
									x: 0.667,
									y: 1
								},
								o: {
									x: 0.333,
									y: 0
								},
								t: 142,
								s: [
									674.107,
									385.171,
									0
								],
								to: [
									0,
									0,
									0
								],
								ti: [
									0,
									0,
									0
								]
							},
							{
								t: 165,
								s: [
									713.107,
									393.671,
									0
								]
							}
						],
						ix: 2
					},
					a: {
						a: 0,
						k: [
							173.107,
							-146.329,
							0
						],
						ix: 1
					},
					s: {
						a: 0,
						k: [
							100,
							100,
							100
						],
						ix: 6
					}
				},
				ao: 0,
				shapes: [
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												-11.904
											],
											[
												11.904,
												0
											],
											[
												0,
												11.904
											],
											[
												-11.904,
												0
											]
										],
										o: [
											[
												0,
												11.904
											],
											[
												-11.904,
												0
											],
											[
												0,
												-11.904
											],
											[
												11.904,
												0
											]
										],
										v: [
											[
												203.161,
												-164.829
											],
											[
												181.607,
												-143.275
											],
											[
												160.053,
												-164.829
											],
											[
												181.607,
												-186.383
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										0.156862750649,
										0.156862750649,
										0.156862750649,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 1",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 1,
						mn: "ADBE Vector Group",
						hd: false
					}
				],
				ip: 0,
				op: 180,
				st: 0,
				bm: 0
			},
			{
				ddd: 0,
				ind: 10,
				ty: 4,
				nm: "head",
				sr: 1,
				ks: {
					o: {
						a: 0,
						k: 100,
						ix: 11
					},
					r: {
						a: 0,
						k: 0,
						ix: 10
					},
					p: {
						a: 0,
						k: [
							699.88,
							409.735,
							0
						],
						ix: 2
					},
					a: {
						a: 0,
						k: [
							159.88,
							-130.265,
							0
						],
						ix: 1
					},
					s: {
						a: 0,
						k: [
							100,
							100,
							100
						],
						ix: 6
					}
				},
				ao: 0,
				shapes: [
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 1,
									k: [
										{
											i: {
												x: 0.667,
												y: 1
											},
											o: {
												x: 0.333,
												y: 0
											},
											t: 0,
											s: [
												{
													i: [
														[
															-7.592,
															-17.374
														],
														[
															45.143,
															3.092
														],
														[
															-21.877,
															2.823
														]
													],
													o: [
														[
															0,
															0
														],
														[
															0,
															0
														],
														[
															0,
															0
														]
													],
													v: [
														[
															182.765,
															-143.713
														],
														[
															121.123,
															-128.742
														],
														[
															149.913,
															-158.071
														]
													],
													c: true
												}
											]
										},
										{
											i: {
												x: 0.667,
												y: 1
											},
											o: {
												x: 0.333,
												y: 0
											},
											t: 23,
											s: [
												{
													i: [
														[
															-7.592,
															-17.374
														],
														[
															45.143,
															3.092
														],
														[
															-23.116,
															1.997
														]
													],
													o: [
														[
															0,
															0
														],
														[
															-0.385,
															-0.257
														],
														[
															0,
															0
														]
													],
													v: [
														[
															181.89,
															-143.338
														],
														[
															124.748,
															-125.117
														],
														[
															149.038,
															-157.696
														]
													],
													c: true
												}
											]
										},
										{
											i: {
												x: 0.667,
												y: 1
											},
											o: {
												x: 0.333,
												y: 0
											},
											t: 52,
											s: [
												{
													i: [
														[
															-7.592,
															-17.374
														],
														[
															45.143,
															3.092
														],
														[
															-23.116,
															1.997
														]
													],
													o: [
														[
															0,
															0
														],
														[
															-0.385,
															-0.257
														],
														[
															0,
															0
														]
													],
													v: [
														[
															181.89,
															-143.338
														],
														[
															124.748,
															-125.117
														],
														[
															149.038,
															-157.696
														]
													],
													c: true
												}
											]
										},
										{
											i: {
												x: 0.667,
												y: 1
											},
											o: {
												x: 0.333,
												y: 0
											},
											t: 75,
											s: [
												{
													i: [
														[
															-7.592,
															-17.374
														],
														[
															45.143,
															3.092
														],
														[
															-21.877,
															2.823
														]
													],
													o: [
														[
															0,
															0
														],
														[
															0,
															0
														],
														[
															0,
															0
														]
													],
													v: [
														[
															182.765,
															-143.713
														],
														[
															121.123,
															-128.742
														],
														[
															149.913,
															-158.071
														]
													],
													c: true
												}
											]
										},
										{
											i: {
												x: 0.667,
												y: 1
											},
											o: {
												x: 0.333,
												y: 0
											},
											t: 97,
											s: [
												{
													i: [
														[
															-7.592,
															-17.374
														],
														[
															45.143,
															3.092
														],
														[
															-21.877,
															2.823
														]
													],
													o: [
														[
															0,
															0
														],
														[
															0,
															0
														],
														[
															0,
															0
														]
													],
													v: [
														[
															182.765,
															-143.713
														],
														[
															121.123,
															-128.742
														],
														[
															149.913,
															-158.071
														]
													],
													c: true
												}
											]
										},
										{
											i: {
												x: 0.667,
												y: 1
											},
											o: {
												x: 0.333,
												y: 0
											},
											t: 120,
											s: [
												{
													i: [
														[
															-7.592,
															-17.374
														],
														[
															45.143,
															3.092
														],
														[
															-23.116,
															1.997
														]
													],
													o: [
														[
															0,
															0
														],
														[
															-0.385,
															-0.257
														],
														[
															0,
															0
														]
													],
													v: [
														[
															181.89,
															-143.338
														],
														[
															124.748,
															-125.117
														],
														[
															149.038,
															-157.696
														]
													],
													c: true
												}
											]
										},
										{
											i: {
												x: 0.667,
												y: 1
											},
											o: {
												x: 0.333,
												y: 0
											},
											t: 142,
											s: [
												{
													i: [
														[
															-7.592,
															-17.374
														],
														[
															45.143,
															3.092
														],
														[
															-23.116,
															1.997
														]
													],
													o: [
														[
															0,
															0
														],
														[
															-0.385,
															-0.257
														],
														[
															0,
															0
														]
													],
													v: [
														[
															181.89,
															-143.338
														],
														[
															124.748,
															-125.117
														],
														[
															149.038,
															-157.696
														]
													],
													c: true
												}
											]
										},
										{
											t: 165,
											s: [
												{
													i: [
														[
															-7.592,
															-17.374
														],
														[
															45.143,
															3.092
														],
														[
															-21.877,
															2.823
														]
													],
													o: [
														[
															0,
															0
														],
														[
															0,
															0
														],
														[
															0,
															0
														]
													],
													v: [
														[
															182.765,
															-143.713
														],
														[
															121.123,
															-128.742
														],
														[
															149.913,
															-158.071
														]
													],
													c: true
												}
											]
										}
									],
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										0.156862750649,
										0.156862750649,
										0.156862750649,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 2",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 1,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 1,
									k: [
										{
											i: {
												x: 0.667,
												y: 1
											},
											o: {
												x: 0.333,
												y: 0
											},
											t: 0,
											s: [
												{
													i: [
														[
															0,
															0
														],
														[
															2.964,
															17.599
														],
														[
															2.484,
															-12.388
														]
													],
													o: [
														[
															0,
															0
														],
														[
															0,
															0
														],
														[
															-2.484,
															12.388
														]
													],
													v: [
														[
															124.64,
															-114.497
														],
														[
															136.603,
															-151.826
														],
														[
															123.766,
															-133.457
														]
													],
													c: true
												}
											]
										},
										{
											i: {
												x: 0.667,
												y: 1
											},
											o: {
												x: 0.333,
												y: 0
											},
											t: 23,
											s: [
												{
													i: [
														[
															0,
															0
														],
														[
															2.964,
															17.599
														],
														[
															4.234,
															-17.231
														]
													],
													o: [
														[
															0,
															0
														],
														[
															0,
															0
														],
														[
															-3.015,
															12.27
														]
													],
													v: [
														[
															126.015,
															-108.622
														],
														[
															136.603,
															-151.826
														],
														[
															123.766,
															-133.457
														]
													],
													c: true
												}
											]
										},
										{
											i: {
												x: 0.667,
												y: 1
											},
											o: {
												x: 0.333,
												y: 0
											},
											t: 52,
											s: [
												{
													i: [
														[
															0,
															0
														],
														[
															2.964,
															17.599
														],
														[
															4.234,
															-17.231
														]
													],
													o: [
														[
															0,
															0
														],
														[
															0,
															0
														],
														[
															-3.015,
															12.27
														]
													],
													v: [
														[
															126.015,
															-108.622
														],
														[
															136.603,
															-151.826
														],
														[
															123.766,
															-133.457
														]
													],
													c: true
												}
											]
										},
										{
											i: {
												x: 0.667,
												y: 1
											},
											o: {
												x: 0.333,
												y: 0
											},
											t: 75,
											s: [
												{
													i: [
														[
															0,
															0
														],
														[
															2.964,
															17.599
														],
														[
															2.484,
															-12.388
														]
													],
													o: [
														[
															0,
															0
														],
														[
															0,
															0
														],
														[
															-2.484,
															12.388
														]
													],
													v: [
														[
															124.64,
															-114.497
														],
														[
															136.603,
															-151.826
														],
														[
															123.766,
															-133.457
														]
													],
													c: true
												}
											]
										},
										{
											i: {
												x: 0.667,
												y: 1
											},
											o: {
												x: 0.333,
												y: 0
											},
											t: 97,
											s: [
												{
													i: [
														[
															0,
															0
														],
														[
															2.964,
															17.599
														],
														[
															2.484,
															-12.388
														]
													],
													o: [
														[
															0,
															0
														],
														[
															0,
															0
														],
														[
															-2.484,
															12.388
														]
													],
													v: [
														[
															124.64,
															-114.497
														],
														[
															136.603,
															-151.826
														],
														[
															123.766,
															-133.457
														]
													],
													c: true
												}
											]
										},
										{
											i: {
												x: 0.667,
												y: 1
											},
											o: {
												x: 0.333,
												y: 0
											},
											t: 120,
											s: [
												{
													i: [
														[
															0,
															0
														],
														[
															2.964,
															17.599
														],
														[
															4.234,
															-17.231
														]
													],
													o: [
														[
															0,
															0
														],
														[
															0,
															0
														],
														[
															-3.015,
															12.27
														]
													],
													v: [
														[
															126.015,
															-108.622
														],
														[
															136.603,
															-151.826
														],
														[
															123.766,
															-133.457
														]
													],
													c: true
												}
											]
										},
										{
											i: {
												x: 0.667,
												y: 1
											},
											o: {
												x: 0.333,
												y: 0
											},
											t: 142,
											s: [
												{
													i: [
														[
															0,
															0
														],
														[
															2.964,
															17.599
														],
														[
															4.234,
															-17.231
														]
													],
													o: [
														[
															0,
															0
														],
														[
															0,
															0
														],
														[
															-3.015,
															12.27
														]
													],
													v: [
														[
															126.015,
															-108.622
														],
														[
															136.603,
															-151.826
														],
														[
															123.766,
															-133.457
														]
													],
													c: true
												}
											]
										},
										{
											t: 165,
											s: [
												{
													i: [
														[
															0,
															0
														],
														[
															2.964,
															17.599
														],
														[
															2.484,
															-12.388
														]
													],
													o: [
														[
															0,
															0
														],
														[
															0,
															0
														],
														[
															-2.484,
															12.388
														]
													],
													v: [
														[
															124.64,
															-114.497
														],
														[
															136.603,
															-151.826
														],
														[
															123.766,
															-133.457
														]
													],
													c: true
												}
											]
										}
									],
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										0.156862750649,
										0.156862750649,
										0.156862750649,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 3",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 2,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												0
											],
											[
												-2.964,
												17.599
											],
											[
												-2.484,
												-12.388
											]
										],
										o: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												2.484,
												12.388
											]
										],
										v: [
											[
												183.843,
												-115.674
											],
											[
												173.957,
												-150.644
											],
											[
												185.979,
												-133.457
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										0.156862750649,
										0.156862750649,
										0.156862750649,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 4",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 3,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												0
											],
											[
												-1.759,
												-7.639
											],
											[
												-6.849,
												-4.207
											],
											[
												0,
												0
											],
											[
												-7.358,
												4.29
											],
											[
												0,
												0
											],
											[
												-1.599,
												8.025
											],
											[
												0,
												0
											],
											[
												32.14,
												-0.612
											]
										],
										o: [
											[
												0,
												12.472
											],
											[
												1.722,
												7.479
											],
											[
												0,
												0
											],
											[
												7.246,
												4.451
											],
											[
												0,
												0
											],
											[
												7.421,
												-4.326
											],
											[
												2.908,
												-14.597
											],
											[
												0,
												0
											],
											[
												-32.139,
												0.612
											]
										],
										v: [
											[
												124.661,
												-126.113
											],
											[
												128.183,
												-95.238
											],
											[
												141.6,
												-78.326
											],
											[
												142.848,
												-77.559
											],
											[
												166.815,
												-77.294
											],
											[
												166.815,
												-77.294
											],
											[
												181.03,
												-95.349
											],
											[
												184.257,
												-126.113
											],
											[
												154.884,
												-156.987
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										1,
										0.694117665291,
										0.647058844566,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 10",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 4,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "gr",
						it: [
							{
								ty: "gr",
								it: [
									{
										ind: 0,
										ty: "sh",
										ix: 1,
										ks: {
											a: 0,
											k: {
												i: [
													[
														0,
														-20.317
													],
													[
														-19.108,
														0
													],
													[
														0,
														20.317
													],
													[
														19.108,
														0
													]
												],
												o: [
													[
														0,
														20.317
													],
													[
														19.108,
														0
													],
													[
														0,
														-20.317
													],
													[
														-19.108,
														0
													]
												],
												v: [
													[
														119.959,
														-127.526
													],
													[
														154.557,
														-97.575
													],
													[
														189.156,
														-127.526
													],
													[
														154.557,
														-161.665
													]
												],
												c: true
											},
											ix: 2
										},
										nm: "Path 1",
										mn: "ADBE Vector Shape - Group",
										hd: false
									},
									{
										ty: "fl",
										c: {
											a: 0,
											k: [
												0.156862750649,
												0.156862750649,
												0.156862750649,
												1
											],
											ix: 4
										},
										o: {
											a: 0,
											k: 100,
											ix: 5
										},
										r: 1,
										bm: 0,
										nm: "Fill 1",
										mn: "ADBE Vector Graphic - Fill",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 1",
								np: 2,
								cix: 2,
								bm: 0,
								ix: 1,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 11",
						np: 1,
						cix: 2,
						bm: 0,
						ix: 5,
						mn: "ADBE Vector Group",
						hd: false
					}
				],
				ip: 0,
				op: 180,
				st: 0,
				bm: 0
			},
			{
				ddd: 0,
				ind: 11,
				ty: 4,
				nm: "ear _l",
				sr: 1,
				ks: {
					o: {
						a: 0,
						k: 100,
						ix: 11
					},
					r: {
						a: 0,
						k: 0,
						ix: 10
					},
					p: {
						a: 1,
						k: [
							{
								i: {
									x: 0.667,
									y: 1
								},
								o: {
									x: 0.333,
									y: 0
								},
								t: 0,
								s: [
									725.344,
									434.605,
									0
								],
								to: [
									0,
									0,
									0
								],
								ti: [
									0,
									0,
									0
								]
							},
							{
								i: {
									x: 0.667,
									y: 1
								},
								o: {
									x: 0.333,
									y: 0
								},
								t: 23,
								s: [
									722.344,
									434.73,
									0
								],
								to: [
									0,
									0,
									0
								],
								ti: [
									0,
									0,
									0
								]
							},
							{
								i: {
									x: 0.667,
									y: 1
								},
								o: {
									x: 0.333,
									y: 0
								},
								t: 52,
								s: [
									722.344,
									434.73,
									0
								],
								to: [
									0,
									0,
									0
								],
								ti: [
									0,
									0,
									0
								]
							},
							{
								i: {
									x: 0.667,
									y: 0.667
								},
								o: {
									x: 0.333,
									y: 0.333
								},
								t: 75,
								s: [
									725.344,
									434.605,
									0
								],
								to: [
									0,
									0,
									0
								],
								ti: [
									0,
									0,
									0
								]
							},
							{
								i: {
									x: 0.667,
									y: 1
								},
								o: {
									x: 0.333,
									y: 0
								},
								t: 97,
								s: [
									725.344,
									434.605,
									0
								],
								to: [
									0,
									0,
									0
								],
								ti: [
									0,
									0,
									0
								]
							},
							{
								i: {
									x: 0.667,
									y: 0.667
								},
								o: {
									x: 0.333,
									y: 0.333
								},
								t: 120,
								s: [
									722.344,
									434.73,
									0
								],
								to: [
									0,
									0,
									0
								],
								ti: [
									0,
									0,
									0
								]
							},
							{
								i: {
									x: 0.667,
									y: 1
								},
								o: {
									x: 0.333,
									y: 0
								},
								t: 142,
								s: [
									722.344,
									434.73,
									0
								],
								to: [
									0,
									0,
									0
								],
								ti: [
									0,
									0,
									0
								]
							},
							{
								t: 165,
								s: [
									725.344,
									434.605,
									0
								]
							}
						],
						ix: 2
					},
					a: {
						a: 0,
						k: [
							186.094,
							-105.52,
							0
						],
						ix: 1
					},
					s: {
						a: 0,
						k: [
							100,
							100,
							100
						],
						ix: 6
					}
				},
				ao: 0,
				shapes: [
					{
						ty: "gr",
						it: [
							{
								ty: "gr",
								it: [
									{
										ty: "gr",
										it: [
											{
												ty: "gr",
												it: [
													{
														ind: 0,
														ty: "sh",
														ix: 1,
														ks: {
															a: 0,
															k: {
																i: [
																	[
																		0,
																		0
																	],
																	[
																		3.403,
																		-4.624
																	]
																],
																o: [
																	[
																		0,
																		0
																	],
																	[
																		0,
																		0
																	]
																],
																v: [
																	[
																		189.416,
																		-107.197
																	],
																	[
																		182.777,
																		-104.372
																	]
																],
																c: false
															},
															ix: 2
														},
														nm: "Path 1",
														mn: "ADBE Vector Shape - Group",
														hd: false
													},
													{
														ty: "st",
														c: {
															a: 0,
															k: [
																0.156862750649,
																0.156862750649,
																0.156862750649,
																1
															],
															ix: 3
														},
														o: {
															a: 0,
															k: 100,
															ix: 4
														},
														w: {
															a: 0,
															k: 0.993,
															ix: 5
														},
														lc: 2,
														lj: 2,
														bm: 0,
														nm: "Stroke 1",
														mn: "ADBE Vector Graphic - Stroke",
														hd: false
													},
													{
														ty: "tr",
														p: {
															a: 0,
															k: [
																0,
																0
															],
															ix: 2
														},
														a: {
															a: 0,
															k: [
																0,
																0
															],
															ix: 1
														},
														s: {
															a: 0,
															k: [
																100,
																100
															],
															ix: 3
														},
														r: {
															a: 0,
															k: 0,
															ix: 6
														},
														o: {
															a: 0,
															k: 100,
															ix: 7
														},
														sk: {
															a: 0,
															k: 0,
															ix: 4
														},
														sa: {
															a: 0,
															k: 0,
															ix: 5
														},
														nm: "Transform"
													}
												],
												nm: "Group 1",
												np: 2,
												cix: 2,
												bm: 0,
												ix: 1,
												mn: "ADBE Vector Group",
												hd: false
											},
											{
												ty: "tr",
												p: {
													a: 0,
													k: [
														0,
														0
													],
													ix: 2
												},
												a: {
													a: 0,
													k: [
														0,
														0
													],
													ix: 1
												},
												s: {
													a: 0,
													k: [
														100,
														100
													],
													ix: 3
												},
												r: {
													a: 0,
													k: 0,
													ix: 6
												},
												o: {
													a: 0,
													k: 100,
													ix: 7
												},
												sk: {
													a: 0,
													k: 0,
													ix: 4
												},
												sa: {
													a: 0,
													k: 0,
													ix: 5
												},
												nm: "Transform"
											}
										],
										nm: "Group 1",
										np: 1,
										cix: 2,
										bm: 0,
										ix: 1,
										mn: "ADBE Vector Group",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 1",
								np: 1,
								cix: 2,
								bm: 0,
								ix: 1,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "gr",
								it: [
									{
										ind: 0,
										ty: "sh",
										ix: 1,
										ks: {
											a: 0,
											k: {
												i: [
													[
														0,
														0
													],
													[
														3.931,
														4.658
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													]
												],
												o: [
													[
														4.103,
														4.409
													],
													[
														-3.931,
														-4.658
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													]
												],
												v: [
													[
														180.542,
														-97.739
													],
													[
														191.952,
														-112.438
													],
													[
														184.173,
														-110.638
													],
													[
														181.868,
														-106.236
													],
													[
														179.896,
														-100.176
													],
													[
														179.415,
														-98.586
													]
												],
												c: true
											},
											ix: 2
										},
										nm: "Path 1",
										mn: "ADBE Vector Shape - Group",
										hd: false
									},
									{
										ty: "fl",
										c: {
											a: 0,
											k: [
												1,
												0.6941176470588235,
												0.6470588235294118,
												1
											],
											ix: 4
										},
										o: {
											a: 0,
											k: 100,
											ix: 5
										},
										r: 1,
										bm: 0,
										nm: "Fill 1",
										mn: "ADBE Vector Graphic - Fill",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 2",
								np: 2,
								cix: 2,
								bm: 0,
								ix: 2,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 12",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 1,
						mn: "ADBE Vector Group",
						hd: false
					}
				],
				ip: 0,
				op: 180,
				st: 0,
				bm: 0
			},
			{
				ddd: 0,
				ind: 12,
				ty: 4,
				nm: "ear_r",
				sr: 1,
				ks: {
					o: {
						a: 0,
						k: 100,
						ix: 11
					},
					r: {
						a: 0,
						k: 0,
						ix: 10
					},
					p: {
						a: 1,
						k: [
							{
								i: {
									x: 0.667,
									y: 1
								},
								o: {
									x: 0.333,
									y: 0
								},
								t: 0,
								s: [
									664.289,
									434.539,
									0
								],
								to: [
									0,
									0,
									0
								],
								ti: [
									0,
									0,
									0
								]
							},
							{
								i: {
									x: 0.667,
									y: 1
								},
								o: {
									x: 0.333,
									y: 0
								},
								t: 23,
								s: [
									662.789,
									434.539,
									0
								],
								to: [
									0,
									0,
									0
								],
								ti: [
									0,
									0,
									0
								]
							},
							{
								i: {
									x: 0.667,
									y: 1
								},
								o: {
									x: 0.333,
									y: 0
								},
								t: 52,
								s: [
									662.789,
									434.539,
									0
								],
								to: [
									0,
									0,
									0
								],
								ti: [
									0,
									0,
									0
								]
							},
							{
								i: {
									x: 0.667,
									y: 0.667
								},
								o: {
									x: 0.333,
									y: 0.333
								},
								t: 75,
								s: [
									664.289,
									434.539,
									0
								],
								to: [
									0,
									0,
									0
								],
								ti: [
									0,
									0,
									0
								]
							},
							{
								i: {
									x: 0.667,
									y: 1
								},
								o: {
									x: 0.333,
									y: 0
								},
								t: 97,
								s: [
									664.289,
									434.539,
									0
								],
								to: [
									0,
									0,
									0
								],
								ti: [
									0,
									0,
									0
								]
							},
							{
								i: {
									x: 0.667,
									y: 0.667
								},
								o: {
									x: 0.333,
									y: 0.333
								},
								t: 120,
								s: [
									662.789,
									434.539,
									0
								],
								to: [
									0,
									0,
									0
								],
								ti: [
									0,
									0,
									0
								]
							},
							{
								i: {
									x: 0.667,
									y: 1
								},
								o: {
									x: 0.333,
									y: 0
								},
								t: 142,
								s: [
									662.789,
									434.539,
									0
								],
								to: [
									0,
									0,
									0
								],
								ti: [
									0,
									0,
									0
								]
							},
							{
								t: 165,
								s: [
									664.289,
									434.539,
									0
								]
							}
						],
						ix: 2
					},
					a: {
						a: 0,
						k: [
							122.789,
							-105.461,
							0
						],
						ix: 1
					},
					s: {
						a: 0,
						k: [
							100,
							100,
							100
						],
						ix: 6
					}
				},
				ao: 0,
				shapes: [
					{
						ty: "gr",
						it: [
							{
								ty: "gr",
								it: [
									{
										ty: "gr",
										it: [
											{
												ty: "gr",
												it: [
													{
														ind: 0,
														ty: "sh",
														ix: 1,
														ks: {
															a: 0,
															k: {
																i: [
																	[
																		0,
																		0
																	],
																	[
																		-3,
																		-4.895
																	]
																],
																o: [
																	[
																		0,
																		0
																	],
																	[
																		0,
																		0
																	]
																],
																v: [
																	[
																		119.74,
																		-107.448
																	],
																	[
																		126.117,
																		-104.072
																	]
																],
																c: false
															},
															ix: 2
														},
														nm: "Path 1",
														mn: "ADBE Vector Shape - Group",
														hd: false
													},
													{
														ty: "st",
														c: {
															a: 0,
															k: [
																0.156862750649,
																0.156862750649,
																0.156862750649,
																1
															],
															ix: 3
														},
														o: {
															a: 0,
															k: 100,
															ix: 4
														},
														w: {
															a: 0,
															k: 0.993,
															ix: 5
														},
														lc: 2,
														lj: 2,
														bm: 0,
														nm: "Stroke 1",
														mn: "ADBE Vector Graphic - Stroke",
														hd: false
													},
													{
														ty: "tr",
														p: {
															a: 0,
															k: [
																0,
																0
															],
															ix: 2
														},
														a: {
															a: 0,
															k: [
																0,
																0
															],
															ix: 1
														},
														s: {
															a: 0,
															k: [
																100,
																100
															],
															ix: 3
														},
														r: {
															a: 0,
															k: 0,
															ix: 6
														},
														o: {
															a: 0,
															k: 100,
															ix: 7
														},
														sk: {
															a: 0,
															k: 0,
															ix: 4
														},
														sa: {
															a: 0,
															k: 0,
															ix: 5
														},
														nm: "Transform"
													}
												],
												nm: "Group 1",
												np: 2,
												cix: 2,
												bm: 0,
												ix: 1,
												mn: "ADBE Vector Group",
												hd: false
											},
											{
												ty: "tr",
												p: {
													a: 0,
													k: [
														0,
														0
													],
													ix: 2
												},
												a: {
													a: 0,
													k: [
														0,
														0
													],
													ix: 1
												},
												s: {
													a: 0,
													k: [
														100,
														100
													],
													ix: 3
												},
												r: {
													a: 0,
													k: 0,
													ix: 6
												},
												o: {
													a: 0,
													k: 100,
													ix: 7
												},
												sk: {
													a: 0,
													k: 0,
													ix: 4
												},
												sa: {
													a: 0,
													k: 0,
													ix: 5
												},
												nm: "Transform"
											}
										],
										nm: "Group 1",
										np: 1,
										cix: 2,
										bm: 0,
										ix: 1,
										mn: "ADBE Vector Group",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 1",
								np: 1,
								cix: 2,
								bm: 0,
								ix: 1,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "gr",
								it: [
									{
										ind: 0,
										ty: "sh",
										ix: 1,
										ks: {
											a: 0,
											k: {
												i: [
													[
														0,
														0
													],
													[
														-4.311,
														4.309
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													]
												],
												o: [
													[
														-4.461,
														4.046
													],
													[
														4.311,
														-4.309
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													]
												],
												v: [
													[
														127.783,
														-97.274
													],
													[
														117.657,
														-112.885
													],
													[
														125.256,
														-110.433
													],
													[
														127.181,
														-105.852
													],
													[
														128.633,
														-99.647
													],
													[
														128.978,
														-98.022
													]
												],
												c: true
											},
											ix: 2
										},
										nm: "Path 1",
										mn: "ADBE Vector Shape - Group",
										hd: false
									},
									{
										ty: "fl",
										c: {
											a: 0,
											k: [
												1,
												0.6941176470588235,
												0.6470588235294118,
												1
											],
											ix: 4
										},
										o: {
											a: 0,
											k: 100,
											ix: 5
										},
										r: 1,
										bm: 0,
										nm: "Fill 1",
										mn: "ADBE Vector Graphic - Fill",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 2",
								np: 2,
								cix: 2,
								bm: 0,
								ix: 2,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 13",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 1,
						mn: "ADBE Vector Group",
						hd: false
					}
				],
				ip: 0,
				op: 180,
				st: 0,
				bm: 0
			},
			{
				ddd: 0,
				ind: 13,
				ty: 4,
				nm: "body",
				sr: 1,
				ks: {
					o: {
						a: 0,
						k: 100,
						ix: 11
					},
					r: {
						a: 0,
						k: 0,
						ix: 10
					},
					p: {
						a: 0,
						k: [
							701.28,
							639.083,
							0
						],
						ix: 2
					},
					a: {
						a: 0,
						k: [
							161.28,
							99.083,
							0
						],
						ix: 1
					},
					s: {
						a: 0,
						k: [
							100,
							100,
							100
						],
						ix: 6
					}
				},
				ao: 0,
				shapes: [
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												0
											],
											[
												-13.645,
												1.172
											],
											[
												0,
												0
											]
										],
										o: [
											[
												0,
												0
											],
											[
												12.541,
												-1.077
											],
											[
												0,
												0
											]
										],
										v: [
											[
												140.196,
												-79.223
											],
											[
												158.954,
												-66.822
											],
											[
												169.499,
												-86.709
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										0.156862750649,
										0.156862750649,
										0.156862750649,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 1",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 1,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												5.183,
												1.291
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												3.765,
												-1.789
											],
											[
												0,
												0
											],
											[
												0,
												0
											]
										],
										o: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												-1.456,
												0.435
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											]
										],
										v: [
											[
												168.922,
												-57.902
											],
											[
												168.922,
												-82.19
											],
											[
												140.46,
												-82.19
											],
											[
												140.46,
												-57.617
											],
											[
												132.814,
												-54.516
											],
											[
												155.013,
												-41.292
											],
											[
												177.707,
												-54.517
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										1,
										0.694117665291,
										0.647058844566,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 2",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 2,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "gr",
						it: [
							{
								ty: "gr",
								it: [
									{
										ty: "gr",
										it: [
											{
												ind: 0,
												ty: "sh",
												ix: 1,
												ks: {
													a: 0,
													k: {
														i: [
															[
																0,
																0
															],
															[
																0,
																0
															]
														],
														o: [
															[
																0,
																0
															],
															[
																0,
																0
															]
														],
														v: [
															[
																201.779,
																24.384
															],
															[
																204.542,
																-6.146
															]
														],
														c: false
													},
													ix: 2
												},
												nm: "Path 1",
												mn: "ADBE Vector Shape - Group",
												hd: false
											},
											{
												ty: "st",
												c: {
													a: 0,
													k: [
														0.156862750649,
														0.156862750649,
														0.156862750649,
														1
													],
													ix: 3
												},
												o: {
													a: 0,
													k: 100,
													ix: 4
												},
												w: {
													a: 0,
													k: 1.233,
													ix: 5
												},
												lc: 2,
												lj: 2,
												bm: 0,
												nm: "Stroke 1",
												mn: "ADBE Vector Graphic - Stroke",
												hd: false
											},
											{
												ty: "tr",
												p: {
													a: 0,
													k: [
														0,
														0
													],
													ix: 2
												},
												a: {
													a: 0,
													k: [
														0,
														0
													],
													ix: 1
												},
												s: {
													a: 0,
													k: [
														100,
														100
													],
													ix: 3
												},
												r: {
													a: 0,
													k: 0,
													ix: 6
												},
												o: {
													a: 0,
													k: 100,
													ix: 7
												},
												sk: {
													a: 0,
													k: 0,
													ix: 4
												},
												sa: {
													a: 0,
													k: 0,
													ix: 5
												},
												nm: "Transform"
											}
										],
										nm: "Group 1",
										np: 2,
										cix: 2,
										bm: 0,
										ix: 1,
										mn: "ADBE Vector Group",
										hd: false
									},
									{
										ty: "gr",
										it: [
											{
												ind: 0,
												ty: "sh",
												ix: 1,
												ks: {
													a: 0,
													k: {
														i: [
															[
																0,
																0
															],
															[
																-10.12,
																-69.924
															],
															[
																0,
																0
															],
															[
																0,
																0
															],
															[
																0,
																0
															],
															[
																0,
																0
															],
															[
																-36.522,
																10.352
															]
														],
														o: [
															[
																-0.94,
																-0.005
															],
															[
																0,
																0
															],
															[
																0,
																0
															],
															[
																0,
																0
															],
															[
																0,
																0
															],
															[
																0,
																0
															],
															[
																0,
																0
															]
														],
														v: [
															[
																163.094,
																-58.902
															],
															[
																233.604,
																19.508
															],
															[
																201.779,
																24.384
															],
															[
																195.363,
																77.172
															],
															[
																106.583,
																77.172
															],
															[
																88.957,
																-20.36
															],
															[
																145.148,
																-58.902
															]
														],
														c: true
													},
													ix: 2
												},
												nm: "Path 1",
												mn: "ADBE Vector Shape - Group",
												hd: false
											},
											{
												ty: "fl",
												c: {
													a: 0,
													k: [
														0.337254911661,
														0.874509811401,
														0.929411768913,
														1
													],
													ix: 4
												},
												o: {
													a: 0,
													k: 100,
													ix: 5
												},
												r: 1,
												bm: 0,
												nm: "Fill 1",
												mn: "ADBE Vector Graphic - Fill",
												hd: false
											},
											{
												ty: "tr",
												p: {
													a: 0,
													k: [
														0,
														0
													],
													ix: 2
												},
												a: {
													a: 0,
													k: [
														0,
														0
													],
													ix: 1
												},
												s: {
													a: 0,
													k: [
														100,
														100
													],
													ix: 3
												},
												r: {
													a: 0,
													k: 0,
													ix: 6
												},
												o: {
													a: 0,
													k: 100,
													ix: 7
												},
												sk: {
													a: 0,
													k: 0,
													ix: 4
												},
												sa: {
													a: 0,
													k: 0,
													ix: 5
												},
												nm: "Transform"
											}
										],
										nm: "Group 2",
										np: 2,
										cix: 2,
										bm: 0,
										ix: 2,
										mn: "ADBE Vector Group",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 1",
								np: 2,
								cix: 2,
								bm: 0,
								ix: 1,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 3",
						np: 1,
						cix: 2,
						bm: 0,
						ix: 3,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "gr",
						it: [
							{
								ty: "gr",
								it: [
									{
										ind: 0,
										ty: "sh",
										ix: 1,
										ks: {
											a: 0,
											k: {
												i: [
													[
														0,
														0
													],
													[
														0,
														0
													]
												],
												o: [
													[
														0,
														0
													],
													[
														0,
														0
													]
												],
												v: [
													[
														135.038,
														140.096
													],
													[
														169.109,
														140.096
													]
												],
												c: false
											},
											ix: 2
										},
										nm: "Path 1",
										mn: "ADBE Vector Shape - Group",
										hd: false
									},
									{
										ty: "st",
										c: {
											a: 0,
											k: [
												0.156862750649,
												0.156862750649,
												0.156862750649,
												1
											],
											ix: 3
										},
										o: {
											a: 0,
											k: 100,
											ix: 4
										},
										w: {
											a: 0,
											k: 1.233,
											ix: 5
										},
										lc: 2,
										lj: 2,
										bm: 0,
										nm: "Stroke 1",
										mn: "ADBE Vector Graphic - Stroke",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 1",
								np: 2,
								cix: 2,
								bm: 0,
								ix: 1,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "gr",
								it: [
									{
										ind: 0,
										ty: "sh",
										ix: 1,
										ks: {
											a: 0,
											k: {
												i: [
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														-22.807,
														-142.781
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													]
												],
												o: [
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														22.807,
														-142.781
													]
												],
												v: [
													[
														195.363,
														73.416
													],
													[
														148.408,
														67.163
													],
													[
														148.775,
														71.826
													],
													[
														108.63,
														77.172
													],
													[
														105.559,
														284.875
													],
													[
														138.215,
														284.875
													],
													[
														149.969,
														140.096
													],
													[
														154.143,
														140.096
													],
													[
														165.527,
														284.875
													],
													[
														198.183,
														284.875
													]
												],
												c: true
											},
											ix: 2
										},
										nm: "Path 1",
										mn: "ADBE Vector Shape - Group",
										hd: false
									},
									{
										ty: "fl",
										c: {
											a: 0,
											k: [
												0.556862771511,
												0.443137258291,
												0.423529416323,
												1
											],
											ix: 4
										},
										o: {
											a: 0,
											k: 100,
											ix: 5
										},
										r: 1,
										bm: 0,
										nm: "Fill 1",
										mn: "ADBE Vector Graphic - Fill",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 2",
								np: 2,
								cix: 2,
								bm: 0,
								ix: 2,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 4",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 4,
						mn: "ADBE Vector Group",
						hd: false
					}
				],
				ip: 0,
				op: 180,
				st: 0,
				bm: 0
			},
			{
				ddd: 0,
				ind: 14,
				ty: 4,
				nm: "l_hand",
				parent: 15,
				sr: 1,
				ks: {
					o: {
						a: 0,
						k: 100,
						ix: 11
					},
					r: {
						a: 1,
						k: [
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 0,
								s: [
									78
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 23.438,
								s: [
									0
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 51.563,
								s: [
									0
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 75,
								s: [
									78
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 97,
								s: [
									78
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 119.667,
								s: [
									0
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 142.333,
								s: [
									0
								]
							},
							{
								t: 165,
								s: [
									78
								]
							}
						],
						ix: 10
					},
					p: {
						a: 0,
						k: [
							222.22,
							89.157,
							0
						],
						ix: 2
					},
					a: {
						a: 0,
						k: [
							222.22,
							89.157,
							0
						],
						ix: 1
					},
					s: {
						a: 0,
						k: [
							100,
							100,
							100
						],
						ix: 6
					}
				},
				ao: 0,
				shapes: [
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												0
											],
											[
												-3.292,
												-1.864
											],
											[
												0.402,
												-1.617
											],
											[
												0,
												0
											],
											[
												1.508,
												-0.19
											],
											[
												0,
												0
											],
											[
												5.806,
												-0.86
											],
											[
												0,
												0
											]
										],
										o: [
											[
												0,
												0
											],
											[
												1.45,
												0.821
											],
											[
												0,
												0
											],
											[
												-0.367,
												1.475
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											]
										],
										v: [
											[
												271.849,
												4.015
											],
											[
												278.788,
												6.591
											],
											[
												280.579,
												10.703
											],
											[
												280.579,
												10.703
											],
											[
												277.469,
												13.466
											],
											[
												268.953,
												14.54
											],
											[
												258.704,
												23.058
											],
											[
												264.03,
												9.612
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										1,
										0.694117665291,
										0.647058844566,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 1",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 1,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "gr",
						it: [
							{
								ty: "gr",
								it: [
									{
										ind: 0,
										ty: "sh",
										ix: 1,
										ks: {
											a: 0,
											k: {
												i: [
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													]
												],
												o: [
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													]
												],
												v: [
													[
														299.067,
														-9.259
													],
													[
														267.112,
														17.305
													],
													[
														284.674,
														-15.5
													]
												],
												c: true
											},
											ix: 2
										},
										nm: "Path 1",
										mn: "ADBE Vector Shape - Group",
										hd: false
									},
									{
										ty: "fl",
										c: {
											a: 0,
											k: [
												1,
												1,
												1,
												1
											],
											ix: 4
										},
										o: {
											a: 0,
											k: 100,
											ix: 5
										},
										r: 1,
										bm: 0,
										nm: "Fill 1",
										mn: "ADBE Vector Graphic - Fill",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 1",
								np: 2,
								cix: 2,
								bm: 0,
								ix: 1,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "gr",
								it: [
									{
										ind: 0,
										ty: "sh",
										ix: 1,
										ks: {
											a: 0,
											k: {
												i: [
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													]
												],
												o: [
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													],
													[
														0,
														0
													]
												],
												v: [
													[
														284.674,
														-15.5
													],
													[
														299.067,
														-9.259
													],
													[
														281.505,
														23.545
													],
													[
														267.112,
														17.305
													]
												],
												c: true
											},
											ix: 2
										},
										nm: "Path 1",
										mn: "ADBE Vector Shape - Group",
										hd: false
									},
									{
										ty: "fl",
										c: {
											a: 0,
											k: [
												0.901960790157,
												0.901960790157,
												0.901960790157,
												1
											],
											ix: 4
										},
										o: {
											a: 0,
											k: 100,
											ix: 5
										},
										r: 1,
										bm: 0,
										nm: "Fill 1",
										mn: "ADBE Vector Graphic - Fill",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 2",
								np: 2,
								cix: 2,
								bm: 0,
								ix: 2,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "gr",
								it: [
									{
										ind: 0,
										ty: "sh",
										ix: 1,
										ks: {
											a: 0,
											k: {
												i: [
													[
														-0.911,
														-0.395
													],
													[
														0,
														0
													],
													[
														0.502,
														-0.938
													],
													[
														0,
														0
													],
													[
														0.911,
														0.395
													],
													[
														0,
														0
													],
													[
														-0.502,
														0.938
													],
													[
														0,
														0
													]
												],
												o: [
													[
														0,
														0
													],
													[
														0.911,
														0.395
													],
													[
														0,
														0
													],
													[
														-0.502,
														0.938
													],
													[
														0,
														0
													],
													[
														-0.911,
														-0.395
													],
													[
														0,
														0
													],
													[
														0.502,
														-0.938
													]
												],
												v: [
													[
														286.522,
														-19.595
													],
													[
														302.902,
														-12.493
													],
													[
														303.643,
														-10.08
													],
													[
														282.094,
														30.171
													],
													[
														279.535,
														31.153
													],
													[
														263.155,
														24.052
													],
													[
														262.414,
														21.638
													],
													[
														283.963,
														-18.612
													]
												],
												c: true
											},
											ix: 2
										},
										nm: "Path 1",
										mn: "ADBE Vector Shape - Group",
										hd: false
									},
									{
										ty: "fl",
										c: {
											a: 0,
											k: [
												0.149019613862,
												0.105882354081,
												0.262745112181,
												1
											],
											ix: 4
										},
										o: {
											a: 0,
											k: 100,
											ix: 5
										},
										r: 1,
										bm: 0,
										nm: "Fill 1",
										mn: "ADBE Vector Graphic - Fill",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 3",
								np: 2,
								cix: 2,
								bm: 0,
								ix: 3,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "gr",
								it: [
									{
										ind: 0,
										ty: "sh",
										ix: 1,
										ks: {
											a: 0,
											k: {
												i: [
													[
														-0.911,
														-0.395
													],
													[
														0,
														0
													],
													[
														0.502,
														-0.938
													],
													[
														0,
														0
													],
													[
														0.911,
														0.395
													],
													[
														0,
														0
													],
													[
														-0.502,
														0.938
													],
													[
														0,
														0
													]
												],
												o: [
													[
														0,
														0
													],
													[
														0.911,
														0.395
													],
													[
														0,
														0
													],
													[
														-0.502,
														0.938
													],
													[
														0,
														0
													],
													[
														-0.911,
														-0.395
													],
													[
														0,
														0
													],
													[
														0.502,
														-0.938
													]
												],
												v: [
													[
														288.086,
														-18.882
													],
													[
														304.467,
														-11.781
													],
													[
														305.208,
														-9.367
													],
													[
														283.659,
														30.883
													],
													[
														281.1,
														31.866
													],
													[
														264.719,
														24.764
													],
													[
														263.979,
														22.351
													],
													[
														285.527,
														-17.9
													]
												],
												c: true
											},
											ix: 2
										},
										nm: "Path 1",
										mn: "ADBE Vector Shape - Group",
										hd: false
									},
									{
										ty: "fl",
										c: {
											a: 0,
											k: [
												0.215686276555,
												0.184313729405,
												0.372549027205,
												1
											],
											ix: 4
										},
										o: {
											a: 0,
											k: 100,
											ix: 5
										},
										r: 1,
										bm: 0,
										nm: "Fill 1",
										mn: "ADBE Vector Graphic - Fill",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 4",
								np: 2,
								cix: 2,
								bm: 0,
								ix: 4,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 2",
						np: 4,
						cix: 2,
						bm: 0,
						ix: 2,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "gr",
						it: [
							{
								ty: "gr",
								it: [
									{
										ind: 0,
										ty: "sh",
										ix: 1,
										ks: {
											a: 0,
											k: {
												i: [
													[
														0,
														0
													],
													[
														7.835,
														3.213
													],
													[
														6.184,
														-15.015
													]
												],
												o: [
													[
														0,
														0
													],
													[
														-7.834,
														-3.213
													],
													[
														0,
														0
													]
												],
												v: [
													[
														279.971,
														13.15
													],
													[
														276.552,
														5.351
													],
													[
														252.848,
														17.89
													]
												],
												c: true
											},
											ix: 2
										},
										nm: "Path 1",
										mn: "ADBE Vector Shape - Group",
										hd: false
									},
									{
										ty: "fl",
										c: {
											a: 0,
											k: [
												1,
												0.694117665291,
												0.647058844566,
												1
											],
											ix: 4
										},
										o: {
											a: 0,
											k: 100,
											ix: 5
										},
										r: 1,
										bm: 0,
										nm: "Fill 1",
										mn: "ADBE Vector Graphic - Fill",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 1",
								np: 2,
								cix: 2,
								bm: 0,
								ix: 1,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "gr",
								it: [
									{
										ind: 0,
										ty: "sh",
										ix: 1,
										ks: {
											a: 0,
											k: {
												i: [
													[
														8.481,
														2.74
													],
													[
														-2.74,
														8.481
													],
													[
														-8.481,
														-2.74
													],
													[
														2.74,
														-8.481
													]
												],
												o: [
													[
														-8.481,
														-2.74
													],
													[
														2.74,
														-8.481
													],
													[
														8.481,
														2.74
													],
													[
														-2.74,
														8.481
													]
												],
												v: [
													[
														263.243,
														38.207
													],
													[
														252.848,
														17.89
													],
													[
														273.165,
														7.495
													],
													[
														283.56,
														27.812
													]
												],
												c: true
											},
											ix: 2
										},
										nm: "Path 1",
										mn: "ADBE Vector Shape - Group",
										hd: false
									},
									{
										ty: "fl",
										c: {
											a: 0,
											k: [
												1,
												0.694117665291,
												0.647058844566,
												1
											],
											ix: 4
										},
										o: {
											a: 0,
											k: 100,
											ix: 5
										},
										r: 1,
										bm: 0,
										nm: "Fill 1",
										mn: "ADBE Vector Graphic - Fill",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 2",
								np: 2,
								cix: 2,
								bm: 0,
								ix: 2,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 3",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 3,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												-7.051,
												-4.577
											],
											[
												0,
												0
											],
											[
												-3.999,
												7.378
											],
											[
												0,
												0
											]
										],
										o: [
											[
												0,
												0
											],
											[
												-5.136,
												6.655
											],
											[
												0,
												0
											],
											[
												7.039,
												4.569
											],
											[
												0,
												0
											],
											[
												0,
												0
											]
										],
										v: [
											[
												253.118,
												25.19
											],
											[
												213.997,
												75.877
											],
											[
												217.552,
												96.732
											],
											[
												217.553,
												96.732
											],
											[
												238.031,
												91.521
											],
											[
												270.594,
												31.442
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										1,
										0.694117665291,
										0.647058844566,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 4",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 4,
						mn: "ADBE Vector Group",
						hd: false
					}
				],
				ip: 0,
				op: 180,
				st: 0,
				bm: 0
			},
			{
				ddd: 0,
				ind: 15,
				ty: 4,
				nm: "l_arm",
				sr: 1,
				ks: {
					o: {
						a: 0,
						k: 100,
						ix: 11
					},
					r: {
						a: 1,
						k: [
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 0,
								s: [
									4
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 23.438,
								s: [
									0
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 51.563,
								s: [
									0
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 75,
								s: [
									4
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 97,
								s: [
									4
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 119.667,
								s: [
									0
								]
							},
							{
								i: {
									x: [
										0.667
									],
									y: [
										1
									]
								},
								o: {
									x: [
										0.333
									],
									y: [
										0
									]
								},
								t: 142.333,
								s: [
									0
								]
							},
							{
								t: 165,
								s: [
									4
								]
							}
						],
						ix: 10
					},
					p: {
						a: 0,
						k: [
							744.975,
							546.825,
							0
						],
						ix: 2
					},
					a: {
						a: 0,
						k: [
							204.975,
							6.825,
							0
						],
						ix: 1
					},
					s: {
						a: 0,
						k: [
							100,
							100,
							100
						],
						ix: 6
					}
				},
				ao: 0,
				shapes: [
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												0
											],
											[
												-0.651,
												0.843
											],
											[
												0,
												0
											]
										],
										o: [
											[
												0,
												0
											],
											[
												0.651,
												-0.843
											],
											[
												0,
												0
											]
										],
										v: [
											[
												233.604,
												49.827
											],
											[
												220.606,
												67.314
											],
											[
												231.309,
												37.693
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										1,
										0.6941176470588235,
										0.6470588235294118,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 1",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 1,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											]
										],
										o: [
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											],
											[
												0,
												0
											]
										],
										v: [
											[
												228.163,
												22.481
											],
											[
												199.352,
												33.661
											],
											[
												196.651,
												19.991
											],
											[
												226.484,
												12.549
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "fl",
								c: {
									a: 0,
									k: [
										1,
										0.6941176470588235,
										0.6470588235294118,
										1
									],
									ix: 4
								},
								o: {
									a: 0,
									k: 100,
									ix: 5
								},
								r: 1,
								bm: 0,
								nm: "Fill 1",
								mn: "ADBE Vector Graphic - Fill",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 2",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 2,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "gr",
						it: [
							{
								ty: "gr",
								it: [
									{
										ind: 0,
										ty: "sh",
										ix: 1,
										ks: {
											a: 0,
											k: {
												i: [
													[
														4.646,
														7.414
													],
													[
														1.191,
														0.14
													],
													[
														-12.69,
														-42.432
													],
													[
														-7.818,
														3.315
													],
													[
														-0.085,
														0.036
													],
													[
														1.244,
														6.6
													]
												],
												o: [
													[
														-4.018,
														-6.412
													],
													[
														-6.1,
														-0.715
													],
													[
														2.433,
														8.135
													],
													[
														0.085,
														-0.036
													],
													[
														6.184,
														-2.62
													],
													[
														-6.036,
														-32.018
													]
												],
												v: [
													[
														222.784,
														4.928
													],
													[
														195.01,
														-1.397
													],
													[
														211.612,
														88.863
													],
													[
														230.814,
														97.921
													],
													[
														231.067,
														97.813
													],
													[
														239.526,
														82.029
													]
												],
												c: true
											},
											ix: 2
										},
										nm: "Path 1",
										mn: "ADBE Vector Shape - Group",
										hd: false
									},
									{
										ty: "fl",
										c: {
											a: 0,
											k: [
												1,
												0.694117665291,
												0.647058844566,
												1
											],
											ix: 4
										},
										o: {
											a: 0,
											k: 100,
											ix: 5
										},
										r: 1,
										bm: 0,
										nm: "Fill 1",
										mn: "ADBE Vector Graphic - Fill",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 1",
								np: 2,
								cix: 2,
								bm: 0,
								ix: 1,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 3",
						np: 1,
						cix: 2,
						bm: 0,
						ix: 3,
						mn: "ADBE Vector Group",
						hd: false
					}
				],
				ip: 0,
				op: 180,
				st: 0,
				bm: 0
			}
		]
	}
];
export const layers = [
	{
		ddd: 0,
		ind: 1,
		ty: 3,
		nm: "NULL CONTROL",
		sr: 1,
		ks: {
			o: {
				a: 0,
				k: 0,
				ix: 11
			},
			r: {
				a: 0,
				k: 0,
				ix: 10
			},
			p: {
				a: 0,
				k: [
					386.733,
					302.675,
					0
				],
				ix: 2
			},
			a: {
				a: 0,
				k: [
					60,
					60,
					0
				],
				ix: 1
			},
			s: {
				a: 0,
				k: [
					93,
					93,
					100
				],
				ix: 6
			}
		},
		ao: 0,
		ip: 0,
		op: 188,
		st: 0,
		bm: 0
	},
	{
		ddd: 0,
		ind: 2,
		ty: 0,
		nm: "guy",
		parent: 1,
		refId: "comp_0",
		sr: 1,
		ks: {
			o: {
				a: 0,
				k: 100,
				ix: 11
			},
			r: {
				a: 0,
				k: 0,
				ix: 10
			},
			p: {
				a: 0,
				k: [
					57.267,
					97.325,
					0
				],
				ix: 2
			},
			a: {
				a: 0,
				k: [
					540,
					540,
					0
				],
				ix: 1
			},
			s: {
				a: 0,
				k: [
					100,
					100,
					100
				],
				ix: 6
			}
		},
		ao: 0,
		hasMask: true,
		masksProperties: [
			{
				inv: false,
				mode: "a",
				pt: {
					a: 0,
					k: {
						i: [
							[
								0,
								0
							],
							[
								0,
								0
							],
							[
								0,
								0
							],
							[
								0,
								0
							]
						],
						o: [
							[
								0,
								0
							],
							[
								0,
								0
							],
							[
								0,
								0
							],
							[
								0,
								0
							]
						],
						v: [
							[
								890,
								326
							],
							[
								200,
								326
							],
							[
								200,
								760
							],
							[
								890,
								760
							]
						],
						c: true
					},
					ix: 1
				},
				o: {
					a: 0,
					k: 100,
					ix: 3
				},
				x: {
					a: 0,
					k: 0,
					ix: 4
				},
				nm: "Mask 1"
			}
		],
		w: 1080,
		h: 1080,
		ip: 0,
		op: 180,
		st: 0,
		bm: 0
	},
	{
		ddd: 0,
		ind: 3,
		ty: 0,
		nm: "lady 2",
		parent: 1,
		refId: "comp_1",
		sr: 1,
		ks: {
			o: {
				a: 0,
				k: 100,
				ix: 11
			},
			r: {
				a: 0,
				k: 0,
				ix: 10
			},
			p: {
				a: 0,
				k: [
					57.267,
					97.325,
					0
				],
				ix: 2
			},
			a: {
				a: 0,
				k: [
					540,
					540,
					0
				],
				ix: 1
			},
			s: {
				a: 0,
				k: [
					100,
					100,
					100
				],
				ix: 6
			}
		},
		ao: 0,
		hasMask: true,
		masksProperties: [
			{
				inv: false,
				mode: "a",
				pt: {
					a: 0,
					k: {
						i: [
							[
								0,
								0
							],
							[
								0,
								0
							],
							[
								0,
								0
							],
							[
								0,
								0
							]
						],
						o: [
							[
								0,
								0
							],
							[
								0,
								0
							],
							[
								0,
								0
							],
							[
								0,
								0
							]
						],
						v: [
							[
								596,
								312
							],
							[
								148,
								312
							],
							[
								150,
								757
							],
							[
								598,
								757
							]
						],
						c: true
					},
					ix: 1
				},
				o: {
					a: 0,
					k: 100,
					ix: 3
				},
				x: {
					a: 0,
					k: 0,
					ix: 4
				},
				nm: "Mask 1"
			}
		],
		w: 1080,
		h: 1080,
		ip: 0,
		op: 180,
		st: 0,
		bm: 0
	},
	{
		ddd: 0,
		ind: 4,
		ty: 0,
		nm: "lady 1",
		parent: 1,
		refId: "comp_2",
		sr: 1,
		ks: {
			o: {
				a: 0,
				k: 100,
				ix: 11
			},
			r: {
				a: 0,
				k: 0,
				ix: 10
			},
			p: {
				a: 0,
				k: [
					57.267,
					97.325,
					0
				],
				ix: 2
			},
			a: {
				a: 0,
				k: [
					540,
					540,
					0
				],
				ix: 1
			},
			s: {
				a: 0,
				k: [
					100,
					100,
					100
				],
				ix: 6
			}
		},
		ao: 0,
		hasMask: true,
		masksProperties: [
			{
				inv: false,
				mode: "a",
				pt: {
					a: 0,
					k: {
						i: [
							[
								0,
								0
							],
							[
								0,
								0
							],
							[
								0,
								0
							],
							[
								0,
								0
							]
						],
						o: [
							[
								0,
								0
							],
							[
								0,
								0
							],
							[
								0,
								0
							],
							[
								0,
								0
							]
						],
						v: [
							[
								964,
								328
							],
							[
								554,
								328
							],
							[
								554,
								756.5
							],
							[
								964,
								756.5
							]
						],
						c: true
					},
					ix: 1
				},
				o: {
					a: 0,
					k: 100,
					ix: 3
				},
				x: {
					a: 0,
					k: 0,
					ix: 4
				},
				nm: "Mask 1"
			}
		],
		w: 1080,
		h: 1080,
		ip: 0,
		op: 180,
		st: 0,
		bm: 0
	},
	{
		ddd: 0,
		ind: 5,
		ty: 4,
		nm: "Layer 22",
		parent: 1,
		sr: 1,
		ks: {
			o: {
				a: 0,
				k: 100,
				ix: 11
			},
			r: {
				a: 1,
				k: [
					{
						i: {
							x: [
								0.833
							],
							y: [
								0.833
							]
						},
						o: {
							x: [
								0.167
							],
							y: [
								0.167
							]
						},
						t: 0,
						s: [
							0
						]
					},
					{
						t: 179,
						s: [
							360
						]
					}
				],
				ix: 10
			},
			p: {
				a: 0,
				k: [
					-258.099,
					147.868,
					0
				],
				ix: 2
			},
			a: {
				a: 0,
				k: [
					-315.365,
					50.543,
					0
				],
				ix: 1
			},
			s: {
				a: 0,
				k: [
					100,
					100,
					100
				],
				ix: 6
			}
		},
		ao: 0,
		shapes: [
			{
				ty: "gr",
				it: [
					{
						ind: 0,
						ty: "sh",
						ix: 1,
						ks: {
							a: 0,
							k: {
								i: [
									[
										-0.233,
										-3.642
									],
									[
										0,
										0
									],
									[
										0.83,
										3.353
									],
									[
										0,
										0
									]
								],
								o: [
									[
										0,
										0
									],
									[
										-0.061,
										-3.352
									],
									[
										0,
										0
									],
									[
										1.71,
										3.001
									]
								],
								v: [
									[
										-292.012,
										49.026
									],
									[
										-303.163,
										49.026
									],
									[
										-304.489,
										38.968
									],
									[
										-295.02,
										38.968
									]
								],
								c: true
							},
							ix: 2
						},
						nm: "Path 1",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ind: 1,
						ty: "sh",
						ix: 2,
						ks: {
							a: 0,
							k: {
								i: [
									[
										1.711,
										-3
									],
									[
										0,
										0
									],
									[
										-0.164,
										3.352
									],
									[
										0,
										0
									]
								],
								o: [
									[
										0,
										0
									],
									[
										0.883,
										-3.352
									],
									[
										0,
										0
									],
									[
										-0.233,
										3.641
									]
								],
								v: [
									[
										-295.02,
										62.117
									],
									[
										-304.789,
										62.117
									],
									[
										-303.209,
										52.06
									],
									[
										-292.012,
										52.06
									]
								],
								c: true
							},
							ix: 2
						},
						nm: "Path 2",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ind: 2,
						ty: "sh",
						ix: 3,
						ks: {
							a: 0,
							k: {
								i: [
									[
										4.713,
										-1.356
									],
									[
										-0.857,
										2.629
									],
									[
										0,
										0
									]
								],
								o: [
									[
										1.272,
										-2.628
									],
									[
										0,
										0
									],
									[
										-2.985,
										3.731
									]
								],
								v: [
									[
										-308.881,
										73.036
									],
									[
										-305.684,
										65.151
									],
									[
										-297.081,
										65.151
									]
								],
								c: true
							},
							ix: 2
						},
						nm: "Path 3",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ind: 3,
						ty: "sh",
						ix: 4,
						ks: {
							a: 0,
							k: {
								i: [
									[
										1.04,
										0
									],
									[
										1.003,
										0.132
									],
									[
										0.98,
										2.866
									],
									[
										0,
										0
									],
									[
										1.429,
										-2.865
									]
								],
								o: [
									[
										-1.039,
										0
									],
									[
										-1.43,
										-2.865
									],
									[
										0,
										0
									],
									[
										-0.98,
										2.866
									],
									[
										-1.004,
										0.132
									]
								],
								v: [
									[
										-315.365,
										73.947
									],
									[
										-318.431,
										73.747
									],
									[
										-322.059,
										65.151
									],
									[
										-308.672,
										65.151
									],
									[
										-312.299,
										73.747
									]
								],
								c: true
							},
							ix: 2
						},
						nm: "Path 4",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ind: 4,
						ty: "sh",
						ix: 5,
						ks: {
							a: 0,
							k: {
								i: [
									[
										2.985,
										3.731
									],
									[
										0,
										0
									],
									[
										-1.272,
										-2.628
									]
								],
								o: [
									[
										0,
										0
									],
									[
										0.857,
										2.628
									],
									[
										-4.713,
										-1.356
									]
								],
								v: [
									[
										-333.649,
										65.151
									],
									[
										-325.046,
										65.151
									],
									[
										-321.849,
										73.036
									]
								],
								c: true
							},
							ix: 2
						},
						nm: "Path 5",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ind: 5,
						ty: "sh",
						ix: 6,
						ks: {
							a: 0,
							k: {
								i: [
									[
										0,
										0
									],
									[
										0.233,
										3.641
									],
									[
										0,
										0
									],
									[
										-0.883,
										-3.353
									]
								],
								o: [
									[
										-1.711,
										-3
									],
									[
										0,
										0
									],
									[
										0.164,
										3.352
									],
									[
										0,
										0
									]
								],
								v: [
									[
										-335.71,
										62.117
									],
									[
										-338.719,
										52.06
									],
									[
										-327.521,
										52.06
									],
									[
										-325.941,
										62.117
									]
								],
								c: true
							},
							ix: 2
						},
						nm: "Path 6",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ind: 6,
						ty: "sh",
						ix: 7,
						ks: {
							a: 0,
							k: {
								i: [
									[
										-1.71,
										3.001
									],
									[
										0,
										0
									],
									[
										0.061,
										-3.352
									],
									[
										0,
										0
									]
								],
								o: [
									[
										0,
										0
									],
									[
										-0.83,
										3.353
									],
									[
										0,
										0
									],
									[
										0.233,
										-3.642
									]
								],
								v: [
									[
										-335.71,
										38.968
									],
									[
										-326.241,
										38.968
									],
									[
										-327.568,
										49.026
									],
									[
										-338.719,
										49.026
									]
								],
								c: true
							},
							ix: 2
						},
						nm: "Path 7",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ind: 7,
						ty: "sh",
						ix: 8,
						ks: {
							a: 0,
							k: {
								i: [
									[
										-4.58,
										1.389
									],
									[
										0.829,
										-2.597
									],
									[
										0,
										0
									]
								],
								o: [
									[
										-1.318,
										2.597
									],
									[
										0,
										0
									],
									[
										2.917,
										-3.647
									]
								],
								v: [
									[
										-322.167,
										28.144
									],
									[
										-325.382,
										35.935
									],
									[
										-333.649,
										35.935
									]
								],
								c: true
							},
							ix: 2
						},
						nm: "Path 8",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ind: 8,
						ty: "sh",
						ix: 9,
						ks: {
							a: 0,
							k: {
								i: [
									[
										-1.247,
										0
									],
									[
										-1.194,
										-0.188
									],
									[
										-0.927,
										-2.837
									],
									[
										0,
										0
									],
									[
										-1.589,
										2.837
									]
								],
								o: [
									[
										1.247,
										0
									],
									[
										1.589,
										2.837
									],
									[
										0,
										0
									],
									[
										0.926,
										-2.837
									],
									[
										1.194,
										-0.188
									]
								],
								v: [
									[
										-315.365,
										27.139
									],
									[
										-311.7,
										27.425
									],
									[
										-307.939,
										35.935
									],
									[
										-322.792,
										35.935
									],
									[
										-319.03,
										27.425
									]
								],
								c: true
							},
							ix: 2
						},
						nm: "Path 9",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ind: 9,
						ty: "sh",
						ix: 10,
						ks: {
							a: 0,
							k: {
								i: [
									[
										0,
										0
									],
									[
										0.946,
										-3.352
									],
									[
										0,
										0
									],
									[
										0.229,
										3.352
									]
								],
								o: [
									[
										-0.229,
										3.352
									],
									[
										0,
										0
									],
									[
										-0.946,
										-3.352
									],
									[
										0,
										0
									]
								],
								v: [
									[
										-305.941,
										52.06
									],
									[
										-307.723,
										62.117
									],
									[
										-323.007,
										62.117
									],
									[
										-324.789,
										52.06
									]
								],
								c: true
							},
							ix: 2
						},
						nm: "Path 10",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ind: 10,
						ty: "sh",
						ix: 11,
						ks: {
							a: 0,
							k: {
								i: [
									[
										0,
										0
									],
									[
										-0.829,
										3.353
									],
									[
										0,
										0
									],
									[
										-0.004,
										-3.352
									]
								],
								o: [
									[
										0.004,
										-3.352
									],
									[
										0,
										0
									],
									[
										0.829,
										3.353
									],
									[
										0,
										0
									]
								],
								v: [
									[
										-324.891,
										49.026
									],
									[
										-323.662,
										38.968
									],
									[
										-307.068,
										38.968
									],
									[
										-305.839,
										49.026
									]
								],
								c: true
							},
							ix: 2
						},
						nm: "Path 11",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ind: 11,
						ty: "sh",
						ix: 12,
						ks: {
							a: 0,
							k: {
								i: [
									[
										-2.917,
										-3.647
									],
									[
										0,
										0
									],
									[
										1.317,
										2.597
									]
								],
								o: [
									[
										0,
										0
									],
									[
										-0.829,
										-2.597
									],
									[
										4.579,
										1.389
									]
								],
								v: [
									[
										-297.081,
										35.935
									],
									[
										-305.348,
										35.935
									],
									[
										-308.563,
										28.144
									]
								],
								c: true
							},
							ix: 2
						},
						nm: "Path 12",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ind: 12,
						ty: "sh",
						ix: 13,
						ks: {
							a: 0,
							k: {
								i: [
									[
										10.075,
										-10.075
									],
									[
										-10.074,
										-10.075
									],
									[
										-10.074,
										10.074
									],
									[
										10.075,
										10.074
									]
								],
								o: [
									[
										-10.075,
										10.075
									],
									[
										10.075,
										10.074
									],
									[
										10.075,
										-10.074
									],
									[
										-10.074,
										-10.075
									]
								],
								v: [
									[
										-333.709,
										32.199
									],
									[
										-333.709,
										68.887
									],
									[
										-297.022,
										68.887
									],
									[
										-297.022,
										32.199
									]
								],
								c: true
							},
							ix: 2
						},
						nm: "Path 13",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ty: "fl",
						c: {
							a: 0,
							k: [
								1,
								1,
								1,
								1
							],
							ix: 4
						},
						o: {
							a: 0,
							k: 100,
							ix: 5
						},
						r: 1,
						bm: 0,
						nm: "Fill 1",
						mn: "ADBE Vector Graphic - Fill",
						hd: false
					},
					{
						ty: "tr",
						p: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 2
						},
						a: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 1
						},
						s: {
							a: 0,
							k: [
								100,
								100
							],
							ix: 3
						},
						r: {
							a: 0,
							k: 0,
							ix: 6
						},
						o: {
							a: 0,
							k: 100,
							ix: 7
						},
						sk: {
							a: 0,
							k: 0,
							ix: 4
						},
						sa: {
							a: 0,
							k: 0,
							ix: 5
						},
						nm: "Transform"
					}
				],
				nm: "Group 1",
				np: 14,
				cix: 2,
				bm: 0,
				ix: 1,
				mn: "ADBE Vector Group",
				hd: false
			}
		],
		ip: 0,
		op: 180,
		st: 0,
		bm: 0
	},
	{
		ddd: 0,
		ind: 6,
		ty: 4,
		nm: "Layer 21",
		parent: 1,
		sr: 1,
		ks: {
			o: {
				a: 0,
				k: 100,
				ix: 11
			},
			r: {
				a: 0,
				k: 0,
				ix: 10
			},
			p: {
				a: 0,
				k: [
					-258.285,
					148.535,
					0
				],
				ix: 2
			},
			a: {
				a: 0,
				k: [
					-315.551,
					51.209,
					0
				],
				ix: 1
			},
			s: {
				a: 0,
				k: [
					100,
					100,
					100
				],
				ix: 6
			}
		},
		ao: 0,
		shapes: [
			{
				ty: "gr",
				it: [
					{
						ind: 0,
						ty: "sh",
						ix: 1,
						ks: {
							a: 0,
							k: {
								i: [
									[
										3.667,
										0
									],
									[
										0,
										0
									],
									[
										0,
										3.667
									],
									[
										0,
										0
									],
									[
										-3.667,
										0
									],
									[
										0,
										0
									],
									[
										0,
										-3.667
									],
									[
										0,
										0
									]
								],
								o: [
									[
										0,
										0
									],
									[
										-3.667,
										0
									],
									[
										0,
										0
									],
									[
										0,
										-3.667
									],
									[
										0,
										0
									],
									[
										3.667,
										0
									],
									[
										0,
										0
									],
									[
										0,
										3.667
									]
								],
								v: [
									[
										-276.687,
										94.307
									],
									[
										-355.163,
										94.307
									],
									[
										-361.802,
										87.668
									],
									[
										-361.802,
										11.751
									],
									[
										-355.163,
										5.112
									],
									[
										-276.687,
										5.112
									],
									[
										-270.048,
										11.751
									],
									[
										-270.048,
										87.668
									]
								],
								c: true
							},
							ix: 2
						},
						nm: "Path 1",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ty: "fl",
						c: {
							a: 0,
							k: [
								0.8941176470588236,
								0.4666666666666667,
								0.3764705882352941,
								1
							],
							ix: 4
						},
						o: {
							a: 0,
							k: 100,
							ix: 5
						},
						r: 1,
						bm: 0,
						nm: "Fill 1",
						mn: "ADBE Vector Graphic - Fill",
						hd: false
					},
					{
						ty: "tr",
						p: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 2
						},
						a: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 1
						},
						s: {
							a: 0,
							k: [
								100,
								100
							],
							ix: 3
						},
						r: {
							a: 0,
							k: 0,
							ix: 6
						},
						o: {
							a: 0,
							k: 100,
							ix: 7
						},
						sk: {
							a: 0,
							k: 0,
							ix: 4
						},
						sa: {
							a: 0,
							k: 0,
							ix: 5
						},
						nm: "Transform"
					}
				],
				nm: "Group 1",
				np: 2,
				cix: 2,
				bm: 0,
				ix: 1,
				mn: "ADBE Vector Group",
				hd: false
			},
			{
				ty: "gr",
				it: [
					{
						ty: "gr",
						it: [
							{
								ty: "gr",
								it: [
									{
										ty: "gr",
										it: [
											{
												ind: 0,
												ty: "sh",
												ix: 1,
												ks: {
													a: 0,
													k: {
														i: [
															[
																3.155,
																0
															],
															[
																0,
																0
															],
															[
																0,
																3.155
															],
															[
																0,
																0
															],
															[
																-3.155,
																0
															],
															[
																0,
																0
															],
															[
																0,
																-3.155
															],
															[
																0,
																0
															]
														],
														o: [
															[
																0,
																0
															],
															[
																-3.155,
																0
															],
															[
																0,
																0
															],
															[
																0,
																-3.155
															],
															[
																0,
																0
															],
															[
																3.155,
																0
															],
															[
																0,
																0
															],
															[
																0,
																3.155
															]
														],
														v: [
															[
																-241.926,
																121.324
															],
															[
																-389.177,
																121.324
															],
															[
																-394.89,
																115.61
															],
															[
																-394.89,
																-13.191
															],
															[
																-389.177,
																-18.905
															],
															[
																-241.926,
																-18.905
															],
															[
																-236.213,
																-13.192
															],
															[
																-236.213,
																115.61
															]
														],
														c: true
													},
													ix: 2
												},
												nm: "Path 1",
												mn: "ADBE Vector Shape - Group",
												hd: false
											},
											{
												ty: "st",
												c: {
													a: 0,
													k: [
														0.870588243008,
														0.847058832645,
														0.835294127464,
														1
													],
													ix: 3
												},
												o: {
													a: 0,
													k: 100,
													ix: 4
												},
												w: {
													a: 0,
													k: 1.968,
													ix: 5
												},
												lc: 1,
												lj: 1,
												ml: 10,
												bm: 0,
												nm: "Stroke 1",
												mn: "ADBE Vector Graphic - Stroke",
												hd: false
											},
											{
												ty: "tr",
												p: {
													a: 0,
													k: [
														0,
														0
													],
													ix: 2
												},
												a: {
													a: 0,
													k: [
														0,
														0
													],
													ix: 1
												},
												s: {
													a: 0,
													k: [
														100,
														100
													],
													ix: 3
												},
												r: {
													a: 0,
													k: 0,
													ix: 6
												},
												o: {
													a: 0,
													k: 100,
													ix: 7
												},
												sk: {
													a: 0,
													k: 0,
													ix: 4
												},
												sa: {
													a: 0,
													k: 0,
													ix: 5
												},
												nm: "Transform"
											}
										],
										nm: "Group 1",
										np: 2,
										cix: 2,
										bm: 0,
										ix: 1,
										mn: "ADBE Vector Group",
										hd: false
									},
									{
										ty: "gr",
										it: [
											{
												ind: 0,
												ty: "sh",
												ix: 1,
												ks: {
													a: 0,
													k: {
														i: [
															[
																3.155,
																0
															],
															[
																0,
																0
															],
															[
																0,
																3.155
															],
															[
																0,
																0
															],
															[
																-3.155,
																0
															],
															[
																0,
																0
															],
															[
																0,
																-3.155
															],
															[
																0,
																0
															]
														],
														o: [
															[
																0,
																0
															],
															[
																-3.155,
																0
															],
															[
																0,
																0
															],
															[
																0,
																-3.155
															],
															[
																0,
																0
															],
															[
																3.155,
																0
															],
															[
																0,
																0
															],
															[
																0,
																3.155
															]
														],
														v: [
															[
																-241.926,
																121.324
															],
															[
																-389.177,
																121.324
															],
															[
																-394.89,
																115.61
															],
															[
																-394.89,
																-13.191
															],
															[
																-389.177,
																-18.905
															],
															[
																-241.926,
																-18.905
															],
															[
																-236.213,
																-13.192
															],
															[
																-236.213,
																115.61
															]
														],
														c: true
													},
													ix: 2
												},
												nm: "Path 1",
												mn: "ADBE Vector Shape - Group",
												hd: false
											},
											{
												ty: "fl",
												c: {
													a: 0,
													k: [
														0.929411768913,
														0.929411768913,
														0.929411768913,
														1
													],
													ix: 4
												},
												o: {
													a: 0,
													k: 100,
													ix: 5
												},
												r: 1,
												bm: 0,
												nm: "Fill 1",
												mn: "ADBE Vector Graphic - Fill",
												hd: false
											},
											{
												ty: "tr",
												p: {
													a: 0,
													k: [
														0,
														0
													],
													ix: 2
												},
												a: {
													a: 0,
													k: [
														0,
														0
													],
													ix: 1
												},
												s: {
													a: 0,
													k: [
														100,
														100
													],
													ix: 3
												},
												r: {
													a: 0,
													k: 0,
													ix: 6
												},
												o: {
													a: 0,
													k: 100,
													ix: 7
												},
												sk: {
													a: 0,
													k: 0,
													ix: 4
												},
												sa: {
													a: 0,
													k: 0,
													ix: 5
												},
												nm: "Transform"
											}
										],
										nm: "Group 2",
										np: 2,
										cix: 2,
										bm: 0,
										ix: 2,
										mn: "ADBE Vector Group",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 1",
								np: 2,
								cix: 2,
								bm: 0,
								ix: 1,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 1",
						np: 1,
						cix: 2,
						bm: 0,
						ix: 1,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "tr",
						p: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 2
						},
						a: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 1
						},
						s: {
							a: 0,
							k: [
								100,
								100
							],
							ix: 3
						},
						r: {
							a: 0,
							k: 0,
							ix: 6
						},
						o: {
							a: 0,
							k: 100,
							ix: 7
						},
						sk: {
							a: 0,
							k: 0,
							ix: 4
						},
						sa: {
							a: 0,
							k: 0,
							ix: 5
						},
						nm: "Transform"
					}
				],
				nm: "Group 2",
				np: 1,
				cix: 2,
				bm: 0,
				ix: 2,
				mn: "ADBE Vector Group",
				hd: false
			}
		],
		ip: 0,
		op: 180,
		st: 0,
		bm: 0
	},
	{
		ddd: 0,
		ind: 7,
		ty: 4,
		nm: "Layer 20",
		parent: 1,
		sr: 1,
		ks: {
			o: {
				a: 0,
				k: 100,
				ix: 11
			},
			r: {
				a: 1,
				k: [
					{
						i: {
							x: [
								0.38
							],
							y: [
								1
							]
						},
						o: {
							x: [
								0.333
							],
							y: [
								0
							]
						},
						t: 0,
						s: [
							-98
						]
					},
					{
						i: {
							x: [
								0.38
							],
							y: [
								1
							]
						},
						o: {
							x: [
								0.302
							],
							y: [
								0
							]
						},
						t: 15,
						s: [
							0
						]
					},
					{
						i: {
							x: [
								0.667
							],
							y: [
								1
							]
						},
						o: {
							x: [
								0.62
							],
							y: [
								0
							]
						},
						t: 62,
						s: [
							0
						]
					},
					{
						i: {
							x: [
								0.38
							],
							y: [
								1
							]
						},
						o: {
							x: [
								0.208
							],
							y: [
								0
							]
						},
						t: 77,
						s: [
							98
						]
					},
					{
						i: {
							x: [
								0.38
							],
							y: [
								1
							]
						},
						o: {
							x: [
								0.333
							],
							y: [
								0
							]
						},
						t: 95,
						s: [
							-98
						]
					},
					{
						i: {
							x: [
								0.38
							],
							y: [
								1
							]
						},
						o: {
							x: [
								0.302
							],
							y: [
								0
							]
						},
						t: 110,
						s: [
							0
						]
					},
					{
						i: {
							x: [
								0.667
							],
							y: [
								1
							]
						},
						o: {
							x: [
								0.62
							],
							y: [
								0
							]
						},
						t: 154,
						s: [
							0
						]
					},
					{
						t: 169,
						s: [
							98
						]
					}
				],
				ix: 10
			},
			p: {
				a: 0,
				k: [
					402.587,
					20.232,
					0
				],
				ix: 2
			},
			a: {
				a: 0,
				k: [
					345.321,
					-77.094,
					0
				],
				ix: 1
			},
			s: {
				a: 1,
				k: [
					{
						i: {
							x: [
								0.38,
								0.38,
								0.38
							],
							y: [
								1,
								1,
								1
							]
						},
						o: {
							x: [
								0.333,
								0.333,
								0.333
							],
							y: [
								0,
								0,
								0
							]
						},
						t: 0,
						s: [
							0,
							0,
							100
						]
					},
					{
						i: {
							x: [
								0.38,
								0.38,
								0.38
							],
							y: [
								1,
								1,
								1
							]
						},
						o: {
							x: [
								0.302,
								0.302,
								0.302
							],
							y: [
								0,
								0,
								0
							]
						},
						t: 15,
						s: [
							100,
							100,
							100
						]
					},
					{
						i: {
							x: [
								0.667,
								0.667,
								0.667
							],
							y: [
								1,
								1,
								1
							]
						},
						o: {
							x: [
								0.62,
								0.62,
								0.62
							],
							y: [
								0,
								0,
								0
							]
						},
						t: 62,
						s: [
							100,
							100,
							100
						]
					},
					{
						i: {
							x: [
								0.38,
								0.38,
								0.38
							],
							y: [
								1,
								1,
								1
							]
						},
						o: {
							x: [
								0.208,
								0.208,
								0.208
							],
							y: [
								0,
								0,
								0
							]
						},
						t: 77,
						s: [
							0,
							0,
							100
						]
					},
					{
						i: {
							x: [
								0.38,
								0.38,
								0.38
							],
							y: [
								1,
								1,
								1
							]
						},
						o: {
							x: [
								0.333,
								0.333,
								0.333
							],
							y: [
								0,
								0,
								0
							]
						},
						t: 95,
						s: [
							0,
							0,
							100
						]
					},
					{
						i: {
							x: [
								0.38,
								0.38,
								0.38
							],
							y: [
								1,
								1,
								1
							]
						},
						o: {
							x: [
								0.302,
								0.302,
								0.302
							],
							y: [
								0,
								0,
								0
							]
						},
						t: 110,
						s: [
							100,
							100,
							100
						]
					},
					{
						i: {
							x: [
								0.667,
								0.667,
								0.667
							],
							y: [
								1,
								1,
								1
							]
						},
						o: {
							x: [
								0.62,
								0.62,
								0.62
							],
							y: [
								0,
								0,
								0
							]
						},
						t: 154,
						s: [
							100,
							100,
							100
						]
					},
					{
						t: 169,
						s: [
							0,
							0,
							100
						]
					}
				],
				ix: 6
			}
		},
		ao: 0,
		shapes: [
			{
				ty: "gr",
				it: [
					{
						ind: 0,
						ty: "sh",
						ix: 1,
						ks: {
							a: 0,
							k: {
								i: [
									[
										0,
										0
									],
									[
										0,
										0
									],
									[
										0,
										0
									]
								],
								o: [
									[
										0,
										0
									],
									[
										0,
										0
									],
									[
										0,
										0
									]
								],
								v: [
									[
										323.641,
										-91.633
									],
									[
										345.321,
										-74.548
									],
									[
										367.001,
										-91.633
									]
								],
								c: false
							},
							ix: 2
						},
						nm: "Path 1",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ty: "st",
						c: {
							a: 0,
							k: [
								1,
								1,
								1,
								1
							],
							ix: 3
						},
						o: {
							a: 0,
							k: 100,
							ix: 4
						},
						w: {
							a: 0,
							k: 1.647,
							ix: 5
						},
						lc: 2,
						lj: 2,
						bm: 0,
						nm: "Stroke 1",
						mn: "ADBE Vector Graphic - Stroke",
						hd: false
					},
					{
						ty: "tr",
						p: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 2
						},
						a: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 1
						},
						s: {
							a: 0,
							k: [
								100,
								100
							],
							ix: 3
						},
						r: {
							a: 0,
							k: 0,
							ix: 6
						},
						o: {
							a: 0,
							k: 100,
							ix: 7
						},
						sk: {
							a: 0,
							k: 0,
							ix: 4
						},
						sa: {
							a: 0,
							k: 0,
							ix: 5
						},
						nm: "Transform"
					}
				],
				nm: "Group 1",
				np: 2,
				cix: 2,
				bm: 0,
				ix: 1,
				mn: "ADBE Vector Group",
				hd: false
			},
			{
				ty: "gr",
				it: [
					{
						ind: 0,
						ty: "sh",
						ix: 1,
						ks: {
							a: 0,
							k: {
								i: [
									[
										0,
										0
									],
									[
										0,
										0
									],
									[
										0,
										0
									],
									[
										0,
										0
									],
									[
										0,
										0
									],
									[
										0,
										0
									]
								],
								o: [
									[
										0,
										0
									],
									[
										0,
										0
									],
									[
										0,
										0
									],
									[
										0,
										0
									],
									[
										0,
										0
									],
									[
										0,
										0
									]
								],
								v: [
									[
										367.001,
										-62.554
									],
									[
										330.274,
										-62.554
									],
									[
										323.641,
										-62.554
									],
									[
										323.641,
										-91.633
									],
									[
										367.001,
										-91.633
									],
									[
										367.001,
										-84.364
									]
								],
								c: true
							},
							ix: 2
						},
						nm: "Path 1",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ty: "st",
						c: {
							a: 0,
							k: [
								1,
								1,
								1,
								1
							],
							ix: 3
						},
						o: {
							a: 0,
							k: 100,
							ix: 4
						},
						w: {
							a: 0,
							k: 1.647,
							ix: 5
						},
						lc: 2,
						lj: 2,
						bm: 0,
						nm: "Stroke 1",
						mn: "ADBE Vector Graphic - Stroke",
						hd: false
					},
					{
						ty: "tr",
						p: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 2
						},
						a: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 1
						},
						s: {
							a: 0,
							k: [
								100,
								100
							],
							ix: 3
						},
						r: {
							a: 0,
							k: 0,
							ix: 6
						},
						o: {
							a: 0,
							k: 100,
							ix: 7
						},
						sk: {
							a: 0,
							k: 0,
							ix: 4
						},
						sa: {
							a: 0,
							k: 0,
							ix: 5
						},
						nm: "Transform"
					}
				],
				nm: "Group 2",
				np: 2,
				cix: 2,
				bm: 0,
				ix: 2,
				mn: "ADBE Vector Group",
				hd: false
			}
		],
		ip: 0,
		op: 180,
		st: 0,
		bm: 0
	},
	{
		ddd: 0,
		ind: 8,
		ty: 4,
		nm: "Layer 19",
		parent: 1,
		sr: 1,
		ks: {
			o: {
				a: 0,
				k: 100,
				ix: 11
			},
			r: {
				a: 0,
				k: 0,
				ix: 10
			},
			p: {
				a: 0,
				k: [
					402.587,
					24.214,
					0
				],
				ix: 2
			},
			a: {
				a: 0,
				k: [
					345.321,
					-73.111,
					0
				],
				ix: 1
			},
			s: {
				a: 0,
				k: [
					100,
					100,
					100
				],
				ix: 6
			}
		},
		ao: 0,
		shapes: [
			{
				ty: "gr",
				it: [
					{
						ty: "gr",
						it: [
							{
								ty: "gr",
								it: [
									{
										ty: "gr",
										it: [
											{
												ind: 0,
												ty: "sh",
												ix: 1,
												ks: {
													a: 0,
													k: {
														i: [
															[
																-3.326,
																0
															],
															[
																0,
																0
															],
															[
																0,
																3.326
															],
															[
																0,
																0
															],
															[
																3.326,
																0
															],
															[
																0,
																0
															],
															[
																0,
																-3.326
															],
															[
																0,
																0
															]
														],
														o: [
															[
																0,
																0
															],
															[
																3.326,
																0
															],
															[
																0,
																0
															],
															[
																0,
																-3.326
															],
															[
																0,
																0
															],
															[
																-3.326,
																0
															],
															[
																0,
																0
															],
															[
																0,
																3.326
															]
														],
														v: [
															[
																304.61,
																-35.923
															],
															[
																386.525,
																-35.923
															],
															[
																392.547,
																-41.945
															],
															[
																392.547,
																-109.7
															],
															[
																386.525,
																-115.722
															],
															[
																304.61,
																-115.722
															],
															[
																298.588,
																-109.7
															],
															[
																298.588,
																-41.945
															]
														],
														c: true
													},
													ix: 2
												},
												nm: "Path 1",
												mn: "ADBE Vector Shape - Group",
												hd: false
											},
											{
												ty: "fl",
												c: {
													a: 0,
													k: [
														0.78823530674,
														0.54509806633,
														0.823529422283,
														1
													],
													ix: 4
												},
												o: {
													a: 0,
													k: 100,
													ix: 5
												},
												r: 1,
												bm: 0,
												nm: "Fill 1",
												mn: "ADBE Vector Graphic - Fill",
												hd: false
											},
											{
												ty: "tr",
												p: {
													a: 0,
													k: [
														0,
														0
													],
													ix: 2
												},
												a: {
													a: 0,
													k: [
														0,
														0
													],
													ix: 1
												},
												s: {
													a: 0,
													k: [
														100,
														100
													],
													ix: 3
												},
												r: {
													a: 0,
													k: 0,
													ix: 6
												},
												o: {
													a: 0,
													k: 100,
													ix: 7
												},
												sk: {
													a: 0,
													k: 0,
													ix: 4
												},
												sa: {
													a: 0,
													k: 0,
													ix: 5
												},
												nm: "Transform"
											}
										],
										nm: "Group 1",
										np: 2,
										cix: 2,
										bm: 0,
										ix: 1,
										mn: "ADBE Vector Group",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 1",
								np: 1,
								cix: 2,
								bm: 0,
								ix: 1,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 1",
						np: 1,
						cix: 2,
						bm: 0,
						ix: 1,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "tr",
						p: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 2
						},
						a: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 1
						},
						s: {
							a: 0,
							k: [
								100,
								100
							],
							ix: 3
						},
						r: {
							a: 0,
							k: 0,
							ix: 6
						},
						o: {
							a: 0,
							k: 100,
							ix: 7
						},
						sk: {
							a: 0,
							k: 0,
							ix: 4
						},
						sa: {
							a: 0,
							k: 0,
							ix: 5
						},
						nm: "Transform"
					}
				],
				nm: "Group 1",
				np: 1,
				cix: 2,
				bm: 0,
				ix: 1,
				mn: "ADBE Vector Group",
				hd: false
			},
			{
				ty: "gr",
				it: [
					{
						ty: "gr",
						it: [
							{
								ty: "gr",
								it: [
									{
										ty: "gr",
										it: [
											{
												ind: 0,
												ty: "sh",
												ix: 1,
												ks: {
													a: 0,
													k: {
														i: [
															[
																3.309,
																0
															],
															[
																0,
																0
															],
															[
																0,
																3.309
															],
															[
																0,
																0
															],
															[
																-3.309,
																0
															],
															[
																0,
																0
															],
															[
																0,
																-3.309
															],
															[
																0,
																0
															]
														],
														o: [
															[
																0,
																0
															],
															[
																-3.309,
																0
															],
															[
																0,
																0
															],
															[
																0,
																-3.309
															],
															[
																0,
																0
															],
															[
																3.309,
																0
															],
															[
																0,
																0
															],
															[
																0,
																3.309
															]
														],
														v: [
															[
																422.522,
																4.407
															],
															[
																268.12,
																4.407
															],
															[
																262.129,
																-1.584
															],
															[
																262.129,
																-144.639
															],
															[
																268.12,
																-150.63
															],
															[
																422.522,
																-150.63
															],
															[
																428.512,
																-144.639
															],
															[
																428.512,
																-1.584
															]
														],
														c: true
													},
													ix: 2
												},
												nm: "Path 1",
												mn: "ADBE Vector Shape - Group",
												hd: false
											},
											{
												ty: "st",
												c: {
													a: 0,
													k: [
														0.870588243008,
														0.847058832645,
														0.835294127464,
														1
													],
													ix: 3
												},
												o: {
													a: 0,
													k: 100,
													ix: 4
												},
												w: {
													a: 0,
													k: 1.968,
													ix: 5
												},
												lc: 1,
												lj: 1,
												ml: 10,
												bm: 0,
												nm: "Stroke 1",
												mn: "ADBE Vector Graphic - Stroke",
												hd: false
											},
											{
												ty: "tr",
												p: {
													a: 0,
													k: [
														0,
														0
													],
													ix: 2
												},
												a: {
													a: 0,
													k: [
														0,
														0
													],
													ix: 1
												},
												s: {
													a: 0,
													k: [
														100,
														100
													],
													ix: 3
												},
												r: {
													a: 0,
													k: 0,
													ix: 6
												},
												o: {
													a: 0,
													k: 100,
													ix: 7
												},
												sk: {
													a: 0,
													k: 0,
													ix: 4
												},
												sa: {
													a: 0,
													k: 0,
													ix: 5
												},
												nm: "Transform"
											}
										],
										nm: "Group 1",
										np: 2,
										cix: 2,
										bm: 0,
										ix: 1,
										mn: "ADBE Vector Group",
										hd: false
									},
									{
										ty: "gr",
										it: [
											{
												ind: 0,
												ty: "sh",
												ix: 1,
												ks: {
													a: 0,
													k: {
														i: [
															[
																3.309,
																0
															],
															[
																0,
																0
															],
															[
																0,
																3.309
															],
															[
																0,
																0
															],
															[
																-3.309,
																0
															],
															[
																0,
																0
															],
															[
																0,
																-3.309
															],
															[
																0,
																0
															]
														],
														o: [
															[
																0,
																0
															],
															[
																-3.309,
																0
															],
															[
																0,
																0
															],
															[
																0,
																-3.309
															],
															[
																0,
																0
															],
															[
																3.309,
																0
															],
															[
																0,
																0
															],
															[
																0,
																3.309
															]
														],
														v: [
															[
																422.522,
																4.407
															],
															[
																268.12,
																4.407
															],
															[
																262.129,
																-1.584
															],
															[
																262.129,
																-144.639
															],
															[
																268.12,
																-150.63
															],
															[
																422.522,
																-150.63
															],
															[
																428.512,
																-144.639
															],
															[
																428.512,
																-1.584
															]
														],
														c: true
													},
													ix: 2
												},
												nm: "Path 1",
												mn: "ADBE Vector Shape - Group",
												hd: false
											},
											{
												ty: "fl",
												c: {
													a: 0,
													k: [
														0.929411768913,
														0.929411768913,
														0.929411768913,
														1
													],
													ix: 4
												},
												o: {
													a: 0,
													k: 100,
													ix: 5
												},
												r: 1,
												bm: 0,
												nm: "Fill 1",
												mn: "ADBE Vector Graphic - Fill",
												hd: false
											},
											{
												ty: "tr",
												p: {
													a: 0,
													k: [
														0,
														0
													],
													ix: 2
												},
												a: {
													a: 0,
													k: [
														0,
														0
													],
													ix: 1
												},
												s: {
													a: 0,
													k: [
														100,
														100
													],
													ix: 3
												},
												r: {
													a: 0,
													k: 0,
													ix: 6
												},
												o: {
													a: 0,
													k: 100,
													ix: 7
												},
												sk: {
													a: 0,
													k: 0,
													ix: 4
												},
												sa: {
													a: 0,
													k: 0,
													ix: 5
												},
												nm: "Transform"
											}
										],
										nm: "Group 2",
										np: 2,
										cix: 2,
										bm: 0,
										ix: 2,
										mn: "ADBE Vector Group",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 1",
								np: 2,
								cix: 2,
								bm: 0,
								ix: 1,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 1",
						np: 1,
						cix: 2,
						bm: 0,
						ix: 1,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "tr",
						p: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 2
						},
						a: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 1
						},
						s: {
							a: 0,
							k: [
								100,
								100
							],
							ix: 3
						},
						r: {
							a: 0,
							k: 0,
							ix: 6
						},
						o: {
							a: 0,
							k: 100,
							ix: 7
						},
						sk: {
							a: 0,
							k: 0,
							ix: 4
						},
						sa: {
							a: 0,
							k: 0,
							ix: 5
						},
						nm: "Transform"
					}
				],
				nm: "Group 2",
				np: 1,
				cix: 2,
				bm: 0,
				ix: 2,
				mn: "ADBE Vector Group",
				hd: false
			}
		],
		ip: 0,
		op: 180,
		st: 0,
		bm: 0
	},
	{
		ddd: 0,
		ind: 9,
		ty: 4,
		nm: "Layer 18",
		parent: 1,
		sr: 1,
		ks: {
			o: {
				a: 0,
				k: 100,
				ix: 11
			},
			r: {
				a: 0,
				k: 0,
				ix: 10
			},
			p: {
				a: 0,
				k: [
					73.437,
					116.512,
					0
				],
				ix: 2
			},
			a: {
				a: 0,
				k: [
					16.171,
					19.187,
					0
				],
				ix: 1
			},
			s: {
				a: 0,
				k: [
					100,
					100,
					100
				],
				ix: 6
			}
		},
		ao: 0,
		shapes: [
			{
				ty: "gr",
				it: [
					{
						ty: "gr",
						it: [
							{
								ty: "gr",
								it: [
									{
										ind: 0,
										ty: "sh",
										ix: 1,
										ks: {
											a: 0,
											k: {
												i: [
													[
														0,
														-3.245
													],
													[
														3.245,
														0
													],
													[
														0,
														3.245
													],
													[
														-3.245,
														0
													]
												],
												o: [
													[
														0,
														3.245
													],
													[
														-3.245,
														0
													],
													[
														0,
														-3.245
													],
													[
														3.245,
														0
													]
												],
												v: [
													[
														-217.009,
														-158.05
													],
													[
														-222.885,
														-152.175
													],
													[
														-228.76,
														-158.05
													],
													[
														-222.885,
														-163.926
													]
												],
												c: true
											},
											ix: 2
										},
										nm: "Path 1",
										mn: "ADBE Vector Shape - Group",
										hd: false
									},
									{
										ty: "fl",
										c: {
											a: 0,
											k: [
												0,
												0.521568655968,
												0.482352942228,
												1
											],
											ix: 4
										},
										o: {
											a: 0,
											k: 100,
											ix: 5
										},
										r: 1,
										bm: 0,
										nm: "Fill 1",
										mn: "ADBE Vector Graphic - Fill",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 1",
								np: 2,
								cix: 2,
								bm: 0,
								ix: 1,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "gr",
								it: [
									{
										ind: 0,
										ty: "sh",
										ix: 1,
										ks: {
											a: 0,
											k: {
												i: [
													[
														0,
														-3.245
													],
													[
														3.245,
														0
													],
													[
														0,
														3.245
													],
													[
														-3.245,
														0
													]
												],
												o: [
													[
														0,
														3.245
													],
													[
														-3.245,
														0
													],
													[
														0,
														-3.245
													],
													[
														3.245,
														0
													]
												],
												v: [
													[
														-239.845,
														-158.05
													],
													[
														-245.721,
														-152.175
													],
													[
														-251.597,
														-158.05
													],
													[
														-245.721,
														-163.926
													]
												],
												c: true
											},
											ix: 2
										},
										nm: "Path 1",
										mn: "ADBE Vector Shape - Group",
										hd: false
									},
									{
										ty: "fl",
										c: {
											a: 0,
											k: [
												0.917647063732,
												0.823529422283,
												0.329411774874,
												1
											],
											ix: 4
										},
										o: {
											a: 0,
											k: 100,
											ix: 5
										},
										r: 1,
										bm: 0,
										nm: "Fill 1",
										mn: "ADBE Vector Graphic - Fill",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 2",
								np: 2,
								cix: 2,
								bm: 0,
								ix: 2,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "gr",
								it: [
									{
										ind: 0,
										ty: "sh",
										ix: 1,
										ks: {
											a: 0,
											k: {
												i: [
													[
														0,
														-3.245
													],
													[
														3.245,
														0
													],
													[
														0,
														3.245
													],
													[
														-3.245,
														0
													]
												],
												o: [
													[
														0,
														3.245
													],
													[
														-3.245,
														0
													],
													[
														0,
														-3.245
													],
													[
														3.245,
														0
													]
												],
												v: [
													[
														-262.681,
														-158.05
													],
													[
														-268.557,
														-152.175
													],
													[
														-274.433,
														-158.05
													],
													[
														-268.557,
														-163.926
													]
												],
												c: true
											},
											ix: 2
										},
										nm: "Path 1",
										mn: "ADBE Vector Shape - Group",
										hd: false
									},
									{
										ty: "fl",
										c: {
											a: 0,
											k: [
												1,
												0.694117665291,
												0.647058844566,
												1
											],
											ix: 4
										},
										o: {
											a: 0,
											k: 100,
											ix: 5
										},
										r: 1,
										bm: 0,
										nm: "Fill 1",
										mn: "ADBE Vector Graphic - Fill",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 3",
								np: 2,
								cix: 2,
								bm: 0,
								ix: 3,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 1",
						np: 3,
						cix: 2,
						bm: 0,
						ix: 1,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												3.602,
												0
											],
											[
												0,
												0
											],
											[
												0,
												3.602
											],
											[
												0,
												0
											],
											[
												-3.602,
												0
											],
											[
												0,
												0
											],
											[
												0,
												-3.602
											],
											[
												0,
												0
											]
										],
										o: [
											[
												0,
												0
											],
											[
												-3.602,
												0
											],
											[
												0,
												0
											],
											[
												0,
												-3.602
											],
											[
												0,
												0
											],
											[
												3.602,
												0
											],
											[
												0,
												0
											],
											[
												0,
												3.602
											]
										],
										v: [
											[
												330.835,
												217.908
											],
											[
												-298.495,
												217.908
											],
											[
												-305.016,
												211.387
											],
											[
												-305.016,
												-173.013
											],
											[
												-298.495,
												-179.534
											],
											[
												330.835,
												-179.534
											],
											[
												337.357,
												-173.013
											],
											[
												337.357,
												211.387
											]
										],
										c: true
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "st",
								c: {
									a: 0,
									k: [
										0.870588243008,
										0.847058832645,
										0.835294127464,
										1
									],
									ix: 3
								},
								o: {
									a: 0,
									k: 100,
									ix: 4
								},
								w: {
									a: 0,
									k: 1.968,
									ix: 5
								},
								lc: 1,
								lj: 1,
								ml: 10,
								bm: 0,
								nm: "Stroke 1",
								mn: "ADBE Vector Graphic - Stroke",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 2",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 2,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "gr",
						it: [
							{
								ind: 0,
								ty: "sh",
								ix: 1,
								ks: {
									a: 0,
									k: {
										i: [
											[
												0,
												0
											],
											[
												0,
												0
											]
										],
										o: [
											[
												0,
												0
											],
											[
												0,
												0
											]
										],
										v: [
											[
												-305.016,
												-137.425
											],
											[
												337.357,
												-137.425
											]
										],
										c: false
									},
									ix: 2
								},
								nm: "Path 1",
								mn: "ADBE Vector Shape - Group",
								hd: false
							},
							{
								ty: "st",
								c: {
									a: 0,
									k: [
										0.870588243008,
										0.847058832645,
										0.835294127464,
										1
									],
									ix: 3
								},
								o: {
									a: 0,
									k: 100,
									ix: 4
								},
								w: {
									a: 0,
									k: 1.968,
									ix: 5
								},
								lc: 1,
								lj: 1,
								ml: 10,
								bm: 0,
								nm: "Stroke 1",
								mn: "ADBE Vector Graphic - Stroke",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 3",
						np: 2,
						cix: 2,
						bm: 0,
						ix: 3,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "tr",
						p: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 2
						},
						a: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 1
						},
						s: {
							a: 0,
							k: [
								100,
								100
							],
							ix: 3
						},
						r: {
							a: 0,
							k: 0,
							ix: 6
						},
						o: {
							a: 0,
							k: 100,
							ix: 7
						},
						sk: {
							a: 0,
							k: 0,
							ix: 4
						},
						sa: {
							a: 0,
							k: 0,
							ix: 5
						},
						nm: "Transform"
					}
				],
				nm: "Group 1",
				np: 3,
				cix: 2,
				bm: 0,
				ix: 1,
				mn: "ADBE Vector Group",
				hd: false
			}
		],
		ip: 0,
		op: 180,
		st: 0,
		bm: 0
	},
	{
		ddd: 0,
		ind: 10,
		ty: 4,
		nm: "Layer 17",
		parent: 1,
		sr: 1,
		ks: {
			o: {
				a: 0,
				k: 100,
				ix: 11
			},
			r: {
				a: 0,
				k: 0,
				ix: 10
			},
			p: {
				a: 0,
				k: [
					-298.111,
					282.661,
					0
				],
				ix: 2
			},
			a: {
				a: 0,
				k: [
					-355.377,
					185.336,
					0
				],
				ix: 1
			},
			s: {
				a: 1,
				k: [
					{
						i: {
							x: [
								0.667,
								0.667,
								0.667
							],
							y: [
								1,
								1,
								1
							]
						},
						o: {
							x: [
								0.333,
								0.333,
								0.333
							],
							y: [
								0,
								0,
								0
							]
						},
						t: 8,
						s: [
							0,
							0,
							100
						]
					},
					{
						i: {
							x: [
								0.667,
								0.667,
								0.667
							],
							y: [
								1,
								1,
								1
							]
						},
						o: {
							x: [
								0.333,
								0.333,
								0.333
							],
							y: [
								0,
								0,
								0
							]
						},
						t: 29.25,
						s: [
							100,
							100,
							100
						]
					},
					{
						i: {
							x: [
								0.667,
								0.667,
								0.667
							],
							y: [
								1,
								1,
								1
							]
						},
						o: {
							x: [
								0.333,
								0.333,
								0.333
							],
							y: [
								0,
								0,
								0
							]
						},
						t: 50.5,
						s: [
							0,
							0,
							100
						]
					},
					{
						i: {
							x: [
								0.667,
								0.667,
								0.667
							],
							y: [
								1,
								1,
								1
							]
						},
						o: {
							x: [
								0.333,
								0.333,
								0.333
							],
							y: [
								0,
								0,
								0
							]
						},
						t: 71.75,
						s: [
							100,
							100,
							100
						]
					},
					{
						i: {
							x: [
								0.667,
								0.667,
								0.667
							],
							y: [
								1,
								1,
								1
							]
						},
						o: {
							x: [
								0.333,
								0.333,
								0.333
							],
							y: [
								0,
								0,
								0
							]
						},
						t: 93,
						s: [
							0,
							0,
							100
						]
					},
					{
						i: {
							x: [
								0.667,
								0.667,
								0.667
							],
							y: [
								1,
								1,
								1
							]
						},
						o: {
							x: [
								0.333,
								0.333,
								0.333
							],
							y: [
								0,
								0,
								0
							]
						},
						t: 114.25,
						s: [
							100,
							100,
							100
						]
					},
					{
						i: {
							x: [
								0.667,
								0.667,
								0.667
							],
							y: [
								1,
								1,
								1
							]
						},
						o: {
							x: [
								0.333,
								0.333,
								0.333
							],
							y: [
								0,
								0,
								0
							]
						},
						t: 135.5,
						s: [
							0,
							0,
							100
						]
					},
					{
						i: {
							x: [
								0.667,
								0.667,
								0.667
							],
							y: [
								1,
								1,
								1
							]
						},
						o: {
							x: [
								0.333,
								0.333,
								0.333
							],
							y: [
								0,
								0,
								0
							]
						},
						t: 156.75,
						s: [
							100,
							100,
							100
						]
					},
					{
						t: 178,
						s: [
							0,
							0,
							100
						]
					}
				],
				ix: 6
			}
		},
		ao: 0,
		shapes: [
			{
				ty: "gr",
				it: [
					{
						ind: 0,
						ty: "sh",
						ix: 1,
						ks: {
							a: 0,
							k: {
								i: [
									[
										1.58,
										0
									],
									[
										0,
										0
									],
									[
										0,
										1.58
									],
									[
										0,
										0
									],
									[
										-1.58,
										0
									],
									[
										0,
										0
									],
									[
										0,
										-1.58
									],
									[
										0,
										0
									]
								],
								o: [
									[
										0,
										0
									],
									[
										-1.58,
										0
									],
									[
										0,
										0
									],
									[
										0,
										-1.58
									],
									[
										0,
										0
									],
									[
										1.58,
										0
									],
									[
										0,
										0
									],
									[
										0,
										1.58
									]
								],
								v: [
									[
										-350.69,
										192.648
									],
									[
										-360.065,
										192.648
									],
									[
										-362.926,
										189.786
									],
									[
										-362.926,
										180.886
									],
									[
										-360.065,
										178.024
									],
									[
										-350.69,
										178.024
									],
									[
										-347.829,
										180.886
									],
									[
										-347.829,
										189.786
									]
								],
								c: true
							},
							ix: 2
						},
						nm: "Path 1",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ty: "fl",
						c: {
							a: 0,
							k: [
								0,
								0,
								0,
								1
							],
							ix: 4
						},
						o: {
							a: 0,
							k: 100,
							ix: 5
						},
						r: 1,
						bm: 0,
						nm: "Fill 1",
						mn: "ADBE Vector Graphic - Fill",
						hd: false
					},
					{
						ty: "tr",
						p: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 2
						},
						a: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 1
						},
						s: {
							a: 0,
							k: [
								100,
								100
							],
							ix: 3
						},
						r: {
							a: 0,
							k: 0,
							ix: 6
						},
						o: {
							a: 0,
							k: 100,
							ix: 7
						},
						sk: {
							a: 0,
							k: 0,
							ix: 4
						},
						sa: {
							a: 0,
							k: 0,
							ix: 5
						},
						nm: "Transform"
					}
				],
				nm: "Group 1",
				np: 2,
				cix: 2,
				bm: 0,
				ix: 1,
				mn: "ADBE Vector Group",
				hd: false
			}
		],
		ip: 8,
		op: 188,
		st: 8,
		bm: 0
	},
	{
		ddd: 0,
		ind: 11,
		ty: 4,
		nm: "Layer 16",
		parent: 1,
		sr: 1,
		ks: {
			o: {
				a: 0,
				k: 100,
				ix: 11
			},
			r: {
				a: 0,
				k: 0,
				ix: 10
			},
			p: {
				a: 0,
				k: [
					435.18,
					248.859,
					0
				],
				ix: 2
			},
			a: {
				a: 0,
				k: [
					377.913,
					151.533,
					0
				],
				ix: 1
			},
			s: {
				a: 1,
				k: [
					{
						i: {
							x: [
								0.667,
								0.667,
								0.667
							],
							y: [
								1,
								1,
								1
							]
						},
						o: {
							x: [
								0.333,
								0.333,
								0.333
							],
							y: [
								0,
								0,
								0
							]
						},
						t: 0,
						s: [
							0,
							0,
							100
						]
					},
					{
						i: {
							x: [
								0.667,
								0.667,
								0.667
							],
							y: [
								1,
								1,
								1
							]
						},
						o: {
							x: [
								0.333,
								0.333,
								0.333
							],
							y: [
								0,
								0,
								0
							]
						},
						t: 21.25,
						s: [
							100,
							100,
							100
						]
					},
					{
						i: {
							x: [
								0.667,
								0.667,
								0.667
							],
							y: [
								1,
								1,
								1
							]
						},
						o: {
							x: [
								0.333,
								0.333,
								0.333
							],
							y: [
								0,
								0,
								0
							]
						},
						t: 42.5,
						s: [
							0,
							0,
							100
						]
					},
					{
						i: {
							x: [
								0.667,
								0.667,
								0.667
							],
							y: [
								1,
								1,
								1
							]
						},
						o: {
							x: [
								0.333,
								0.333,
								0.333
							],
							y: [
								0,
								0,
								0
							]
						},
						t: 63.75,
						s: [
							100,
							100,
							100
						]
					},
					{
						i: {
							x: [
								0.667,
								0.667,
								0.667
							],
							y: [
								1,
								1,
								1
							]
						},
						o: {
							x: [
								0.333,
								0.333,
								0.333
							],
							y: [
								0,
								0,
								0
							]
						},
						t: 85,
						s: [
							0,
							0,
							100
						]
					},
					{
						i: {
							x: [
								0.667,
								0.667,
								0.667
							],
							y: [
								1,
								1,
								1
							]
						},
						o: {
							x: [
								0.333,
								0.333,
								0.333
							],
							y: [
								0,
								0,
								0
							]
						},
						t: 106.25,
						s: [
							100,
							100,
							100
						]
					},
					{
						i: {
							x: [
								0.667,
								0.667,
								0.667
							],
							y: [
								1,
								1,
								1
							]
						},
						o: {
							x: [
								0.333,
								0.333,
								0.333
							],
							y: [
								0,
								0,
								0
							]
						},
						t: 127.5,
						s: [
							0,
							0,
							100
						]
					},
					{
						i: {
							x: [
								0.667,
								0.667,
								0.667
							],
							y: [
								1,
								1,
								1
							]
						},
						o: {
							x: [
								0.333,
								0.333,
								0.333
							],
							y: [
								0,
								0,
								0
							]
						},
						t: 148.75,
						s: [
							100,
							100,
							100
						]
					},
					{
						t: 170,
						s: [
							0,
							0,
							100
						]
					}
				],
				ix: 6
			}
		},
		ao: 0,
		shapes: [
			{
				ty: "gr",
				it: [
					{
						ind: 0,
						ty: "sh",
						ix: 1,
						ks: {
							a: 0,
							k: {
								i: [
									[
										1.58,
										0
									],
									[
										0,
										0
									],
									[
										0,
										1.58
									],
									[
										0,
										0
									],
									[
										-1.58,
										0
									],
									[
										0,
										0
									],
									[
										0,
										-1.58
									],
									[
										0,
										0
									]
								],
								o: [
									[
										0,
										0
									],
									[
										-1.58,
										0
									],
									[
										0,
										0
									],
									[
										0,
										-1.58
									],
									[
										0,
										0
									],
									[
										1.58,
										0
									],
									[
										0,
										0
									],
									[
										0,
										1.58
									]
								],
								v: [
									[
										382.601,
										158.845
									],
									[
										373.226,
										158.845
									],
									[
										370.365,
										155.984
									],
									[
										370.365,
										147.083
									],
									[
										373.226,
										144.222
									],
									[
										382.601,
										144.222
									],
									[
										385.462,
										147.083
									],
									[
										385.462,
										155.984
									]
								],
								c: true
							},
							ix: 2
						},
						nm: "Path 1",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ty: "fl",
						c: {
							a: 0,
							k: [
								0.8941176470588236,
								0.4666666666666667,
								0.3764705882352941,
								1
							],
							ix: 4
						},
						o: {
							a: 0,
							k: 100,
							ix: 5
						},
						r: 1,
						bm: 0,
						nm: "Fill 1",
						mn: "ADBE Vector Graphic - Fill",
						hd: false
					},
					{
						ty: "tr",
						p: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 2
						},
						a: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 1
						},
						s: {
							a: 0,
							k: [
								100,
								100
							],
							ix: 3
						},
						r: {
							a: 0,
							k: 0,
							ix: 6
						},
						o: {
							a: 0,
							k: 100,
							ix: 7
						},
						sk: {
							a: 0,
							k: 0,
							ix: 4
						},
						sa: {
							a: 0,
							k: 0,
							ix: 5
						},
						nm: "Transform"
					}
				],
				nm: "Group 1",
				np: 2,
				cix: 2,
				bm: 0,
				ix: 1,
				mn: "ADBE Vector Group",
				hd: false
			}
		],
		ip: 0,
		op: 180,
		st: 0,
		bm: 0
	},
	{
		ddd: 0,
		ind: 12,
		ty: 4,
		nm: "Shape Layer 10",
		parent: 1,
		td: 1,
		sr: 1,
		ks: {
			o: {
				a: 0,
				k: 100,
				ix: 11
			},
			r: {
				a: 0,
				k: 0,
				ix: 10
			},
			p: {
				a: 0,
				k: [
					57.267,
					97.325,
					0
				],
				ix: 2
			},
			a: {
				a: 0,
				k: [
					0,
					0,
					0
				],
				ix: 1
			},
			s: {
				a: 0,
				k: [
					100,
					100,
					100
				],
				ix: 6
			}
		},
		ao: 0,
		shapes: [
			{
				ty: "gr",
				it: [
					{
						ind: 0,
						ty: "sh",
						ix: 1,
						ks: {
							a: 0,
							k: {
								i: [
									[
										0,
										0
									],
									[
										0,
										0
									]
								],
								o: [
									[
										0,
										0
									],
									[
										0,
										0
									]
								],
								v: [
									[
										357.5,
										97.25
									],
									[
										432.5,
										96.75
									]
								],
								c: false
							},
							ix: 2
						},
						nm: "Path 1",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ty: "st",
						c: {
							a: 0,
							k: [
								0.645784983915,
								0.674509983437,
								0.640123015759,
								1
							],
							ix: 3
						},
						o: {
							a: 0,
							k: 100,
							ix: 4
						},
						w: {
							a: 0,
							k: 16,
							ix: 5
						},
						lc: 1,
						lj: 1,
						ml: 4,
						bm: 0,
						nm: "Stroke 1",
						mn: "ADBE Vector Graphic - Stroke",
						hd: false
					},
					{
						ty: "tr",
						p: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 2
						},
						a: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 1
						},
						s: {
							a: 0,
							k: [
								100,
								100
							],
							ix: 3
						},
						r: {
							a: 0,
							k: 0,
							ix: 6
						},
						o: {
							a: 0,
							k: 100,
							ix: 7
						},
						sk: {
							a: 0,
							k: 0,
							ix: 4
						},
						sa: {
							a: 0,
							k: 0,
							ix: 5
						},
						nm: "Transform"
					}
				],
				nm: "Shape 1",
				np: 3,
				cix: 2,
				bm: 0,
				ix: 1,
				mn: "ADBE Vector Group",
				hd: false
			},
			{
				ty: "tm",
				s: {
					a: 1,
					k: [
						{
							i: {
								x: [
									0.667
								],
								y: [
									1
								]
							},
							o: {
								x: [
									0.333
								],
								y: [
									0
								]
							},
							t: 145,
							s: [
								0
							]
						},
						{
							t: 160,
							s: [
								100
							]
						}
					],
					ix: 1
				},
				e: {
					a: 1,
					k: [
						{
							i: {
								x: [
									0.667
								],
								y: [
									1
								]
							},
							o: {
								x: [
									0.333
								],
								y: [
									0
								]
							},
							t: 165,
							s: [
								0
							]
						},
						{
							t: 180,
							s: [
								100
							]
						}
					],
					ix: 2
				},
				o: {
					a: 0,
					k: 0,
					ix: 3
				},
				m: 1,
				ix: 2,
				nm: "Trim Paths 1",
				mn: "ADBE Vector Filter - Trim",
				hd: false
			}
		],
		ip: 145,
		op: 180,
		st: 145,
		bm: 0
	},
	{
		ddd: 0,
		ind: 13,
		ty: 4,
		nm: "Layer 15",
		parent: 1,
		tt: 1,
		sr: 1,
		ks: {
			o: {
				a: 0,
				k: 100,
				ix: 11
			},
			r: {
				a: 0,
				k: 0,
				ix: 10
			},
			p: {
				a: 0,
				k: [
					451.733,
					194.849,
					0
				],
				ix: 2
			},
			a: {
				a: 0,
				k: [
					394.467,
					97.524,
					0
				],
				ix: 1
			},
			s: {
				a: 0,
				k: [
					100,
					100,
					100
				],
				ix: 6
			}
		},
		ao: 0,
		shapes: [
			{
				ty: "gr",
				it: [
					{
						ind: 0,
						ty: "sh",
						ix: 1,
						ks: {
							a: 0,
							k: {
								i: [
									[
										2.695,
										0
									],
									[
										0,
										0
									],
									[
										0,
										2.695
									],
									[
										0,
										0
									],
									[
										-2.695,
										0
									],
									[
										0,
										0
									],
									[
										0,
										-2.695
									],
									[
										0,
										0
									]
								],
								o: [
									[
										0,
										0
									],
									[
										-2.695,
										0
									],
									[
										0,
										0
									],
									[
										0,
										-2.695
									],
									[
										0,
										0
									],
									[
										2.695,
										0
									],
									[
										0,
										0
									],
									[
										0,
										2.695
									]
								],
								v: [
									[
										426.121,
										102.403
									],
									[
										362.812,
										102.403
									],
									[
										357.933,
										97.524
									],
									[
										357.933,
										97.524
									],
									[
										362.812,
										92.644
									],
									[
										426.121,
										92.644
									],
									[
										431,
										97.524
									],
									[
										431,
										97.524
									]
								],
								c: true
							},
							ix: 2
						},
						nm: "Path 1",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ty: "fl",
						c: {
							a: 0,
							k: [
								0.2196078431372549,
								0.1450980392156863,
								0.3764705882352941,
								1
							],
							ix: 4
						},
						o: {
							a: 0,
							k: 100,
							ix: 5
						},
						r: 1,
						bm: 0,
						nm: "Fill 1",
						mn: "ADBE Vector Graphic - Fill",
						hd: false
					},
					{
						ty: "tr",
						p: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 2
						},
						a: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 1
						},
						s: {
							a: 0,
							k: [
								100,
								100
							],
							ix: 3
						},
						r: {
							a: 0,
							k: 0,
							ix: 6
						},
						o: {
							a: 0,
							k: 100,
							ix: 7
						},
						sk: {
							a: 0,
							k: 0,
							ix: 4
						},
						sa: {
							a: 0,
							k: 0,
							ix: 5
						},
						nm: "Transform"
					}
				],
				nm: "Group 1",
				np: 2,
				cix: 2,
				bm: 0,
				ix: 1,
				mn: "ADBE Vector Group",
				hd: false
			}
		],
		ip: 145,
		op: 180,
		st: 145,
		bm: 0
	},
	{
		ddd: 0,
		ind: 14,
		ty: 4,
		nm: "Shape Layer 9",
		parent: 1,
		td: 1,
		sr: 1,
		ks: {
			o: {
				a: 0,
				k: 100,
				ix: 11
			},
			r: {
				a: 0,
				k: 0,
				ix: 10
			},
			p: {
				a: 0,
				k: [
					57.267,
					97.325,
					0
				],
				ix: 2
			},
			a: {
				a: 0,
				k: [
					0,
					0,
					0
				],
				ix: 1
			},
			s: {
				a: 0,
				k: [
					100,
					100,
					100
				],
				ix: 6
			}
		},
		ao: 0,
		shapes: [
			{
				ty: "gr",
				it: [
					{
						ind: 0,
						ty: "sh",
						ix: 1,
						ks: {
							a: 0,
							k: {
								i: [
									[
										0,
										0
									],
									[
										0,
										0
									]
								],
								o: [
									[
										0,
										0
									],
									[
										0,
										0
									]
								],
								v: [
									[
										357.5,
										97.25
									],
									[
										432.5,
										96.75
									]
								],
								c: false
							},
							ix: 2
						},
						nm: "Path 1",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ty: "st",
						c: {
							a: 0,
							k: [
								0.645784983915,
								0.674509983437,
								0.640123015759,
								1
							],
							ix: 3
						},
						o: {
							a: 0,
							k: 100,
							ix: 4
						},
						w: {
							a: 0,
							k: 16,
							ix: 5
						},
						lc: 1,
						lj: 1,
						ml: 4,
						bm: 0,
						nm: "Stroke 1",
						mn: "ADBE Vector Graphic - Stroke",
						hd: false
					},
					{
						ty: "tr",
						p: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 2
						},
						a: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 1
						},
						s: {
							a: 0,
							k: [
								100,
								100
							],
							ix: 3
						},
						r: {
							a: 0,
							k: 0,
							ix: 6
						},
						o: {
							a: 0,
							k: 100,
							ix: 7
						},
						sk: {
							a: 0,
							k: 0,
							ix: 4
						},
						sa: {
							a: 0,
							k: 0,
							ix: 5
						},
						nm: "Transform"
					}
				],
				nm: "Shape 1",
				np: 3,
				cix: 2,
				bm: 0,
				ix: 1,
				mn: "ADBE Vector Group",
				hd: false
			},
			{
				ty: "tm",
				s: {
					a: 1,
					k: [
						{
							i: {
								x: [
									0.667
								],
								y: [
									1
								]
							},
							o: {
								x: [
									0.333
								],
								y: [
									0
								]
							},
							t: 109,
							s: [
								0
							]
						},
						{
							t: 124,
							s: [
								100
							]
						}
					],
					ix: 1
				},
				e: {
					a: 1,
					k: [
						{
							i: {
								x: [
									0.667
								],
								y: [
									1
								]
							},
							o: {
								x: [
									0.333
								],
								y: [
									0
								]
							},
							t: 129,
							s: [
								0
							]
						},
						{
							t: 144,
							s: [
								100
							]
						}
					],
					ix: 2
				},
				o: {
					a: 0,
					k: 0,
					ix: 3
				},
				m: 1,
				ix: 2,
				nm: "Trim Paths 1",
				mn: "ADBE Vector Filter - Trim",
				hd: false
			}
		],
		ip: 109,
		op: 144,
		st: 109,
		bm: 0
	},
	{
		ddd: 0,
		ind: 15,
		ty: 4,
		nm: "Layer 14",
		parent: 1,
		tt: 1,
		sr: 1,
		ks: {
			o: {
				a: 0,
				k: 100,
				ix: 11
			},
			r: {
				a: 0,
				k: 0,
				ix: 10
			},
			p: {
				a: 0,
				k: [
					451.733,
					194.849,
					0
				],
				ix: 2
			},
			a: {
				a: 0,
				k: [
					394.467,
					97.524,
					0
				],
				ix: 1
			},
			s: {
				a: 0,
				k: [
					100,
					100,
					100
				],
				ix: 6
			}
		},
		ao: 0,
		shapes: [
			{
				ty: "gr",
				it: [
					{
						ind: 0,
						ty: "sh",
						ix: 1,
						ks: {
							a: 0,
							k: {
								i: [
									[
										2.695,
										0
									],
									[
										0,
										0
									],
									[
										0,
										2.695
									],
									[
										0,
										0
									],
									[
										-2.695,
										0
									],
									[
										0,
										0
									],
									[
										0,
										-2.695
									],
									[
										0,
										0
									]
								],
								o: [
									[
										0,
										0
									],
									[
										-2.695,
										0
									],
									[
										0,
										0
									],
									[
										0,
										-2.695
									],
									[
										0,
										0
									],
									[
										2.695,
										0
									],
									[
										0,
										0
									],
									[
										0,
										2.695
									]
								],
								v: [
									[
										426.121,
										102.403
									],
									[
										362.812,
										102.403
									],
									[
										357.933,
										97.524
									],
									[
										357.933,
										97.524
									],
									[
										362.812,
										92.644
									],
									[
										426.121,
										92.644
									],
									[
										431,
										97.524
									],
									[
										431,
										97.524
									]
								],
								c: true
							},
							ix: 2
						},
						nm: "Path 1",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ty: "fl",
						c: {
							a: 0,
							k: [
								0.8941176470588236,
								0.4666666666666667,
								0.3764705882352941,
								1
							],
							ix: 4
						},
						o: {
							a: 0,
							k: 100,
							ix: 5
						},
						r: 1,
						bm: 0,
						nm: "Fill 1",
						mn: "ADBE Vector Graphic - Fill",
						hd: false
					},
					{
						ty: "tr",
						p: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 2
						},
						a: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 1
						},
						s: {
							a: 0,
							k: [
								100,
								100
							],
							ix: 3
						},
						r: {
							a: 0,
							k: 0,
							ix: 6
						},
						o: {
							a: 0,
							k: 100,
							ix: 7
						},
						sk: {
							a: 0,
							k: 0,
							ix: 4
						},
						sa: {
							a: 0,
							k: 0,
							ix: 5
						},
						nm: "Transform"
					}
				],
				nm: "Group 1",
				np: 2,
				cix: 2,
				bm: 0,
				ix: 1,
				mn: "ADBE Vector Group",
				hd: false
			}
		],
		ip: 109,
		op: 144,
		st: 109,
		bm: 0
	},
	{
		ddd: 0,
		ind: 16,
		ty: 4,
		nm: "Shape Layer 8",
		parent: 1,
		td: 1,
		sr: 1,
		ks: {
			o: {
				a: 0,
				k: 100,
				ix: 11
			},
			r: {
				a: 0,
				k: 0,
				ix: 10
			},
			p: {
				a: 0,
				k: [
					57.267,
					97.325,
					0
				],
				ix: 2
			},
			a: {
				a: 0,
				k: [
					0,
					0,
					0
				],
				ix: 1
			},
			s: {
				a: 0,
				k: [
					100,
					100,
					100
				],
				ix: 6
			}
		},
		ao: 0,
		shapes: [
			{
				ty: "gr",
				it: [
					{
						ind: 0,
						ty: "sh",
						ix: 1,
						ks: {
							a: 0,
							k: {
								i: [
									[
										0,
										0
									],
									[
										0,
										0
									]
								],
								o: [
									[
										0,
										0
									],
									[
										0,
										0
									]
								],
								v: [
									[
										357.5,
										97.25
									],
									[
										432.5,
										96.75
									]
								],
								c: false
							},
							ix: 2
						},
						nm: "Path 1",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ty: "st",
						c: {
							a: 0,
							k: [
								0.6078431372549019,
								0.6078431372549019,
								0.6078431372549019,
								1
							],
							ix: 3
						},
						o: {
							a: 0,
							k: 100,
							ix: 4
						},
						w: {
							a: 0,
							k: 16,
							ix: 5
						},
						lc: 1,
						lj: 1,
						ml: 4,
						bm: 0,
						nm: "Stroke 1",
						mn: "ADBE Vector Graphic - Stroke",
						hd: false
					},
					{
						ty: "tr",
						p: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 2
						},
						a: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 1
						},
						s: {
							a: 0,
							k: [
								100,
								100
							],
							ix: 3
						},
						r: {
							a: 0,
							k: 0,
							ix: 6
						},
						o: {
							a: 0,
							k: 100,
							ix: 7
						},
						sk: {
							a: 0,
							k: 0,
							ix: 4
						},
						sa: {
							a: 0,
							k: 0,
							ix: 5
						},
						nm: "Transform"
					}
				],
				nm: "Shape 1",
				np: 3,
				cix: 2,
				bm: 0,
				ix: 1,
				mn: "ADBE Vector Group",
				hd: false
			},
			{
				ty: "tm",
				s: {
					a: 1,
					k: [
						{
							i: {
								x: [
									0.667
								],
								y: [
									1
								]
							},
							o: {
								x: [
									0.333
								],
								y: [
									0
								]
							},
							t: 73,
							s: [
								0
							]
						},
						{
							t: 88,
							s: [
								100
							]
						}
					],
					ix: 1
				},
				e: {
					a: 1,
					k: [
						{
							i: {
								x: [
									0.667
								],
								y: [
									1
								]
							},
							o: {
								x: [
									0.333
								],
								y: [
									0
								]
							},
							t: 93,
							s: [
								0
							]
						},
						{
							t: 108,
							s: [
								100
							]
						}
					],
					ix: 2
				},
				o: {
					a: 0,
					k: 0,
					ix: 3
				},
				m: 1,
				ix: 2,
				nm: "Trim Paths 1",
				mn: "ADBE Vector Filter - Trim",
				hd: false
			}
		],
		ip: 73,
		op: 108,
		st: 73,
		bm: 0
	},
	{
		ddd: 0,
		ind: 17,
		ty: 4,
		nm: "Layer 13",
		parent: 1,
		tt: 1,
		sr: 1,
		ks: {
			o: {
				a: 0,
				k: 100,
				ix: 11
			},
			r: {
				a: 0,
				k: 0,
				ix: 10
			},
			p: {
				a: 0,
				k: [
					451.733,
					194.849,
					0
				],
				ix: 2
			},
			a: {
				a: 0,
				k: [
					394.467,
					97.524,
					0
				],
				ix: 1
			},
			s: {
				a: 0,
				k: [
					100,
					100,
					100
				],
				ix: 6
			}
		},
		ao: 0,
		shapes: [
			{
				ty: "gr",
				it: [
					{
						ind: 0,
						ty: "sh",
						ix: 1,
						ks: {
							a: 0,
							k: {
								i: [
									[
										2.695,
										0
									],
									[
										0,
										0
									],
									[
										0,
										2.695
									],
									[
										0,
										0
									],
									[
										-2.695,
										0
									],
									[
										0,
										0
									],
									[
										0,
										-2.695
									],
									[
										0,
										0
									]
								],
								o: [
									[
										0,
										0
									],
									[
										-2.695,
										0
									],
									[
										0,
										0
									],
									[
										0,
										-2.695
									],
									[
										0,
										0
									],
									[
										2.695,
										0
									],
									[
										0,
										0
									],
									[
										0,
										2.695
									]
								],
								v: [
									[
										426.121,
										102.403
									],
									[
										362.812,
										102.403
									],
									[
										357.933,
										97.524
									],
									[
										357.933,
										97.524
									],
									[
										362.812,
										92.644
									],
									[
										426.121,
										92.644
									],
									[
										431,
										97.524
									],
									[
										431,
										97.524
									]
								],
								c: true
							},
							ix: 2
						},
						nm: "Path 1",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ty: "fl",
						c: {
							a: 0,
							k: [
								0.2196078431372549,
								0.1450980392156863,
								0.3764705882352941,
								1
							],
							ix: 4
						},
						o: {
							a: 0,
							k: 100,
							ix: 5
						},
						r: 1,
						bm: 0,
						nm: "Fill 1",
						mn: "ADBE Vector Graphic - Fill",
						hd: false
					},
					{
						ty: "tr",
						p: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 2
						},
						a: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 1
						},
						s: {
							a: 0,
							k: [
								100,
								100
							],
							ix: 3
						},
						r: {
							a: 0,
							k: 0,
							ix: 6
						},
						o: {
							a: 0,
							k: 100,
							ix: 7
						},
						sk: {
							a: 0,
							k: 0,
							ix: 4
						},
						sa: {
							a: 0,
							k: 0,
							ix: 5
						},
						nm: "Transform"
					}
				],
				nm: "Group 1",
				np: 2,
				cix: 2,
				bm: 0,
				ix: 1,
				mn: "ADBE Vector Group",
				hd: false
			}
		],
		ip: 73,
		op: 108,
		st: 73,
		bm: 0
	},
	{
		ddd: 0,
		ind: 18,
		ty: 4,
		nm: "Shape Layer 7",
		parent: 1,
		td: 1,
		sr: 1,
		ks: {
			o: {
				a: 0,
				k: 100,
				ix: 11
			},
			r: {
				a: 0,
				k: 0,
				ix: 10
			},
			p: {
				a: 0,
				k: [
					57.267,
					97.325,
					0
				],
				ix: 2
			},
			a: {
				a: 0,
				k: [
					0,
					0,
					0
				],
				ix: 1
			},
			s: {
				a: 0,
				k: [
					100,
					100,
					100
				],
				ix: 6
			}
		},
		ao: 0,
		shapes: [
			{
				ty: "gr",
				it: [
					{
						ind: 0,
						ty: "sh",
						ix: 1,
						ks: {
							a: 0,
							k: {
								i: [
									[
										0,
										0
									],
									[
										0,
										0
									]
								],
								o: [
									[
										0,
										0
									],
									[
										0,
										0
									]
								],
								v: [
									[
										357.5,
										97.25
									],
									[
										432.5,
										96.75
									]
								],
								c: false
							},
							ix: 2
						},
						nm: "Path 1",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ty: "st",
						c: {
							a: 0,
							k: [
								0.645784983915,
								0.674509983437,
								0.640123015759,
								1
							],
							ix: 3
						},
						o: {
							a: 0,
							k: 100,
							ix: 4
						},
						w: {
							a: 0,
							k: 16,
							ix: 5
						},
						lc: 1,
						lj: 1,
						ml: 4,
						bm: 0,
						nm: "Stroke 1",
						mn: "ADBE Vector Graphic - Stroke",
						hd: false
					},
					{
						ty: "tr",
						p: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 2
						},
						a: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 1
						},
						s: {
							a: 0,
							k: [
								100,
								100
							],
							ix: 3
						},
						r: {
							a: 0,
							k: 0,
							ix: 6
						},
						o: {
							a: 0,
							k: 100,
							ix: 7
						},
						sk: {
							a: 0,
							k: 0,
							ix: 4
						},
						sa: {
							a: 0,
							k: 0,
							ix: 5
						},
						nm: "Transform"
					}
				],
				nm: "Shape 1",
				np: 3,
				cix: 2,
				bm: 0,
				ix: 1,
				mn: "ADBE Vector Group",
				hd: false
			},
			{
				ty: "tm",
				s: {
					a: 1,
					k: [
						{
							i: {
								x: [
									0.667
								],
								y: [
									1
								]
							},
							o: {
								x: [
									0.333
								],
								y: [
									0
								]
							},
							t: 36,
							s: [
								0
							]
						},
						{
							t: 51,
							s: [
								100
							]
						}
					],
					ix: 1
				},
				e: {
					a: 1,
					k: [
						{
							i: {
								x: [
									0.667
								],
								y: [
									1
								]
							},
							o: {
								x: [
									0.333
								],
								y: [
									0
								]
							},
							t: 56,
							s: [
								0
							]
						},
						{
							t: 71,
							s: [
								100
							]
						}
					],
					ix: 2
				},
				o: {
					a: 0,
					k: 0,
					ix: 3
				},
				m: 1,
				ix: 2,
				nm: "Trim Paths 1",
				mn: "ADBE Vector Filter - Trim",
				hd: false
			}
		],
		ip: 36,
		op: 71,
		st: 36,
		bm: 0
	},
	{
		ddd: 0,
		ind: 19,
		ty: 4,
		nm: "Layer 12",
		parent: 1,
		tt: 1,
		sr: 1,
		ks: {
			o: {
				a: 0,
				k: 100,
				ix: 11
			},
			r: {
				a: 0,
				k: 0,
				ix: 10
			},
			p: {
				a: 0,
				k: [
					451.733,
					194.849,
					0
				],
				ix: 2
			},
			a: {
				a: 0,
				k: [
					394.467,
					97.524,
					0
				],
				ix: 1
			},
			s: {
				a: 0,
				k: [
					100,
					100,
					100
				],
				ix: 6
			}
		},
		ao: 0,
		shapes: [
			{
				ty: "gr",
				it: [
					{
						ind: 0,
						ty: "sh",
						ix: 1,
						ks: {
							a: 0,
							k: {
								i: [
									[
										2.695,
										0
									],
									[
										0,
										0
									],
									[
										0,
										2.695
									],
									[
										0,
										0
									],
									[
										-2.695,
										0
									],
									[
										0,
										0
									],
									[
										0,
										-2.695
									],
									[
										0,
										0
									]
								],
								o: [
									[
										0,
										0
									],
									[
										-2.695,
										0
									],
									[
										0,
										0
									],
									[
										0,
										-2.695
									],
									[
										0,
										0
									],
									[
										2.695,
										0
									],
									[
										0,
										0
									],
									[
										0,
										2.695
									]
								],
								v: [
									[
										426.121,
										102.403
									],
									[
										362.812,
										102.403
									],
									[
										357.933,
										97.524
									],
									[
										357.933,
										97.524
									],
									[
										362.812,
										92.644
									],
									[
										426.121,
										92.644
									],
									[
										431,
										97.524
									],
									[
										431,
										97.524
									]
								],
								c: true
							},
							ix: 2
						},
						nm: "Path 1",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ty: "fl",
						c: {
							a: 0,
							k: [
								0.2196078431372549,
								0.1450980392156863,
								0.3764705882352941,
								1
							],
							ix: 4
						},
						o: {
							a: 0,
							k: 100,
							ix: 5
						},
						r: 1,
						bm: 0,
						nm: "Fill 1",
						mn: "ADBE Vector Graphic - Fill",
						hd: false
					},
					{
						ty: "tr",
						p: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 2
						},
						a: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 1
						},
						s: {
							a: 0,
							k: [
								100,
								100
							],
							ix: 3
						},
						r: {
							a: 0,
							k: 0,
							ix: 6
						},
						o: {
							a: 0,
							k: 100,
							ix: 7
						},
						sk: {
							a: 0,
							k: 0,
							ix: 4
						},
						sa: {
							a: 0,
							k: 0,
							ix: 5
						},
						nm: "Transform"
					}
				],
				nm: "Group 1",
				np: 2,
				cix: 2,
				bm: 0,
				ix: 1,
				mn: "ADBE Vector Group",
				hd: false
			}
		],
		ip: 36,
		op: 71,
		st: 36,
		bm: 0
	},
	{
		ddd: 0,
		ind: 20,
		ty: 4,
		nm: "Shape Layer 6",
		parent: 1,
		td: 1,
		sr: 1,
		ks: {
			o: {
				a: 0,
				k: 100,
				ix: 11
			},
			r: {
				a: 0,
				k: 0,
				ix: 10
			},
			p: {
				a: 0,
				k: [
					57.267,
					97.325,
					0
				],
				ix: 2
			},
			a: {
				a: 0,
				k: [
					0,
					0,
					0
				],
				ix: 1
			},
			s: {
				a: 0,
				k: [
					100,
					100,
					100
				],
				ix: 6
			}
		},
		ao: 0,
		shapes: [
			{
				ty: "gr",
				it: [
					{
						ind: 0,
						ty: "sh",
						ix: 1,
						ks: {
							a: 0,
							k: {
								i: [
									[
										0,
										0
									],
									[
										0,
										0
									]
								],
								o: [
									[
										0,
										0
									],
									[
										0,
										0
									]
								],
								v: [
									[
										357.5,
										97.25
									],
									[
										432.5,
										96.75
									]
								],
								c: false
							},
							ix: 2
						},
						nm: "Path 1",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ty: "st",
						c: {
							a: 0,
							k: [
								0.645784983915,
								0.674509983437,
								0.640123015759,
								1
							],
							ix: 3
						},
						o: {
							a: 0,
							k: 100,
							ix: 4
						},
						w: {
							a: 0,
							k: 16,
							ix: 5
						},
						lc: 1,
						lj: 1,
						ml: 4,
						bm: 0,
						nm: "Stroke 1",
						mn: "ADBE Vector Graphic - Stroke",
						hd: false
					},
					{
						ty: "tr",
						p: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 2
						},
						a: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 1
						},
						s: {
							a: 0,
							k: [
								100,
								100
							],
							ix: 3
						},
						r: {
							a: 0,
							k: 0,
							ix: 6
						},
						o: {
							a: 0,
							k: 100,
							ix: 7
						},
						sk: {
							a: 0,
							k: 0,
							ix: 4
						},
						sa: {
							a: 0,
							k: 0,
							ix: 5
						},
						nm: "Transform"
					}
				],
				nm: "Shape 1",
				np: 3,
				cix: 2,
				bm: 0,
				ix: 1,
				mn: "ADBE Vector Group",
				hd: false
			},
			{
				ty: "tm",
				s: {
					a: 1,
					k: [
						{
							i: {
								x: [
									0.667
								],
								y: [
									1
								]
							},
							o: {
								x: [
									0.333
								],
								y: [
									0
								]
							},
							t: 0,
							s: [
								0
							]
						},
						{
							t: 15,
							s: [
								100
							]
						}
					],
					ix: 1
				},
				e: {
					a: 1,
					k: [
						{
							i: {
								x: [
									0.667
								],
								y: [
									1
								]
							},
							o: {
								x: [
									0.333
								],
								y: [
									0
								]
							},
							t: 20,
							s: [
								0
							]
						},
						{
							t: 35,
							s: [
								100
							]
						}
					],
					ix: 2
				},
				o: {
					a: 0,
					k: 0,
					ix: 3
				},
				m: 1,
				ix: 2,
				nm: "Trim Paths 1",
				mn: "ADBE Vector Filter - Trim",
				hd: false
			}
		],
		ip: 0,
		op: 35,
		st: 0,
		bm: 0
	},
	{
		ddd: 0,
		ind: 21,
		ty: 4,
		nm: "Layer 11",
		parent: 1,
		tt: 1,
		sr: 1,
		ks: {
			o: {
				a: 0,
				k: 100,
				ix: 11
			},
			r: {
				a: 0,
				k: 0,
				ix: 10
			},
			p: {
				a: 0,
				k: [
					451.733,
					194.849,
					0
				],
				ix: 2
			},
			a: {
				a: 0,
				k: [
					394.467,
					97.524,
					0
				],
				ix: 1
			},
			s: {
				a: 0,
				k: [
					100,
					100,
					100
				],
				ix: 6
			}
		},
		ao: 0,
		shapes: [
			{
				ty: "gr",
				it: [
					{
						ind: 0,
						ty: "sh",
						ix: 1,
						ks: {
							a: 0,
							k: {
								i: [
									[
										2.695,
										0
									],
									[
										0,
										0
									],
									[
										0,
										2.695
									],
									[
										0,
										0
									],
									[
										-2.695,
										0
									],
									[
										0,
										0
									],
									[
										0,
										-2.695
									],
									[
										0,
										0
									]
								],
								o: [
									[
										0,
										0
									],
									[
										-2.695,
										0
									],
									[
										0,
										0
									],
									[
										0,
										-2.695
									],
									[
										0,
										0
									],
									[
										2.695,
										0
									],
									[
										0,
										0
									],
									[
										0,
										2.695
									]
								],
								v: [
									[
										426.121,
										102.403
									],
									[
										362.812,
										102.403
									],
									[
										357.933,
										97.524
									],
									[
										357.933,
										97.524
									],
									[
										362.812,
										92.644
									],
									[
										426.121,
										92.644
									],
									[
										431,
										97.524
									],
									[
										431,
										97.524
									]
								],
								c: true
							},
							ix: 2
						},
						nm: "Path 1",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ty: "fl",
						c: {
							a: 0,
							k: [
								0.2196078431372549,
								0.1450980392156863,
								0.3764705882352941,
								1
							],
							ix: 4
						},
						o: {
							a: 0,
							k: 100,
							ix: 5
						},
						r: 1,
						bm: 0,
						nm: "Fill 1",
						mn: "ADBE Vector Graphic - Fill",
						hd: false
					},
					{
						ty: "tr",
						p: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 2
						},
						a: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 1
						},
						s: {
							a: 0,
							k: [
								100,
								100
							],
							ix: 3
						},
						r: {
							a: 0,
							k: 0,
							ix: 6
						},
						o: {
							a: 0,
							k: 100,
							ix: 7
						},
						sk: {
							a: 0,
							k: 0,
							ix: 4
						},
						sa: {
							a: 0,
							k: 0,
							ix: 5
						},
						nm: "Transform"
					}
				],
				nm: "Group 1",
				np: 2,
				cix: 2,
				bm: 0,
				ix: 1,
				mn: "ADBE Vector Group",
				hd: false
			}
		],
		ip: 0,
		op: 35,
		st: 0,
		bm: 0
	},
	{
		ddd: 0,
		ind: 22,
		ty: 4,
		nm: "Layer 10",
		parent: 1,
		sr: 1,
		ks: {
			o: {
				a: 0,
				k: 100,
				ix: 11
			},
			r: {
				a: 0,
				k: 0,
				ix: 10
			},
			p: {
				a: 0,
				k: [
					202.46,
					-139.748,
					0
				],
				ix: 2
			},
			a: {
				a: 0,
				k: [
					145.194,
					-237.073,
					0
				],
				ix: 1
			},
			s: {
				a: 0,
				k: [
					100,
					100,
					100
				],
				ix: 6
			}
		},
		ao: 0,
		shapes: [
			{
				ty: "gr",
				it: [
					{
						ind: 0,
						ty: "sh",
						ix: 1,
						ks: {
							a: 1,
							k: [
								{
									i: {
										x: 0.667,
										y: 1
									},
									o: {
										x: 0.333,
										y: 0
									},
									t: 9.421,
									s: [
										{
											i: [
												[
													0,
													0
												],
												[
													0,
													0
												]
											],
											o: [
												[
													0,
													0
												],
												[
													0,
													0
												]
											],
											v: [
												[
													126.546,
													-237.073
												],
												[
													125.841,
													-237.147
												]
											],
											c: false
										}
									]
								},
								{
									i: {
										x: 0.667,
										y: 1
									},
									o: {
										x: 0.333,
										y: 0
									},
									t: 37.685,
									s: [
										{
											i: [
												[
													0,
													0
												],
												[
													0,
													0
												]
											],
											o: [
												[
													0,
													0
												],
												[
													0,
													0
												]
											],
											v: [
												[
													126.546,
													-237.073
												],
												[
													163.841,
													-237.073
												]
											],
											c: false
										}
									]
								},
								{
									i: {
										x: 0.667,
										y: 1
									},
									o: {
										x: 0.333,
										y: 0
									},
									t: 65.947,
									s: [
										{
											i: [
												[
													0,
													0
												],
												[
													0,
													0
												]
											],
											o: [
												[
													0,
													0
												],
												[
													0,
													0
												]
											],
											v: [
												[
													126.546,
													-237.073
												],
												[
													125.841,
													-237.147
												]
											],
											c: false
										}
									]
								},
								{
									i: {
										x: 0.667,
										y: 1
									},
									o: {
										x: 0.333,
										y: 0
									},
									t: 94.211,
									s: [
										{
											i: [
												[
													0,
													0
												],
												[
													0,
													0
												]
											],
											o: [
												[
													0,
													0
												],
												[
													0,
													0
												]
											],
											v: [
												[
													126.546,
													-237.073
												],
												[
													163.841,
													-237.073
												]
											],
											c: false
										}
									]
								},
								{
									i: {
										x: 0.667,
										y: 1
									},
									o: {
										x: 0.333,
										y: 0
									},
									t: 122.474,
									s: [
										{
											i: [
												[
													0,
													0
												],
												[
													0,
													0
												]
											],
											o: [
												[
													0,
													0
												],
												[
													0,
													0
												]
											],
											v: [
												[
													126.546,
													-237.073
												],
												[
													125.841,
													-237.147
												]
											],
											c: false
										}
									]
								},
								{
									i: {
										x: 0.667,
										y: 1
									},
									o: {
										x: 0.333,
										y: 0
									},
									t: 150.737,
									s: [
										{
											i: [
												[
													0,
													0
												],
												[
													0,
													0
												]
											],
											o: [
												[
													0,
													0
												],
												[
													0,
													0
												]
											],
											v: [
												[
													126.546,
													-237.073
												],
												[
													163.841,
													-237.073
												]
											],
											c: false
										}
									]
								},
								{
									t: 179,
									s: [
										{
											i: [
												[
													0,
													0
												],
												[
													0,
													0
												]
											],
											o: [
												[
													0,
													0
												],
												[
													0,
													0
												]
											],
											v: [
												[
													126.546,
													-237.073
												],
												[
													125.841,
													-237.147
												]
											],
											c: false
										}
									]
								}
							],
							ix: 2
						},
						nm: "Path 1",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ty: "st",
						c: {
							a: 0,
							k: [
								1,
								1,
								1,
								1
							],
							ix: 3
						},
						o: {
							a: 0,
							k: 100,
							ix: 4
						},
						w: {
							a: 0,
							k: 1.18,
							ix: 5
						},
						lc: 1,
						lj: 1,
						ml: 10,
						bm: 0,
						nm: "Stroke 1",
						mn: "ADBE Vector Graphic - Stroke",
						hd: false
					},
					{
						ty: "tr",
						p: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 2
						},
						a: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 1
						},
						s: {
							a: 0,
							k: [
								100,
								100
							],
							ix: 3
						},
						r: {
							a: 0,
							k: 0,
							ix: 6
						},
						o: {
							a: 0,
							k: 100,
							ix: 7
						},
						sk: {
							a: 0,
							k: 0,
							ix: 4
						},
						sa: {
							a: 0,
							k: 0,
							ix: 5
						},
						nm: "Transform"
					}
				],
				nm: "Group 1",
				np: 2,
				cix: 2,
				bm: 0,
				ix: 1,
				mn: "ADBE Vector Group",
				hd: false
			}
		],
		ip: 5,
		op: 185,
		st: 5,
		bm: 0
	},
	{
		ddd: 0,
		ind: 23,
		ty: 4,
		nm: "Layer 9",
		parent: 1,
		sr: 1,
		ks: {
			o: {
				a: 0,
				k: 100,
				ix: 11
			},
			r: {
				a: 0,
				k: 0,
				ix: 10
			},
			p: {
				a: 0,
				k: [
					229.594,
					-149.146,
					0
				],
				ix: 2
			},
			a: {
				a: 0,
				k: [
					172.327,
					-246.471,
					0
				],
				ix: 1
			},
			s: {
				a: 0,
				k: [
					100,
					100,
					100
				],
				ix: 6
			}
		},
		ao: 0,
		shapes: [
			{
				ty: "gr",
				it: [
					{
						ind: 0,
						ty: "sh",
						ix: 1,
						ks: {
							a: 1,
							k: [
								{
									i: {
										x: 0.667,
										y: 1
									},
									o: {
										x: 0.333,
										y: 0
									},
									t: 0,
									s: [
										{
											i: [
												[
													0,
													0
												],
												[
													0,
													0
												]
											],
											o: [
												[
													0,
													0
												],
												[
													0,
													0
												]
											],
											v: [
												[
													126.546,
													-246.471
												],
												[
													126.357,
													-246.442
												]
											],
											c: false
										}
									]
								},
								{
									i: {
										x: 0.667,
										y: 1
									},
									o: {
										x: 0.333,
										y: 0
									},
									t: 28.263,
									s: [
										{
											i: [
												[
													0,
													0
												],
												[
													0,
													0
												]
											],
											o: [
												[
													0,
													0
												],
												[
													0,
													0
												]
											],
											v: [
												[
													126.546,
													-246.471
												],
												[
													218.107,
													-246.471
												]
											],
											c: false
										}
									]
								},
								{
									i: {
										x: 0.667,
										y: 1
									},
									o: {
										x: 0.333,
										y: 0
									},
									t: 56.526,
									s: [
										{
											i: [
												[
													0,
													0
												],
												[
													0,
													0
												]
											],
											o: [
												[
													0,
													0
												],
												[
													0,
													0
												]
											],
											v: [
												[
													126.546,
													-246.471
												],
												[
													126.357,
													-246.442
												]
											],
											c: false
										}
									]
								},
								{
									i: {
										x: 0.667,
										y: 1
									},
									o: {
										x: 0.333,
										y: 0
									},
									t: 84.789,
									s: [
										{
											i: [
												[
													0,
													0
												],
												[
													0,
													0
												]
											],
											o: [
												[
													0,
													0
												],
												[
													0,
													0
												]
											],
											v: [
												[
													126.546,
													-246.471
												],
												[
													218.107,
													-246.471
												]
											],
											c: false
										}
									]
								},
								{
									i: {
										x: 0.667,
										y: 1
									},
									o: {
										x: 0.333,
										y: 0
									},
									t: 113.053,
									s: [
										{
											i: [
												[
													0,
													0
												],
												[
													0,
													0
												]
											],
											o: [
												[
													0,
													0
												],
												[
													0,
													0
												]
											],
											v: [
												[
													126.546,
													-246.471
												],
												[
													126.357,
													-246.442
												]
											],
											c: false
										}
									]
								},
								{
									i: {
										x: 0.667,
										y: 1
									},
									o: {
										x: 0.333,
										y: 0
									},
									t: 141.315,
									s: [
										{
											i: [
												[
													0,
													0
												],
												[
													0,
													0
												]
											],
											o: [
												[
													0,
													0
												],
												[
													0,
													0
												]
											],
											v: [
												[
													126.546,
													-246.471
												],
												[
													218.107,
													-246.471
												]
											],
											c: false
										}
									]
								},
								{
									t: 169.5791015625,
									s: [
										{
											i: [
												[
													0,
													0
												],
												[
													0,
													0
												]
											],
											o: [
												[
													0,
													0
												],
												[
													0,
													0
												]
											],
											v: [
												[
													126.546,
													-246.471
												],
												[
													126.357,
													-246.442
												]
											],
											c: false
										}
									]
								}
							],
							ix: 2
						},
						nm: "Path 1",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ty: "st",
						c: {
							a: 0,
							k: [
								1,
								1,
								1,
								1
							],
							ix: 3
						},
						o: {
							a: 0,
							k: 100,
							ix: 4
						},
						w: {
							a: 0,
							k: 1.18,
							ix: 5
						},
						lc: 1,
						lj: 1,
						ml: 10,
						bm: 0,
						nm: "Stroke 1",
						mn: "ADBE Vector Graphic - Stroke",
						hd: false
					},
					{
						ty: "tr",
						p: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 2
						},
						a: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 1
						},
						s: {
							a: 0,
							k: [
								100,
								100
							],
							ix: 3
						},
						r: {
							a: 0,
							k: 0,
							ix: 6
						},
						o: {
							a: 0,
							k: 100,
							ix: 7
						},
						sk: {
							a: 0,
							k: 0,
							ix: 4
						},
						sa: {
							a: 0,
							k: 0,
							ix: 5
						},
						nm: "Transform"
					}
				],
				nm: "Group 1",
				np: 2,
				cix: 2,
				bm: 0,
				ix: 1,
				mn: "ADBE Vector Group",
				hd: false
			}
		],
		ip: 0,
		op: 180,
		st: 0,
		bm: 0
	},
	{
		ddd: 0,
		ind: 24,
		ty: 4,
		nm: "Layer 8",
		parent: 1,
		sr: 1,
		ks: {
			o: {
				a: 0,
				k: 100,
				ix: 11
			},
			r: {
				a: 0,
				k: 0,
				ix: 10
			},
			p: {
				a: 0,
				k: [
					233.468,
					-138.097,
					0
				],
				ix: 2
			},
			a: {
				a: 0,
				k: [
					176.202,
					-235.423,
					0
				],
				ix: 1
			},
			s: {
				a: 0,
				k: [
					100,
					100,
					100
				],
				ix: 6
			}
		},
		ao: 0,
		shapes: [
			{
				ty: "gr",
				it: [
					{
						ind: 0,
						ty: "sh",
						ix: 1,
						ks: {
							a: 0,
							k: {
								i: [
									[
										0,
										0
									],
									[
										0,
										0
									],
									[
										0,
										0
									]
								],
								o: [
									[
										0,
										0
									],
									[
										0,
										0
									],
									[
										0,
										0
									]
								],
								v: [
									[
										122.823,
										-225.683
									],
									[
										122.823,
										-210.413
									],
									[
										142.027,
										-225.683
									]
								],
								c: true
							},
							ix: 2
						},
						nm: "Path 1",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ty: "fl",
						c: {
							a: 0,
							k: [
								0.9725490196078431,
								0.9058823529411765,
								0.10980392156862745,
								1
							],
							ix: 4
						},
						o: {
							a: 0,
							k: 100,
							ix: 5
						},
						r: 1,
						bm: 0,
						nm: "Fill 1",
						mn: "ADBE Vector Graphic - Fill",
						hd: false
					},
					{
						ty: "tr",
						p: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 2
						},
						a: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 1
						},
						s: {
							a: 0,
							k: [
								100,
								100
							],
							ix: 3
						},
						r: {
							a: 0,
							k: 0,
							ix: 6
						},
						o: {
							a: 0,
							k: 100,
							ix: 7
						},
						sk: {
							a: 0,
							k: 0,
							ix: 4
						},
						sa: {
							a: 0,
							k: 0,
							ix: 5
						},
						nm: "Transform"
					}
				],
				nm: "Group 1",
				np: 2,
				cix: 2,
				bm: 0,
				ix: 1,
				mn: "ADBE Vector Group",
				hd: false
			},
			{
				ty: "gr",
				it: [
					{
						ind: 0,
						ty: "sh",
						ix: 1,
						ks: {
							a: 0,
							k: {
								i: [
									[
										1.663,
										0
									],
									[
										0,
										0
									],
									[
										0,
										1.663
									],
									[
										0,
										0
									],
									[
										-1.663,
										0
									],
									[
										0,
										0
									],
									[
										0,
										-1.663
									],
									[
										0,
										0
									]
								],
								o: [
									[
										0,
										0
									],
									[
										-1.663,
										0
									],
									[
										0,
										0
									],
									[
										0,
										-1.663
									],
									[
										0,
										0
									],
									[
										1.663,
										0
									],
									[
										0,
										0
									],
									[
										0,
										1.663
									]
								],
								v: [
									[
										241.436,
										-221.25
									],
									[
										110.967,
										-221.25
									],
									[
										107.955,
										-224.262
									],
									[
										107.955,
										-257.42
									],
									[
										110.967,
										-260.432
									],
									[
										241.436,
										-260.432
									],
									[
										244.448,
										-257.421
									],
									[
										244.448,
										-224.262
									]
								],
								c: true
							},
							ix: 2
						},
						nm: "Path 1",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ty: "fl",
						c: {
							a: 0,
							k: [
								0.9725490196078431,
								0.9058823529411765,
								0.10980392156862745,
								1
							],
							ix: 4
						},
						o: {
							a: 0,
							k: 100,
							ix: 5
						},
						r: 1,
						bm: 0,
						nm: "Fill 1",
						mn: "ADBE Vector Graphic - Fill",
						hd: false
					},
					{
						ty: "tr",
						p: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 2
						},
						a: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 1
						},
						s: {
							a: 0,
							k: [
								100,
								100
							],
							ix: 3
						},
						r: {
							a: 0,
							k: 0,
							ix: 6
						},
						o: {
							a: 0,
							k: 100,
							ix: 7
						},
						sk: {
							a: 0,
							k: 0,
							ix: 4
						},
						sa: {
							a: 0,
							k: 0,
							ix: 5
						},
						nm: "Transform"
					}
				],
				nm: "Group 2",
				np: 2,
				cix: 2,
				bm: 0,
				ix: 2,
				mn: "ADBE Vector Group",
				hd: false
			}
		],
		ip: 0,
		op: 180,
		st: 0,
		bm: 0
	},
	{
		ddd: 0,
		ind: 25,
		ty: 4,
		nm: "Shape Layer 5",
		parent: 1,
		td: 1,
		sr: 1,
		ks: {
			o: {
				a: 0,
				k: 100,
				ix: 11
			},
			r: {
				a: 0,
				k: 0,
				ix: 10
			},
			p: {
				a: 0,
				k: [
					-331.733,
					-123.175,
					0
				],
				ix: 2
			},
			a: {
				a: 0,
				k: [
					-389,
					-220.5,
					0
				],
				ix: 1
			},
			s: {
				a: 0,
				k: [
					100,
					100,
					100
				],
				ix: 6
			}
		},
		ao: 0,
		shapes: [
			{
				ty: "gr",
				it: [
					{
						ind: 0,
						ty: "sh",
						ix: 1,
						ks: {
							a: 0,
							k: {
								i: [
									[
										0,
										0
									],
									[
										0,
										0
									]
								],
								o: [
									[
										0,
										0
									],
									[
										0,
										0
									]
								],
								v: [
									[
										-389,
										-220.5
									],
									[
										-246.5,
										-222
									]
								],
								c: false
							},
							ix: 2
						},
						nm: "Path 1",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ty: "tm",
						s: {
							a: 1,
							k: [
								{
									i: {
										x: [
											0.667
										],
										y: [
											1
										]
									},
									o: {
										x: [
											0.333
										],
										y: [
											0
										]
									},
									t: 145,
									s: [
										0
									]
								},
								{
									t: 160,
									s: [
										100
									]
								}
							],
							ix: 1
						},
						e: {
							a: 1,
							k: [
								{
									i: {
										x: [
											0.667
										],
										y: [
											1
										]
									},
									o: {
										x: [
											0.333
										],
										y: [
											0
										]
									},
									t: 165,
									s: [
										0
									]
								},
								{
									t: 180,
									s: [
										100
									]
								}
							],
							ix: 2
						},
						o: {
							a: 0,
							k: 0,
							ix: 3
						},
						m: 1,
						ix: 2,
						nm: "Trim Paths 1",
						mn: "ADBE Vector Filter - Trim",
						hd: false
					},
					{
						ty: "st",
						c: {
							a: 0,
							k: [
								0.645784983915,
								0.674509983437,
								0.640123015759,
								1
							],
							ix: 3
						},
						o: {
							a: 0,
							k: 100,
							ix: 4
						},
						w: {
							a: 0,
							k: 16,
							ix: 5
						},
						lc: 1,
						lj: 1,
						ml: 4,
						bm: 0,
						nm: "Stroke 1",
						mn: "ADBE Vector Graphic - Stroke",
						hd: false
					},
					{
						ty: "tr",
						p: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 2
						},
						a: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 1
						},
						s: {
							a: 0,
							k: [
								100,
								100
							],
							ix: 3
						},
						r: {
							a: 0,
							k: 0,
							ix: 6
						},
						o: {
							a: 0,
							k: 100,
							ix: 7
						},
						sk: {
							a: 0,
							k: 0,
							ix: 4
						},
						sa: {
							a: 0,
							k: 0,
							ix: 5
						},
						nm: "Transform"
					}
				],
				nm: "Shape 1",
				np: 4,
				cix: 2,
				bm: 0,
				ix: 1,
				mn: "ADBE Vector Group",
				hd: false
			}
		],
		ip: 145,
		op: 180,
		st: 145,
		bm: 0
	},
	{
		ddd: 0,
		ind: 26,
		ty: 4,
		nm: "Layer 7",
		parent: 1,
		tt: 1,
		sr: 1,
		ks: {
			o: {
				a: 0,
				k: 100,
				ix: 11
			},
			r: {
				a: 0,
				k: 0,
				ix: 10
			},
			p: {
				a: 0,
				k: [
					-260.095,
					-123.764,
					0
				],
				ix: 2
			},
			a: {
				a: 0,
				k: [
					-317.361,
					-221.089,
					0
				],
				ix: 1
			},
			s: {
				a: 0,
				k: [
					100,
					100,
					100
				],
				ix: 6
			}
		},
		ao: 0,
		shapes: [
			{
				ty: "gr",
				it: [
					{
						ind: 0,
						ty: "sh",
						ix: 1,
						ks: {
							a: 0,
							k: {
								i: [
									[
										2.695,
										0
									],
									[
										0,
										0
									],
									[
										0,
										2.695
									],
									[
										0,
										0
									],
									[
										-2.695,
										0
									],
									[
										0,
										0
									],
									[
										0,
										-2.695
									],
									[
										0,
										0
									]
								],
								o: [
									[
										0,
										0
									],
									[
										-2.695,
										0
									],
									[
										0,
										0
									],
									[
										0,
										-2.695
									],
									[
										0,
										0
									],
									[
										2.695,
										0
									],
									[
										0,
										0
									],
									[
										0,
										2.695
									]
								],
								v: [
									[
										-252.143,
										-216.21
									],
									[
										-382.579,
										-216.21
									],
									[
										-387.458,
										-221.089
									],
									[
										-387.458,
										-221.089
									],
									[
										-382.579,
										-225.968
									],
									[
										-252.143,
										-225.968
									],
									[
										-247.264,
										-221.089
									],
									[
										-247.264,
										-221.089
									]
								],
								c: true
							},
							ix: 2
						},
						nm: "Path 1",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ty: "fl",
						c: {
							a: 0,
							k: [
								0.9725490196078431,
								0.9058823529411765,
								0.10980392156862745,
								1
							],
							ix: 4
						},
						o: {
							a: 0,
							k: 100,
							ix: 5
						},
						r: 1,
						bm: 0,
						nm: "Fill 1",
						mn: "ADBE Vector Graphic - Fill",
						hd: false
					},
					{
						ty: "tr",
						p: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 2
						},
						a: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 1
						},
						s: {
							a: 0,
							k: [
								100,
								100
							],
							ix: 3
						},
						r: {
							a: 0,
							k: 0,
							ix: 6
						},
						o: {
							a: 0,
							k: 100,
							ix: 7
						},
						sk: {
							a: 0,
							k: 0,
							ix: 4
						},
						sa: {
							a: 0,
							k: 0,
							ix: 5
						},
						nm: "Transform"
					}
				],
				nm: "Group 1",
				np: 2,
				cix: 2,
				bm: 0,
				ix: 1,
				mn: "ADBE Vector Group",
				hd: false
			}
		],
		ip: 145,
		op: 180,
		st: 145,
		bm: 0
	},
	{
		ddd: 0,
		ind: 27,
		ty: 4,
		nm: "Shape Layer 4",
		parent: 1,
		td: 1,
		sr: 1,
		ks: {
			o: {
				a: 0,
				k: 100,
				ix: 11
			},
			r: {
				a: 0,
				k: 0,
				ix: 10
			},
			p: {
				a: 0,
				k: [
					-331.733,
					-123.175,
					0
				],
				ix: 2
			},
			a: {
				a: 0,
				k: [
					-389,
					-220.5,
					0
				],
				ix: 1
			},
			s: {
				a: 0,
				k: [
					100,
					100,
					100
				],
				ix: 6
			}
		},
		ao: 0,
		shapes: [
			{
				ty: "gr",
				it: [
					{
						ind: 0,
						ty: "sh",
						ix: 1,
						ks: {
							a: 0,
							k: {
								i: [
									[
										0,
										0
									],
									[
										0,
										0
									]
								],
								o: [
									[
										0,
										0
									],
									[
										0,
										0
									]
								],
								v: [
									[
										-389,
										-220.5
									],
									[
										-246.5,
										-222
									]
								],
								c: false
							},
							ix: 2
						},
						nm: "Path 1",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ty: "tm",
						s: {
							a: 1,
							k: [
								{
									i: {
										x: [
											0.667
										],
										y: [
											1
										]
									},
									o: {
										x: [
											0.333
										],
										y: [
											0
										]
									},
									t: 108,
									s: [
										0
									]
								},
								{
									t: 123,
									s: [
										100
									]
								}
							],
							ix: 1
						},
						e: {
							a: 1,
							k: [
								{
									i: {
										x: [
											0.667
										],
										y: [
											1
										]
									},
									o: {
										x: [
											0.333
										],
										y: [
											0
										]
									},
									t: 128,
									s: [
										0
									]
								},
								{
									t: 143,
									s: [
										100
									]
								}
							],
							ix: 2
						},
						o: {
							a: 0,
							k: 0,
							ix: 3
						},
						m: 1,
						ix: 2,
						nm: "Trim Paths 1",
						mn: "ADBE Vector Filter - Trim",
						hd: false
					},
					{
						ty: "st",
						c: {
							a: 0,
							k: [
								0.645784983915,
								0.674509983437,
								0.640123015759,
								1
							],
							ix: 3
						},
						o: {
							a: 0,
							k: 100,
							ix: 4
						},
						w: {
							a: 0,
							k: 16,
							ix: 5
						},
						lc: 1,
						lj: 1,
						ml: 4,
						bm: 0,
						nm: "Stroke 1",
						mn: "ADBE Vector Graphic - Stroke",
						hd: false
					},
					{
						ty: "tr",
						p: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 2
						},
						a: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 1
						},
						s: {
							a: 0,
							k: [
								100,
								100
							],
							ix: 3
						},
						r: {
							a: 0,
							k: 0,
							ix: 6
						},
						o: {
							a: 0,
							k: 100,
							ix: 7
						},
						sk: {
							a: 0,
							k: 0,
							ix: 4
						},
						sa: {
							a: 0,
							k: 0,
							ix: 5
						},
						nm: "Transform"
					}
				],
				nm: "Shape 1",
				np: 4,
				cix: 2,
				bm: 0,
				ix: 1,
				mn: "ADBE Vector Group",
				hd: false
			}
		],
		ip: 108,
		op: 143,
		st: 108,
		bm: 0
	},
	{
		ddd: 0,
		ind: 28,
		ty: 4,
		nm: "Layer 6",
		parent: 1,
		tt: 1,
		sr: 1,
		ks: {
			o: {
				a: 0,
				k: 100,
				ix: 11
			},
			r: {
				a: 0,
				k: 0,
				ix: 10
			},
			p: {
				a: 0,
				k: [
					-260.095,
					-123.764,
					0
				],
				ix: 2
			},
			a: {
				a: 0,
				k: [
					-317.361,
					-221.089,
					0
				],
				ix: 1
			},
			s: {
				a: 0,
				k: [
					100,
					100,
					100
				],
				ix: 6
			}
		},
		ao: 0,
		shapes: [
			{
				ty: "gr",
				it: [
					{
						ind: 0,
						ty: "sh",
						ix: 1,
						ks: {
							a: 0,
							k: {
								i: [
									[
										2.695,
										0
									],
									[
										0,
										0
									],
									[
										0,
										2.695
									],
									[
										0,
										0
									],
									[
										-2.695,
										0
									],
									[
										0,
										0
									],
									[
										0,
										-2.695
									],
									[
										0,
										0
									]
								],
								o: [
									[
										0,
										0
									],
									[
										-2.695,
										0
									],
									[
										0,
										0
									],
									[
										0,
										-2.695
									],
									[
										0,
										0
									],
									[
										2.695,
										0
									],
									[
										0,
										0
									],
									[
										0,
										2.695
									]
								],
								v: [
									[
										-252.143,
										-216.21
									],
									[
										-382.579,
										-216.21
									],
									[
										-387.458,
										-221.089
									],
									[
										-387.458,
										-221.089
									],
									[
										-382.579,
										-225.968
									],
									[
										-252.143,
										-225.968
									],
									[
										-247.264,
										-221.089
									],
									[
										-247.264,
										-221.089
									]
								],
								c: true
							},
							ix: 2
						},
						nm: "Path 1",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ty: "fl",
						c: {
							a: 0,
							k: [
								0.8156862745098039,
								0.00784313725490196,
								0.10588235294117647,
								1
							],
							ix: 4
						},
						o: {
							a: 0,
							k: 100,
							ix: 5
						},
						r: 1,
						bm: 0,
						nm: "Fill 1",
						mn: "ADBE Vector Graphic - Fill",
						hd: false
					},
					{
						ty: "tr",
						p: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 2
						},
						a: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 1
						},
						s: {
							a: 0,
							k: [
								100,
								100
							],
							ix: 3
						},
						r: {
							a: 0,
							k: 0,
							ix: 6
						},
						o: {
							a: 0,
							k: 100,
							ix: 7
						},
						sk: {
							a: 0,
							k: 0,
							ix: 4
						},
						sa: {
							a: 0,
							k: 0,
							ix: 5
						},
						nm: "Transform"
					}
				],
				nm: "Group 1",
				np: 2,
				cix: 2,
				bm: 0,
				ix: 1,
				mn: "ADBE Vector Group",
				hd: false
			}
		],
		ip: 108,
		op: 143,
		st: 108,
		bm: 0
	},
	{
		ddd: 0,
		ind: 29,
		ty: 4,
		nm: "Shape Layer 3",
		parent: 1,
		td: 1,
		sr: 1,
		ks: {
			o: {
				a: 0,
				k: 100,
				ix: 11
			},
			r: {
				a: 0,
				k: 0,
				ix: 10
			},
			p: {
				a: 0,
				k: [
					-331.733,
					-123.175,
					0
				],
				ix: 2
			},
			a: {
				a: 0,
				k: [
					-389,
					-220.5,
					0
				],
				ix: 1
			},
			s: {
				a: 0,
				k: [
					100,
					100,
					100
				],
				ix: 6
			}
		},
		ao: 0,
		shapes: [
			{
				ty: "gr",
				it: [
					{
						ind: 0,
						ty: "sh",
						ix: 1,
						ks: {
							a: 0,
							k: {
								i: [
									[
										0,
										0
									],
									[
										0,
										0
									]
								],
								o: [
									[
										0,
										0
									],
									[
										0,
										0
									]
								],
								v: [
									[
										-389,
										-220.5
									],
									[
										-246.5,
										-222
									]
								],
								c: false
							},
							ix: 2
						},
						nm: "Path 1",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ty: "tm",
						s: {
							a: 1,
							k: [
								{
									i: {
										x: [
											0.667
										],
										y: [
											1
										]
									},
									o: {
										x: [
											0.333
										],
										y: [
											0
										]
									},
									t: 72,
									s: [
										0
									]
								},
								{
									t: 87,
									s: [
										100
									]
								}
							],
							ix: 1
						},
						e: {
							a: 1,
							k: [
								{
									i: {
										x: [
											0.667
										],
										y: [
											1
										]
									},
									o: {
										x: [
											0.333
										],
										y: [
											0
										]
									},
									t: 92,
									s: [
										0
									]
								},
								{
									t: 107,
									s: [
										100
									]
								}
							],
							ix: 2
						},
						o: {
							a: 0,
							k: 0,
							ix: 3
						},
						m: 1,
						ix: 2,
						nm: "Trim Paths 1",
						mn: "ADBE Vector Filter - Trim",
						hd: false
					},
					{
						ty: "st",
						c: {
							a: 0,
							k: [
								0.645784983915,
								0.674509983437,
								0.640123015759,
								1
							],
							ix: 3
						},
						o: {
							a: 0,
							k: 100,
							ix: 4
						},
						w: {
							a: 0,
							k: 16,
							ix: 5
						},
						lc: 1,
						lj: 1,
						ml: 4,
						bm: 0,
						nm: "Stroke 1",
						mn: "ADBE Vector Graphic - Stroke",
						hd: false
					},
					{
						ty: "tr",
						p: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 2
						},
						a: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 1
						},
						s: {
							a: 0,
							k: [
								100,
								100
							],
							ix: 3
						},
						r: {
							a: 0,
							k: 0,
							ix: 6
						},
						o: {
							a: 0,
							k: 100,
							ix: 7
						},
						sk: {
							a: 0,
							k: 0,
							ix: 4
						},
						sa: {
							a: 0,
							k: 0,
							ix: 5
						},
						nm: "Transform"
					}
				],
				nm: "Shape 1",
				np: 4,
				cix: 2,
				bm: 0,
				ix: 1,
				mn: "ADBE Vector Group",
				hd: false
			}
		],
		ip: 72,
		op: 107,
		st: 72,
		bm: 0
	},
	{
		ddd: 0,
		ind: 30,
		ty: 4,
		nm: "Layer 5",
		parent: 1,
		tt: 1,
		sr: 1,
		ks: {
			o: {
				a: 0,
				k: 100,
				ix: 11
			},
			r: {
				a: 0,
				k: 0,
				ix: 10
			},
			p: {
				a: 0,
				k: [
					-260.095,
					-123.764,
					0
				],
				ix: 2
			},
			a: {
				a: 0,
				k: [
					-317.361,
					-221.089,
					0
				],
				ix: 1
			},
			s: {
				a: 0,
				k: [
					100,
					100,
					100
				],
				ix: 6
			}
		},
		ao: 0,
		shapes: [
			{
				ty: "gr",
				it: [
					{
						ind: 0,
						ty: "sh",
						ix: 1,
						ks: {
							a: 0,
							k: {
								i: [
									[
										2.695,
										0
									],
									[
										0,
										0
									],
									[
										0,
										2.695
									],
									[
										0,
										0
									],
									[
										-2.695,
										0
									],
									[
										0,
										0
									],
									[
										0,
										-2.695
									],
									[
										0,
										0
									]
								],
								o: [
									[
										0,
										0
									],
									[
										-2.695,
										0
									],
									[
										0,
										0
									],
									[
										0,
										-2.695
									],
									[
										0,
										0
									],
									[
										2.695,
										0
									],
									[
										0,
										0
									],
									[
										0,
										2.695
									]
								],
								v: [
									[
										-252.143,
										-216.21
									],
									[
										-382.579,
										-216.21
									],
									[
										-387.458,
										-221.089
									],
									[
										-387.458,
										-221.089
									],
									[
										-382.579,
										-225.968
									],
									[
										-252.143,
										-225.968
									],
									[
										-247.264,
										-221.089
									],
									[
										-247.264,
										-221.089
									]
								],
								c: true
							},
							ix: 2
						},
						nm: "Path 1",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ty: "fl",
						c: {
							a: 0,
							k: [
								0.8941176470588236,
								0.4666666666666667,
								0.3764705882352941,
								1
							],
							ix: 4
						},
						o: {
							a: 0,
							k: 100,
							ix: 5
						},
						r: 1,
						bm: 0,
						nm: "Fill 1",
						mn: "ADBE Vector Graphic - Fill",
						hd: false
					},
					{
						ty: "tr",
						p: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 2
						},
						a: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 1
						},
						s: {
							a: 0,
							k: [
								100,
								100
							],
							ix: 3
						},
						r: {
							a: 0,
							k: 0,
							ix: 6
						},
						o: {
							a: 0,
							k: 100,
							ix: 7
						},
						sk: {
							a: 0,
							k: 0,
							ix: 4
						},
						sa: {
							a: 0,
							k: 0,
							ix: 5
						},
						nm: "Transform"
					}
				],
				nm: "Group 1",
				np: 2,
				cix: 2,
				bm: 0,
				ix: 1,
				mn: "ADBE Vector Group",
				hd: false
			}
		],
		ip: 72,
		op: 107,
		st: 72,
		bm: 0
	},
	{
		ddd: 0,
		ind: 31,
		ty: 4,
		nm: "Shape Layer 2",
		parent: 1,
		td: 1,
		sr: 1,
		ks: {
			o: {
				a: 0,
				k: 100,
				ix: 11
			},
			r: {
				a: 0,
				k: 0,
				ix: 10
			},
			p: {
				a: 0,
				k: [
					-331.733,
					-123.175,
					0
				],
				ix: 2
			},
			a: {
				a: 0,
				k: [
					-389,
					-220.5,
					0
				],
				ix: 1
			},
			s: {
				a: 0,
				k: [
					100,
					100,
					100
				],
				ix: 6
			}
		},
		ao: 0,
		shapes: [
			{
				ty: "gr",
				it: [
					{
						ind: 0,
						ty: "sh",
						ix: 1,
						ks: {
							a: 0,
							k: {
								i: [
									[
										0,
										0
									],
									[
										0,
										0
									]
								],
								o: [
									[
										0,
										0
									],
									[
										0,
										0
									]
								],
								v: [
									[
										-389,
										-220.5
									],
									[
										-246.5,
										-222
									]
								],
								c: false
							},
							ix: 2
						},
						nm: "Path 1",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ty: "tm",
						s: {
							a: 1,
							k: [
								{
									i: {
										x: [
											0.667
										],
										y: [
											1
										]
									},
									o: {
										x: [
											0.333
										],
										y: [
											0
										]
									},
									t: 36,
									s: [
										0
									]
								},
								{
									t: 51,
									s: [
										100
									]
								}
							],
							ix: 1
						},
						e: {
							a: 1,
							k: [
								{
									i: {
										x: [
											0.667
										],
										y: [
											1
										]
									},
									o: {
										x: [
											0.333
										],
										y: [
											0
										]
									},
									t: 56,
									s: [
										0
									]
								},
								{
									t: 71,
									s: [
										100
									]
								}
							],
							ix: 2
						},
						o: {
							a: 0,
							k: 0,
							ix: 3
						},
						m: 1,
						ix: 2,
						nm: "Trim Paths 1",
						mn: "ADBE Vector Filter - Trim",
						hd: false
					},
					{
						ty: "st",
						c: {
							a: 0,
							k: [
								0.645784983915,
								0.674509983437,
								0.640123015759,
								1
							],
							ix: 3
						},
						o: {
							a: 0,
							k: 100,
							ix: 4
						},
						w: {
							a: 0,
							k: 16,
							ix: 5
						},
						lc: 1,
						lj: 1,
						ml: 4,
						bm: 0,
						nm: "Stroke 1",
						mn: "ADBE Vector Graphic - Stroke",
						hd: false
					},
					{
						ty: "tr",
						p: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 2
						},
						a: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 1
						},
						s: {
							a: 0,
							k: [
								100,
								100
							],
							ix: 3
						},
						r: {
							a: 0,
							k: 0,
							ix: 6
						},
						o: {
							a: 0,
							k: 100,
							ix: 7
						},
						sk: {
							a: 0,
							k: 0,
							ix: 4
						},
						sa: {
							a: 0,
							k: 0,
							ix: 5
						},
						nm: "Transform"
					}
				],
				nm: "Shape 1",
				np: 4,
				cix: 2,
				bm: 0,
				ix: 1,
				mn: "ADBE Vector Group",
				hd: false
			}
		],
		ip: 36,
		op: 71,
		st: 36,
		bm: 0
	},
	{
		ddd: 0,
		ind: 32,
		ty: 4,
		nm: "Layer 4",
		parent: 1,
		tt: 1,
		sr: 1,
		ks: {
			o: {
				a: 0,
				k: 100,
				ix: 11
			},
			r: {
				a: 0,
				k: 0,
				ix: 10
			},
			p: {
				a: 0,
				k: [
					-260.095,
					-123.764,
					0
				],
				ix: 2
			},
			a: {
				a: 0,
				k: [
					-317.361,
					-221.089,
					0
				],
				ix: 1
			},
			s: {
				a: 0,
				k: [
					100,
					100,
					100
				],
				ix: 6
			}
		},
		ao: 0,
		shapes: [
			{
				ty: "gr",
				it: [
					{
						ind: 0,
						ty: "sh",
						ix: 1,
						ks: {
							a: 0,
							k: {
								i: [
									[
										2.695,
										0
									],
									[
										0,
										0
									],
									[
										0,
										2.695
									],
									[
										0,
										0
									],
									[
										-2.695,
										0
									],
									[
										0,
										0
									],
									[
										0,
										-2.695
									],
									[
										0,
										0
									]
								],
								o: [
									[
										0,
										0
									],
									[
										-2.695,
										0
									],
									[
										0,
										0
									],
									[
										0,
										-2.695
									],
									[
										0,
										0
									],
									[
										2.695,
										0
									],
									[
										0,
										0
									],
									[
										0,
										2.695
									]
								],
								v: [
									[
										-252.143,
										-216.21
									],
									[
										-382.579,
										-216.21
									],
									[
										-387.458,
										-221.089
									],
									[
										-387.458,
										-221.089
									],
									[
										-382.579,
										-225.968
									],
									[
										-252.143,
										-225.968
									],
									[
										-247.264,
										-221.089
									],
									[
										-247.264,
										-221.089
									]
								],
								c: true
							},
							ix: 2
						},
						nm: "Path 1",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ty: "fl",
						c: {
							a: 0,
							k: [
								0.8941176470588236,
								0.4666666666666667,
								0.3764705882352941,
								1
							],
							ix: 4
						},
						o: {
							a: 0,
							k: 100,
							ix: 5
						},
						r: 1,
						bm: 0,
						nm: "Fill 1",
						mn: "ADBE Vector Graphic - Fill",
						hd: false
					},
					{
						ty: "tr",
						p: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 2
						},
						a: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 1
						},
						s: {
							a: 0,
							k: [
								100,
								100
							],
							ix: 3
						},
						r: {
							a: 0,
							k: 0,
							ix: 6
						},
						o: {
							a: 0,
							k: 100,
							ix: 7
						},
						sk: {
							a: 0,
							k: 0,
							ix: 4
						},
						sa: {
							a: 0,
							k: 0,
							ix: 5
						},
						nm: "Transform"
					}
				],
				nm: "Group 1",
				np: 2,
				cix: 2,
				bm: 0,
				ix: 1,
				mn: "ADBE Vector Group",
				hd: false
			}
		],
		ip: 36,
		op: 71,
		st: 36,
		bm: 0
	},
	{
		ddd: 0,
		ind: 33,
		ty: 4,
		nm: "Shape Layer 1",
		parent: 1,
		td: 1,
		sr: 1,
		ks: {
			o: {
				a: 0,
				k: 100,
				ix: 11
			},
			r: {
				a: 0,
				k: 0,
				ix: 10
			},
			p: {
				a: 0,
				k: [
					-331.733,
					-123.175,
					0
				],
				ix: 2
			},
			a: {
				a: 0,
				k: [
					-389,
					-220.5,
					0
				],
				ix: 1
			},
			s: {
				a: 0,
				k: [
					100,
					100,
					100
				],
				ix: 6
			}
		},
		ao: 0,
		shapes: [
			{
				ty: "gr",
				it: [
					{
						ind: 0,
						ty: "sh",
						ix: 1,
						ks: {
							a: 0,
							k: {
								i: [
									[
										0,
										0
									],
									[
										0,
										0
									]
								],
								o: [
									[
										0,
										0
									],
									[
										0,
										0
									]
								],
								v: [
									[
										-389,
										-220.5
									],
									[
										-246.5,
										-222
									]
								],
								c: false
							},
							ix: 2
						},
						nm: "Path 1",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ty: "tm",
						s: {
							a: 1,
							k: [
								{
									i: {
										x: [
											0.667
										],
										y: [
											1
										]
									},
									o: {
										x: [
											0.333
										],
										y: [
											0
										]
									},
									t: 0,
									s: [
										0
									]
								},
								{
									t: 15,
									s: [
										100
									]
								}
							],
							ix: 1
						},
						e: {
							a: 1,
							k: [
								{
									i: {
										x: [
											0.667
										],
										y: [
											1
										]
									},
									o: {
										x: [
											0.333
										],
										y: [
											0
										]
									},
									t: 20,
									s: [
										0
									]
								},
								{
									t: 35,
									s: [
										100
									]
								}
							],
							ix: 2
						},
						o: {
							a: 0,
							k: 0,
							ix: 3
						},
						m: 1,
						ix: 2,
						nm: "Trim Paths 1",
						mn: "ADBE Vector Filter - Trim",
						hd: false
					},
					{
						ty: "st",
						c: {
							a: 0,
							k: [
								0.645784983915,
								0.674509983437,
								0.640123015759,
								1
							],
							ix: 3
						},
						o: {
							a: 0,
							k: 100,
							ix: 4
						},
						w: {
							a: 0,
							k: 16,
							ix: 5
						},
						lc: 1,
						lj: 1,
						ml: 4,
						bm: 0,
						nm: "Stroke 1",
						mn: "ADBE Vector Graphic - Stroke",
						hd: false
					},
					{
						ty: "tr",
						p: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 2
						},
						a: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 1
						},
						s: {
							a: 0,
							k: [
								100,
								100
							],
							ix: 3
						},
						r: {
							a: 0,
							k: 0,
							ix: 6
						},
						o: {
							a: 0,
							k: 100,
							ix: 7
						},
						sk: {
							a: 0,
							k: 0,
							ix: 4
						},
						sa: {
							a: 0,
							k: 0,
							ix: 5
						},
						nm: "Transform"
					}
				],
				nm: "Shape 1",
				np: 4,
				cix: 2,
				bm: 0,
				ix: 1,
				mn: "ADBE Vector Group",
				hd: false
			}
		],
		ip: 0,
		op: 35,
		st: 0,
		bm: 0
	},
	{
		ddd: 0,
		ind: 34,
		ty: 4,
		nm: "Layer 3",
		parent: 1,
		tt: 1,
		sr: 1,
		ks: {
			o: {
				a: 0,
				k: 100,
				ix: 11
			},
			r: {
				a: 0,
				k: 0,
				ix: 10
			},
			p: {
				a: 0,
				k: [
					-260.095,
					-123.764,
					0
				],
				ix: 2
			},
			a: {
				a: 0,
				k: [
					-317.361,
					-221.089,
					0
				],
				ix: 1
			},
			s: {
				a: 0,
				k: [
					100,
					100,
					100
				],
				ix: 6
			}
		},
		ao: 0,
		shapes: [
			{
				ty: "gr",
				it: [
					{
						ind: 0,
						ty: "sh",
						ix: 1,
						ks: {
							a: 0,
							k: {
								i: [
									[
										2.695,
										0
									],
									[
										0,
										0
									],
									[
										0,
										2.695
									],
									[
										0,
										0
									],
									[
										-2.695,
										0
									],
									[
										0,
										0
									],
									[
										0,
										-2.695
									],
									[
										0,
										0
									]
								],
								o: [
									[
										0,
										0
									],
									[
										-2.695,
										0
									],
									[
										0,
										0
									],
									[
										0,
										-2.695
									],
									[
										0,
										0
									],
									[
										2.695,
										0
									],
									[
										0,
										0
									],
									[
										0,
										2.695
									]
								],
								v: [
									[
										-252.143,
										-216.21
									],
									[
										-382.579,
										-216.21
									],
									[
										-387.458,
										-221.089
									],
									[
										-387.458,
										-221.089
									],
									[
										-382.579,
										-225.968
									],
									[
										-252.143,
										-225.968
									],
									[
										-247.264,
										-221.089
									],
									[
										-247.264,
										-221.089
									]
								],
								c: true
							},
							ix: 2
						},
						nm: "Path 1",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ty: "fl",
						c: {
							a: 0,
							k: [
								0.2235294117647059,
								0.48627450980392156,
								0.9490196078431372,
								1
							],
							ix: 4
						},
						o: {
							a: 0,
							k: 100,
							ix: 5
						},
						r: 1,
						bm: 0,
						nm: "Fill 1",
						mn: "ADBE Vector Graphic - Fill",
						hd: false
					},
					{
						ty: "tr",
						p: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 2
						},
						a: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 1
						},
						s: {
							a: 0,
							k: [
								100,
								100
							],
							ix: 3
						},
						r: {
							a: 0,
							k: 0,
							ix: 6
						},
						o: {
							a: 0,
							k: 100,
							ix: 7
						},
						sk: {
							a: 0,
							k: 0,
							ix: 4
						},
						sa: {
							a: 0,
							k: 0,
							ix: 5
						},
						nm: "Transform"
					}
				],
				nm: "Group 1",
				np: 2,
				cix: 2,
				bm: 0,
				ix: 1,
				mn: "ADBE Vector Group",
				hd: false
			}
		],
		ip: 0,
		op: 35,
		st: 0,
		bm: 0
	},
	{
		ddd: 0,
		ind: 35,
		ty: 4,
		nm: "Layer 2",
		parent: 1,
		sr: 1,
		ks: {
			o: {
				a: 0,
				k: 100,
				ix: 11
			},
			r: {
				a: 0,
				k: 0,
				ix: 10
			},
			p: {
				a: 0,
				k: [
					-49.526,
					-162.661,
					0
				],
				ix: 2
			},
			a: {
				a: 0,
				k: [
					-106.793,
					-259.987,
					0
				],
				ix: 1
			},
			s: {
				a: 1,
				k: [
					{
						i: {
							x: [
								0.667,
								0.667,
								0.667
							],
							y: [
								1,
								1,
								1
							]
						},
						o: {
							x: [
								0.333,
								0.333,
								0.333
							],
							y: [
								0,
								0,
								0
							]
						},
						t: 0,
						s: [
							0,
							0,
							100
						]
					},
					{
						i: {
							x: [
								0.667,
								0.667,
								0.667
							],
							y: [
								1,
								1,
								1
							]
						},
						o: {
							x: [
								0.333,
								0.333,
								0.333
							],
							y: [
								0,
								0,
								0
							]
						},
						t: 23.704,
						s: [
							100,
							100,
							100
						]
					},
					{
						i: {
							x: [
								0.667,
								0.667,
								0.667
							],
							y: [
								1,
								1,
								1
							]
						},
						o: {
							x: [
								0.333,
								0.333,
								0.333
							],
							y: [
								0,
								0,
								0
							]
						},
						t: 47.407,
						s: [
							100,
							100,
							100
						]
					},
					{
						i: {
							x: [
								0.667,
								0.667,
								0.667
							],
							y: [
								1,
								1,
								1
							]
						},
						o: {
							x: [
								0.206,
								0.206,
								0.206
							],
							y: [
								0,
								0,
								0
							]
						},
						t: 71.111,
						s: [
							0,
							0,
							100
						]
					},
					{
						i: {
							x: [
								0.667,
								0.667,
								0.667
							],
							y: [
								1,
								1,
								1
							]
						},
						o: {
							x: [
								0.333,
								0.333,
								0.333
							],
							y: [
								0,
								0,
								0
							]
						},
						t: 88.889,
						s: [
							0,
							0,
							100
						]
					},
					{
						i: {
							x: [
								0.667,
								0.667,
								0.667
							],
							y: [
								1,
								1,
								1
							]
						},
						o: {
							x: [
								0.333,
								0.333,
								0.333
							],
							y: [
								0,
								0,
								0
							]
						},
						t: 112.593,
						s: [
							100,
							100,
							100
						]
					},
					{
						i: {
							x: [
								0.667,
								0.667,
								0.667
							],
							y: [
								1,
								1,
								1
							]
						},
						o: {
							x: [
								0.333,
								0.333,
								0.333
							],
							y: [
								0,
								0,
								0
							]
						},
						t: 136.296,
						s: [
							100,
							100,
							100
						]
					},
					{
						t: 160,
						s: [
							0,
							0,
							100
						]
					}
				],
				ix: 6
			}
		},
		ao: 0,
		shapes: [
			{
				ty: "gr",
				it: [
					{
						ind: 0,
						ty: "sh",
						ix: 1,
						ks: {
							a: 0,
							k: {
								i: [
									[
										0.747,
										-0.83
									],
									[
										0.332,
										-0.332
									],
									[
										0.581,
										-0.581
									],
									[
										1.244,
										0
									],
									[
										0.166,
										0
									],
									[
										1.659,
										0.83
									],
									[
										3.484,
										4.148
									],
									[
										1.327,
										3.402
									],
									[
										-0.166,
										1.576
									],
									[
										-0.747,
										0.664
									],
									[
										0,
										0
									],
									[
										-0.498,
										0
									],
									[
										-0.332,
										-0.332
									],
									[
										-0.498,
										-0.498
									],
									[
										-0.332,
										-0.249
									],
									[
										0,
										0
									],
									[
										0,
										-0.415
									],
									[
										0.249,
										-0.249
									],
									[
										0.249,
										-0.249
									],
									[
										0.664,
										-0.664
									],
									[
										0.083,
										-0.083
									],
									[
										-0.166,
										-0.498
									],
									[
										0,
										0
									],
									[
										-1.245,
										-1.659
									],
									[
										-2.738,
										-1.742
									],
									[
										-0.332,
										-0.166
									],
									[
										-0.249,
										-0.166
									],
									[
										0,
										0
									],
									[
										-0.664,
										0.664
									],
									[
										0,
										0
									],
									[
										-0.498,
										0
									],
									[
										-0.249,
										-0.249
									],
									[
										0,
										0
									]
								],
								o: [
									[
										-0.332,
										0.332
									],
									[
										-0.581,
										0.498
									],
									[
										-0.83,
										0.83
									],
									[
										-0.166,
										0
									],
									[
										-2.489,
										-0.166
									],
									[
										-4.729,
										-2.323
									],
									[
										-2.821,
										-3.402
									],
									[
										-0.83,
										-1.991
									],
									[
										0.083,
										-0.913
									],
									[
										0,
										0
									],
									[
										0.249,
										-0.249
									],
									[
										0.498,
										0
									],
									[
										0.498,
										0.498
									],
									[
										0.249,
										0.249
									],
									[
										0,
										0
									],
									[
										0.249,
										0.249
									],
									[
										0,
										0.498
									],
									[
										-0.249,
										0.249
									],
									[
										-0.747,
										0.747
									],
									[
										0,
										0
									],
									[
										-0.83,
										0.83
									],
									[
										0,
										0
									],
									[
										0.581,
										1.493
									],
									[
										2.323,
										2.904
									],
									[
										0.332,
										0.249
									],
									[
										0.332,
										0.166
									],
									[
										0,
										0
									],
									[
										0.83,
										0.415
									],
									[
										0,
										0
									],
									[
										0.249,
										-0.249
									],
									[
										0.415,
										0
									],
									[
										0,
										0
									],
									[
										0.747,
										0.747
									]
								],
								v: [
									[
										-91.089,
										-247.501
									],
									[
										-92.085,
										-246.505
									],
									[
										-93.744,
										-244.846
									],
									[
										-96.731,
										-243.602
									],
									[
										-97.146,
										-243.602
									],
									[
										-103.617,
										-245.593
									],
									[
										-115.978,
										-255.299
									],
									[
										-122.035,
										-265.338
									],
									[
										-123.03,
										-270.482
									],
									[
										-121.869,
										-272.887
									],
									[
										-119.048,
										-275.708
									],
									[
										-117.887,
										-276.289
									],
									[
										-116.725,
										-275.708
									],
									[
										-115.232,
										-274.215
									],
									[
										-114.402,
										-273.385
									],
									[
										-112.079,
										-271.062
									],
									[
										-111.498,
										-269.901
									],
									[
										-112.079,
										-268.739
									],
									[
										-112.826,
										-267.993
									],
									[
										-114.9,
										-265.919
									],
									[
										-114.983,
										-265.836
									],
									[
										-115.481,
										-263.762
									],
									[
										-115.481,
										-263.679
									],
									[
										-112.743,
										-259.199
									],
									[
										-105.193,
										-252.313
									],
									[
										-104.115,
										-251.732
									],
									[
										-103.285,
										-251.317
									],
									[
										-103.202,
										-251.234
									],
									[
										-100.879,
										-251.649
									],
									[
										-97.976,
										-254.553
									],
									[
										-96.814,
										-255.133
									],
									[
										-95.735,
										-254.553
									],
									[
										-91.089,
										-249.907
									]
								],
								c: true
							},
							ix: 2
						},
						nm: "Path 1",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ind: 1,
						ty: "sh",
						ix: 2,
						ks: {
							a: 0,
							k: {
								i: [
									[
										1.742,
										1.742
									],
									[
										0,
										0
									],
									[
										1.078,
										0
									],
									[
										0.83,
										-0.83
									],
									[
										0,
										0
									],
									[
										0.166,
										0.083
									],
									[
										0.249,
										0.166
									],
									[
										2.157,
										2.655
									],
									[
										0.415,
										0.996
									],
									[
										-0.581,
										0.581
									],
									[
										-0.249,
										0.249
									],
									[
										0,
										1.078
									],
									[
										0.913,
										0.913
									],
									[
										0,
										0
									],
									[
										0.249,
										0.332
									],
									[
										0.498,
										0.498
									],
									[
										1.079,
										0
									],
									[
										0.913,
										-0.913
									],
									[
										0,
										0
									],
									[
										0.166,
										-1.576
									],
									[
										-0.581,
										-1.493
									],
									[
										-3.07,
										-3.65
									],
									[
										-5.144,
										-2.489
									],
									[
										-2.904,
										-0.249
									],
									[
										-0.249,
										0
									],
									[
										-1.327,
										1.41
									],
									[
										-0.083,
										0.083
									],
									[
										-0.581,
										0.498
									],
									[
										-0.332,
										0.332
									]
								],
								o: [
									[
										0,
										0
									],
									[
										-0.83,
										-0.913
									],
									[
										-1.079,
										0
									],
									[
										0,
										0
									],
									[
										-0.166,
										-0.083
									],
									[
										-0.332,
										-0.166
									],
									[
										-2.489,
										-1.576
									],
									[
										-0.996,
										-1.244
									],
									[
										0.664,
										-0.581
									],
									[
										0.249,
										-0.249
									],
									[
										0.913,
										-0.913
									],
									[
										0,
										-1.079
									],
									[
										0,
										0
									],
									[
										-0.249,
										-0.249
									],
									[
										-0.498,
										-0.498
									],
									[
										-0.83,
										-0.83
									],
									[
										-1.078,
										0
									],
									[
										0,
										0
									],
									[
										-1.078,
										1.078
									],
									[
										-0.166,
										2.489
									],
									[
										1.327,
										3.816
									],
									[
										3.733,
										4.397
									],
									[
										1.908,
										0.913
									],
									[
										0.166,
										0
									],
									[
										1.991,
										0
									],
									[
										0,
										0
									],
									[
										0.415,
										-0.498
									],
									[
										0.332,
										-0.332
									],
									[
										1.742,
										-1.825
									]
								],
								v: [
									[
										-89.181,
										-251.815
									],
									[
										-93.827,
										-256.461
									],
									[
										-96.814,
										-257.871
									],
									[
										-99.801,
										-256.544
									],
									[
										-102.455,
										-253.889
									],
									[
										-102.953,
										-254.138
									],
									[
										-103.783,
										-254.553
									],
									[
										-110.669,
										-260.858
									],
									[
										-112.826,
										-264.259
									],
									[
										-111.001,
										-266.085
									],
									[
										-110.254,
										-266.831
									],
									[
										-108.844,
										-269.901
									],
									[
										-110.254,
										-272.97
									],
									[
										-112.577,
										-275.293
									],
									[
										-113.324,
										-276.123
									],
									[
										-114.9,
										-277.699
									],
									[
										-117.887,
										-279.027
									],
									[
										-120.873,
										-277.699
									],
									[
										-123.777,
										-274.796
									],
									[
										-125.685,
										-270.73
									],
									[
										-124.607,
										-264.425
									],
									[
										-118.136,
										-253.557
									],
									[
										-104.861,
										-243.187
									],
									[
										-97.395,
										-240.947
									],
									[
										-96.814,
										-240.947
									],
									[
										-91.836,
										-243.104
									],
									[
										-91.753,
										-243.187
									],
									[
										-90.26,
										-244.68
									],
									[
										-89.181,
										-245.758
									]
								],
								c: true
							},
							ix: 2
						},
						nm: "Path 2",
						mn: "ADBE Vector Shape - Group",
						hd: false
					},
					{
						ty: "fl",
						c: {
							a: 0,
							k: [
								1,
								1,
								1,
								1
							],
							ix: 4
						},
						o: {
							a: 0,
							k: 100,
							ix: 5
						},
						r: 1,
						bm: 0,
						nm: "Fill 1",
						mn: "ADBE Vector Graphic - Fill",
						hd: false
					},
					{
						ty: "tr",
						p: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 2
						},
						a: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 1
						},
						s: {
							a: 0,
							k: [
								100,
								100
							],
							ix: 3
						},
						r: {
							a: 0,
							k: 0,
							ix: 6
						},
						o: {
							a: 0,
							k: 100,
							ix: 7
						},
						sk: {
							a: 0,
							k: 0,
							ix: 4
						},
						sa: {
							a: 0,
							k: 0,
							ix: 5
						},
						nm: "Transform"
					}
				],
				nm: "Group 1",
				np: 3,
				cix: 2,
				bm: 0,
				ix: 1,
				mn: "ADBE Vector Group",
				hd: false
			}
		],
		ip: 0,
		op: 180,
		st: 0,
		bm: 0
	},
	{
		ddd: 0,
		ind: 36,
		ty: 4,
		nm: "Layer 1",
		parent: 1,
		sr: 1,
		ks: {
			o: {
				a: 0,
				k: 100,
				ix: 11
			},
			r: {
				a: 0,
				k: 0,
				ix: 10
			},
			p: {
				a: 0,
				k: [
					-50.955,
					-160.199,
					0
				],
				ix: 2
			},
			a: {
				a: 0,
				k: [
					-108.222,
					-257.524,
					0
				],
				ix: 1
			},
			s: {
				a: 0,
				k: [
					100,
					100,
					100
				],
				ix: 6
			}
		},
		ao: 0,
		shapes: [
			{
				ty: "gr",
				it: [
					{
						ty: "gr",
						it: [
							{
								ty: "gr",
								it: [
									{
										ty: "gr",
										it: [
											{
												ty: "gr",
												it: [
													{
														ind: 0,
														ty: "sh",
														ix: 1,
														ks: {
															a: 0,
															k: {
																i: [
																	[
																		3.568,
																		0
																	],
																	[
																		0,
																		0
																	],
																	[
																		0,
																		4.706
																	],
																	[
																		0,
																		0
																	],
																	[
																		-3.568,
																		0
																	],
																	[
																		0,
																		0
																	],
																	[
																		0,
																		-3.568
																	],
																	[
																		0,
																		0
																	]
																],
																o: [
																	[
																		0,
																		0
																	],
																	[
																		-4.706,
																		0
																	],
																	[
																		0,
																		0
																	],
																	[
																		0,
																		-3.568
																	],
																	[
																		0,
																		0
																	],
																	[
																		3.568,
																		0
																	],
																	[
																		0,
																		0
																	],
																	[
																		0,
																		3.568
																	]
																],
																v: [
																	[
																		-73.886,
																		-218.919
																	],
																	[
																		-140.497,
																		-218.919
																	],
																	[
																		-149.018,
																		-227.44
																	],
																	[
																		-149.018,
																		-289.67
																	],
																	[
																		-142.558,
																		-296.13
																	],
																	[
																		-73.886,
																		-296.13
																	],
																	[
																		-67.426,
																		-289.67
																	],
																	[
																		-67.426,
																		-225.379
																	]
																],
																c: true
															},
															ix: 2
														},
														nm: "Path 1",
														mn: "ADBE Vector Shape - Group",
														hd: false
													},
													{
														ty: "fl",
														c: {
															a: 0,
															k: [
																0.337254911661,
																0.874509811401,
																0.929411768913,
																1
															],
															ix: 4
														},
														o: {
															a: 0,
															k: 100,
															ix: 5
														},
														r: 1,
														bm: 0,
														nm: "Fill 1",
														mn: "ADBE Vector Graphic - Fill",
														hd: false
													},
													{
														ty: "tr",
														p: {
															a: 0,
															k: [
																0,
																0
															],
															ix: 2
														},
														a: {
															a: 0,
															k: [
																0,
																0
															],
															ix: 1
														},
														s: {
															a: 0,
															k: [
																100,
																100
															],
															ix: 3
														},
														r: {
															a: 0,
															k: 0,
															ix: 6
														},
														o: {
															a: 0,
															k: 100,
															ix: 7
														},
														sk: {
															a: 0,
															k: 0,
															ix: 4
														},
														sa: {
															a: 0,
															k: 0,
															ix: 5
														},
														nm: "Transform"
													}
												],
												nm: "Group 1",
												np: 2,
												cix: 2,
												bm: 0,
												ix: 1,
												mn: "ADBE Vector Group",
												hd: false
											},
											{
												ty: "tr",
												p: {
													a: 0,
													k: [
														0,
														0
													],
													ix: 2
												},
												a: {
													a: 0,
													k: [
														0,
														0
													],
													ix: 1
												},
												s: {
													a: 0,
													k: [
														100,
														100
													],
													ix: 3
												},
												r: {
													a: 0,
													k: 0,
													ix: 6
												},
												o: {
													a: 0,
													k: 100,
													ix: 7
												},
												sk: {
													a: 0,
													k: 0,
													ix: 4
												},
												sa: {
													a: 0,
													k: 0,
													ix: 5
												},
												nm: "Transform"
											}
										],
										nm: "Group 1",
										np: 1,
										cix: 2,
										bm: 0,
										ix: 1,
										mn: "ADBE Vector Group",
										hd: false
									},
									{
										ty: "tr",
										p: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 2
										},
										a: {
											a: 0,
											k: [
												0,
												0
											],
											ix: 1
										},
										s: {
											a: 0,
											k: [
												100,
												100
											],
											ix: 3
										},
										r: {
											a: 0,
											k: 0,
											ix: 6
										},
										o: {
											a: 0,
											k: 100,
											ix: 7
										},
										sk: {
											a: 0,
											k: 0,
											ix: 4
										},
										sa: {
											a: 0,
											k: 0,
											ix: 5
										},
										nm: "Transform"
									}
								],
								nm: "Group 1",
								np: 1,
								cix: 2,
								bm: 0,
								ix: 1,
								mn: "ADBE Vector Group",
								hd: false
							},
							{
								ty: "tr",
								p: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 2
								},
								a: {
									a: 0,
									k: [
										0,
										0
									],
									ix: 1
								},
								s: {
									a: 0,
									k: [
										100,
										100
									],
									ix: 3
								},
								r: {
									a: 0,
									k: 0,
									ix: 6
								},
								o: {
									a: 0,
									k: 100,
									ix: 7
								},
								sk: {
									a: 0,
									k: 0,
									ix: 4
								},
								sa: {
									a: 0,
									k: 0,
									ix: 5
								},
								nm: "Transform"
							}
						],
						nm: "Group 1",
						np: 1,
						cix: 2,
						bm: 0,
						ix: 1,
						mn: "ADBE Vector Group",
						hd: false
					},
					{
						ty: "tr",
						p: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 2
						},
						a: {
							a: 0,
							k: [
								0,
								0
							],
							ix: 1
						},
						s: {
							a: 0,
							k: [
								100,
								100
							],
							ix: 3
						},
						r: {
							a: 0,
							k: 0,
							ix: 6
						},
						o: {
							a: 0,
							k: 100,
							ix: 7
						},
						sk: {
							a: 0,
							k: 0,
							ix: 4
						},
						sa: {
							a: 0,
							k: 0,
							ix: 5
						},
						nm: "Transform"
					}
				],
				nm: "Group 1",
				np: 1,
				cix: 2,
				bm: 0,
				ix: 1,
				mn: "ADBE Vector Group",
				hd: false
			}
		],
		ip: 0,
		op: 180,
		st: 0,
		bm: 0
	}
];
export const markers = [
];
export default {
	v: v,
	fr: fr,
	ip: ip,
	op: op,
	w: w,
	h: h,
	nm: nm,
	ddd: ddd,
	assets: assets,
	layers: layers,
	markers: markers
};
