export const dashboard = {
	title: "Beranda"
};
export const title = "App Saya";
export default {
	dashboard: dashboard,
	title: title
};
