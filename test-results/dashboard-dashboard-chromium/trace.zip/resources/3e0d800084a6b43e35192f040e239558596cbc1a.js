import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/layouts/components/UserProfileAvatar.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f9dec5ba"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/dharma/Work/react-boilerplate/src/layouts/components/UserProfileAvatar.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { LogoutOutlined, UserOutlined } from "/node_modules/.vite/deps/@ant-design_icons.js?v=7a8c6384";
import { Button, Popover, theme } from "/node_modules/.vite/deps/antd.js?v=26d7e361";
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=f9dec5ba"; const React = __vite__cjsImport5_react.__esModule ? __vite__cjsImport5_react.default : __vite__cjsImport5_react;
import { handleLogout } from "/src/services/authServices.jsx";
import { useSelector } from "/node_modules/.vite/deps/react-redux.js?v=3db4bc54";
const {
  useToken
} = theme;
const UserProfileAvatar = () => {
  _s();
  const {
    token
  } = useToken();
  const {
    auth
  } = useSelector((state) => state);
  return /* @__PURE__ */ jsxDEV("div", { style: {
    display: "flex",
    alignItems: "center",
    backgroundColor: "transparent",
    borderRadius: "6px"
  }, children: /* @__PURE__ */ jsxDEV(Popover, { placement: "bottomRight", arrow: false, content: /* @__PURE__ */ jsxDEV("div", { style: {
    display: "flex",
    alignItems: "center",
    gap: "30px",
    backgroundColor: "transparent",
    borderRadius: "6px"
  }, children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("div", { style: {
        lineHeight: "20px",
        fontSize: "14px",
        fontWeight: "500"
      }, children: auth?.user ?? "" }, void 0, false, {
        fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/UserProfileAvatar.jsx",
        lineNumber: 32,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: {
        lineHeight: "16px",
        fontSize: "10px",
        opacity: 0.7
      }, children: auth?.email ?? "" }, void 0, false, {
        fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/UserProfileAvatar.jsx",
        lineNumber: 39,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/UserProfileAvatar.jsx",
      lineNumber: 31,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(Button, { type: "default", icon: /* @__PURE__ */ jsxDEV(LogoutOutlined, {}, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/UserProfileAvatar.jsx",
      lineNumber: 48,
      columnNumber: 42
    }, this), title: "Signout", onClick: handleLogout }, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/UserProfileAvatar.jsx",
      lineNumber: 48,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/UserProfileAvatar.jsx",
    lineNumber: 24,
    columnNumber: 63
  }, this), trigger: "click", children: /* @__PURE__ */ jsxDEV(Button, { type: "primary", icon: /* @__PURE__ */ jsxDEV(UserOutlined, {}, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/UserProfileAvatar.jsx",
    lineNumber: 50,
    columnNumber: 38
  }, this), size: "middle", style: {
    backgroundColor: token.colorTextTertiary
  } }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/UserProfileAvatar.jsx",
    lineNumber: 50,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/UserProfileAvatar.jsx",
    lineNumber: 24,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/layouts/components/UserProfileAvatar.jsx",
    lineNumber: 18,
    columnNumber: 10
  }, this);
};
_s(UserProfileAvatar, "KVIZYNZdjGTXweW+ea4tDwd/Iwo=", false, function() {
  return [useToken, useSelector];
});
_c = UserProfileAvatar;
export default UserProfileAvatar;
var _c;
$RefreshReg$(_c, "UserProfileAvatar");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/dharma/Work/react-boilerplate/src/layouts/components/UserProfileAvatar.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0NjOzs7Ozs7Ozs7Ozs7Ozs7OztBQXBDZCxTQUFTQSxnQkFBZ0JDLG9CQUFvQjtBQUM3QyxTQUFTQyxRQUFRQyxTQUFTQyxhQUFhO0FBQ3ZDLE9BQU9DLFdBQVc7QUFFbEIsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLG1CQUFtQjtBQUU1QixNQUFNO0FBQUEsRUFBRUM7QUFBUyxJQUFJSjtBQUVyQixNQUFNSyxvQkFBb0JBLE1BQU07QUFBQUMsS0FBQTtBQUM5QixRQUFNO0FBQUEsSUFBRUM7QUFBQUEsRUFBTSxJQUFJSCxTQUFTO0FBQzNCLFFBQU07QUFBQSxJQUFFSTtBQUFBQSxFQUFLLElBQUlMLFlBQWFNLFdBQVVBLEtBQUs7QUFFN0MsU0FDRSx1QkFBQyxTQUNDLE9BQU87QUFBQSxJQUNMQyxTQUFTO0FBQUEsSUFDVEMsWUFBWTtBQUFBLElBQ1pDLGlCQUFpQjtBQUFBLElBQ2pCQyxjQUFjO0FBQUEsRUFDaEIsR0FFQSxpQ0FBQyxXQUNDLFdBQVUsZUFDVixPQUFPLE9BQ1AsU0FDRSx1QkFBQyxTQUNDLE9BQU87QUFBQSxJQUNMSCxTQUFTO0FBQUEsSUFDVEMsWUFBWTtBQUFBLElBQ1pHLEtBQUs7QUFBQSxJQUNMRixpQkFBaUI7QUFBQSxJQUNqQkMsY0FBYztBQUFBLEVBQ2hCLEdBRUE7QUFBQSwyQkFBQyxTQUNDO0FBQUEsNkJBQUMsU0FDQyxPQUFPO0FBQUEsUUFDTEUsWUFBWTtBQUFBLFFBQ1pDLFVBQVU7QUFBQSxRQUNWQyxZQUFZO0FBQUEsTUFDZCxHQUVDVCxnQkFBTVUsUUFBUSxNQVBqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxNQUNBLHVCQUFDLFNBQ0MsT0FBTztBQUFBLFFBQUVILFlBQVk7QUFBQSxRQUFRQyxVQUFVO0FBQUEsUUFBUUcsU0FBUztBQUFBLE1BQUksR0FFM0RYLGdCQUFNWSxTQUFTLE1BSGxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJQTtBQUFBLFNBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWVBO0FBQUEsSUFFQSx1QkFBQyxVQUNDLE1BQUssV0FDTCxNQUFNLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZSxHQUNyQixPQUFNLFdBQ04sU0FBU2xCLGdCQUpYO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJd0I7QUFBQSxPQTlCMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdDQSxHQUVGLFNBQVEsU0FFUixpQ0FBQyxVQUNDLE1BQUssV0FDTCxNQUFNLHVCQUFDLGtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBYSxHQUNuQixNQUFNLFVBQ04sT0FBTztBQUFBLElBQUVVLGlCQUFpQkwsTUFBTWM7QUFBQUEsRUFBa0IsS0FKcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUlzRCxLQTVDeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQThDQSxLQXRERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBdURBO0FBRUo7QUFBRWYsR0E5RElELG1CQUFpQjtBQUFBLFVBQ0hELFVBQ0RELFdBQVc7QUFBQTtBQUFBbUIsS0FGeEJqQjtBQWdFTixlQUFlQTtBQUFrQixJQUFBaUI7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkxvZ291dE91dGxpbmVkIiwiVXNlck91dGxpbmVkIiwiQnV0dG9uIiwiUG9wb3ZlciIsInRoZW1lIiwiUmVhY3QiLCJoYW5kbGVMb2dvdXQiLCJ1c2VTZWxlY3RvciIsInVzZVRva2VuIiwiVXNlclByb2ZpbGVBdmF0YXIiLCJfcyIsInRva2VuIiwiYXV0aCIsInN0YXRlIiwiZGlzcGxheSIsImFsaWduSXRlbXMiLCJiYWNrZ3JvdW5kQ29sb3IiLCJib3JkZXJSYWRpdXMiLCJnYXAiLCJsaW5lSGVpZ2h0IiwiZm9udFNpemUiLCJmb250V2VpZ2h0IiwidXNlciIsIm9wYWNpdHkiLCJlbWFpbCIsImNvbG9yVGV4dFRlcnRpYXJ5IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJVc2VyUHJvZmlsZUF2YXRhci5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTG9nb3V0T3V0bGluZWQsIFVzZXJPdXRsaW5lZCB9IGZyb20gXCJAYW50LWRlc2lnbi9pY29uc1wiO1xuaW1wb3J0IHsgQnV0dG9uLCBQb3BvdmVyLCB0aGVtZSB9IGZyb20gXCJhbnRkXCI7XG5pbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5cbmltcG9ydCB7IGhhbmRsZUxvZ291dCB9IGZyb20gXCIuLi8uLi9zZXJ2aWNlcy9hdXRoU2VydmljZXNcIjtcbmltcG9ydCB7IHVzZVNlbGVjdG9yIH0gZnJvbSBcInJlYWN0LXJlZHV4XCI7XG5cbmNvbnN0IHsgdXNlVG9rZW4gfSA9IHRoZW1lO1xuXG5jb25zdCBVc2VyUHJvZmlsZUF2YXRhciA9ICgpID0+IHtcbiAgY29uc3QgeyB0b2tlbiB9ID0gdXNlVG9rZW4oKTtcbiAgY29uc3QgeyBhdXRoIH0gPSB1c2VTZWxlY3Rvcigoc3RhdGUpID0+IHN0YXRlKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIHN0eWxlPXt7XG4gICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxuICAgICAgICBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLFxuICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IFwidHJhbnNwYXJlbnRcIixcbiAgICAgICAgYm9yZGVyUmFkaXVzOiBcIjZweFwiLFxuICAgICAgfX1cbiAgICA+XG4gICAgICA8UG9wb3ZlclxuICAgICAgICBwbGFjZW1lbnQ9XCJib3R0b21SaWdodFwiXG4gICAgICAgIGFycm93PXtmYWxzZX1cbiAgICAgICAgY29udGVudD17XG4gICAgICAgICAgPGRpdlxuICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXG4gICAgICAgICAgICAgIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsXG4gICAgICAgICAgICAgIGdhcDogXCIzMHB4XCIsXG4gICAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogXCJ0cmFuc3BhcmVudFwiLFxuICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6IFwiNnB4XCIsXG4gICAgICAgICAgICB9fVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgICAgbGluZUhlaWdodDogXCIyMHB4XCIsXG4gICAgICAgICAgICAgICAgICBmb250U2l6ZTogXCIxNHB4XCIsXG4gICAgICAgICAgICAgICAgICBmb250V2VpZ2h0OiBcIjUwMFwiLFxuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICB7YXV0aD8udXNlciA/PyBcIlwifVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IGxpbmVIZWlnaHQ6IFwiMTZweFwiLCBmb250U2l6ZTogXCIxMHB4XCIsIG9wYWNpdHk6IDAuNyB9fVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAge2F1dGg/LmVtYWlsID8/IFwiXCJ9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgdHlwZT1cImRlZmF1bHRcIlxuICAgICAgICAgICAgICBpY29uPXs8TG9nb3V0T3V0bGluZWQgLz59XG4gICAgICAgICAgICAgIHRpdGxlPVwiU2lnbm91dFwiXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUxvZ291dH1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIH1cbiAgICAgICAgdHJpZ2dlcj1cImNsaWNrXCJcbiAgICAgID5cbiAgICAgICAgPEJ1dHRvblxuICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcbiAgICAgICAgICBpY29uPXs8VXNlck91dGxpbmVkIC8+fVxuICAgICAgICAgIHNpemU9e1wibWlkZGxlXCJ9XG4gICAgICAgICAgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiB0b2tlbi5jb2xvclRleHRUZXJ0aWFyeSB9fVxuICAgICAgICAvPlxuICAgICAgPC9Qb3BvdmVyPlxuICAgIDwvZGl2PlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgVXNlclByb2ZpbGVBdmF0YXI7XG4iXSwiZmlsZSI6Ii9ob21lL2RoYXJtYS9Xb3JrL3JlYWN0LWJvaWxlcnBsYXRlL3NyYy9sYXlvdXRzL2NvbXBvbmVudHMvVXNlclByb2ZpbGVBdmF0YXIuanN4In0=