import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/layouts/Sidebar.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f9dec5ba"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/dharma/Work/react-boilerplate/src/layouts/Sidebar.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Grid, Menu } from "/node_modules/.vite/deps/antd.js?v=26d7e361";
import Sider from "/node_modules/.vite/deps/antd_es_layout_Sider.js?v=5aaf5f52";
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=f9dec5ba"; const React = __vite__cjsImport5_react.__esModule ? __vite__cjsImport5_react.default : __vite__cjsImport5_react;
import { useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=f16f2ff9";
import { useSelector } from "/node_modules/.vite/deps/react-redux.js?v=3db4bc54";
const {
  useBreakpoint
} = Grid;
const Sidebar = () => {
  _s();
  const screens = useBreakpoint();
  const location = useLocation();
  const {
    app
  } = useSelector((state) => state);
  return /* @__PURE__ */ jsxDEV(Sider, { style: {
    padding: screens.md ? "0 5px" : "0",
    display: "flex",
    flexDirection: "column",
    justifyContent: "space-between"
  }, theme: "light", breakpoint: "lg", collapsedWidth: screens.md ? 60 : 0, collapsible: true, zeroWidthTriggerStyle: {
    top: 115
  }, children: /* @__PURE__ */ jsxDEV(Menu, { theme: "light", mode: "inline", style: {
    marginTop: "6px",
    height: "calc(100% - 6px)",
    borderRight: 0
  }, selectedKeys: location.pathname.split("/")[1], items: !app.loading && app.page.list }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/layouts/Sidebar.jsx",
    lineNumber: 25,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/layouts/Sidebar.jsx",
    lineNumber: 17,
    columnNumber: 10
  }, this);
};
_s(Sidebar, "bhpVAREQY0URd1C24mLh3svuljw=", false, function() {
  return [useBreakpoint, useLocation, useSelector];
});
_c = Sidebar;
export default Sidebar;
var _c;
$RefreshReg$(_c, "Sidebar");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/dharma/Work/react-boilerplate/src/layouts/Sidebar.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOEJNOzs7Ozs7Ozs7Ozs7Ozs7OztBQTlCTixTQUFTQSxNQUFNQyxZQUFZO0FBQzNCLE9BQU9DLFdBQVc7QUFDbEIsT0FBT0MsV0FBVztBQUVsQixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsbUJBQW1CO0FBRTVCLE1BQU07QUFBQSxFQUFFQztBQUFjLElBQUlOO0FBRTFCLE1BQU1PLFVBQVVBLE1BQU07QUFBQUMsS0FBQTtBQUNwQixRQUFNQyxVQUFVSCxjQUFjO0FBQzlCLFFBQU1JLFdBQVdOLFlBQVk7QUFDN0IsUUFBTTtBQUFBLElBQUVPO0FBQUFBLEVBQUksSUFBSU4sWUFBYU8sV0FBVUEsS0FBSztBQUU1QyxTQUNFLHVCQUFDLFNBQ0MsT0FBTztBQUFBLElBQ0xDLFNBQVNKLFFBQVFLLEtBQUssVUFBVTtBQUFBLElBQ2hDQyxTQUFTO0FBQUEsSUFDVEMsZUFBZTtBQUFBLElBQ2ZDLGdCQUFnQjtBQUFBLEVBQ2xCLEdBQ0EsT0FBTSxTQUNOLFlBQVcsTUFDWCxnQkFBZ0JSLFFBQVFLLEtBQUssS0FBSyxHQUNsQyxhQUFhLE1BQ2IsdUJBQXVCO0FBQUEsSUFDckJJLEtBQUs7QUFBQSxFQUNQLEdBRUEsaUNBQUMsUUFDQyxPQUFNLFNBQ04sTUFBSyxVQUNMLE9BQU87QUFBQSxJQUNMQyxXQUFXO0FBQUEsSUFDWEMsUUFBUTtBQUFBLElBQ1JDLGFBQWE7QUFBQSxFQUNmLEdBQ0EsY0FBY1gsU0FBU1ksU0FBU0MsTUFBTSxHQUFHLEVBQUUsQ0FBQyxHQUM1QyxPQUFPLENBQUNaLElBQUlhLFdBQVdiLElBQUljLEtBQUtDLFFBVGxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FTdUMsS0F4QnpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EwQkE7QUFFSjtBQUFFbEIsR0FsQ0lELFNBQU87QUFBQSxVQUNLRCxlQUNDRixhQUNEQyxXQUFXO0FBQUE7QUFBQXNCLEtBSHZCcEI7QUFvQ04sZUFBZUE7QUFBUSxJQUFBb0I7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkdyaWQiLCJNZW51IiwiU2lkZXIiLCJSZWFjdCIsInVzZUxvY2F0aW9uIiwidXNlU2VsZWN0b3IiLCJ1c2VCcmVha3BvaW50IiwiU2lkZWJhciIsIl9zIiwic2NyZWVucyIsImxvY2F0aW9uIiwiYXBwIiwic3RhdGUiLCJwYWRkaW5nIiwibWQiLCJkaXNwbGF5IiwiZmxleERpcmVjdGlvbiIsImp1c3RpZnlDb250ZW50IiwidG9wIiwibWFyZ2luVG9wIiwiaGVpZ2h0IiwiYm9yZGVyUmlnaHQiLCJwYXRobmFtZSIsInNwbGl0IiwibG9hZGluZyIsInBhZ2UiLCJsaXN0IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJTaWRlYmFyLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBHcmlkLCBNZW51IH0gZnJvbSBcImFudGRcIjtcbmltcG9ydCBTaWRlciBmcm9tIFwiYW50ZC9lcy9sYXlvdXQvU2lkZXJcIjtcbmltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcblxuaW1wb3J0IHsgdXNlTG9jYXRpb24gfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xuaW1wb3J0IHsgdXNlU2VsZWN0b3IgfSBmcm9tIFwicmVhY3QtcmVkdXhcIjtcblxuY29uc3QgeyB1c2VCcmVha3BvaW50IH0gPSBHcmlkO1xuXG5jb25zdCBTaWRlYmFyID0gKCkgPT4ge1xuICBjb25zdCBzY3JlZW5zID0gdXNlQnJlYWtwb2ludCgpO1xuICBjb25zdCBsb2NhdGlvbiA9IHVzZUxvY2F0aW9uKCk7XG4gIGNvbnN0IHsgYXBwIH0gPSB1c2VTZWxlY3Rvcigoc3RhdGUpID0+IHN0YXRlKTtcblxuICByZXR1cm4gKFxuICAgIDxTaWRlclxuICAgICAgc3R5bGU9e3tcbiAgICAgICAgcGFkZGluZzogc2NyZWVucy5tZCA/IFwiMCA1cHhcIiA6IFwiMFwiLFxuICAgICAgICBkaXNwbGF5OiBcImZsZXhcIixcbiAgICAgICAgZmxleERpcmVjdGlvbjogXCJjb2x1bW5cIixcbiAgICAgICAganVzdGlmeUNvbnRlbnQ6IFwic3BhY2UtYmV0d2VlblwiLFxuICAgICAgfX1cbiAgICAgIHRoZW1lPVwibGlnaHRcIlxuICAgICAgYnJlYWtwb2ludD1cImxnXCJcbiAgICAgIGNvbGxhcHNlZFdpZHRoPXtzY3JlZW5zLm1kID8gNjAgOiAwfVxuICAgICAgY29sbGFwc2libGU9e3RydWV9XG4gICAgICB6ZXJvV2lkdGhUcmlnZ2VyU3R5bGU9e3tcbiAgICAgICAgdG9wOiAxMTUsXG4gICAgICB9fVxuICAgID5cbiAgICAgIDxNZW51XG4gICAgICAgIHRoZW1lPVwibGlnaHRcIlxuICAgICAgICBtb2RlPVwiaW5saW5lXCJcbiAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICBtYXJnaW5Ub3A6IFwiNnB4XCIsXG4gICAgICAgICAgaGVpZ2h0OiBcImNhbGMoMTAwJSAtIDZweClcIixcbiAgICAgICAgICBib3JkZXJSaWdodDogMCxcbiAgICAgICAgfX1cbiAgICAgICAgc2VsZWN0ZWRLZXlzPXtsb2NhdGlvbi5wYXRobmFtZS5zcGxpdChcIi9cIilbMV19XG4gICAgICAgIGl0ZW1zPXshYXBwLmxvYWRpbmcgJiYgYXBwLnBhZ2UubGlzdH1cbiAgICAgIC8+XG4gICAgPC9TaWRlcj5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IFNpZGViYXI7XG4iXSwiZmlsZSI6Ii9ob21lL2RoYXJtYS9Xb3JrL3JlYWN0LWJvaWxlcnBsYXRlL3NyYy9sYXlvdXRzL1NpZGViYXIuanN4In0=