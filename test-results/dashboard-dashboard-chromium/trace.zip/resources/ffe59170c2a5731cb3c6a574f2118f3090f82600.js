import { createMongoAbility, AbilityBuilder } from "/node_modules/.vite/deps/@casl_ability.js?v=852e8aae";
import { adminAbility, anonymousAbility, guestAbility, userAbility } from "/src/services/abilityServices.jsx";
import { store } from "/src/redux/store.jsx";
export const accountAbility = () => {
  const {
    can,
    cannot,
    rules
  } = new AbilityBuilder(createMongoAbility);
  const user = store.getState().auth;
  if (!user) {
    anonymousAbility({
      can,
      cannot
    });
  } else if (user?.role === "admin") {
    adminAbility({
      can,
      cannot
    });
  } else if (user?.role === "user") {
    userAbility({
      can,
      cannot
    });
  } else if (user?.role === "guest") {
    guestAbility({
      can,
      cannot
    });
  }
  return createMongoAbility(rules);
};

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUEsU0FBU0Esb0JBQW9CQyxzQkFBc0I7QUFDbkQsU0FDRUMsY0FDQUMsa0JBQ0FDLGNBQ0FDLG1CQUNLO0FBQ1AsU0FBU0MsYUFBYTtBQUVmLGFBQU1DLGlCQUFpQkEsTUFBTTtBQUNsQyxRQUFNO0FBQUEsSUFBRUM7QUFBQUEsSUFBS0M7QUFBQUEsSUFBUUM7QUFBQUEsRUFBTSxJQUFJLElBQUlULGVBQWVELGtCQUFrQjtBQUNwRSxRQUFNVyxPQUFPTCxNQUFNTSxTQUFTLEVBQUVDO0FBRTlCLE1BQUksQ0FBQ0YsTUFBTTtBQUNUUixxQkFBaUI7QUFBQSxNQUFFSztBQUFBQSxNQUFLQztBQUFBQSxJQUFPLENBQUM7QUFBQSxFQUNsQyxXQUFXRSxNQUFNRyxTQUFTLFNBQVM7QUFDakNaLGlCQUFhO0FBQUEsTUFBRU07QUFBQUEsTUFBS0M7QUFBQUEsSUFBTyxDQUFDO0FBQUEsRUFDOUIsV0FBV0UsTUFBTUcsU0FBUyxRQUFRO0FBQ2hDVCxnQkFBWTtBQUFBLE1BQUVHO0FBQUFBLE1BQUtDO0FBQUFBLElBQU8sQ0FBQztBQUFBLEVBQzdCLFdBQVdFLE1BQU1HLFNBQVMsU0FBUztBQUNqQ1YsaUJBQWE7QUFBQSxNQUFFSTtBQUFBQSxNQUFLQztBQUFBQSxJQUFPLENBQUM7QUFBQSxFQUM5QjtBQUVBLFNBQU9ULG1CQUFtQlUsS0FBSztBQUNqQyIsIm5hbWVzIjpbImNyZWF0ZU1vbmdvQWJpbGl0eSIsIkFiaWxpdHlCdWlsZGVyIiwiYWRtaW5BYmlsaXR5IiwiYW5vbnltb3VzQWJpbGl0eSIsImd1ZXN0QWJpbGl0eSIsInVzZXJBYmlsaXR5Iiwic3RvcmUiLCJhY2NvdW50QWJpbGl0eSIsImNhbiIsImNhbm5vdCIsInJ1bGVzIiwidXNlciIsImdldFN0YXRlIiwiYXV0aCIsInJvbGUiXSwic291cmNlcyI6WyJhYmlsaXR5LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjcmVhdGVNb25nb0FiaWxpdHksIEFiaWxpdHlCdWlsZGVyIH0gZnJvbSBcIkBjYXNsL2FiaWxpdHlcIjtcbmltcG9ydCB7XG4gIGFkbWluQWJpbGl0eSxcbiAgYW5vbnltb3VzQWJpbGl0eSxcbiAgZ3Vlc3RBYmlsaXR5LFxuICB1c2VyQWJpbGl0eSxcbn0gZnJvbSBcIi4uL3NlcnZpY2VzL2FiaWxpdHlTZXJ2aWNlc1wiO1xuaW1wb3J0IHsgc3RvcmUgfSBmcm9tIFwiLi4vcmVkdXgvc3RvcmVcIjtcblxuZXhwb3J0IGNvbnN0IGFjY291bnRBYmlsaXR5ID0gKCkgPT4ge1xuICBjb25zdCB7IGNhbiwgY2Fubm90LCBydWxlcyB9ID0gbmV3IEFiaWxpdHlCdWlsZGVyKGNyZWF0ZU1vbmdvQWJpbGl0eSk7XG4gIGNvbnN0IHVzZXIgPSBzdG9yZS5nZXRTdGF0ZSgpLmF1dGg7XG5cbiAgaWYgKCF1c2VyKSB7XG4gICAgYW5vbnltb3VzQWJpbGl0eSh7IGNhbiwgY2Fubm90IH0pO1xuICB9IGVsc2UgaWYgKHVzZXI/LnJvbGUgPT09IFwiYWRtaW5cIikge1xuICAgIGFkbWluQWJpbGl0eSh7IGNhbiwgY2Fubm90IH0pO1xuICB9IGVsc2UgaWYgKHVzZXI/LnJvbGUgPT09IFwidXNlclwiKSB7XG4gICAgdXNlckFiaWxpdHkoeyBjYW4sIGNhbm5vdCB9KTtcbiAgfSBlbHNlIGlmICh1c2VyPy5yb2xlID09PSBcImd1ZXN0XCIpIHtcbiAgICBndWVzdEFiaWxpdHkoeyBjYW4sIGNhbm5vdCB9KTtcbiAgfVxuXG4gIHJldHVybiBjcmVhdGVNb25nb0FiaWxpdHkocnVsZXMpO1xufTtcbiJdLCJmaWxlIjoiL2hvbWUvZGhhcm1hL1dvcmsvcmVhY3QtYm9pbGVycGxhdGUvc3JjL3V0aWxzL2FiaWxpdHkuanN4In0=