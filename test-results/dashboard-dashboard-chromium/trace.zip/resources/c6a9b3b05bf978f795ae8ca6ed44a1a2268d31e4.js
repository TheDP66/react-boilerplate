import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/dashboard/Dashboard.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f9dec5ba"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/dharma/Work/react-boilerplate/src/pages/dashboard/Dashboard.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { DownloadOutlined, PlusOutlined } from "/node_modules/.vite/deps/@ant-design_icons.js?v=7a8c6384";
import { Button, DatePicker, FloatButton, Spin, Table } from "/node_modules/.vite/deps/antd.js?v=26d7e361";
import __vite__cjsImport5_dayjs from "/node_modules/.vite/deps/dayjs.js?v=ccea1070"; const dayjs = __vite__cjsImport5_dayjs.__esModule ? __vite__cjsImport5_dayjs.default : __vite__cjsImport5_dayjs;
import Cookies from "/node_modules/.vite/deps/js-cookie.js?v=ea88deea";
import __vite__cjsImport7_react from "/node_modules/.vite/deps/react.js?v=f9dec5ba"; const React = __vite__cjsImport7_react.__esModule ? __vite__cjsImport7_react.default : __vite__cjsImport7_react; const useEffect = __vite__cjsImport7_react["useEffect"]; const useState = __vite__cjsImport7_react["useState"];
import { useTranslation } from "/node_modules/.vite/deps/react-i18next.js?v=626db4bf";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=f16f2ff9";
import { charactersColumn } from "/src/constant/columns/characters.jsx";
import { GET_CHARACTERS } from "/src/constant/queries/character.jsx";
import { Can } from "/src/context/AbilityContext.jsx";
import StickyHeader from "/src/layouts/StickyHeader.jsx";
import { useQueryGql } from "/src/lib/useQueryGql.jsx";
const {
  RangePicker
} = DatePicker;
const Dashboard = () => {
  _s();
  const {
    t
  } = useTranslation();
  const navigate = useNavigate();
  const {
    data,
    loading
  } = useQueryGql(GET_CHARACTERS);
  const [startDate, setStartDate] = useState(dayjs().add(-7, "days"));
  const [endDate, setEndDate] = useState(dayjs());
  const handleChangeDate = (date) => {
    setStartDate(date[0]);
    setEndDate(date[1]);
  };
  useEffect(() => {
    if (Cookies.get("redirect_uri")) {
      const uri = Cookies.get("redirect_uri");
      Cookies.remove("redirect_uri");
      navigate(uri);
    }
  }, []);
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV(Spin, { spinning: loading, size: "large", children: [
      /* @__PURE__ */ jsxDEV(StickyHeader, { title: t("title"), children: [
        /* @__PURE__ */ jsxDEV(RangePicker, { placement: "bottomRight", presets: [{
          label: "Last 7 days",
          value: [dayjs().add(-7, "days"), dayjs()]
        }, {
          label: "Last 30 days",
          value: [dayjs().add(-30, "days"), dayjs()]
        }], onChange: handleChangeDate, value: [startDate, endDate], format: "DD/MM/YYYY", allowClear: false }, void 0, false, {
          fileName: "/home/dharma/Work/react-boilerplate/src/pages/dashboard/Dashboard.jsx",
          lineNumber: 53,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { icon: /* @__PURE__ */ jsxDEV(DownloadOutlined, {}, void 0, false, {
          fileName: "/home/dharma/Work/react-boilerplate/src/pages/dashboard/Dashboard.jsx",
          lineNumber: 61,
          columnNumber: 25
        }, this), size: "middle", title: "Export" }, void 0, false, {
          fileName: "/home/dharma/Work/react-boilerplate/src/pages/dashboard/Dashboard.jsx",
          lineNumber: 61,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/home/dharma/Work/react-boilerplate/src/pages/dashboard/Dashboard.jsx",
        lineNumber: 52,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: {
        padding: 32
      }, children: /* @__PURE__ */ jsxDEV(Table, { loading, columns: charactersColumn(), dataSource: data?.characters?.results ?? [], scroll: {
        x: 1e3
      } }, void 0, false, {
        fileName: "/home/dharma/Work/react-boilerplate/src/pages/dashboard/Dashboard.jsx",
        lineNumber: 67,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/home/dharma/Work/react-boilerplate/src/pages/dashboard/Dashboard.jsx",
        lineNumber: 64,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/home/dharma/Work/react-boilerplate/src/pages/dashboard/Dashboard.jsx",
      lineNumber: 51,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Can, { I: "create", a: "dashboard", children: /* @__PURE__ */ jsxDEV(FloatButton, { shape: "square", type: "primary", tooltip: "Add new character", style: {
      width: 56,
      height: 56
    }, icon: /* @__PURE__ */ jsxDEV(PlusOutlined, {}, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/pages/dashboard/Dashboard.jsx",
      lineNumber: 77,
      columnNumber: 16
    }, this) }, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/pages/dashboard/Dashboard.jsx",
      lineNumber: 74,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/pages/dashboard/Dashboard.jsx",
      lineNumber: 73,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/dharma/Work/react-boilerplate/src/pages/dashboard/Dashboard.jsx",
    lineNumber: 50,
    columnNumber: 10
  }, this);
};
_s(Dashboard, "KQ1/QDrNrBzwq6F7NI7yjYbcONs=", false, function() {
  return [useTranslation, useNavigate, useQueryGql];
});
_c = Dashboard;
export default Dashboard;
var _c;
$RefreshReg$(_c, "Dashboard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/dharma/Work/react-boilerplate/src/pages/dashboard/Dashboard.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0RVOzs7Ozs7Ozs7Ozs7Ozs7OztBQWxEVixTQUFTQSxrQkFBa0JDLG9CQUFvQjtBQUMvQyxTQUFTQyxRQUFRQyxZQUFZQyxhQUFhQyxNQUFNQyxhQUFhO0FBQzdELE9BQU9DLFdBQVc7QUFDbEIsT0FBT0MsYUFBYTtBQUNwQixPQUFPQyxTQUFTQyxXQUFXQyxnQkFBZ0I7QUFDM0MsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyx3QkFBd0I7QUFDakMsU0FDRUMsc0JBQ0s7QUFDUCxTQUFTQyxXQUFXO0FBQ3BCLE9BQU9DLGtCQUFrQjtBQUN6QixTQUFTQyxtQkFBbUI7QUFFNUIsTUFBTTtBQUFBLEVBQUVDO0FBQVksSUFBSWhCO0FBRXhCLE1BQU1pQixZQUFZQSxNQUFNO0FBQUFDLEtBQUE7QUFDdEIsUUFBTTtBQUFBLElBQUVDO0FBQUFBLEVBQUUsSUFBSVYsZUFBZTtBQUM3QixRQUFNVyxXQUFXVixZQUFZO0FBQzdCLFFBQU07QUFBQSxJQUFFVztBQUFBQSxJQUFNQztBQUFBQSxFQUFRLElBQUlQLFlBQVlILGNBQWM7QUFFcEQsUUFBTSxDQUFDVyxXQUFXQyxZQUFZLElBQUloQixTQUFTSixNQUFNLEVBQUVxQixJQUFJLElBQUksTUFBTSxDQUFDO0FBQ2xFLFFBQU0sQ0FBQ0MsU0FBU0MsVUFBVSxJQUFJbkIsU0FBU0osTUFBTSxDQUFDO0FBTzlDLFFBQU13QixtQkFBb0JDLFVBQVM7QUFDakNMLGlCQUFhSyxLQUFLLENBQUMsQ0FBQztBQUNwQkYsZUFBV0UsS0FBSyxDQUFDLENBQUM7QUFBQSxFQUNwQjtBQUdBdEIsWUFBVSxNQUFNO0FBQ2QsUUFBSUYsUUFBUXlCLElBQUksY0FBYyxHQUFHO0FBQy9CLFlBQU1DLE1BQU0xQixRQUFReUIsSUFBSSxjQUFjO0FBQ3RDekIsY0FBUTJCLE9BQU8sY0FBYztBQUM3QlosZUFBU1csR0FBRztBQUFBLElBQ2Q7QUFBQSxFQUdGLEdBQUcsRUFBRTtBQUVMLFNBQ0UsdUJBQUMsU0FDQztBQUFBLDJCQUFDLFFBQUssVUFBVVQsU0FBUyxNQUFLLFNBQzVCO0FBQUEsNkJBQUMsZ0JBQWEsT0FBT0gsRUFBRSxPQUFPLEdBQzVCO0FBQUEsK0JBQUMsZUFDQyxXQUFVLGVBQ1YsU0FBUyxDQUNQO0FBQUEsVUFDRWMsT0FBTztBQUFBLFVBQ1BDLE9BQU8sQ0FBQzlCLE1BQU0sRUFBRXFCLElBQUksSUFBSSxNQUFNLEdBQUdyQixNQUFNLENBQUM7QUFBQSxRQUMxQyxHQUNBO0FBQUEsVUFDRTZCLE9BQU87QUFBQSxVQUNQQyxPQUFPLENBQUM5QixNQUFNLEVBQUVxQixJQUFJLEtBQUssTUFBTSxHQUFHckIsTUFBTSxDQUFDO0FBQUEsUUFDM0MsQ0FBQyxHQUVILFVBQVV3QixrQkFDVixPQUFPLENBQUNMLFdBQVdHLE9BQU8sR0FDMUIsUUFBUSxjQUNSLFlBQVksU0FmZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZW9CO0FBQUEsUUFHcEIsdUJBQUMsVUFBTyxNQUFNLHVCQUFDLHNCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUIsR0FBSyxNQUFLLFVBQVMsT0FBTSxZQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdFO0FBQUEsV0FuQmxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvQkE7QUFBQSxNQUVBLHVCQUFDLFNBQUksT0FBTztBQUFBLFFBQUVTLFNBQVM7QUFBQSxNQUFHLEdBQ3hCLGlDQUFDLFNBQ0MsU0FDQSxTQUFTeEIsaUJBQWlCLEdBQzFCLFlBQVlVLE1BQU1lLFlBQVlDLFdBQVcsSUFDekMsUUFBUTtBQUFBLFFBQUVDLEdBQUc7QUFBQSxNQUFLLEtBSnBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJc0IsS0FMeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsU0E5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQStCQTtBQUFBLElBRUEsdUJBQUMsT0FBSSxHQUFFLFVBQVMsR0FBRSxhQUNoQixpQ0FBQyxlQUNDLE9BQU0sVUFDTixNQUFLLFdBQ0wsU0FBUSxxQkFDUixPQUFPO0FBQUEsTUFBRUMsT0FBTztBQUFBLE1BQUlDLFFBQVE7QUFBQSxJQUFHLEdBQy9CLE1BQU0sdUJBQUMsa0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFhLEtBTHJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLeUIsS0FOM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFBO0FBQUEsT0ExQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTJDQTtBQUVKO0FBQUV0QixHQTNFSUQsV0FBUztBQUFBLFVBQ0NSLGdCQUNHQyxhQUNTSyxXQUFXO0FBQUE7QUFBQTBCLEtBSGpDeEI7QUE2RU4sZUFBZUE7QUFBVSxJQUFBd0I7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkRvd25sb2FkT3V0bGluZWQiLCJQbHVzT3V0bGluZWQiLCJCdXR0b24iLCJEYXRlUGlja2VyIiwiRmxvYXRCdXR0b24iLCJTcGluIiwiVGFibGUiLCJkYXlqcyIsIkNvb2tpZXMiLCJSZWFjdCIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwidXNlVHJhbnNsYXRpb24iLCJ1c2VOYXZpZ2F0ZSIsImNoYXJhY3RlcnNDb2x1bW4iLCJHRVRfQ0hBUkFDVEVSUyIsIkNhbiIsIlN0aWNreUhlYWRlciIsInVzZVF1ZXJ5R3FsIiwiUmFuZ2VQaWNrZXIiLCJEYXNoYm9hcmQiLCJfcyIsInQiLCJuYXZpZ2F0ZSIsImRhdGEiLCJsb2FkaW5nIiwic3RhcnREYXRlIiwic2V0U3RhcnREYXRlIiwiYWRkIiwiZW5kRGF0ZSIsInNldEVuZERhdGUiLCJoYW5kbGVDaGFuZ2VEYXRlIiwiZGF0ZSIsImdldCIsInVyaSIsInJlbW92ZSIsImxhYmVsIiwidmFsdWUiLCJwYWRkaW5nIiwiY2hhcmFjdGVycyIsInJlc3VsdHMiLCJ4Iiwid2lkdGgiLCJoZWlnaHQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkRhc2hib2FyZC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRG93bmxvYWRPdXRsaW5lZCwgUGx1c091dGxpbmVkIH0gZnJvbSBcIkBhbnQtZGVzaWduL2ljb25zXCI7XG5pbXBvcnQgeyBCdXR0b24sIERhdGVQaWNrZXIsIEZsb2F0QnV0dG9uLCBTcGluLCBUYWJsZSB9IGZyb20gXCJhbnRkXCI7XG5pbXBvcnQgZGF5anMgZnJvbSBcImRheWpzXCI7XG5pbXBvcnQgQ29va2llcyBmcm9tIFwianMtY29va2llXCI7XG5pbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgdXNlVHJhbnNsYXRpb24gfSBmcm9tIFwicmVhY3QtaTE4bmV4dFwiO1xuaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xuaW1wb3J0IHsgY2hhcmFjdGVyc0NvbHVtbiB9IGZyb20gXCIuLi8uLi9jb25zdGFudC9jb2x1bW5zL2NoYXJhY3RlcnNcIjtcbmltcG9ydCB7XG4gIEdFVF9DSEFSQUNURVJTXG59IGZyb20gXCIuLi8uLi9jb25zdGFudC9xdWVyaWVzL2NoYXJhY3RlclwiO1xuaW1wb3J0IHsgQ2FuIH0gZnJvbSBcIi4uLy4uL2NvbnRleHQvQWJpbGl0eUNvbnRleHRcIjtcbmltcG9ydCBTdGlja3lIZWFkZXIgZnJvbSBcIi4uLy4uL2xheW91dHMvU3RpY2t5SGVhZGVyXCI7XG5pbXBvcnQgeyB1c2VRdWVyeUdxbCB9IGZyb20gXCIuLi8uLi9saWIvdXNlUXVlcnlHcWxcIjtcblxuY29uc3QgeyBSYW5nZVBpY2tlciB9ID0gRGF0ZVBpY2tlcjtcblxuY29uc3QgRGFzaGJvYXJkID0gKCkgPT4ge1xuICBjb25zdCB7IHQgfSA9IHVzZVRyYW5zbGF0aW9uKCk7XG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgY29uc3QgeyBkYXRhLCBsb2FkaW5nIH0gPSB1c2VRdWVyeUdxbChHRVRfQ0hBUkFDVEVSUyk7XG5cbiAgY29uc3QgW3N0YXJ0RGF0ZSwgc2V0U3RhcnREYXRlXSA9IHVzZVN0YXRlKGRheWpzKCkuYWRkKC03LCBcImRheXNcIikpO1xuICBjb25zdCBbZW5kRGF0ZSwgc2V0RW5kRGF0ZV0gPSB1c2VTdGF0ZShkYXlqcygpKTtcblxuICAvLyBjb25zdCBbZ2V0Q2hhcmFjdGVyLCB7IGRhdGE6IGNoYXJEYXRhLCBsb2FkaW5nOiBjaGFyTG9hZCB9XSA9IHVzZUxhenlRdWVyeShcbiAgLy8gICBHRVRfQ0hBUkFDVEVSLFxuICAvLyAgIHsgdmFyaWFibGVzOiB7IGlkOiAyIH0gfVxuICAvLyApO1xuXG4gIGNvbnN0IGhhbmRsZUNoYW5nZURhdGUgPSAoZGF0ZSkgPT4ge1xuICAgIHNldFN0YXJ0RGF0ZShkYXRlWzBdKTtcbiAgICBzZXRFbmREYXRlKGRhdGVbMV0pO1xuICB9O1xuXG4gIC8vID8gQXV0byByZWRpcmVjdCB0byBwcmV2aW91cyBwYWdlIGFmdGVyIGxvZ2luXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKENvb2tpZXMuZ2V0KFwicmVkaXJlY3RfdXJpXCIpKSB7XG4gICAgICBjb25zdCB1cmkgPSBDb29raWVzLmdldChcInJlZGlyZWN0X3VyaVwiKTtcbiAgICAgIENvb2tpZXMucmVtb3ZlKFwicmVkaXJlY3RfdXJpXCIpO1xuICAgICAgbmF2aWdhdGUodXJpKTtcbiAgICB9XG5cbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lXG4gIH0sIFtdKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXY+XG4gICAgICA8U3BpbiBzcGlubmluZz17bG9hZGluZ30gc2l6ZT1cImxhcmdlXCI+XG4gICAgICAgIDxTdGlja3lIZWFkZXIgdGl0bGU9e3QoXCJ0aXRsZVwiKX0+XG4gICAgICAgICAgPFJhbmdlUGlja2VyXG4gICAgICAgICAgICBwbGFjZW1lbnQ9XCJib3R0b21SaWdodFwiXG4gICAgICAgICAgICBwcmVzZXRzPXtbXG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBsYWJlbDogXCJMYXN0IDcgZGF5c1wiLFxuICAgICAgICAgICAgICAgIHZhbHVlOiBbZGF5anMoKS5hZGQoLTcsIFwiZGF5c1wiKSwgZGF5anMoKV0sXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBsYWJlbDogXCJMYXN0IDMwIGRheXNcIixcbiAgICAgICAgICAgICAgICB2YWx1ZTogW2RheWpzKCkuYWRkKC0zMCwgXCJkYXlzXCIpLCBkYXlqcygpXSxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIF19XG4gICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlRGF0ZX1cbiAgICAgICAgICAgIHZhbHVlPXtbc3RhcnREYXRlLCBlbmREYXRlXX1cbiAgICAgICAgICAgIGZvcm1hdD17XCJERC9NTS9ZWVlZXCJ9XG4gICAgICAgICAgICBhbGxvd0NsZWFyPXtmYWxzZX1cbiAgICAgICAgICAvPlxuXG4gICAgICAgICAgPEJ1dHRvbiBpY29uPXs8RG93bmxvYWRPdXRsaW5lZCAvPn0gc2l6ZT1cIm1pZGRsZVwiIHRpdGxlPVwiRXhwb3J0XCIgLz5cbiAgICAgICAgPC9TdGlja3lIZWFkZXI+XG5cbiAgICAgICAgPGRpdiBzdHlsZT17eyBwYWRkaW5nOiAzMiB9fT5cbiAgICAgICAgICA8VGFibGVcbiAgICAgICAgICAgIGxvYWRpbmc9e2xvYWRpbmd9XG4gICAgICAgICAgICBjb2x1bW5zPXtjaGFyYWN0ZXJzQ29sdW1uKCl9XG4gICAgICAgICAgICBkYXRhU291cmNlPXtkYXRhPy5jaGFyYWN0ZXJzPy5yZXN1bHRzID8/IFtdfVxuICAgICAgICAgICAgc2Nyb2xsPXt7IHg6IDEwMDAgfX1cbiAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvU3Bpbj5cblxuICAgICAgPENhbiBJPVwiY3JlYXRlXCIgYT1cImRhc2hib2FyZFwiPlxuICAgICAgICA8RmxvYXRCdXR0b25cbiAgICAgICAgICBzaGFwZT1cInNxdWFyZVwiXG4gICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxuICAgICAgICAgIHRvb2x0aXA9XCJBZGQgbmV3IGNoYXJhY3RlclwiXG4gICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IDU2LCBoZWlnaHQ6IDU2IH19XG4gICAgICAgICAgaWNvbj17PFBsdXNPdXRsaW5lZCAvPn1cbiAgICAgICAgLz5cbiAgICAgIDwvQ2FuPlxuICAgIDwvZGl2PlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgRGFzaGJvYXJkO1xuIl0sImZpbGUiOiIvaG9tZS9kaGFybWEvV29yay9yZWFjdC1ib2lsZXJwbGF0ZS9zcmMvcGFnZXMvZGFzaGJvYXJkL0Rhc2hib2FyZC5qc3gifQ==