import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f9dec5ba"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/dharma/Work/react-boilerplate/src/App.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useDetectAdBlock } from "/node_modules/.vite/deps/adblock-detect-react.js?v=97fd0e7c";
import { ConfigProvider, message, notification, theme } from "/node_modules/.vite/deps/antd.js?v=26d7e361";
import __vite__cjsImport5_antd_lib_alert_ErrorBoundary from "/node_modules/.vite/deps/antd_lib_alert_ErrorBoundary.js?v=dd291a61"; const ErrorBoundary = __vite__cjsImport5_antd_lib_alert_ErrorBoundary.__esModule ? __vite__cjsImport5_antd_lib_alert_ErrorBoundary.default : __vite__cjsImport5_antd_lib_alert_ErrorBoundary;
import __vite__cjsImport6_dayjs from "/node_modules/.vite/deps/dayjs.js?v=ccea1070"; const dayjs = __vite__cjsImport6_dayjs.__esModule ? __vite__cjsImport6_dayjs.default : __vite__cjsImport6_dayjs;
import Cookies from "/node_modules/.vite/deps/js-cookie.js?v=ea88deea";
import __vite__cjsImport8_react from "/node_modules/.vite/deps/react.js?v=f9dec5ba"; const React = __vite__cjsImport8_react.__esModule ? __vite__cjsImport8_react.default : __vite__cjsImport8_react; const useEffect = __vite__cjsImport8_react["useEffect"]; const useState = __vite__cjsImport8_react["useState"];
import { useDispatch, useSelector } from "/node_modules/.vite/deps/react-redux.js?v=3db4bc54";
import { Route, BrowserRouter as Router, Routes } from "/node_modules/.vite/deps/react-router-dom.js?v=f16f2ff9";
import { CookiesIcon } from "/src/assets/svg/cookiesSvg.jsx";
import LaravelEchoClient from "/src/components/LaravelEchoClient.jsx";
import { cookiesButton, cookiesMessage } from "/src/constant/cookiesNotification.jsx";
import { unauthenticatedPageList } from "/src/constant/pageList.jsx";
import { themeColor } from "/src/constant/themeColor.jsx";
import { AbilityContext } from "/src/context/AbilityContext.jsx";
import DataContext from "/src/context/DataContext.jsx";
import AppLayout from "/src/layouts/AppLayout.jsx";
import NotFound from "/src/pages/notFound/NotFound.jsx";
import { refreshToken } from "/src/redux/actions/authAction.jsx";
import AuthenticatedRouter from "/src/routes/AuthenticatedRouter.jsx";
import UnauthenticatedRouter from "/src/routes/UnauthenticatedRouter.jsx";
import { accountAbility } from "/src/utils/ability.jsx";
import { notificationPermission } from "/src/utils/permissions.jsx";
function App() {
  _s();
  const {
    auth,
    app
  } = useSelector((state2) => state2);
  const dispatch = useDispatch();
  const [messageApi, messageHolder] = message.useMessage();
  const [notificationApi, notificationHolder] = notification.useNotification();
  const [alertApi, setAlertApi] = useState({
    open: false,
    type: "",
    // success, info, warning, error
    message: ""
  });
  const showMessage = ({
    type,
    content
  }) => {
    messageApi.open({
      type,
      // error, info, loading, success, warning
      content
    });
  };
  const showNotification = ({
    type,
    message: message2,
    description,
    ...props
  }) => {
    notificationApi[type]({
      message: message2,
      description,
      ...props
    });
  };
  const handleCloseAlert = () => {
    setAlertApi({
      open: false,
      type: "",
      // success, info, warning, error
      message: ""
    });
  };
  const adBlockDetected = useDetectAdBlock();
  const state = {
    showMessage,
    showNotification,
    setAlertApi
  };
  useEffect(() => {
    if (adBlockDetected) {
      showNotification({
        type: "warning",
        message: "AdBlock Detected",
        description: "Please disable your adblocker to use this website",
        placement: "bottomLeft",
        duration: 0
      });
    }
    if (Cookies.get("allow_cookies") === void 0) {
      const key = dayjs().unix();
      showNotification({
        key,
        type: "info",
        icon: /* @__PURE__ */ jsxDEV(CookiesIcon, {}, void 0, false, {
          fileName: "/home/dharma/Work/react-boilerplate/src/App.jsx",
          lineNumber: 99,
          columnNumber: 15
        }, this),
        message: "Cookies Settings",
        description: cookiesMessage(),
        placement: "bottomLeft",
        onClose: () => Cookies.set("allow_cookies", true),
        btn: cookiesButton(notificationApi, key),
        duration: 0
      });
    }
  }, []);
  useEffect(() => {
    notificationPermission();
  }, []);
  useEffect(() => {
    if (!auth.token) {
      dispatch(refreshToken());
    }
  }, [dispatch, auth.token]);
  return /* @__PURE__ */ jsxDEV(Router, { children: /* @__PURE__ */ jsxDEV(ErrorBoundary, { children: /* @__PURE__ */ jsxDEV(DataContext.Provider, { value: {
    ...state
  }, children: /* @__PURE__ */ jsxDEV(AbilityContext.Provider, { value: accountAbility(), children: /* @__PURE__ */ jsxDEV(ConfigProvider, { theme: {
    ...themeColor,
    algorithm: app.darkMode ? theme.darkAlgorithm : theme.defaultAlgorithm
  }, children: [
    auth.accessToken && /* @__PURE__ */ jsxDEV(LaravelEchoClient, {}, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/App.jsx",
      lineNumber: 133,
      columnNumber: 36
    }, this),
    /* @__PURE__ */ jsxDEV(AppLayout, { alertApi, handleCloseAlert, messageHolder, notificationHolder, children: /* @__PURE__ */ jsxDEV(Routes, { children: [
      /* @__PURE__ */ jsxDEV(Route, { path: "/", element: /* @__PURE__ */ jsxDEV(UnauthenticatedRouter, {}, void 0, false, {
        fileName: "/home/dharma/Work/react-boilerplate/src/App.jsx",
        lineNumber: 137,
        columnNumber: 44
      }, this), children: unauthenticatedPageList.map((item) => /* @__PURE__ */ jsxDEV(Route, { path: item.path, element: item.element }, item.key, false, {
        fileName: "/home/dharma/Work/react-boilerplate/src/App.jsx",
        lineNumber: 138,
        columnNumber: 58
      }, this)) }, void 0, false, {
        fileName: "/home/dharma/Work/react-boilerplate/src/App.jsx",
        lineNumber: 137,
        columnNumber: 19
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "/", element: /* @__PURE__ */ jsxDEV(AuthenticatedRouter, {}, void 0, false, {
        fileName: "/home/dharma/Work/react-boilerplate/src/App.jsx",
        lineNumber: 141,
        columnNumber: 44
      }, this), children: [
        app.page.list.map((item) => /* @__PURE__ */ jsxDEV(Route, { path: item.path, element: /* @__PURE__ */ jsxDEV("div", { style: {
          width: "100%"
        }, children: item.element }, void 0, false, {
          fileName: "/home/dharma/Work/react-boilerplate/src/App.jsx",
          lineNumber: 143,
          columnNumber: 96
        }, this) }, item.key, false, {
          fileName: "/home/dharma/Work/react-boilerplate/src/App.jsx",
          lineNumber: 143,
          columnNumber: 48
        }, this)),
        /* @__PURE__ */ jsxDEV(Route, { path: "*", element: /* @__PURE__ */ jsxDEV(NotFound, {}, void 0, false, {
          fileName: "/home/dharma/Work/react-boilerplate/src/App.jsx",
          lineNumber: 147,
          columnNumber: 46
        }, this) }, void 0, false, {
          fileName: "/home/dharma/Work/react-boilerplate/src/App.jsx",
          lineNumber: 147,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/home/dharma/Work/react-boilerplate/src/App.jsx",
        lineNumber: 141,
        columnNumber: 19
      }, this)
    ] }, void 0, true, {
      fileName: "/home/dharma/Work/react-boilerplate/src/App.jsx",
      lineNumber: 136,
      columnNumber: 17
    }, this) }, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/App.jsx",
      lineNumber: 135,
      columnNumber: 15
    }, this)
  ] }, void 0, true, {
    fileName: "/home/dharma/Work/react-boilerplate/src/App.jsx",
    lineNumber: 129,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/App.jsx",
    lineNumber: 128,
    columnNumber: 11
  }, this) }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/App.jsx",
    lineNumber: 125,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/App.jsx",
    lineNumber: 124,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/App.jsx",
    lineNumber: 123,
    columnNumber: 10
  }, this);
}
_s(App, "lh1BSaTuj8M4htfM/oh2BuD4n24=", false, function() {
  return [useSelector, useDispatch, message.useMessage, notification.useNotification, useDetectAdBlock];
});
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/dharma/Work/react-boilerplate/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUZjOzs7Ozs7Ozs7Ozs7Ozs7OztBQXZGZCxTQUFTQSx3QkFBd0I7QUFDakMsU0FBU0MsZ0JBQWdCQyxTQUFTQyxjQUFjQyxhQUFhO0FBQzdELE9BQU9DLG1CQUFtQjtBQUMxQixPQUFPQyxXQUFXO0FBQ2xCLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsU0FBU0MsV0FBV0MsZ0JBQWdCO0FBQzNDLFNBQVNDLGFBQWFDLG1CQUFtQjtBQUN6QyxTQUFTQyxPQUFPQyxpQkFBaUJDLFFBQVFDLGNBQWM7QUFDdkQsU0FBU0MsbUJBQW1CO0FBQzVCLE9BQU9DLHVCQUF1QjtBQUM5QixTQUFTQyxlQUFlQyxzQkFBc0I7QUFDOUMsU0FBU0MsK0JBQStCO0FBQ3hDLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxzQkFBc0I7QUFDL0IsT0FBT0MsaUJBQWlCO0FBQ3hCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsY0FBYztBQUNyQixTQUFTQyxvQkFBb0I7QUFDN0IsT0FBT0MseUJBQXlCO0FBQ2hDLE9BQU9DLDJCQUEyQjtBQUNsQyxTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0MsOEJBQThCO0FBRXZDLFNBQVNDLE1BQU07QUFBQUMsS0FBQTtBQUNiLFFBQU07QUFBQSxJQUFFQztBQUFBQSxJQUFNQztBQUFBQSxFQUFJLElBQUl2QixZQUFhd0IsWUFBVUEsTUFBSztBQUNsRCxRQUFNQyxXQUFXMUIsWUFBWTtBQUM3QixRQUFNLENBQUMyQixZQUFZQyxhQUFhLElBQUlyQyxRQUFRc0MsV0FBVztBQUN2RCxRQUFNLENBQUNDLGlCQUFpQkMsa0JBQWtCLElBQUl2QyxhQUFhd0MsZ0JBQWdCO0FBQzNFLFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJbkMsU0FBUztBQUFBLElBQ3ZDb0MsTUFBTTtBQUFBLElBQ05DLE1BQU07QUFBQTtBQUFBLElBQ043QyxTQUFTO0FBQUEsRUFDWCxDQUFDO0FBR0QsUUFBTThDLGNBQWNBLENBQUM7QUFBQSxJQUFFRDtBQUFBQSxJQUFNRTtBQUFBQSxFQUFRLE1BQU07QUFDekNYLGVBQVdRLEtBQUs7QUFBQSxNQUNkQztBQUFBQTtBQUFBQSxNQUNBRTtBQUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBR0EsUUFBTUMsbUJBQW1CQSxDQUFDO0FBQUEsSUFBRUg7QUFBQUEsSUFBTTdDO0FBQUFBLElBQVNpRDtBQUFBQSxJQUFhLEdBQUdDO0FBQUFBLEVBQU0sTUFBTTtBQUVyRVgsb0JBQWdCTSxJQUFJLEVBQUU7QUFBQSxNQUNwQjdDO0FBQUFBLE1BQ0FpRDtBQUFBQSxNQUNBLEdBQUdDO0FBQUFBLElBQ0wsQ0FBQztBQUFBLEVBQ0g7QUFFQSxRQUFNQyxtQkFBbUJBLE1BQU07QUFDN0JSLGdCQUFZO0FBQUEsTUFDVkMsTUFBTTtBQUFBLE1BQ05DLE1BQU07QUFBQTtBQUFBLE1BQ043QyxTQUFTO0FBQUEsSUFDWCxDQUFDO0FBQUEsRUFDSDtBQUdBLFFBQU1vRCxrQkFBa0J0RCxpQkFBaUI7QUFFekMsUUFBTW9DLFFBQVE7QUFBQSxJQUNaWTtBQUFBQSxJQUNBRTtBQUFBQSxJQUNBTDtBQUFBQSxFQUNGO0FBR0FwQyxZQUFVLE1BQU07QUFDZCxRQUFJNkMsaUJBQWlCO0FBQ25CSix1QkFBaUI7QUFBQSxRQUNmSCxNQUFNO0FBQUEsUUFDTjdDLFNBQVM7QUFBQSxRQUNUaUQsYUFBYTtBQUFBLFFBQ2JJLFdBQVc7QUFBQSxRQUNYQyxVQUFVO0FBQUEsTUFDWixDQUFDO0FBQUEsSUFDSDtBQUVBLFFBQUlqRCxRQUFRa0QsSUFBSSxlQUFlLE1BQU1DLFFBQVc7QUFDOUMsWUFBTUMsTUFBTXJELE1BQU0sRUFBRXNELEtBQUs7QUFFekJWLHVCQUFpQjtBQUFBLFFBQ2ZTO0FBQUFBLFFBQ0FaLE1BQU07QUFBQSxRQUNOYyxNQUFNLHVCQUFDLGlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBWTtBQUFBLFFBQ2xCM0QsU0FBUztBQUFBLFFBQ1RpRCxhQUFhL0IsZUFBZTtBQUFBLFFBQzVCbUMsV0FBVztBQUFBLFFBQ1hPLFNBQVNBLE1BQU12RCxRQUFRd0QsSUFBSSxpQkFBaUIsSUFBSTtBQUFBLFFBQ2hEQyxLQUFLN0MsY0FBY3NCLGlCQUFpQmtCLEdBQUc7QUFBQSxRQUN2Q0gsVUFBVTtBQUFBLE1BQ1osQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUdGLEdBQUcsRUFBRTtBQUdML0MsWUFBVSxNQUFNO0FBQ2RzQiwyQkFBdUI7QUFBQSxFQUN6QixHQUFHLEVBQUU7QUFHTHRCLFlBQVUsTUFBTTtBQUNkLFFBQUksQ0FBQ3lCLEtBQUsrQixPQUFPO0FBQ2Y1QixlQUFTVixhQUFhLENBQUM7QUFBQSxJQUN6QjtBQUFBLEVBQ0YsR0FBRyxDQUFDVSxVQUFVSCxLQUFLK0IsS0FBSyxDQUFDO0FBRXpCLFNBQ0UsdUJBQUMsVUFDQyxpQ0FBQyxpQkFDQyxpQ0FBQyxZQUFZLFVBQVosRUFBcUIsT0FBTztBQUFBLElBQUUsR0FBRzdCO0FBQUFBLEVBQU0sR0FDdEMsaUNBQUMsZUFBZSxVQUFmLEVBQXdCLE9BQU9OLGVBQWUsR0FDN0MsaUNBQUMsa0JBQ0MsT0FBTztBQUFBLElBQ0wsR0FBR1I7QUFBQUEsSUFDSDRDLFdBQVcvQixJQUFJZ0MsV0FDWC9ELE1BQU1nRSxnQkFDTmhFLE1BQU1pRTtBQUFBQSxFQUNaLEdBRUNuQztBQUFBQSxTQUFLb0MsZUFBZSx1QkFBQyx1QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWtCO0FBQUEsSUFFdkMsdUJBQUMsYUFDQyxVQUNBLGtCQUNBLGVBQ0Esb0JBRUEsaUNBQUMsVUFDQztBQUFBLDZCQUFDLFNBQU0sTUFBSyxLQUFJLFNBQVMsdUJBQUMsMkJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzQixHQUM1Q2pELGtDQUF3QmtELElBQUtDLFVBQzVCLHVCQUFDLFNBRUMsTUFBTUEsS0FBS0MsTUFDWCxTQUFTRCxLQUFLRSxXQUZURixLQUFLYixLQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHd0IsQ0FFekIsS0FQSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxNQUVBLHVCQUFDLFNBQU0sTUFBSyxLQUFJLFNBQVMsdUJBQUMseUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvQixHQUUxQ3hCO0FBQUFBLFlBQUl3QyxLQUFLQyxLQUFLTCxJQUFLQyxVQUNsQix1QkFBQyxTQUVDLE1BQU1BLEtBQUtDLE1BQ1gsU0FDRSx1QkFBQyxTQUFJLE9BQU87QUFBQSxVQUFFSSxPQUFPO0FBQUEsUUFBTyxHQUFJTCxlQUFLRSxXQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZDLEtBSDFDRixLQUFLYixLQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLRyxDQUVKO0FBQUEsUUFFRCx1QkFBQyxTQUFNLE1BQUssS0FBSSxTQUFTLHVCQUFDLGNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFTLEtBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0M7QUFBQSxXQVp4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBYUE7QUFBQSxTQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBeUJBLEtBL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnQ0E7QUFBQSxPQTFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMkNBLEtBNUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E2Q0EsS0E5Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQStDQSxLQWhERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBaURBLEtBbERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtREE7QUFFSjtBQUFDMUIsR0EvSVFELEtBQUc7QUFBQSxVQUNZcEIsYUFDTEQsYUFDbUJULFFBQVFzQyxZQUNFckMsYUFBYXdDLGlCQWtDbkMzQyxnQkFBZ0I7QUFBQTtBQUFBOEUsS0F0Q2pDOUM7QUFpSlQsZUFBZUE7QUFBSSxJQUFBOEM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZURldGVjdEFkQmxvY2siLCJDb25maWdQcm92aWRlciIsIm1lc3NhZ2UiLCJub3RpZmljYXRpb24iLCJ0aGVtZSIsIkVycm9yQm91bmRhcnkiLCJkYXlqcyIsIkNvb2tpZXMiLCJSZWFjdCIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwidXNlRGlzcGF0Y2giLCJ1c2VTZWxlY3RvciIsIlJvdXRlIiwiQnJvd3NlclJvdXRlciIsIlJvdXRlciIsIlJvdXRlcyIsIkNvb2tpZXNJY29uIiwiTGFyYXZlbEVjaG9DbGllbnQiLCJjb29raWVzQnV0dG9uIiwiY29va2llc01lc3NhZ2UiLCJ1bmF1dGhlbnRpY2F0ZWRQYWdlTGlzdCIsInRoZW1lQ29sb3IiLCJBYmlsaXR5Q29udGV4dCIsIkRhdGFDb250ZXh0IiwiQXBwTGF5b3V0IiwiTm90Rm91bmQiLCJyZWZyZXNoVG9rZW4iLCJBdXRoZW50aWNhdGVkUm91dGVyIiwiVW5hdXRoZW50aWNhdGVkUm91dGVyIiwiYWNjb3VudEFiaWxpdHkiLCJub3RpZmljYXRpb25QZXJtaXNzaW9uIiwiQXBwIiwiX3MiLCJhdXRoIiwiYXBwIiwic3RhdGUiLCJkaXNwYXRjaCIsIm1lc3NhZ2VBcGkiLCJtZXNzYWdlSG9sZGVyIiwidXNlTWVzc2FnZSIsIm5vdGlmaWNhdGlvbkFwaSIsIm5vdGlmaWNhdGlvbkhvbGRlciIsInVzZU5vdGlmaWNhdGlvbiIsImFsZXJ0QXBpIiwic2V0QWxlcnRBcGkiLCJvcGVuIiwidHlwZSIsInNob3dNZXNzYWdlIiwiY29udGVudCIsInNob3dOb3RpZmljYXRpb24iLCJkZXNjcmlwdGlvbiIsInByb3BzIiwiaGFuZGxlQ2xvc2VBbGVydCIsImFkQmxvY2tEZXRlY3RlZCIsInBsYWNlbWVudCIsImR1cmF0aW9uIiwiZ2V0IiwidW5kZWZpbmVkIiwia2V5IiwidW5peCIsImljb24iLCJvbkNsb3NlIiwic2V0IiwiYnRuIiwidG9rZW4iLCJhbGdvcml0aG0iLCJkYXJrTW9kZSIsImRhcmtBbGdvcml0aG0iLCJkZWZhdWx0QWxnb3JpdGhtIiwiYWNjZXNzVG9rZW4iLCJtYXAiLCJpdGVtIiwicGF0aCIsImVsZW1lbnQiLCJwYWdlIiwibGlzdCIsIndpZHRoIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBcHAuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZURldGVjdEFkQmxvY2sgfSBmcm9tIFwiYWRibG9jay1kZXRlY3QtcmVhY3RcIjtcbmltcG9ydCB7IENvbmZpZ1Byb3ZpZGVyLCBtZXNzYWdlLCBub3RpZmljYXRpb24sIHRoZW1lIH0gZnJvbSBcImFudGRcIjtcbmltcG9ydCBFcnJvckJvdW5kYXJ5IGZyb20gXCJhbnRkL2xpYi9hbGVydC9FcnJvckJvdW5kYXJ5XCI7XG5pbXBvcnQgZGF5anMgZnJvbSBcImRheWpzXCI7XG5pbXBvcnQgQ29va2llcyBmcm9tIFwianMtY29va2llXCI7XG5pbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgdXNlRGlzcGF0Y2gsIHVzZVNlbGVjdG9yIH0gZnJvbSBcInJlYWN0LXJlZHV4XCI7XG5pbXBvcnQgeyBSb3V0ZSwgQnJvd3NlclJvdXRlciBhcyBSb3V0ZXIsIFJvdXRlcyB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XG5pbXBvcnQgeyBDb29raWVzSWNvbiB9IGZyb20gXCIuL2Fzc2V0cy9zdmcvY29va2llc1N2Z1wiO1xuaW1wb3J0IExhcmF2ZWxFY2hvQ2xpZW50IGZyb20gXCIuL2NvbXBvbmVudHMvTGFyYXZlbEVjaG9DbGllbnRcIjtcbmltcG9ydCB7IGNvb2tpZXNCdXR0b24sIGNvb2tpZXNNZXNzYWdlIH0gZnJvbSBcIi4vY29uc3RhbnQvY29va2llc05vdGlmaWNhdGlvblwiO1xuaW1wb3J0IHsgdW5hdXRoZW50aWNhdGVkUGFnZUxpc3QgfSBmcm9tIFwiLi9jb25zdGFudC9wYWdlTGlzdFwiO1xuaW1wb3J0IHsgdGhlbWVDb2xvciB9IGZyb20gXCIuL2NvbnN0YW50L3RoZW1lQ29sb3JcIjtcbmltcG9ydCB7IEFiaWxpdHlDb250ZXh0IH0gZnJvbSBcIi4vY29udGV4dC9BYmlsaXR5Q29udGV4dFwiO1xuaW1wb3J0IERhdGFDb250ZXh0IGZyb20gXCIuL2NvbnRleHQvRGF0YUNvbnRleHRcIjtcbmltcG9ydCBBcHBMYXlvdXQgZnJvbSBcIi4vbGF5b3V0cy9BcHBMYXlvdXRcIjtcbmltcG9ydCBOb3RGb3VuZCBmcm9tIFwiLi9wYWdlcy9ub3RGb3VuZC9Ob3RGb3VuZFwiO1xuaW1wb3J0IHsgcmVmcmVzaFRva2VuIH0gZnJvbSBcIi4vcmVkdXgvYWN0aW9ucy9hdXRoQWN0aW9uXCI7XG5pbXBvcnQgQXV0aGVudGljYXRlZFJvdXRlciBmcm9tIFwiLi9yb3V0ZXMvQXV0aGVudGljYXRlZFJvdXRlclwiO1xuaW1wb3J0IFVuYXV0aGVudGljYXRlZFJvdXRlciBmcm9tIFwiLi9yb3V0ZXMvVW5hdXRoZW50aWNhdGVkUm91dGVyXCI7XG5pbXBvcnQgeyBhY2NvdW50QWJpbGl0eSB9IGZyb20gXCIuL3V0aWxzL2FiaWxpdHlcIjtcbmltcG9ydCB7IG5vdGlmaWNhdGlvblBlcm1pc3Npb24gfSBmcm9tIFwiLi91dGlscy9wZXJtaXNzaW9uc1wiO1xuXG5mdW5jdGlvbiBBcHAoKSB7XG4gIGNvbnN0IHsgYXV0aCwgYXBwIH0gPSB1c2VTZWxlY3Rvcigoc3RhdGUpID0+IHN0YXRlKTtcbiAgY29uc3QgZGlzcGF0Y2ggPSB1c2VEaXNwYXRjaCgpO1xuICBjb25zdCBbbWVzc2FnZUFwaSwgbWVzc2FnZUhvbGRlcl0gPSBtZXNzYWdlLnVzZU1lc3NhZ2UoKTtcbiAgY29uc3QgW25vdGlmaWNhdGlvbkFwaSwgbm90aWZpY2F0aW9uSG9sZGVyXSA9IG5vdGlmaWNhdGlvbi51c2VOb3RpZmljYXRpb24oKTtcbiAgY29uc3QgW2FsZXJ0QXBpLCBzZXRBbGVydEFwaV0gPSB1c2VTdGF0ZSh7XG4gICAgb3BlbjogZmFsc2UsXG4gICAgdHlwZTogXCJcIiwgLy8gc3VjY2VzcywgaW5mbywgd2FybmluZywgZXJyb3JcbiAgICBtZXNzYWdlOiBcIlwiLFxuICB9KTtcblxuICAvLyA/IHNob3dNZXNzYWdlIHVzZWQgZm9yIHN1Y2Nlc3Mgb3Igc2ltcGxlIG1lc3NhZ2VcbiAgY29uc3Qgc2hvd01lc3NhZ2UgPSAoeyB0eXBlLCBjb250ZW50IH0pID0+IHtcbiAgICBtZXNzYWdlQXBpLm9wZW4oe1xuICAgICAgdHlwZSwgLy8gZXJyb3IsIGluZm8sIGxvYWRpbmcsIHN1Y2Nlc3MsIHdhcm5pbmdcbiAgICAgIGNvbnRlbnQsXG4gICAgfSk7XG4gIH07XG5cbiAgLy8gPyBzaG93Tm90aWZpY2F0aW9uIHVzZWQgZm9yIGVycm9yIG9yIGNvbXBsZXggbWVzc2FnZVxuICBjb25zdCBzaG93Tm90aWZpY2F0aW9uID0gKHsgdHlwZSwgbWVzc2FnZSwgZGVzY3JpcHRpb24sIC4uLnByb3BzIH0pID0+IHtcbiAgICAvLyBkZXN0cm95LCBlcnJvciwgaW5mbywgc3VjY2Vzcywgd2FybmluZ1xuICAgIG5vdGlmaWNhdGlvbkFwaVt0eXBlXSh7XG4gICAgICBtZXNzYWdlLFxuICAgICAgZGVzY3JpcHRpb24sXG4gICAgICAuLi5wcm9wcyxcbiAgICB9KTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVDbG9zZUFsZXJ0ID0gKCkgPT4ge1xuICAgIHNldEFsZXJ0QXBpKHtcbiAgICAgIG9wZW46IGZhbHNlLFxuICAgICAgdHlwZTogXCJcIiwgLy8gc3VjY2VzcywgaW5mbywgd2FybmluZywgZXJyb3JcbiAgICAgIG1lc3NhZ2U6IFwiXCIsXG4gICAgfSk7XG4gIH07XG5cbiAgLy8gPyBhZEJsb2NrRGV0ZWN0ZWQgdXNlZCBmb3IgZGV0ZWN0IGFkYmxvY2tlclxuICBjb25zdCBhZEJsb2NrRGV0ZWN0ZWQgPSB1c2VEZXRlY3RBZEJsb2NrKCk7XG5cbiAgY29uc3Qgc3RhdGUgPSB7XG4gICAgc2hvd01lc3NhZ2UsXG4gICAgc2hvd05vdGlmaWNhdGlvbixcbiAgICBzZXRBbGVydEFwaSxcbiAgfTtcblxuICAvLyogQWRCbG9jayBhbmQgQ29va2llcyBOb3RpZmljYXRpb25cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoYWRCbG9ja0RldGVjdGVkKSB7XG4gICAgICBzaG93Tm90aWZpY2F0aW9uKHtcbiAgICAgICAgdHlwZTogXCJ3YXJuaW5nXCIsXG4gICAgICAgIG1lc3NhZ2U6IFwiQWRCbG9jayBEZXRlY3RlZFwiLFxuICAgICAgICBkZXNjcmlwdGlvbjogXCJQbGVhc2UgZGlzYWJsZSB5b3VyIGFkYmxvY2tlciB0byB1c2UgdGhpcyB3ZWJzaXRlXCIsXG4gICAgICAgIHBsYWNlbWVudDogXCJib3R0b21MZWZ0XCIsXG4gICAgICAgIGR1cmF0aW9uOiAwLFxuICAgICAgfSk7XG4gICAgfVxuXG4gICAgaWYgKENvb2tpZXMuZ2V0KFwiYWxsb3dfY29va2llc1wiKSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICBjb25zdCBrZXkgPSBkYXlqcygpLnVuaXgoKTtcblxuICAgICAgc2hvd05vdGlmaWNhdGlvbih7XG4gICAgICAgIGtleSxcbiAgICAgICAgdHlwZTogXCJpbmZvXCIsXG4gICAgICAgIGljb246IDxDb29raWVzSWNvbiAvPixcbiAgICAgICAgbWVzc2FnZTogXCJDb29raWVzIFNldHRpbmdzXCIsXG4gICAgICAgIGRlc2NyaXB0aW9uOiBjb29raWVzTWVzc2FnZSgpLFxuICAgICAgICBwbGFjZW1lbnQ6IFwiYm90dG9tTGVmdFwiLFxuICAgICAgICBvbkNsb3NlOiAoKSA9PiBDb29raWVzLnNldChcImFsbG93X2Nvb2tpZXNcIiwgdHJ1ZSksXG4gICAgICAgIGJ0bjogY29va2llc0J1dHRvbihub3RpZmljYXRpb25BcGksIGtleSksXG4gICAgICAgIGR1cmF0aW9uOiAwLFxuICAgICAgfSk7XG4gICAgfVxuXG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZVxuICB9LCBbXSk7XG5cbiAgLy8qIEJyb3dzZXIgUGVybWlzc2lvblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIG5vdGlmaWNhdGlvblBlcm1pc3Npb24oKTtcbiAgfSwgW10pO1xuXG4gIC8vKiBHZXQgQWNjZXNzIFRva2VuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFhdXRoLnRva2VuKSB7XG4gICAgICBkaXNwYXRjaChyZWZyZXNoVG9rZW4oKSk7XG4gICAgfVxuICB9LCBbZGlzcGF0Y2gsIGF1dGgudG9rZW5dKTtcblxuICByZXR1cm4gKFxuICAgIDxSb3V0ZXI+XG4gICAgICA8RXJyb3JCb3VuZGFyeT5cbiAgICAgICAgPERhdGFDb250ZXh0LlByb3ZpZGVyIHZhbHVlPXt7IC4uLnN0YXRlIH19PlxuICAgICAgICAgIDxBYmlsaXR5Q29udGV4dC5Qcm92aWRlciB2YWx1ZT17YWNjb3VudEFiaWxpdHkoKX0+XG4gICAgICAgICAgICA8Q29uZmlnUHJvdmlkZXJcbiAgICAgICAgICAgICAgdGhlbWU9e3tcbiAgICAgICAgICAgICAgICAuLi50aGVtZUNvbG9yLFxuICAgICAgICAgICAgICAgIGFsZ29yaXRobTogYXBwLmRhcmtNb2RlXG4gICAgICAgICAgICAgICAgICA/IHRoZW1lLmRhcmtBbGdvcml0aG1cbiAgICAgICAgICAgICAgICAgIDogdGhlbWUuZGVmYXVsdEFsZ29yaXRobSxcbiAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge2F1dGguYWNjZXNzVG9rZW4gJiYgPExhcmF2ZWxFY2hvQ2xpZW50IC8+fVxuXG4gICAgICAgICAgICAgIDxBcHBMYXlvdXRcbiAgICAgICAgICAgICAgICBhbGVydEFwaT17YWxlcnRBcGl9XG4gICAgICAgICAgICAgICAgaGFuZGxlQ2xvc2VBbGVydD17aGFuZGxlQ2xvc2VBbGVydH1cbiAgICAgICAgICAgICAgICBtZXNzYWdlSG9sZGVyPXttZXNzYWdlSG9sZGVyfVxuICAgICAgICAgICAgICAgIG5vdGlmaWNhdGlvbkhvbGRlcj17bm90aWZpY2F0aW9uSG9sZGVyfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFJvdXRlcz5cbiAgICAgICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL1wiIGVsZW1lbnQ9ezxVbmF1dGhlbnRpY2F0ZWRSb3V0ZXIgLz59PlxuICAgICAgICAgICAgICAgICAgICB7dW5hdXRoZW50aWNhdGVkUGFnZUxpc3QubWFwKChpdGVtKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgPFJvdXRlXG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2l0ZW0ua2V5fVxuICAgICAgICAgICAgICAgICAgICAgICAgcGF0aD17aXRlbS5wYXRofVxuICAgICAgICAgICAgICAgICAgICAgICAgZWxlbWVudD17aXRlbS5lbGVtZW50fVxuICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgPC9Sb3V0ZT5cblxuICAgICAgICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIvXCIgZWxlbWVudD17PEF1dGhlbnRpY2F0ZWRSb3V0ZXIgLz59PlxuICAgICAgICAgICAgICAgICAgICB7LyogPyBEb2N1bWVudGF0aW9uIGluIHNyYy91dGlscy9wYWdlcy5qcyAqL31cbiAgICAgICAgICAgICAgICAgICAge2FwcC5wYWdlLmxpc3QubWFwKChpdGVtKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgPFJvdXRlXG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2l0ZW0ua2V5fVxuICAgICAgICAgICAgICAgICAgICAgICAgcGF0aD17aXRlbS5wYXRofVxuICAgICAgICAgICAgICAgICAgICAgICAgZWxlbWVudD17XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgd2lkdGg6IFwiMTAwJVwiIH19PntpdGVtLmVsZW1lbnR9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgKSl9XG5cbiAgICAgICAgICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIqXCIgZWxlbWVudD17PE5vdEZvdW5kIC8+fSAvPlxuICAgICAgICAgICAgICAgICAgPC9Sb3V0ZT5cbiAgICAgICAgICAgICAgICA8L1JvdXRlcz5cbiAgICAgICAgICAgICAgPC9BcHBMYXlvdXQ+XG4gICAgICAgICAgICA8L0NvbmZpZ1Byb3ZpZGVyPlxuICAgICAgICAgIDwvQWJpbGl0eUNvbnRleHQuUHJvdmlkZXI+XG4gICAgICAgIDwvRGF0YUNvbnRleHQuUHJvdmlkZXI+XG4gICAgICA8L0Vycm9yQm91bmRhcnk+XG4gICAgPC9Sb3V0ZXI+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IEFwcDtcbiJdLCJmaWxlIjoiL2hvbWUvZGhhcm1hL1dvcmsvcmVhY3QtYm9pbGVycGxhdGUvc3JjL0FwcC5qc3gifQ==