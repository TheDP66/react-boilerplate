import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f9dec5ba"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { ArrowUpOutlined, InfoCircleOutlined, PlusOutlined, QuestionOutlined } from "/node_modules/.vite/deps/@ant-design_icons.js?v=7a8c6384";
import { Avatar, Button, Tag } from "/node_modules/.vite/deps/antd.js?v=26d7e361";
import { accountAbility } from "/src/utils/ability.jsx";
const statusOptions = [{
  text: "Alive",
  value: "Alive"
}, {
  text: "Dead",
  value: "Dead"
}, {
  text: "unknown",
  value: "unknown"
}];
const speciesOptions = [{
  text: "Human",
  value: "Human"
}, {
  text: "Alien",
  value: "Alien"
}];
const genderOptions = [{
  text: "Male",
  value: "Male"
}, {
  text: "Female",
  value: "Female"
}, {
  text: "unknown",
  value: "unknown"
}];
export const charactersColumn = () => [{
  title: "ID",
  dataIndex: "id",
  key: "id",
  width: "14px"
}, {
  title: "Name",
  key: "name",
  sorter: (a, b) => a.name.localeCompare(b.name),
  render: (_, record) => /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV(Avatar, { src: record.image, alt: record.name, style: {
      marginRight: "8px"
    } }, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/constant/columns/characters.jsx",
      lineNumber: 41,
      columnNumber: 11
    }, this),
    " ",
    record.name
  ] }, void 0, true, {
    fileName: "/home/dharma/Work/react-boilerplate/src/constant/columns/characters.jsx",
    lineNumber: 40,
    columnNumber: 26
  }, this)
}, {
  title: "Species",
  dataIndex: "species",
  key: "species",
  filters: speciesOptions,
  onFilter: (value, record) => record.species.indexOf(value) === 0
}, {
  title: "Gender",
  key: "gender",
  filters: genderOptions,
  onFilter: (value, record) => record.gender.indexOf(value) === 0,
  render: (_, record) => /* @__PURE__ */ jsxDEV(Tag, { icon: record.gender === "Male" ? /* @__PURE__ */ jsxDEV(ArrowUpOutlined, { rotate: 45 }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/constant/columns/characters.jsx",
    lineNumber: 57,
    columnNumber: 64
  }, this) : record.gender === "Female" ? /* @__PURE__ */ jsxDEV(PlusOutlined, {}, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/constant/columns/characters.jsx",
    lineNumber: 57,
    columnNumber: 127
  }, this) : /* @__PURE__ */ jsxDEV(QuestionOutlined, {}, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/constant/columns/characters.jsx",
    lineNumber: 57,
    columnNumber: 146
  }, this), color: record.gender === "Male" ? "blue" : record.gender === "Female" ? "pink" : "orange", children: record.gender }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/constant/columns/characters.jsx",
    lineNumber: 57,
    columnNumber: 26
  }, this)
}, {
  title: "Status",
  key: "status",
  filters: statusOptions,
  onFilter: (value, record) => record.status.indexOf(value) === 0,
  render: (_, record) => /* @__PURE__ */ jsxDEV(Tag, { color: record.status === "Alive" ? "green" : record.status === "Dead" ? "red" : "orange", children: record.status }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/constant/columns/characters.jsx",
    lineNumber: 65,
    columnNumber: 26
  }, this)
}, {
  title: "Action",
  key: "action",
  render: () => /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV(Button, { type: "text", size: "large", icon: /* @__PURE__ */ jsxDEV(InfoCircleOutlined, {}, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/constant/columns/characters.jsx",
    lineNumber: 72,
    columnNumber: 50
  }, this) }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/constant/columns/characters.jsx",
    lineNumber: 72,
    columnNumber: 11
  }, this) }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/constant/columns/characters.jsx",
    lineNumber: 71,
    columnNumber: 17
  }, this),
  hidden: accountAbility().can("update", "dashboard") ? false : true
}].filter((item) => !item.hidden);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0VVLFNBbUVGLFVBbkVFO0FBaEVWLFNBQ0VBLGlCQUNBQyxvQkFDQUMsY0FDQUMsd0JBQ0s7QUFDUCxTQUFTQyxRQUFRQyxRQUFRQyxXQUFXO0FBQ3BDLFNBQVNDLHNCQUFzQjtBQUUvQixNQUFNQyxnQkFBZ0IsQ0FDcEI7QUFBQSxFQUNFQyxNQUFNO0FBQUEsRUFDTkMsT0FBTztBQUNULEdBQ0E7QUFBQSxFQUNFRCxNQUFNO0FBQUEsRUFDTkMsT0FBTztBQUNULEdBQ0E7QUFBQSxFQUNFRCxNQUFNO0FBQUEsRUFDTkMsT0FBTztBQUNULENBQUM7QUFHSCxNQUFNQyxpQkFBaUIsQ0FDckI7QUFBQSxFQUNFRixNQUFNO0FBQUEsRUFDTkMsT0FBTztBQUNULEdBQ0E7QUFBQSxFQUNFRCxNQUFNO0FBQUEsRUFDTkMsT0FBTztBQUNULENBQUM7QUFHSCxNQUFNRSxnQkFBZ0IsQ0FDcEI7QUFBQSxFQUNFSCxNQUFNO0FBQUEsRUFDTkMsT0FBTztBQUNULEdBQ0E7QUFBQSxFQUNFRCxNQUFNO0FBQUEsRUFDTkMsT0FBTztBQUNULEdBQ0E7QUFBQSxFQUNFRCxNQUFNO0FBQUEsRUFDTkMsT0FBTztBQUNULENBQUM7QUFHSSxhQUFNRyxtQkFBbUJBLE1BQzlCLENBQ0U7QUFBQSxFQUNFQyxPQUFPO0FBQUEsRUFDUEMsV0FBVztBQUFBLEVBQ1hDLEtBQUs7QUFBQSxFQUNMQyxPQUFPO0FBQ1QsR0FDQTtBQUFBLEVBQ0VILE9BQU87QUFBQSxFQUNQRSxLQUFLO0FBQUEsRUFDTEUsUUFBUUEsQ0FBQ0MsR0FBR0MsTUFBTUQsRUFBRUUsS0FBS0MsY0FBY0YsRUFBRUMsSUFBSTtBQUFBLEVBQzdDRSxRQUFRQSxDQUFDQyxHQUFHQyxXQUNWLHVCQUFDLFNBQ0M7QUFBQSwyQkFBQyxVQUNDLEtBQUtBLE9BQU9DLE9BQ1osS0FBS0QsT0FBT0osTUFDWixPQUFPO0FBQUEsTUFBRU0sYUFBYTtBQUFBLElBQU0sS0FIOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdnQztBQUFBLElBQzdCO0FBQUEsSUFDRkYsT0FBT0o7QUFBQUEsT0FOVjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBT0E7QUFFSixHQUNBO0FBQUEsRUFDRVAsT0FBTztBQUFBLEVBQ1BDLFdBQVc7QUFBQSxFQUNYQyxLQUFLO0FBQUEsRUFDTFksU0FBU2pCO0FBQUFBLEVBQ1RrQixVQUFVQSxDQUFDbkIsT0FBT2UsV0FBV0EsT0FBT0ssUUFBUUMsUUFBUXJCLEtBQUssTUFBTTtBQUNqRSxHQUNBO0FBQUEsRUFDRUksT0FBTztBQUFBLEVBQ1BFLEtBQUs7QUFBQSxFQUNMWSxTQUFTaEI7QUFBQUEsRUFDVGlCLFVBQVVBLENBQUNuQixPQUFPZSxXQUFXQSxPQUFPTyxPQUFPRCxRQUFRckIsS0FBSyxNQUFNO0FBQUEsRUFDOURhLFFBQVFBLENBQUNDLEdBQUdDLFdBQ1YsdUJBQUMsT0FDQyxNQUNFQSxPQUFPTyxXQUFXLFNBQ2hCLHVCQUFDLG1CQUFnQixRQUFRLE1BQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBNEIsSUFDMUJQLE9BQU9PLFdBQVcsV0FDcEIsdUJBQUMsa0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFhLElBRWIsdUJBQUMsc0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFpQixHQUdyQixPQUNFUCxPQUFPTyxXQUFXLFNBQ2QsU0FDQVAsT0FBT08sV0FBVyxXQUNsQixTQUNBLFVBR0xQLGlCQUFPTyxVQWxCVjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBbUJBO0FBRUosR0FDQTtBQUFBLEVBQ0VsQixPQUFPO0FBQUEsRUFDUEUsS0FBSztBQUFBLEVBQ0xZLFNBQVNwQjtBQUFBQSxFQUNUcUIsVUFBVUEsQ0FBQ25CLE9BQU9lLFdBQVdBLE9BQU9RLE9BQU9GLFFBQVFyQixLQUFLLE1BQU07QUFBQSxFQUM5RGEsUUFBUUEsQ0FBQ0MsR0FBR0MsV0FDVix1QkFBQyxPQUNDLE9BQ0VBLE9BQU9RLFdBQVcsVUFDZCxVQUNBUixPQUFPUSxXQUFXLFNBQ2xCLFFBQ0EsVUFHTFIsaUJBQU9RLFVBVFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVVBO0FBRUosR0FDQTtBQUFBLEVBQ0VuQixPQUFPO0FBQUEsRUFDUEUsS0FBSztBQUFBLEVBQ0xPLFFBQVFBLE1BQ04sbUNBQ0UsaUNBQUMsVUFBTyxNQUFLLFFBQU8sTUFBSyxTQUFRLE1BQU0sdUJBQUMsd0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFtQixLQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQThELEtBRGhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFQTtBQUFBLEVBRUZXLFFBQVEzQixlQUFlLEVBQUU0QixJQUFJLFVBQVUsV0FBVyxJQUFJLFFBQVE7QUFDaEUsQ0FBQyxFQUNEQyxPQUFRQyxVQUFTLENBQUNBLEtBQUtILE1BQU0iLCJuYW1lcyI6WyJBcnJvd1VwT3V0bGluZWQiLCJJbmZvQ2lyY2xlT3V0bGluZWQiLCJQbHVzT3V0bGluZWQiLCJRdWVzdGlvbk91dGxpbmVkIiwiQXZhdGFyIiwiQnV0dG9uIiwiVGFnIiwiYWNjb3VudEFiaWxpdHkiLCJzdGF0dXNPcHRpb25zIiwidGV4dCIsInZhbHVlIiwic3BlY2llc09wdGlvbnMiLCJnZW5kZXJPcHRpb25zIiwiY2hhcmFjdGVyc0NvbHVtbiIsInRpdGxlIiwiZGF0YUluZGV4Iiwia2V5Iiwid2lkdGgiLCJzb3J0ZXIiLCJhIiwiYiIsIm5hbWUiLCJsb2NhbGVDb21wYXJlIiwicmVuZGVyIiwiXyIsInJlY29yZCIsImltYWdlIiwibWFyZ2luUmlnaHQiLCJmaWx0ZXJzIiwib25GaWx0ZXIiLCJzcGVjaWVzIiwiaW5kZXhPZiIsImdlbmRlciIsInN0YXR1cyIsImhpZGRlbiIsImNhbiIsImZpbHRlciIsIml0ZW0iXSwic291cmNlcyI6WyJjaGFyYWN0ZXJzLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBBcnJvd1VwT3V0bGluZWQsXG4gIEluZm9DaXJjbGVPdXRsaW5lZCxcbiAgUGx1c091dGxpbmVkLFxuICBRdWVzdGlvbk91dGxpbmVkLFxufSBmcm9tIFwiQGFudC1kZXNpZ24vaWNvbnNcIjtcbmltcG9ydCB7IEF2YXRhciwgQnV0dG9uLCBUYWcgfSBmcm9tIFwiYW50ZFwiO1xuaW1wb3J0IHsgYWNjb3VudEFiaWxpdHkgfSBmcm9tIFwiLi4vLi4vdXRpbHMvYWJpbGl0eVwiO1xuXG5jb25zdCBzdGF0dXNPcHRpb25zID0gW1xuICB7XG4gICAgdGV4dDogXCJBbGl2ZVwiLFxuICAgIHZhbHVlOiBcIkFsaXZlXCIsXG4gIH0sXG4gIHtcbiAgICB0ZXh0OiBcIkRlYWRcIixcbiAgICB2YWx1ZTogXCJEZWFkXCIsXG4gIH0sXG4gIHtcbiAgICB0ZXh0OiBcInVua25vd25cIixcbiAgICB2YWx1ZTogXCJ1bmtub3duXCIsXG4gIH0sXG5dO1xuXG5jb25zdCBzcGVjaWVzT3B0aW9ucyA9IFtcbiAge1xuICAgIHRleHQ6IFwiSHVtYW5cIixcbiAgICB2YWx1ZTogXCJIdW1hblwiLFxuICB9LFxuICB7XG4gICAgdGV4dDogXCJBbGllblwiLFxuICAgIHZhbHVlOiBcIkFsaWVuXCIsXG4gIH0sXG5dO1xuXG5jb25zdCBnZW5kZXJPcHRpb25zID0gW1xuICB7XG4gICAgdGV4dDogXCJNYWxlXCIsXG4gICAgdmFsdWU6IFwiTWFsZVwiLFxuICB9LFxuICB7XG4gICAgdGV4dDogXCJGZW1hbGVcIixcbiAgICB2YWx1ZTogXCJGZW1hbGVcIixcbiAgfSxcbiAge1xuICAgIHRleHQ6IFwidW5rbm93blwiLFxuICAgIHZhbHVlOiBcInVua25vd25cIixcbiAgfSxcbl07XG5cbmV4cG9ydCBjb25zdCBjaGFyYWN0ZXJzQ29sdW1uID0gKCkgPT5cbiAgW1xuICAgIHtcbiAgICAgIHRpdGxlOiBcIklEXCIsXG4gICAgICBkYXRhSW5kZXg6IFwiaWRcIixcbiAgICAgIGtleTogXCJpZFwiLFxuICAgICAgd2lkdGg6IFwiMTRweFwiLFxuICAgIH0sXG4gICAge1xuICAgICAgdGl0bGU6IFwiTmFtZVwiLFxuICAgICAga2V5OiBcIm5hbWVcIixcbiAgICAgIHNvcnRlcjogKGEsIGIpID0+IGEubmFtZS5sb2NhbGVDb21wYXJlKGIubmFtZSksXG4gICAgICByZW5kZXI6IChfLCByZWNvcmQpID0+IChcbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8QXZhdGFyXG4gICAgICAgICAgICBzcmM9e3JlY29yZC5pbWFnZX1cbiAgICAgICAgICAgIGFsdD17cmVjb3JkLm5hbWV9XG4gICAgICAgICAgICBzdHlsZT17eyBtYXJnaW5SaWdodDogXCI4cHhcIiB9fVxuICAgICAgICAgIC8+e1wiIFwifVxuICAgICAgICAgIHtyZWNvcmQubmFtZX1cbiAgICAgICAgPC9kaXY+XG4gICAgICApLFxuICAgIH0sXG4gICAge1xuICAgICAgdGl0bGU6IFwiU3BlY2llc1wiLFxuICAgICAgZGF0YUluZGV4OiBcInNwZWNpZXNcIixcbiAgICAgIGtleTogXCJzcGVjaWVzXCIsXG4gICAgICBmaWx0ZXJzOiBzcGVjaWVzT3B0aW9ucyxcbiAgICAgIG9uRmlsdGVyOiAodmFsdWUsIHJlY29yZCkgPT4gcmVjb3JkLnNwZWNpZXMuaW5kZXhPZih2YWx1ZSkgPT09IDAsXG4gICAgfSxcbiAgICB7XG4gICAgICB0aXRsZTogXCJHZW5kZXJcIixcbiAgICAgIGtleTogXCJnZW5kZXJcIixcbiAgICAgIGZpbHRlcnM6IGdlbmRlck9wdGlvbnMsXG4gICAgICBvbkZpbHRlcjogKHZhbHVlLCByZWNvcmQpID0+IHJlY29yZC5nZW5kZXIuaW5kZXhPZih2YWx1ZSkgPT09IDAsXG4gICAgICByZW5kZXI6IChfLCByZWNvcmQpID0+IChcbiAgICAgICAgPFRhZ1xuICAgICAgICAgIGljb249e1xuICAgICAgICAgICAgcmVjb3JkLmdlbmRlciA9PT0gXCJNYWxlXCIgPyAoXG4gICAgICAgICAgICAgIDxBcnJvd1VwT3V0bGluZWQgcm90YXRlPXs0NX0gLz5cbiAgICAgICAgICAgICkgOiByZWNvcmQuZ2VuZGVyID09PSBcIkZlbWFsZVwiID8gKFxuICAgICAgICAgICAgICA8UGx1c091dGxpbmVkIC8+XG4gICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICA8UXVlc3Rpb25PdXRsaW5lZCAvPlxuICAgICAgICAgICAgKVxuICAgICAgICAgIH1cbiAgICAgICAgICBjb2xvcj17XG4gICAgICAgICAgICByZWNvcmQuZ2VuZGVyID09PSBcIk1hbGVcIlxuICAgICAgICAgICAgICA/IFwiYmx1ZVwiXG4gICAgICAgICAgICAgIDogcmVjb3JkLmdlbmRlciA9PT0gXCJGZW1hbGVcIlxuICAgICAgICAgICAgICA/IFwicGlua1wiXG4gICAgICAgICAgICAgIDogXCJvcmFuZ2VcIlxuICAgICAgICAgIH1cbiAgICAgICAgPlxuICAgICAgICAgIHtyZWNvcmQuZ2VuZGVyfVxuICAgICAgICA8L1RhZz5cbiAgICAgICksXG4gICAgfSxcbiAgICB7XG4gICAgICB0aXRsZTogXCJTdGF0dXNcIixcbiAgICAgIGtleTogXCJzdGF0dXNcIixcbiAgICAgIGZpbHRlcnM6IHN0YXR1c09wdGlvbnMsXG4gICAgICBvbkZpbHRlcjogKHZhbHVlLCByZWNvcmQpID0+IHJlY29yZC5zdGF0dXMuaW5kZXhPZih2YWx1ZSkgPT09IDAsXG4gICAgICByZW5kZXI6IChfLCByZWNvcmQpID0+IChcbiAgICAgICAgPFRhZ1xuICAgICAgICAgIGNvbG9yPXtcbiAgICAgICAgICAgIHJlY29yZC5zdGF0dXMgPT09IFwiQWxpdmVcIlxuICAgICAgICAgICAgICA/IFwiZ3JlZW5cIlxuICAgICAgICAgICAgICA6IHJlY29yZC5zdGF0dXMgPT09IFwiRGVhZFwiXG4gICAgICAgICAgICAgID8gXCJyZWRcIlxuICAgICAgICAgICAgICA6IFwib3JhbmdlXCJcbiAgICAgICAgICB9XG4gICAgICAgID5cbiAgICAgICAgICB7cmVjb3JkLnN0YXR1c31cbiAgICAgICAgPC9UYWc+XG4gICAgICApLFxuICAgIH0sXG4gICAge1xuICAgICAgdGl0bGU6IFwiQWN0aW9uXCIsXG4gICAgICBrZXk6IFwiYWN0aW9uXCIsXG4gICAgICByZW5kZXI6ICgpID0+IChcbiAgICAgICAgPD5cbiAgICAgICAgICA8QnV0dG9uIHR5cGU9XCJ0ZXh0XCIgc2l6ZT1cImxhcmdlXCIgaWNvbj17PEluZm9DaXJjbGVPdXRsaW5lZCAvPn0gLz5cbiAgICAgICAgPC8+XG4gICAgICApLFxuICAgICAgaGlkZGVuOiBhY2NvdW50QWJpbGl0eSgpLmNhbihcInVwZGF0ZVwiLCBcImRhc2hib2FyZFwiKSA/IGZhbHNlIDogdHJ1ZSxcbiAgICB9LFxuICBdLmZpbHRlcigoaXRlbSkgPT4gIWl0ZW0uaGlkZGVuKTtcbiJdLCJmaWxlIjoiL2hvbWUvZGhhcm1hL1dvcmsvcmVhY3QtYm9pbGVycGxhdGUvc3JjL2NvbnN0YW50L2NvbHVtbnMvY2hhcmFjdGVycy5qc3gifQ==