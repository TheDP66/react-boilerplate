import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/login/components/LoginForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f9dec5ba"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/dharma/Work/react-boilerplate/src/pages/login/components/LoginForm.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Button, Divider, Form, Input } from "/node_modules/.vite/deps/antd.js?v=26d7e361";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=f9dec5ba"; const React = __vite__cjsImport4_react.__esModule ? __vite__cjsImport4_react.default : __vite__cjsImport4_react;
import { useDispatch } from "/node_modules/.vite/deps/react-redux.js?v=3db4bc54";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=f16f2ff9";
import logoDNet from "/src/assets/images/logo d~net.png?import";
import { login } from "/src/redux/actions/authAction.jsx";
const LoginForm = () => {
  _s();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const onFinish = (data) => {
    try {
      dispatch(login(data));
      navigate("/");
    } catch (err) {
      console.error(err);
    }
  };
  const onFinishFailed = (errorInfo) => {
    console.log("Failed:", errorInfo);
  };
  return /* @__PURE__ */ jsxDEV("div", { style: {
    width: "80%"
  }, children: [
    /* @__PURE__ */ jsxDEV("div", { style: {
      fontSize: "32px",
      fontWeight: "bold",
      marginBottom: "3px"
    }, children: "Welcome!" }, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/pages/login/components/LoginForm.jsx",
      lineNumber: 26,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: {
      fontSize: "14px",
      marginBottom: "36px",
      opacity: 0.7
    }, children: "Log In your account" }, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/pages/login/components/LoginForm.jsx",
      lineNumber: 33,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Form, { onFinish, onFinishFailed, autoComplete: "off", layout: "vertical", children: [
      /* @__PURE__ */ jsxDEV(Form.Item, { label: "Username", name: "username", rules: [{
        required: true,
        message: "Please input your username!"
      }], children: /* @__PURE__ */ jsxDEV(Input, {}, void 0, false, {
        fileName: "/home/dharma/Work/react-boilerplate/src/pages/login/components/LoginForm.jsx",
        lineNumber: 46,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/home/dharma/Work/react-boilerplate/src/pages/login/components/LoginForm.jsx",
        lineNumber: 42,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Form.Item, { label: "Password", name: "password", rules: [{
        required: true,
        message: "Please input your password!"
      }], style: {
        marginBottom: 8
      }, children: /* @__PURE__ */ jsxDEV(Input.Password, {}, void 0, false, {
        fileName: "/home/dharma/Work/react-boilerplate/src/pages/login/components/LoginForm.jsx",
        lineNumber: 55,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/home/dharma/Work/react-boilerplate/src/pages/login/components/LoginForm.jsx",
        lineNumber: 49,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: {
        marginBottom: 24,
        textAlign: "right",
        marginTop: 5
      }, children: /* @__PURE__ */ jsxDEV("a", { href: "/forgot_password", children: "Forgot Password?" }, void 0, false, {
        fileName: "/home/dharma/Work/react-boilerplate/src/pages/login/components/LoginForm.jsx",
        lineNumber: 63,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/home/dharma/Work/react-boilerplate/src/pages/login/components/LoginForm.jsx",
        lineNumber: 58,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Form.Item, { children: /* @__PURE__ */ jsxDEV(Button, { type: "primary", htmlType: "submit", style: {
        width: "100%"
      }, children: "Login" }, void 0, false, {
        fileName: "/home/dharma/Work/react-boilerplate/src/pages/login/components/LoginForm.jsx",
        lineNumber: 67,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/home/dharma/Work/react-boilerplate/src/pages/login/components/LoginForm.jsx",
        lineNumber: 66,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/home/dharma/Work/react-boilerplate/src/pages/login/components/LoginForm.jsx",
      lineNumber: 41,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Divider, { style: {
      opacity: 0.7
    }, children: "or" }, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/pages/login/components/LoginForm.jsx",
      lineNumber: 75,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Button, { type: "default", style: {
      width: "100%",
      alignItems: "center",
      display: "flex",
      justifyContent: "center"
    }, children: [
      /* @__PURE__ */ jsxDEV("img", { src: logoDNet, alt: "Logo d~net", height: "100%", style: {
        marginRight: "3px"
      } }, void 0, false, {
        fileName: "/home/dharma/Work/react-boilerplate/src/pages/login/components/LoginForm.jsx",
        lineNumber: 85,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { style: {
        fontSize: "11px",
        fontWeight: 600,
        opacity: 0.6,
        marginTop: "3px"
      }, children: "Continue with OAuth" }, void 0, false, {
        fileName: "/home/dharma/Work/react-boilerplate/src/pages/login/components/LoginForm.jsx",
        lineNumber: 88,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/home/dharma/Work/react-boilerplate/src/pages/login/components/LoginForm.jsx",
      lineNumber: 79,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: {
      fontSize: "12px",
      textAlign: "center",
      marginTop: 30,
      opacity: 0.7
    }, children: [
      "Don‘t have any account? ",
      /* @__PURE__ */ jsxDEV("a", { href: "/signup", children: "Sign Up" }, void 0, false, {
        fileName: "/home/dharma/Work/react-boilerplate/src/pages/login/components/LoginForm.jsx",
        lineNumber: 104,
        columnNumber: 39
      }, this)
    ] }, void 0, true, {
      fileName: "/home/dharma/Work/react-boilerplate/src/pages/login/components/LoginForm.jsx",
      lineNumber: 98,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/dharma/Work/react-boilerplate/src/pages/login/components/LoginForm.jsx",
    lineNumber: 23,
    columnNumber: 10
  }, this);
};
_s(LoginForm, "ZaVe+Vo7W9FMoQ/aTgBrV7UvA04=", false, function() {
  return [useNavigate, useDispatch];
});
_c = LoginForm;
export default LoginForm;
var _c;
$RefreshReg$(_c, "LoginForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/dharma/Work/react-boilerplate/src/pages/login/components/LoginForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkJNOzs7Ozs7Ozs7Ozs7Ozs7OztBQTNCTixTQUFTQSxRQUFRQyxTQUFTQyxNQUFNQyxhQUFhO0FBQzdDLE9BQU9DLFdBQVc7QUFDbEIsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLG1CQUFtQjtBQUM1QixPQUFPQyxjQUFjO0FBQ3JCLFNBQVNDLGFBQWE7QUFFdEIsTUFBTUMsWUFBWUEsTUFBTTtBQUFBQyxLQUFBO0FBQ3RCLFFBQU1DLFdBQVdMLFlBQVk7QUFFN0IsUUFBTU0sV0FBV1AsWUFBWTtBQUU3QixRQUFNUSxXQUFZQyxVQUFTO0FBQ3pCLFFBQUk7QUFDRkYsZUFBU0osTUFBTU0sSUFBSSxDQUFDO0FBQ3BCSCxlQUFTLEdBQUc7QUFBQSxJQUNkLFNBQVNJLEtBQUs7QUFDWkMsY0FBUUMsTUFBTUYsR0FBRztBQUFBLElBQ25CO0FBQUEsRUFDRjtBQUVBLFFBQU1HLGlCQUFrQkMsZUFBYztBQUNwQ0gsWUFBUUksSUFBSSxXQUFXRCxTQUFTO0FBQUEsRUFDbEM7QUFFQSxTQUNFLHVCQUFDLFNBQUksT0FBTztBQUFBLElBQUVFLE9BQU87QUFBQSxFQUFNLEdBQ3pCO0FBQUEsMkJBQUMsU0FDQyxPQUFPO0FBQUEsTUFBRUMsVUFBVTtBQUFBLE1BQVFDLFlBQVk7QUFBQSxNQUFRQyxjQUFjO0FBQUEsSUFBTSxHQUFFLHdCQUR2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUE7QUFBQSxJQUNBLHVCQUFDLFNBQUksT0FBTztBQUFBLE1BQUVGLFVBQVU7QUFBQSxNQUFRRSxjQUFjO0FBQUEsTUFBUUMsU0FBUztBQUFBLElBQUksR0FBRSxtQ0FBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFFQSx1QkFBQyxRQUNDLFVBQ0EsZ0JBQ0EsY0FBYSxPQUNiLFFBQU8sWUFFUDtBQUFBLDZCQUFDLEtBQUssTUFBTCxFQUNDLE9BQU0sWUFDTixNQUFLLFlBQ0wsT0FBTyxDQUNMO0FBQUEsUUFDRUMsVUFBVTtBQUFBLFFBQ1ZDLFNBQVM7QUFBQSxNQUNYLENBQUMsR0FHSCxpQ0FBQyxXQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBTSxLQVZSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFXQTtBQUFBLE1BRUEsdUJBQUMsS0FBSyxNQUFMLEVBQ0MsT0FBTSxZQUNOLE1BQUssWUFDTCxPQUFPLENBQ0w7QUFBQSxRQUNFRCxVQUFVO0FBQUEsUUFDVkMsU0FBUztBQUFBLE1BQ1gsQ0FBQyxHQUVILE9BQU87QUFBQSxRQUFFSCxjQUFjO0FBQUEsTUFBRSxHQUV6QixpQ0FBQyxNQUFNLFVBQU4sSUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWUsS0FYakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVlBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLE9BQU87QUFBQSxRQUFFQSxjQUFjO0FBQUEsUUFBSUksV0FBVztBQUFBLFFBQVNDLFdBQVc7QUFBQSxNQUFFLEdBQy9ELGlDQUFDLE9BQUUsTUFBSyxvQkFBbUIsZ0NBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkMsS0FEN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFFQSx1QkFBQyxLQUFLLE1BQUwsRUFDQyxpQ0FBQyxVQUFPLE1BQUssV0FBVSxVQUFTLFVBQVMsT0FBTztBQUFBLFFBQUVSLE9BQU87QUFBQSxNQUFPLEdBQUUscUJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJQTtBQUFBLFNBekNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EwQ0E7QUFBQSxJQUVBLHVCQUFDLFdBQVEsT0FBTztBQUFBLE1BQUVJLFNBQVM7QUFBQSxJQUFJLEdBQUcsa0JBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0M7QUFBQSxJQUVwQyx1QkFBQyxVQUNDLE1BQUssV0FDTCxPQUFPO0FBQUEsTUFDTEosT0FBTztBQUFBLE1BQ1BTLFlBQVk7QUFBQSxNQUNaQyxTQUFTO0FBQUEsTUFDVEMsZ0JBQWdCO0FBQUEsSUFDbEIsR0FFQTtBQUFBLDZCQUFDLFNBQ0MsS0FBS3pCLFVBQ0wsS0FBSSxjQUNKLFFBQU8sUUFDUCxPQUFPO0FBQUEsUUFBRTBCLGFBQWE7QUFBQSxNQUFNLEtBSjlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJZ0M7QUFBQSxNQUVoQyx1QkFBQyxVQUNDLE9BQU87QUFBQSxRQUNMWCxVQUFVO0FBQUEsUUFDVkMsWUFBWTtBQUFBLFFBQ1pFLFNBQVM7QUFBQSxRQUNUSSxXQUFXO0FBQUEsTUFDYixHQUFFLG1DQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLFNBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5QkE7QUFBQSxJQUVBLHVCQUFDLFNBQ0MsT0FBTztBQUFBLE1BQ0xQLFVBQVU7QUFBQSxNQUNWTSxXQUFXO0FBQUEsTUFDWEMsV0FBVztBQUFBLE1BQ1hKLFNBQVM7QUFBQSxJQUNYLEdBQUU7QUFBQTtBQUFBLE1BRTRCLHVCQUFDLE9BQUUsTUFBSyxXQUFVLHVCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlCO0FBQUEsU0FSekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBO0FBQUEsT0E1RkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTZGQTtBQUVKO0FBQUVmLEdBbEhJRCxXQUFTO0FBQUEsVUFDSUgsYUFFQUQsV0FBVztBQUFBO0FBQUE2QixLQUh4QnpCO0FBb0hOLGVBQWVBO0FBQVUsSUFBQXlCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJCdXR0b24iLCJEaXZpZGVyIiwiRm9ybSIsIklucHV0IiwiUmVhY3QiLCJ1c2VEaXNwYXRjaCIsInVzZU5hdmlnYXRlIiwibG9nb0ROZXQiLCJsb2dpbiIsIkxvZ2luRm9ybSIsIl9zIiwibmF2aWdhdGUiLCJkaXNwYXRjaCIsIm9uRmluaXNoIiwiZGF0YSIsImVyciIsImNvbnNvbGUiLCJlcnJvciIsIm9uRmluaXNoRmFpbGVkIiwiZXJyb3JJbmZvIiwibG9nIiwid2lkdGgiLCJmb250U2l6ZSIsImZvbnRXZWlnaHQiLCJtYXJnaW5Cb3R0b20iLCJvcGFjaXR5IiwicmVxdWlyZWQiLCJtZXNzYWdlIiwidGV4dEFsaWduIiwibWFyZ2luVG9wIiwiYWxpZ25JdGVtcyIsImRpc3BsYXkiLCJqdXN0aWZ5Q29udGVudCIsIm1hcmdpblJpZ2h0IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJMb2dpbkZvcm0uanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEJ1dHRvbiwgRGl2aWRlciwgRm9ybSwgSW5wdXQgfSBmcm9tIFwiYW50ZFwiO1xuaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgdXNlRGlzcGF0Y2ggfSBmcm9tIFwicmVhY3QtcmVkdXhcIjtcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcbmltcG9ydCBsb2dvRE5ldCBmcm9tIFwiLi4vLi4vLi4vYXNzZXRzL2ltYWdlcy9sb2dvIGR+bmV0LnBuZ1wiO1xuaW1wb3J0IHsgbG9naW4gfSBmcm9tIFwiLi4vLi4vLi4vcmVkdXgvYWN0aW9ucy9hdXRoQWN0aW9uXCI7XG5cbmNvbnN0IExvZ2luRm9ybSA9ICgpID0+IHtcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuXG4gIGNvbnN0IGRpc3BhdGNoID0gdXNlRGlzcGF0Y2goKTtcblxuICBjb25zdCBvbkZpbmlzaCA9IChkYXRhKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGRpc3BhdGNoKGxvZ2luKGRhdGEpKTtcbiAgICAgIG5hdmlnYXRlKFwiL1wiKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKVxuICAgIH1cbiAgfTtcblxuICBjb25zdCBvbkZpbmlzaEZhaWxlZCA9IChlcnJvckluZm8pID0+IHtcbiAgICBjb25zb2xlLmxvZyhcIkZhaWxlZDpcIiwgZXJyb3JJbmZvKTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgc3R5bGU9e3sgd2lkdGg6IFwiODAlXCIgfX0+XG4gICAgICA8ZGl2XG4gICAgICAgIHN0eWxlPXt7IGZvbnRTaXplOiBcIjMycHhcIiwgZm9udFdlaWdodDogXCJib2xkXCIsIG1hcmdpbkJvdHRvbTogXCIzcHhcIiB9fVxuICAgICAgPlxuICAgICAgICBXZWxjb21lIVxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRTaXplOiBcIjE0cHhcIiwgbWFyZ2luQm90dG9tOiBcIjM2cHhcIiwgb3BhY2l0eTogMC43IH19PlxuICAgICAgICBMb2cgSW4geW91ciBhY2NvdW50XG4gICAgICA8L2Rpdj5cblxuICAgICAgPEZvcm1cbiAgICAgICAgb25GaW5pc2g9e29uRmluaXNofVxuICAgICAgICBvbkZpbmlzaEZhaWxlZD17b25GaW5pc2hGYWlsZWR9XG4gICAgICAgIGF1dG9Db21wbGV0ZT1cIm9mZlwiXG4gICAgICAgIGxheW91dD1cInZlcnRpY2FsXCJcbiAgICAgID5cbiAgICAgICAgPEZvcm0uSXRlbVxuICAgICAgICAgIGxhYmVsPVwiVXNlcm5hbWVcIlxuICAgICAgICAgIG5hbWU9XCJ1c2VybmFtZVwiXG4gICAgICAgICAgcnVsZXM9e1tcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgcmVxdWlyZWQ6IHRydWUsXG4gICAgICAgICAgICAgIG1lc3NhZ2U6IFwiUGxlYXNlIGlucHV0IHlvdXIgdXNlcm5hbWUhXCIsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF19XG4gICAgICAgID5cbiAgICAgICAgICA8SW5wdXQgLz5cbiAgICAgICAgPC9Gb3JtLkl0ZW0+XG5cbiAgICAgICAgPEZvcm0uSXRlbVxuICAgICAgICAgIGxhYmVsPVwiUGFzc3dvcmRcIlxuICAgICAgICAgIG5hbWU9XCJwYXNzd29yZFwiXG4gICAgICAgICAgcnVsZXM9e1tcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgcmVxdWlyZWQ6IHRydWUsXG4gICAgICAgICAgICAgIG1lc3NhZ2U6IFwiUGxlYXNlIGlucHV0IHlvdXIgcGFzc3dvcmQhXCIsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF19XG4gICAgICAgICAgc3R5bGU9e3sgbWFyZ2luQm90dG9tOiA4IH19XG4gICAgICAgID5cbiAgICAgICAgICA8SW5wdXQuUGFzc3dvcmQgLz5cbiAgICAgICAgPC9Gb3JtLkl0ZW0+XG5cbiAgICAgICAgPGRpdiBzdHlsZT17eyBtYXJnaW5Cb3R0b206IDI0LCB0ZXh0QWxpZ246IFwicmlnaHRcIiwgbWFyZ2luVG9wOiA1IH19PlxuICAgICAgICAgIDxhIGhyZWY9XCIvZm9yZ290X3Bhc3N3b3JkXCI+Rm9yZ290IFBhc3N3b3JkPzwvYT5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPEZvcm0uSXRlbT5cbiAgICAgICAgICA8QnV0dG9uIHR5cGU9XCJwcmltYXJ5XCIgaHRtbFR5cGU9XCJzdWJtaXRcIiBzdHlsZT17eyB3aWR0aDogXCIxMDAlXCIgfX0+XG4gICAgICAgICAgICBMb2dpblxuICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICA8L0Zvcm0uSXRlbT5cbiAgICAgIDwvRm9ybT5cblxuICAgICAgPERpdmlkZXIgc3R5bGU9e3sgb3BhY2l0eTogMC43IH19Pm9yPC9EaXZpZGVyPlxuXG4gICAgICA8QnV0dG9uXG4gICAgICAgIHR5cGU9XCJkZWZhdWx0XCJcbiAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICB3aWR0aDogXCIxMDAlXCIsXG4gICAgICAgICAgYWxpZ25JdGVtczogXCJjZW50ZXJcIixcbiAgICAgICAgICBkaXNwbGF5OiBcImZsZXhcIixcbiAgICAgICAgICBqdXN0aWZ5Q29udGVudDogXCJjZW50ZXJcIixcbiAgICAgICAgfX1cbiAgICAgID5cbiAgICAgICAgPGltZ1xuICAgICAgICAgIHNyYz17bG9nb0ROZXR9XG4gICAgICAgICAgYWx0PVwiTG9nbyBkfm5ldFwiXG4gICAgICAgICAgaGVpZ2h0PVwiMTAwJVwiXG4gICAgICAgICAgc3R5bGU9e3sgbWFyZ2luUmlnaHQ6IFwiM3B4XCIgfX1cbiAgICAgICAgLz5cbiAgICAgICAgPHNwYW5cbiAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgZm9udFNpemU6IFwiMTFweFwiLFxuICAgICAgICAgICAgZm9udFdlaWdodDogNjAwLFxuICAgICAgICAgICAgb3BhY2l0eTogMC42LFxuICAgICAgICAgICAgbWFyZ2luVG9wOiBcIjNweFwiLFxuICAgICAgICAgIH19XG4gICAgICAgID5cbiAgICAgICAgICBDb250aW51ZSB3aXRoIE9BdXRoXG4gICAgICAgIDwvc3Bhbj5cbiAgICAgIDwvQnV0dG9uPlxuXG4gICAgICA8ZGl2XG4gICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgZm9udFNpemU6IFwiMTJweFwiLFxuICAgICAgICAgIHRleHRBbGlnbjogXCJjZW50ZXJcIixcbiAgICAgICAgICBtYXJnaW5Ub3A6IDMwLFxuICAgICAgICAgIG9wYWNpdHk6IDAuNyxcbiAgICAgICAgfX1cbiAgICAgID5cbiAgICAgICAgRG9uJmxzcXVvO3QgaGF2ZSBhbnkgYWNjb3VudD8gPGEgaHJlZj1cIi9zaWdudXBcIj5TaWduIFVwPC9hPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBMb2dpbkZvcm07XG4iXSwiZmlsZSI6Ii9ob21lL2RoYXJtYS9Xb3JrL3JlYWN0LWJvaWxlcnBsYXRlL3NyYy9wYWdlcy9sb2dpbi9jb21wb25lbnRzL0xvZ2luRm9ybS5qc3gifQ==