import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/redux/store.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f9dec5ba"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/dharma/Work/react-boilerplate/src/redux/store.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { applyMiddleware, configureStore } from "/node_modules/.vite/deps/@reduxjs_toolkit.js?v=0307406a";
import { Provider } from "/node_modules/.vite/deps/react-redux.js?v=3db4bc54";
import __vite__cjsImport5_reduxDevtoolsExtension from "/node_modules/.vite/deps/redux-devtools-extension.js?v=bc45b08a"; const composeWithDevTools = __vite__cjsImport5_reduxDevtoolsExtension["composeWithDevTools"];
import thunk from "/node_modules/.vite/deps/redux-thunk.js?v=dfe478a3";
import rootReducer from "/src/redux/reducers/index.jsx";
export const store = configureStore({
  reducer: rootReducer,
  devTools: composeWithDevTools(applyMiddleware(thunk)),
  middleware: (getDefaultMiddleware) => getDefaultMiddleware({
    serializableCheck: false
  })
});
const ReduxProvider = ({
  children
}) => {
  return /* @__PURE__ */ jsxDEV(Provider, { store, children }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/redux/store.jsx",
    lineNumber: 16,
    columnNumber: 10
  }, this);
};
_c = ReduxProvider;
export default ReduxProvider;
var _c;
$RefreshReg$(_c, "ReduxProvider");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/dharma/Work/react-boilerplate/src/redux/store.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JTO0FBaEJULDJCQUEwQkE7QUFBYyxNQUFRLHFCQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDbEUsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLDJCQUEyQjtBQUNwQyxPQUFPQyxXQUFXO0FBQ2xCLE9BQU9DLGlCQUFpQjtBQUVqQixhQUFNQyxRQUFRTCxlQUFlO0FBQUEsRUFDbENNLFNBQVNGO0FBQUFBLEVBQ1RHLFVBQVVMLG9CQUFvQk0sZ0JBQWdCTCxLQUFLLENBQUM7QUFBQSxFQUNwRE0sWUFBYUMsMEJBQ1hBLHFCQUFxQjtBQUFBLElBQ25CQyxtQkFBbUI7QUFBQSxFQUNyQixDQUFDO0FBQ0wsQ0FBQztBQUVELE1BQU1DLGdCQUFnQkEsQ0FBQztBQUFBLEVBQUVDO0FBQVMsTUFBTTtBQUN0QyxTQUFPLHVCQUFDLFlBQVMsT0FBZUEsWUFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFrQztBQUMzQztBQUFFQyxLQUZJRjtBQUlOLGVBQWVBO0FBQWMsSUFBQUU7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbImNvbmZpZ3VyZVN0b3JlIiwiUHJvdmlkZXIiLCJjb21wb3NlV2l0aERldlRvb2xzIiwidGh1bmsiLCJyb290UmVkdWNlciIsInN0b3JlIiwicmVkdWNlciIsImRldlRvb2xzIiwiYXBwbHlNaWRkbGV3YXJlIiwibWlkZGxld2FyZSIsImdldERlZmF1bHRNaWRkbGV3YXJlIiwic2VyaWFsaXphYmxlQ2hlY2siLCJSZWR1eFByb3ZpZGVyIiwiY2hpbGRyZW4iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbInN0b3JlLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBhcHBseU1pZGRsZXdhcmUsIGNvbmZpZ3VyZVN0b3JlIH0gZnJvbSBcIkByZWR1eGpzL3Rvb2xraXRcIjtcbmltcG9ydCB7IFByb3ZpZGVyIH0gZnJvbSBcInJlYWN0LXJlZHV4XCI7XG5pbXBvcnQgeyBjb21wb3NlV2l0aERldlRvb2xzIH0gZnJvbSBcInJlZHV4LWRldnRvb2xzLWV4dGVuc2lvblwiO1xuaW1wb3J0IHRodW5rIGZyb20gXCJyZWR1eC10aHVua1wiO1xuaW1wb3J0IHJvb3RSZWR1Y2VyIGZyb20gXCIuL3JlZHVjZXJzL2luZGV4XCI7XG5cbmV4cG9ydCBjb25zdCBzdG9yZSA9IGNvbmZpZ3VyZVN0b3JlKHtcbiAgcmVkdWNlcjogcm9vdFJlZHVjZXIsXG4gIGRldlRvb2xzOiBjb21wb3NlV2l0aERldlRvb2xzKGFwcGx5TWlkZGxld2FyZSh0aHVuaykpLFxuICBtaWRkbGV3YXJlOiAoZ2V0RGVmYXVsdE1pZGRsZXdhcmUpID0+XG4gICAgZ2V0RGVmYXVsdE1pZGRsZXdhcmUoe1xuICAgICAgc2VyaWFsaXphYmxlQ2hlY2s6IGZhbHNlLFxuICAgIH0pLFxufSk7XG5cbmNvbnN0IFJlZHV4UHJvdmlkZXIgPSAoeyBjaGlsZHJlbiB9KSA9PiB7XG4gIHJldHVybiA8UHJvdmlkZXIgc3RvcmU9e3N0b3JlfT57Y2hpbGRyZW59PC9Qcm92aWRlcj47XG59O1xuXG5leHBvcnQgZGVmYXVsdCBSZWR1eFByb3ZpZGVyO1xuIl0sImZpbGUiOiIvaG9tZS9kaGFybWEvV29yay9yZWFjdC1ib2lsZXJwbGF0ZS9zcmMvcmVkdXgvc3RvcmUuanN4In0=