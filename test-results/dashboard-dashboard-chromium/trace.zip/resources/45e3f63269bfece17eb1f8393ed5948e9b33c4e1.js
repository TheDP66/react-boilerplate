import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/layouts/StickyHeader.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f9dec5ba"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/dharma/Work/react-boilerplate/src/layouts/StickyHeader.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { DownOutlined } from "/node_modules/.vite/deps/@ant-design_icons.js?v=7a8c6384";
import { Collapse, Grid, Space, theme } from "/node_modules/.vite/deps/antd.js?v=26d7e361";
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=f9dec5ba"; const React = __vite__cjsImport5_react.__esModule ? __vite__cjsImport5_react.default : __vite__cjsImport5_react; const useEffect = __vite__cjsImport5_react["useEffect"]; const useState = __vite__cjsImport5_react["useState"];
const {
  useBreakpoint
} = Grid;
const {
  useToken
} = theme;
const StickyHeader = ({
  title,
  children
}) => {
  _s();
  const screens = useBreakpoint();
  const {
    token
  } = useToken();
  const [activeKey, setActiveKey] = useState("");
  const handleCollapse = () => {
    if (activeKey === "") {
      setActiveKey(title);
    } else {
      setActiveKey("");
    }
  };
  useEffect(() => {
    if (screens.md)
      setActiveKey("");
  }, [screens]);
  return /* @__PURE__ */ jsxDEV(Collapse, { style: {
    position: "sticky",
    top: "0px",
    zIndex: 3,
    backgroundColor: token.colorBgContainer + "80",
    color: token.colorText,
    display: "flex",
    fontSize: "19px",
    width: "100%",
    borderRadius: "0px",
    fontWeight: "500",
    letterSpacing: "0.228px",
    backdropFilter: "blur(20px) saturate(180%)",
    WebkitBackdropFilter: "blur(20px) saturate(180%)"
  }, expandIcon: ({
    isActive
  }) => /* @__PURE__ */ jsxDEV(DownOutlined, { rotate: isActive ? -180 : 0 }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/layouts/StickyHeader.jsx",
    lineNumber: 47,
    columnNumber: 9
  }, this), activeKey, expandIconPosition: "end", collapsible: "header", bordered: false, onChange: handleCollapse, items: [{
    key: title,
    id: "sticky-header-title",
    label: title,
    children: screens.md ? /* @__PURE__ */ jsxDEV(Fragment, {}, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/layouts/StickyHeader.jsx",
      lineNumber: 51,
      columnNumber: 28
    }, this) : children !== void 0 ? /* @__PURE__ */ jsxDEV(Space, { size: "middle", style: {
      width: "100%",
      justifyContent: "end"
    }, children }, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/layouts/StickyHeader.jsx",
      lineNumber: 51,
      columnNumber: 61
    }, this) : /* @__PURE__ */ jsxDEV(Fragment, {}, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/layouts/StickyHeader.jsx",
      lineNumber: 56,
      columnNumber: 24
    }, this),
    style: {
      flex: 1
    },
    showArrow: screens.md ? false : children !== void 0 ? true : false,
    extra: screens.md ? /* @__PURE__ */ jsxDEV(Space, { size: "middle", style: {
      marginLeft: "32px"
    }, wrap: true, children }, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/layouts/StickyHeader.jsx",
      lineNumber: 61,
      columnNumber: 25
    }, this) : /* @__PURE__ */ jsxDEV(Fragment, {}, void 0, false, {
      fileName: "/home/dharma/Work/react-boilerplate/src/layouts/StickyHeader.jsx",
      lineNumber: 65,
      columnNumber: 24
    }, this)
  }] }, void 0, false, {
    fileName: "/home/dharma/Work/react-boilerplate/src/layouts/StickyHeader.jsx",
    lineNumber: 31,
    columnNumber: 10
  }, this);
};
_s(StickyHeader, "SaPTrUGHEfsE88rQs8GY8oHtDnc=", false, function() {
  return [useBreakpoint, useToken];
});
_c = StickyHeader;
export default StickyHeader;
var _c;
$RefreshReg$(_c, "StickyHeader");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/dharma/Work/react-boilerplate/src/layouts/StickyHeader.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkNRLFNBYUksVUFiSjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUEzQ1IsU0FBU0Esb0JBQW9CO0FBQzdCLFNBQVNDLFVBQVVDLE1BQU1DLE9BQU9DLGFBQWE7QUFDN0MsT0FBT0MsU0FBU0MsV0FBV0MsZ0JBQWdCO0FBRTNDLE1BQU07QUFBQSxFQUFFQztBQUFjLElBQUlOO0FBQzFCLE1BQU07QUFBQSxFQUFFTztBQUFTLElBQUlMO0FBRXJCLE1BQU1NLGVBQWVBLENBQUM7QUFBQSxFQUFFQztBQUFBQSxFQUFPQztBQUFTLE1BQU07QUFBQUMsS0FBQTtBQUM1QyxRQUFNQyxVQUFVTixjQUFjO0FBQzlCLFFBQU07QUFBQSxJQUFFTztBQUFBQSxFQUFNLElBQUlOLFNBQVM7QUFFM0IsUUFBTSxDQUFDTyxXQUFXQyxZQUFZLElBQUlWLFNBQVMsRUFBRTtBQUU3QyxRQUFNVyxpQkFBaUJBLE1BQU07QUFDM0IsUUFBSUYsY0FBYyxJQUFJO0FBQ3BCQyxtQkFBYU4sS0FBSztBQUFBLElBQ3BCLE9BQU87QUFDTE0sbUJBQWEsRUFBRTtBQUFBLElBQ2pCO0FBQUEsRUFDRjtBQUVBWCxZQUFVLE1BQU07QUFDZCxRQUFJUSxRQUFRSztBQUFJRixtQkFBYSxFQUFFO0FBQUEsRUFDakMsR0FBRyxDQUFDSCxPQUFPLENBQUM7QUFFWixTQUNFLHVCQUFDLFlBQ0MsT0FBTztBQUFBLElBQ0xNLFVBQVU7QUFBQSxJQUNWQyxLQUFLO0FBQUEsSUFDTEMsUUFBUTtBQUFBLElBQ1JDLGlCQUFpQlIsTUFBTVMsbUJBQW1CO0FBQUEsSUFDMUNDLE9BQU9WLE1BQU1XO0FBQUFBLElBQ2JDLFNBQVM7QUFBQSxJQUNUQyxVQUFVO0FBQUEsSUFDVkMsT0FBTztBQUFBLElBQ1BDLGNBQWM7QUFBQSxJQUNkQyxZQUFZO0FBQUEsSUFDWkMsZUFBZTtBQUFBLElBQ2ZDLGdCQUFnQjtBQUFBLElBQ2hCQyxzQkFBc0I7QUFBQSxFQUN4QixHQUNBLFlBQVksQ0FBQztBQUFBLElBQUVDO0FBQUFBLEVBQVMsTUFDdEIsdUJBQUMsZ0JBQWEsUUFBUUEsV0FBVyxPQUFPLEtBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBMEMsR0FFNUMsV0FDQSxvQkFBbUIsT0FDbkIsYUFBWSxVQUNaLFVBQVUsT0FDVixVQUFVakIsZ0JBQ1YsT0FBTyxDQUNMO0FBQUEsSUFDRWtCLEtBQUt6QjtBQUFBQSxJQUNMMEIsSUFBRztBQUFBLElBQ0hDLE9BQU8zQjtBQUFBQSxJQUNQQyxVQUFVRSxRQUFRSyxLQUNoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQUUsSUFDQVAsYUFBYTJCLFNBQ2YsdUJBQUMsU0FDQyxNQUFNLFVBQ04sT0FBTztBQUFBLE1BQUVWLE9BQU87QUFBQSxNQUFRVyxnQkFBZ0I7QUFBQSxJQUFNLEdBRTdDNUIsWUFKSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0EsSUFFQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQUU7QUFBQSxJQUVKNkIsT0FBTztBQUFBLE1BQUVDLE1BQU07QUFBQSxJQUFFO0FBQUEsSUFDakJDLFdBQVc3QixRQUFRSyxLQUFLLFFBQVFQLGFBQWEyQixTQUFZLE9BQU87QUFBQSxJQUNoRUssT0FBTzlCLFFBQVFLLEtBQ2IsdUJBQUMsU0FBTSxNQUFNLFVBQVUsT0FBTztBQUFBLE1BQUUwQixZQUFZO0FBQUEsSUFBTyxHQUFHLE1BQUksTUFDdkRqQyxZQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxJQUVBO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBRTtBQUFBLEVBRU4sQ0FBQyxLQWxETDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBbURJO0FBR1I7QUFBRUMsR0F6RUlILGNBQVk7QUFBQSxVQUNBRixlQUNFQyxRQUFRO0FBQUE7QUFBQXFDLEtBRnRCcEM7QUEyRU4sZUFBZUE7QUFBYSxJQUFBb0M7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkRvd25PdXRsaW5lZCIsIkNvbGxhcHNlIiwiR3JpZCIsIlNwYWNlIiwidGhlbWUiLCJSZWFjdCIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwidXNlQnJlYWtwb2ludCIsInVzZVRva2VuIiwiU3RpY2t5SGVhZGVyIiwidGl0bGUiLCJjaGlsZHJlbiIsIl9zIiwic2NyZWVucyIsInRva2VuIiwiYWN0aXZlS2V5Iiwic2V0QWN0aXZlS2V5IiwiaGFuZGxlQ29sbGFwc2UiLCJtZCIsInBvc2l0aW9uIiwidG9wIiwiekluZGV4IiwiYmFja2dyb3VuZENvbG9yIiwiY29sb3JCZ0NvbnRhaW5lciIsImNvbG9yIiwiY29sb3JUZXh0IiwiZGlzcGxheSIsImZvbnRTaXplIiwid2lkdGgiLCJib3JkZXJSYWRpdXMiLCJmb250V2VpZ2h0IiwibGV0dGVyU3BhY2luZyIsImJhY2tkcm9wRmlsdGVyIiwiV2Via2l0QmFja2Ryb3BGaWx0ZXIiLCJpc0FjdGl2ZSIsImtleSIsImlkIiwibGFiZWwiLCJ1bmRlZmluZWQiLCJqdXN0aWZ5Q29udGVudCIsInN0eWxlIiwiZmxleCIsInNob3dBcnJvdyIsImV4dHJhIiwibWFyZ2luTGVmdCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiU3RpY2t5SGVhZGVyLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBEb3duT3V0bGluZWQgfSBmcm9tIFwiQGFudC1kZXNpZ24vaWNvbnNcIjtcbmltcG9ydCB7IENvbGxhcHNlLCBHcmlkLCBTcGFjZSwgdGhlbWUgfSBmcm9tIFwiYW50ZFwiO1xuaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcblxuY29uc3QgeyB1c2VCcmVha3BvaW50IH0gPSBHcmlkO1xuY29uc3QgeyB1c2VUb2tlbiB9ID0gdGhlbWU7XG5cbmNvbnN0IFN0aWNreUhlYWRlciA9ICh7IHRpdGxlLCBjaGlsZHJlbiB9KSA9PiB7XG4gIGNvbnN0IHNjcmVlbnMgPSB1c2VCcmVha3BvaW50KCk7XG4gIGNvbnN0IHsgdG9rZW4gfSA9IHVzZVRva2VuKCk7XG5cbiAgY29uc3QgW2FjdGl2ZUtleSwgc2V0QWN0aXZlS2V5XSA9IHVzZVN0YXRlKFwiXCIpO1xuXG4gIGNvbnN0IGhhbmRsZUNvbGxhcHNlID0gKCkgPT4ge1xuICAgIGlmIChhY3RpdmVLZXkgPT09IFwiXCIpIHtcbiAgICAgIHNldEFjdGl2ZUtleSh0aXRsZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHNldEFjdGl2ZUtleShcIlwiKTtcbiAgICB9XG4gIH07XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoc2NyZWVucy5tZCkgc2V0QWN0aXZlS2V5KFwiXCIpO1xuICB9LCBbc2NyZWVuc10pO1xuXG4gIHJldHVybiAoXG4gICAgPENvbGxhcHNlXG4gICAgICBzdHlsZT17e1xuICAgICAgICBwb3NpdGlvbjogXCJzdGlja3lcIixcbiAgICAgICAgdG9wOiBcIjBweFwiLFxuICAgICAgICB6SW5kZXg6IDMsXG4gICAgICAgIGJhY2tncm91bmRDb2xvcjogdG9rZW4uY29sb3JCZ0NvbnRhaW5lciArIFwiODBcIixcbiAgICAgICAgY29sb3I6IHRva2VuLmNvbG9yVGV4dCxcbiAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXG4gICAgICAgIGZvbnRTaXplOiBcIjE5cHhcIixcbiAgICAgICAgd2lkdGg6IFwiMTAwJVwiLFxuICAgICAgICBib3JkZXJSYWRpdXM6IFwiMHB4XCIsXG4gICAgICAgIGZvbnRXZWlnaHQ6IFwiNTAwXCIsXG4gICAgICAgIGxldHRlclNwYWNpbmc6IFwiMC4yMjhweFwiLFxuICAgICAgICBiYWNrZHJvcEZpbHRlcjogXCJibHVyKDIwcHgpIHNhdHVyYXRlKDE4MCUpXCIsXG4gICAgICAgIFdlYmtpdEJhY2tkcm9wRmlsdGVyOiBcImJsdXIoMjBweCkgc2F0dXJhdGUoMTgwJSlcIixcbiAgICAgIH19XG4gICAgICBleHBhbmRJY29uPXsoeyBpc0FjdGl2ZSB9KSA9PiAoXG4gICAgICAgIDxEb3duT3V0bGluZWQgcm90YXRlPXtpc0FjdGl2ZSA/IC0xODAgOiAwfSAvPlxuICAgICAgKX1cbiAgICAgIGFjdGl2ZUtleT17YWN0aXZlS2V5fVxuICAgICAgZXhwYW5kSWNvblBvc2l0aW9uPVwiZW5kXCJcbiAgICAgIGNvbGxhcHNpYmxlPVwiaGVhZGVyXCJcbiAgICAgIGJvcmRlcmVkPXtmYWxzZX1cbiAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDb2xsYXBzZX1cbiAgICAgIGl0ZW1zPXtbXG4gICAgICAgIHtcbiAgICAgICAgICBrZXk6IHRpdGxlLFxuICAgICAgICAgIGlkOlwic3RpY2t5LWhlYWRlci10aXRsZVwiLFxuICAgICAgICAgIGxhYmVsOiB0aXRsZSxcbiAgICAgICAgICBjaGlsZHJlbjogc2NyZWVucy5tZCA/IChcbiAgICAgICAgICAgIDw+PC8+XG4gICAgICAgICAgKSA6IGNoaWxkcmVuICE9PSB1bmRlZmluZWQgPyAoXG4gICAgICAgICAgICA8U3BhY2VcbiAgICAgICAgICAgICAgc2l6ZT17XCJtaWRkbGVcIn1cbiAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IFwiMTAwJVwiLCBqdXN0aWZ5Q29udGVudDogXCJlbmRcIiB9fVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7Y2hpbGRyZW59XG4gICAgICAgICAgICA8L1NwYWNlPlxuICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICA8PjwvPlxuICAgICAgICAgICksXG4gICAgICAgICAgc3R5bGU6IHsgZmxleDogMSB9LFxuICAgICAgICAgIHNob3dBcnJvdzogc2NyZWVucy5tZCA/IGZhbHNlIDogY2hpbGRyZW4gIT09IHVuZGVmaW5lZCA/IHRydWUgOiBmYWxzZSxcbiAgICAgICAgICBleHRyYTogc2NyZWVucy5tZCA/IChcbiAgICAgICAgICAgIDxTcGFjZSBzaXplPXtcIm1pZGRsZVwifSBzdHlsZT17eyBtYXJnaW5MZWZ0OiBcIjMycHhcIiB9fSB3cmFwPlxuICAgICAgICAgICAgICB7Y2hpbGRyZW59XG4gICAgICAgICAgICA8L1NwYWNlPlxuICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICA8PjwvPlxuICAgICAgICAgICksXG4gICAgICAgIH0sXG4gICAgICBdfVxuICAgIC8+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBTdGlja3lIZWFkZXI7XG4iXSwiZmlsZSI6Ii9ob21lL2RoYXJtYS9Xb3JrL3JlYWN0LWJvaWxlcnBsYXRlL3NyYy9sYXlvdXRzL1N0aWNreUhlYWRlci5qc3gifQ==